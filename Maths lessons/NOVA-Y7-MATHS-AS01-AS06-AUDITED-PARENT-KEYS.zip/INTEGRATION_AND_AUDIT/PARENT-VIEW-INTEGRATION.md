# NOVA maths parent answer-key integration

1. Store `PARENT_SECURE_ONLY/*-PARENT-MARKING-KEY.json` in private website/server storage (e.g. non-public storage bucket or backend filesystem), **not in the client public directory**.
2. Have the authenticated parent dashboard request assessment key via a protected server endpoint after verifying (a) signed-in role parent/approved teacher, (b) relationship to pupil, (c) requested assessment is legitimate and related to that pupil. Reject other users.
3. Fetch assessment result and rubric server-side; compare `questions[].id` with stored answers/working; present question, pupil answer, model answer and `markPoints` only in parent view.
4. For written responses, allow parent reviewer to assign 0..question.marks based on clear marking criteria, record marker identity and feedback, then recalculate final mark. Do not assign grade until written review is complete.
5. Do **not** import or serve parent HTML, parent JSON or answer keys from a route available to pupils or unauthenticated viewers. No frontend-only PIN or hidden CSS.
6. To prevent users inspecting auto-answer keys, migrate `correctAnswer` out of public HTML to server grading, returning only approved result data after hand-in. Until then, auto keys remain discoverable from the pupil HTML source, even though there is no on-screen marking-guide panel.
7. Regression checks required after integration: unauthorised GET 403/404; correct parent's own child permitted; unrelated parent's child denied; pupil denied; no parent JSON in page source/network for pupil; written review updates only authorised results.

No website endpoint was changed in this artifact pack.
