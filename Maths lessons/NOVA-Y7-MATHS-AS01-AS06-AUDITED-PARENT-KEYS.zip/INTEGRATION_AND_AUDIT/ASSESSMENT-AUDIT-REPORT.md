# NOVA Year 7 Maths — assessment mathematical and marking audit

Assessment files received: 6. All 128 questions were inspected, including all 92 auto-marked answers and 36 written-answer prompts.

| Assessment | Questions | Total marks | Auto answers verified | Written prompts / rubric |
|---|---:|---:|---:|---:|
| Y7-AS01 | 18 | 24 | 14 | 4 |
| Y7-AS02 | 18 | 27 | 13 | 5 |
| Y7-AS03 | 18 | 29 | 12 | 6 |
| Y7-AS04 | 20 | 29 | 16 | 4 |
| Y7-AS05 | 18 | 30 | 11 | 7 |
| Y7-AS06 | 36 | 51 | 26 | 10 |

## Findings
- Independently checked all 92 numeric, fraction and multiple-choice correct answers against the question statements: **no incorrect supplied automatic answers found**.
- Checked each written question for a mathematically valid target solution, reasoning and an allocation of one explicit marking point per available mark (36 sets of written marking guidance).
- Checked that every MCQ has a corresponding correct option and that fraction answers are in lowest terms when the question requires this.
- Checked AS04 unit conversions for cm² and m³; AS05 ratio, direct proportion, unit price, interest and map scales; AS06 probability and financial maths.
- **Pupil-answer exposure defect repaired in AS05**: its entire visible post-hand-in marking scheme panel and detailed client-side written answer rubrics were removed from the pupil file. Its other diagnostic feedback and assessment experience were retained.
- Five other pupil files already had no visible parent marking scheme; separate full parent review keys are now supplied for all six.

## Deployment and security — IMPORTANT
- `PUPIL_HTML` = pupil-facing assessment HTML. Keep the website’s existing authentication, role-gated Teacher/Parent routes and submission handler.
- `PARENT_SECURE_ONLY` = 6 self-contained parent review HTML pages and 6 machine-readable answer/rubric JSON files. **Never host this folder as a public static asset, or ship its bytes to the pupil browser.**
- In the website parent results route, **authorise parent ownership of the specific child/assessment server-side** before returning any answer-key JSON or parent HTML. A simple hidden element, JavaScript flag or PIN in frontend source is not security.
- The original pupil scripts still include `correctAnswer` for local multiple-choice, fraction and numeric auto-marking; that means determined pupils can inspect those answers in browser source. Full examination-grade secrecy requires moving automatic marking and answer keys to a trusted authenticated backend. **That backend migration was not done** because website integration code and authorisation contracts were not supplied.
- The supplied standalone parent pages are usable as marking references, but are **not themselves access controls** and should not be publicly linked.
- Written items remain human-marked; current standalone lesson results (especially AS05 local reviewer) do not constitute authenticated parent grades.
- AS01–AS04 and AS06 request `window.NOVA_ASSESSMENT_SUBMIT` for connected submission; their successful website hand-in paths require the website-provided handler. AS05 remains an offline/device-only review preset until deliberately connected.

## Test evidence and limitations
- Data parsed and structurally validated from each original HTML file; all question IDs, types, option keys, marks and rubrics checked by independent oracle.
- Produced six complete parent HTML marking schemes and six corresponding JSON keys.
- Verified AS05 replacement does not call or display the former pupil marking guide, and its confidential written answer arrays are no longer embedded in the script.
- Source-level inspection only: cannot verify live site role-gating, database submission, parent record mapping or actual browser visual layout from these files alone.
- No GitHub changes or website deployment performed.

## Executed browser checks (Chromium, isolated HTML)
- Six pupil HTML pages loaded with zero JavaScript page errors; `Begin → questions → review → hand-in → results` completed for all six when a simulated successful NOVA submission handler was supplied for connected assessments. AS05 completed using its existing device-only hand-in path.
- Six parent marking HTML pages loaded with all of the expected question rows (18, 18, 18, 20, 18, 36).
- All six pupil files were checked at a 390 px mobile viewport: zero horizontal overflow on the initial page and no JavaScript page errors.
- The `window.NOVA_ASSESSMENT_SUBMIT` browser test stub is not the real website submission service; **actual server submissions, permissions, marking persistence and role gating remain untested**.
- The full rendered sequence was tested at 1200 px desktop; other device sizes, assistive technology and voice quality are not certified by this test.
