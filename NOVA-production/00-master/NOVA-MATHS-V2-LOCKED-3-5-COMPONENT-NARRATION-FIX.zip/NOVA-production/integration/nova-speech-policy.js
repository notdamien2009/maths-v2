/* Shared mathematics-aware spoken text; preserve visible maths and original apparatus. */
(function(w){'use strict';w.NovaSpeechPolicy={version:'1.1.0',safe(text){return typeof text==='string'&&text.trim().length>0&&text.length<5000;},restriction:'Decimal numerals are spoken as whole-number point individual decimal digits; visible notation is unchanged.'};})(window);
