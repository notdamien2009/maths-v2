#!/usr/bin/env python3
"""Structural/browser smoke tests for the 3–5 concept contract. No edits to master."""
import copy,json,re,tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'NOVA-MATHS-V2-3-5-CONCEPT-TEMPLATE-CANDIDATE.html').read_text(encoding='utf-8')

def get_json(doc,sid):
 m=re.search(r'(<script\b[^>]*\bid="'+sid+r'"[^>]*>)(.*?)(</script>)',doc,re.S)
 assert m,sid
 return json.loads(m.group(2))

def set_json(doc,sid,data):
 p=r'(<script\b[^>]*\bid="'+sid+r'"[^>]*>)(.*?)(</script>)'
 return re.sub(p,lambda m:m.group(1)+json.dumps(data,ensure_ascii=False)+m.group(3),doc,count=1,flags=re.S)

def candidate(n,declared=None,mismatch=False,duplicate=False,rogue=False,no_coverage=False):
 lesson=get_json(HTML,'novaLessonData')
 prod=get_json(HTML,'novaProductionData')
 base=lesson['learn'][0]; bob=lesson['bob']['concepts'][0]
 lesson['meta'].update(templateMode=False,plannedConceptCount=n if declared is None else declared,curriculumCode='QA-'+str(n))
 lesson['learn']=[dict(copy.deepcopy(base),id='C'+str(i+1),title='Concept '+str(i+1)) for i in range(n)]
 lesson['bob']['concepts']=[]
 for i in range(n+(1 if mismatch else 0)):
  c=copy.deepcopy(bob)
  c.update(id=('C1' if duplicate and i==1 else 'C'+str(i+1)),title='Concept '+str(i+1))
  c['beats']=[dict(copy.deepcopy(bob['beats'][0]),id='B'+str(i+1)+'.0'+str(j+1),title='Beat '+str(j+1),speech='Bob concept '+str(i+1)+' beat '+str(j+1)) for j in range(4)]
  lesson['bob']['concepts'].append(c)
 # Fixed Challenge count is independent of concept count; every concept gets coverage.
 for i,r in enumerate(prod['manifest']['challenge']):
  r['conceptId']='C'+str(i%n+1)
 if rogue:prod['manifest']['challenge'][-1]['conceptId']='C99'
 if no_coverage:
  for r in prod['manifest']['challenge']:
   if r['conceptId']=='C'+str(n):r['conceptId']='C1'
 prod['manifest']['watch']=[dict(copy.deepcopy(prod['manifest']['watch'][0]),id='L'+str(i+1)+'.W1') for i in range(n)]
 doc=set_json(HTML,'novaLessonData',lesson)
 return set_json(doc,'novaProductionData',prod)

def inspect(page,html_path):
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html_path.read_text(encoding='utf-8'),wait_until='load',timeout=20000)
 page.wait_for_timeout(380)
 return errors

if __name__=='__main__':
 results=[]
 with tempfile.TemporaryDirectory(prefix='nova-concept-qa-') as temp, sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
  for n in [3,4,5]:
   path=Path(temp)/(f'positive-{n}.html');path.write_text(candidate(n),encoding='utf-8')
   page=browser.new_page(viewport={'width':1280,'height':900})
   errs=inspect(page,path)
   assert not errs,(n,errs)
   assert page.locator('.nova-stage-btn').count()==7
   assert page.evaluate('window.NovaLessonProduction.concepts.length')==n
   assert page.locator('#stageLearn .v2-concept').count()==n
   assert page.evaluate('window.NovaLessonProduction.bob.length')==n
   assert page.evaluate('window.NovaLessonProduction.manifest.challenge.length')==15
   page.locator('#startLearnWithBob').click()
   assert page.evaluate("document.getElementById('bobLessonPage').classList.contains('active')")
   assert page.locator('#bobcSubtitle').inner_text().strip()==f'Concept 1 of {n}'
   for i in range(1,n):
    page.locator('#bobcNextConcept').click()
    assert page.locator('#bobcSubtitle').inner_text().strip()==f'Concept {i+1} of {n}'
   assert page.locator('#bobcNextConcept').is_disabled()
   page.locator('#bobcPrevConcept').click()
   assert page.locator('#bobcSubtitle').inner_text().strip()==f'Concept {n-1} of {n}'
   page.set_viewport_size({'width':390,'height':844})
   page.wait_for_timeout(100)
   assert page.locator('#bobcSubtitle').inner_text().strip()==f'Concept {n-1} of {n}'
   assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 1')
   page.close()
   results.append({'test':f'{n} concepts / Bob next-prev / desktop+mobile','result':'PASS'})
  for label,kwargs,expected in [
   ('too few concepts',dict(n=2),'plannedConceptCount must be an integer'),
   ('too many concepts',dict(n=6),'plannedConceptCount must be an integer'),
   ('planned count mismatch',dict(n=3,declared=4),'approved 4-concept plan requires'),
   ('Bob count mismatch',dict(n=3,mismatch=True),'requires 3 Learn and 3 matching Bob'),
   ('duplicate IDs',dict(n=3,duplicate=True),'unique concept IDs'),
   ('rogue Challenge ID',dict(n=3,rogue=True),'every Challenge question must reference'),
   ('unassessed concept',dict(n=4,no_coverage=True),'must assess every approved concept'),
   ('undeclared approved count',dict(n=3,declared=''), 'plannedConceptCount must be an integer')
  ]:
   path=Path(temp)/(f'negative-{len(results)}.html');path.write_text(candidate(**kwargs),encoding='utf-8')
   page=browser.new_page()
   errs=inspect(page,path)
   assert len(errs)>0,(label,errs)
   assert any(expected in e for e in errs),(label,errs)
   page.close()
   results.append({'test':label,'result':'PASS (rejected)'})
  # original empty template mode should still open without implying production readiness
  path=Path(temp)/'template-mode.html';path.write_text(HTML,encoding='utf-8')
  page=browser.new_page();errs=inspect(page,path)
  assert not errs,errs
  page.close()
  results.append({'test':'master blueprint in template mode','result':'PASS'})
  browser.close()
 print(json.dumps(results,indent=2))
