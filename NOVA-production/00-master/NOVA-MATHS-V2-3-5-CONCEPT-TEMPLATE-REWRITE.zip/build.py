#!/usr/bin/env python3
"""Rebuild the portable HTML from the locked shell and two readable source modules.

Usage: python build.py
Does not edit the NOVA repository, Library or approved original sources.
"""
from pathlib import Path
import re
root=Path(__file__).resolve().parent
shell=(root/'src/template-shell.tmpl').read_text(encoding='utf-8')
css=(root/'src/nova-design.css').read_text(encoding='utf-8')
js=(root/'src/nova-runtime.js').read_text(encoding='utf-8')
assert shell.count('/* BUILD_SLOT: nova-design.css */')==1
assert shell.count('/* BUILD_SLOT: nova-runtime.js */')==1
build=shell.replace('/* BUILD_SLOT: nova-design.css */',css).replace('/* BUILD_SLOT: nova-runtime.js */',js)
output=root/'NOVA-MATHS-V2-3-5-CONCEPT-TEMPLATE-CANDIDATE.html'
output.write_text(build,encoding='utf-8')
print('Rebuilt:',output,'bytes:',output.stat().st_size)
