# NOVA Maths V2 — Variable Concept Template (3–5)

**Review candidate, not certified for production.** This pack contains **one generated standalone HTML candidate**, and the readable sources used to build that candidate. No duplicate HTML versions, appended runtime patches, new apparatus or changed layouts.

## What changed

- Each lesson has **one main learning objective** and exactly **3, 4 or 5 purposeful, progressive concepts**, as approved in Run 1. Five is never a default target to fill.
- `novaLessonData.meta.plannedConceptCount` is required for completed lessons and must match both `learn` and `bob.concepts`. Each concept has a matching unique ID and 4–6 Bob teaching beats.
- All 10 core and 5 optional Challenge questions must refer to the approved concept IDs. Core questions collectively cover every planned concept. The number of Challenge questions **does not** change with the number of concepts.
- Explore architecture is **separate**: keep the five activity slots where required. Existing approved components and their modes/states can support distinct purposeful investigations; do not add/re-map components just to reach a count.
- The master is a **template-mode example with three empty concepts**, not an approved or populated lesson. Increase to four/five or rewrite those concept records based on the approved plan; then set `meta.templateMode=false` and `meta.plannedConceptCount` to that exact number.

## One source of truth

Only edit the three source files for implementation work:

- `src/template-shell.tmpl` — data JSON and the unchanged seven-stage markup
- `src/nova-runtime.js` — runtime, with the 3–5 validator rewritten **in place**, not overridden by a late patch
- `src/nova-design.css` — unchanged consolidated styling

Run `python build.py` to produce `NOVA-MATHS-V2-3-5-CONCEPT-TEMPLATE-CANDIDATE.html`. **Do not hand-edit the generated HTML as a separate second source.** The standalone file works offline as an HTML artifact.

## What remains locked

Seven pages, fixed 700px desktop Bob Board without internal scroll, approved F0–F18 native components and their mapping, Watch/Explore/Guided/Challenge separation, all existing controls, source IDs, Ryan TTS policy, Start/Practice/Exit counts and F0-12 controller.

Read `QA-AND-REGRESSION-REPORT.md` for the evidence and remaining integration tests. Nothing was pushed to Git or saved to ChatGPT Library.
