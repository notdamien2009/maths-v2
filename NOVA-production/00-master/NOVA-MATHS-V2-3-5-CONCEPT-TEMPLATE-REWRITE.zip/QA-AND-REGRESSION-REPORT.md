# QA — NOVA Maths V2 3–5 Concept Template

**Status: SOURCE UPDATE COMPLETE; BROWSER SMOKE PASSED; FULL LESSON GOLD QA NOT DONE.**

## Actual source change

This change is made directly to the owning `validateZeroDrift()` function and production contracts. It is **not** a new script appended to the HTML, not a late override, and not a separate copy of the template. The existing consolidated host CSS and the native apparatus interfaces were left untouched. The master data includes three template-only concept examples, each with four empty teaching beats. Their mathematical content must be supplied from the approved lesson plan.

In completed lessons the validator requires:

1. An integer `meta.plannedConceptCount` of 3, 4 or 5.
2. Exact agreement between that count, Learn, and Bob's presentation; concept IDs unique and matching in order.
3. Four to six teaching beats per Bob concept.
4. Ten core and five optional-stretch Challenge records, none referring to an absent concept; core records assess every included concept.
5. The existing 5 Start / 15 Practice / 5 Exit and associated visual-aid placement contract, unchanged.

Explore activity count is **not derived from the Learn count**. Five Explore slots (where required) remain an independent requirement of lesson planning/production.

## Tests run (Chromium)

`python qa/concept-count-regression.py` tested the rebuilt standalone master and locally synthesised *nonproduction* 3-, 4-, and 5-concept data sets; these test data sets are generated in memory and are **not** shipped as duplicate lesson HTML files.

| Test | Result |
|---|---|
| 3 concepts: page initialisation, matching Learn sections, Bob previous/next, 1280px and 390px | PASS |
| 4 concepts: same | PASS |
| 5 concepts: same | PASS |
| Invalid 2 or 6 concept count | REJECTED |
| Approved count disagrees with Learn/Bob | REJECTED |
| Repeated concept IDs | REJECTED |
| Challenge refers to missing concept | REJECTED |
| Core Challenge fails to cover a concept | REJECTED |
| Missing approved count | REJECTED |
| Unpopulated template opens in template mode | PASS |
| JS syntax and reproducible standalone build | PASS |

No JavaScript page exceptions arose during these tested routes. The mobile concept-navigation test also checked that the document had no horizontal overflow. The resulting standalone candidate regenerates from exactly three source files.

## Unverified / release blockers

The test inputs do **not** contain real original component source bytes or a completed lesson's narration/assessment data. They cannot prove source-specific animations, correct mathematical teaching, timed voice and cue alignment, actual Explore states, F0-12 scoring/replay, device touch/keyboard interactions, real fixed-height Board visual framing, or cross-lesson progression. Independent GOLD/production certification must still run on a completed three-, four-, or five-concept lesson, preferably piloted on the approved reference lessons, before replacing the production master.

Older visual parity and CSS-refactor observations from the incoming candidate are not claimed as new test results here. The prior candidate's existing runtime ownership/legacy duplicate rendering code has **not** undergone the broader independent behaviour-led refactor; this task changes only the concept-count logic and its data contracts, without adding more runtime layers.
