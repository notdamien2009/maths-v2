# PARENT PRIVATE — do not publish

This folder contains the authoritative answer guidance for the Y7-058 assessment.

1. Open the PARENT-REVIEW HTML in a trusted offline environment as an adult, or deploy its functionality only behind NOVA's verified parent authentication.
2. Ask for the exported attempt JSON from the pupil-local assessment preview.
3. Load the private `NOVA-ENGLISH-Y7-058-PRIVATE-MARK-SCHEME.json` when prompted.
4. Apply mark bands fairly and enter each awarded mark. The report includes the 70% pass threshold (28 out of 40).
5. Export the mark report. It does **not** write to NOVA progress automatically.

Never place these files in `/public` or anywhere the pupil browser can fetch them. The reviewer HTML itself does not authenticate a user.
