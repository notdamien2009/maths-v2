NOVA MATHS V2 - COMPLETE F14 FAMILY REVIEW

Open INDEX.html first.

engines/: 13 standalone complete HTML engines.
screenshots/: 26 fresh cross-family browser screenshots (380 Watch, 1280 Explore).
individual-QA/: original QA notes for all 13 engines.
AUDIT-REPORT.html: current cross-family audit scope, results and caveats.
audit/F14-FAMILY-RESULTS.json: per-component assertions and metrics.
audit/F14-VISUAL-COMPARISON.png: side-by-side contact sheet.

No code changes, no GitHub writes. These are review builds, not GOLD approved.
