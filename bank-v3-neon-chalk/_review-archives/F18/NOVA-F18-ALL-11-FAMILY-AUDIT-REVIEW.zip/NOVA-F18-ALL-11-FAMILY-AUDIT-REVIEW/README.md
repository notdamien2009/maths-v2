# NOVA F18 FAMILY — AUDIT / REVIEW BUNDLE
Audit date: 2026-10-13
Status: REVIEW BUILD — NOT GOLD APPROVED

Contents:
- NOVA-F18-FAMILY-AUDIT-REPORT.html : Open first (visual dashboard).
- engines/ : 11 original standalone HTML files, NOT MODIFIED.
- QA/family-audit-results.json : 2,013 assertions, 176 browser observations and findings.
- QA/visual-contact-sheets/ : side-by-side gallery JPGs.
- QA/screenshots/ : selected actual captured teaching-stage screenshots.
- tests/audit_f18_family.py : executable family audit runner (depends on Playwright and Chromium).

F18-09 is implemented as a preset in F18-02; it does NOT require a separate file.
All eleven engines embed the identical NOVA JS core (SHA-256 fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc).
No GitHub modifications. Physical touchscreen QA and owner GOLD approval are outstanding.

Review findings:
1. F18-01..04 show an extra Sir Bob narration text panel outside the stage; newer F18 stages hide it. This is not a second mascot artwork.
2. F18-01 historical ZIP includes results but not executable component stress script.
3. F18-03/F18-07 historical claims include separate 8-case smoke tests not captured as machine-readable JSON in their ZIPs.

All 11 files are unchanged copies of their current review builds.
