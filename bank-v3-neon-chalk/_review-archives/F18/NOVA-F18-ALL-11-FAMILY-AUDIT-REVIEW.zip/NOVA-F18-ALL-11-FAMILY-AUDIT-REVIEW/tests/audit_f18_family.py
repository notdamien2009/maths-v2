from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image,ImageDraw
import hashlib,json,zipfile,os
R=Path('/mnt/data');OUT=R/'f18_family_audit';P=OUT/'screenshots';P.mkdir(parents=True,exist_ok=True)
ALL_FILES=sorted(R.glob('F18-*.html'));start=int(os.environ.get('AUDIT_START','0'));end=int(os.environ.get('AUDIT_END',str(len(ALL_FILES))));files=ALL_FILES[start:end]; checks=[];obs=[];inventory=[]; first=None

def ck(id,mode,width,theme,item,yes,evidence=''):
 checks.append({'id':id,'mode':mode,'width':width,'theme':theme,'assertion':item,'passed':bool(yes),'evidence':str(evidence)[:200]})
 if not yes:print('FAIL',id,width,mode,theme,item,str(evidence)[:100],flush=True)
for f in files:
 id=f.stem[:6];s=f.read_text();core=s.split('<script>',1)[1].split('</script>',1)[0];sha=hashlib.sha256(core.encode()).hexdigest();first=first or sha
 ck(id,'source',0,'source','Identical embedded NOVA JS core',sha==first,sha[:20]);ck(id,'source',0,'source','Embedded chalk font','@font-face' in s);ck(id,'source',0,'source','No linked scripts/styles',not ('<script src=' in s or '<link rel="stylesheet"' in s));ck(id,'source',0,'source','Engine identifier in source',id in s)
 with zipfile.ZipFile(R/f'NOVA-{id}-REVIEW.zip') as z:
  n=z.namelist();err=z.testzip();q=any('QA-REPORT' in a or 'qa-report' in a.lower() for a in n);png=sum(a.lower().endswith(('.png','.jpg','.jpeg')) for a in n)
  ck(id,'source',0,'source','Individual review ZIP passes integrity',err is None,err);ck(id,'source',0,'source','Individual QA report present',q);ck(id,'source',0,'source','Review screenshots present',png>=8,png)
 inventory.append({'id':id,'title':f.stem[7:].replace('-',' ').title(),'bytes':f.stat().st_size,'sha256':hashlib.sha256(s.encode()).hexdigest(),'core_sha256':sha,'prior_screenshots':png})
print('SOURCE',len(checks),'checks; engines',len(files),flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for f in files:
  id=f.stem[:6];html=f.read_text()
  for w in (380,1280):
   page=b.new_page(viewport={'width':w,'height':950},reduced_motion='reduce');errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
   try:
    page.set_content(html,wait_until='domcontentloaded',timeout=25000);page.wait_for_timeout(40)
    ck(id,'init',w,'dark','Four mode tabs',page.locator(f'#{id} .nova-tabs button').count()==4)
    ck(id,'init',w,'dark','NOVA svgDrag available',page.evaluate('typeof NOVA.ui.svgDrag')=='function')
    ck(id,'init',w,'dark','NOVA motion available',page.evaluate('typeof NOVA.motion')=='object')
    ck(id,'init',w,'dark','No remote dependencies',page.evaluate('document.querySelectorAll("script[src],link[rel=stylesheet]").length')==0)
    for theme in ('dark','light'):
     if theme=='light':page.locator('.themetog').click(timeout=3000);page.wait_for_timeout(35)
     ck(id,'init',w,theme,'Theme toggles properly',page.evaluate('document.documentElement.getAttribute("data-theme")')==theme)
     for mode in ('Watch','Guided','Explore','Challenge'):
      page.locator(f'#{id} .nova-tabs button').filter(has_text=mode).click(timeout=6000);page.wait_for_timeout(35)
      t=page.evaluate('''() => {const root=document.querySelector('ROOT'),st=root.querySelector('.nova-stage'),d=st?.querySelector('.nv-dock'),svg=st?.querySelector('svg.nv-svg'),o=root.querySelector('.nova-bob');const sr=st.getBoundingClientRect(),dr=d?.getBoundingClientRect();return {tab:root.querySelector('.nova-tab[aria-selected="true"]')?.textContent?.trim(),stages:root.querySelectorAll('.nova-stage').length,docks:st.querySelectorAll('.nv-dock').length,allDocks:document.querySelectorAll('.nv-dock').length,extra:o?getComputedStyle(o).display:'absent',overflow:document.documentElement.scrollWidth-innerWidth,svg:!!svg,svgWidth:svg?.getBoundingClientRect().width||0,labels:svg?.querySelectorAll('text').length||0,stageHeight:sr.height,dockInside:!!(dr&&dr.x>=sr.x-4&&dr.right<=sr.right+4&&dr.y>=sr.y-4&&dr.bottom<=sr.bottom+4),timeline:root.querySelector('.nova-tl')?.getAttribute('aria-hidden')}}'''.replace('ROOT',f'#{id}'))
      t.update({'id':id,'mode':mode,'width':w,'theme':theme});obs.append(t)
      for key,val,info in [('Correct mode visible',t['tab']==mode,t['tab']),('Only one stage',t['stages']==1,t['stages']),('Exactly one mascot inside stage',t['docks']==1,t['docks']),('No outside mascot',t['allDocks']==1,t['allDocks']),('Legacy tutor identified',t['extra'] in ('absent','none','flex'),t['extra']),('No horizontal overflow',t['overflow']<=1,t['overflow']),('Math SVG visible',t['svg'] and t['svgWidth']>=min(w-50,290),t['svgWidth']),('Math drawing has chalk labels',t['labels']>=4,t['labels']),('Mascot contained in stage',t['dockInside'],t['dockInside']),('Stage has teaching area',t['stageHeight']>330,t['stageHeight'])]:ck(id,mode,w,theme,key,val,info)
      if theme=='dark' and (mode=='Explore' or (mode=='Challenge' and w==380)) and not (P/f'{id}_{w}_{mode.lower()}.jpg').exists():
       try:page.locator(f'#{id} .nova-stage').screenshot(path=str(P/f'{id}_{w}_{mode.lower()}.jpg'),type='jpeg',quality=75,animations='disabled',timeout=13000)
       except Exception as e:ck(id,mode,w,theme,'Screenshot captured',False,str(e))
     ck(id,'all modes',w,theme,'No JS page errors',not errs,errs[-2:])
   except Exception as e:ck(id,'load',w,'unknown','Browser audit ran',False,str(e))
   finally:page.close()
  print('AUDITED',id,'tests',len(checks),'fail',sum(not x['passed'] for x in checks),flush=True)
 b.close()
for mode in ():
 width=812;h=185+len(files)*305;sheet=Image.new('RGB',(width,h),'#07111d');draw=ImageDraw.Draw(sheet);draw.text((15,18),'NOVA · F18 FAMILY · '+mode.upper()+' · MOBILE 380 / DESKTOP 1280',fill='white')
 for i,f in enumerate(files):
  id=f.stem[:6];y=60+i*305;draw.text((15,y),f.stem.replace('-',' '),fill='#bdeeff')
  for col,w in enumerate((380,1280)):
   path=P/f'{id}_{w}_{mode}.jpg'
   if path.exists():
    im=Image.open(path).convert('RGB');im.thumbnail((374,270));x=15+col*400;sheet.paste(im,(x+(374-im.width)//2,y+25))
 sheet.save(OUT/f'F18-FAMILY-{mode.upper()}-CONTACT-SHEET.jpg',quality=84,optimize=True)
sumry={'engines':len(files),'checks':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'failures':[x for x in checks if not x['passed']],'mode_viewport_theme_cases':len(obs),'screenshots':len(list(P.glob('*.jpg'))),'shared_core_sha256':first,'inventory':inventory}
(OUT/f'audit-results-batch-{start}-{end}.json').write_text(json.dumps({'summary':sumry,'checks':checks,'observations':obs},indent=2));print('RESULT',sumry['passed'],'/',sumry['checks'],'FAILURES',sumry['failed'],'COMBINATIONS',len(obs),'SHOTS',sumry['screenshots'],flush=True)
