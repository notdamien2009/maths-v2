#!/usr/bin/env python3
"""F11-12 hostless preset geometry and review-preview smoke/interaction tests.
No F18-03 host exists: integration is deliberately NOT claimed as tested.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,math,sys,hashlib
root=Path(__file__).resolve().parents[1]
html=(root/'previews/F11-12-clock-face-angles-PREVIEW.html').read_text()
shots=root/'shots/F11-12';shots.mkdir(exist_ok=True,parents=True)
results={'passes':[],'failures':[],'integrationStatus':'blocked: F18-03 host not yet built','previewStatus':'in QA'}
def ck(name,yes):
 (results['passes'] if yes else results['failures']).append(name)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=browser.new_page(viewport={'width':width,'height':950},reduced_motion='reduce');err=[];page.on('pageerror',lambda e:err.append(str(e)))
  page.set_content(html,wait_until='load');page.wait_for_timeout(200)
  prefix=str(width)
  ck(prefix+' preview title',page.get_by_text('F11-12 · Clock-Face Angles').count()==1)
  ck(prefix+' hostless indicator',page.get_by_text('F18-03 PRESET · REVIEW PREVIEW').count()==1)
  ck(prefix+' genuine NOVA Chalk',page.evaluate('document.fonts.check("24px NOVA Chalk")'))
  ck(prefix+' stage SVG',page.locator('#figure svg').count()==1)
  ck(prefix+' mascot inside stage',page.evaluate('''()=>{let A=document.querySelector('#stage').getBoundingClientRect(),B=document.querySelector('#stage .nv-dockfig').getBoundingClientRect();return B.left>=A.left-2 && B.right<=A.right+2 && B.top>=A.top-2 && B.bottom<=A.bottom+2}'''))
  ck(prefix+' stage not horizontally overflowing',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+5'))
  ck(prefix+' result concealed',page.locator('#angleValue').inner_text()=='NOT SHOWN YET')
  page.locator('#mode').select_option('Explore');page.wait_for_timeout(80)
  page.locator('#reveal').click();ck(prefix+' reveal 3:00 right angle',page.locator('#angleValue').inner_text()=='90°')
  page.locator('#time').select_option('2,30');page.locator('#reveal').click();ck(prefix+' 2:30 105 degrees',page.locator('#angleValue').inner_text()=='105°')
  page.locator('#time').select_option('5,40');page.locator('#kind').select_option('reflex');page.locator('#reveal').click();ck(prefix+' reflex 5:40 290',page.locator('#angleValue').inner_text()=='290°')
  page.locator('#kind').select_option('minor');page.locator('#time').select_option('3,0')
  h=page.locator('#minuteHandle');h.scroll_into_view_if_needed();h.focus();initial=int(h.get_attribute('aria-valuenow'))
  page.keyboard.press('ArrowRight');page.wait_for_timeout(60)
  ck(prefix+' keyboard minute advance',int(h.get_attribute('aria-valuenow'))==((initial+1)%360 if False else 6))
  page.locator('#reset').click();page.locator('#mode').select_option('Explore');h=page.locator('#minuteHandle');h.scroll_into_view_if_needed()
  r=h.bounding_box();cx=r['x']+r['width']/2;cy=r['y']+r['height']/2
  target=page.evaluate('''()=>{let p=document.querySelector('#figure svg').createSVGPoint();p.x=490;p.y=275;let z=p.matrixTransform(document.querySelector('#figure svg').getScreenCTM());return {x:z.x,y:z.y}}''')
  page.mouse.move(cx,cy);page.mouse.down();page.mouse.move(target['x'],target['y'],steps=1);page.wait_for_timeout(80)
  changed=int(h.get_attribute('aria-valuenow'));ck(prefix+' live drag updates before release',changed!=0)
  page.keyboard.press('Escape');page.wait_for_timeout(70)
  ck(prefix+' Escape rollback',int(h.get_attribute('aria-valuenow'))==0)
  page.mouse.up();ck(prefix+' no active drag after release',page.evaluate('window.__f1112Preview.getState().minute===undefined') is False if False else page.evaluate('window.__f1112Preview.getState().minute===0'))
  page.locator('#mode').select_option('Challenge');ck(prefix+' challenge no pre-reveal',page.locator('#angleValue').inner_text()=='NOT SHOWN YET')
  for i,(answer,reason) in enumerate([(90,'time-hands'),(105,'hour-hand-moves'),(180,'straight-angle'),(270,'reflex-complement'),(115,'hour-hand-moves'),(130,'hour-hand-moves'),(0,'coincident-hands'),(290,'reflex-complement')]):
   page.locator('#answer').fill(str(answer));page.locator('#reason').select_option(reason);page.locator('#check').click();page.wait_for_timeout(70)
   ck(prefix+' challenge '+str(i+1)+' accepts valid solution', 'Correct angle and reason.' in page.locator('#feedback').inner_text())
   page.wait_for_timeout(1020)
  ck(prefix+' no page errors',not err)
  # Edge cases and host integration must be testable without a host.
  vectors=[(3,0,90,270),(2,30,105,255),(6,0,180,180),(9,0,90,270),(10,10,115,245),(8,20,130,230),(12,0,0,360),(5,40,70,290)]
  for hrs,mins,minor,reflex in vectors:
   got=page.evaluate('([h,m])=>{let a=window.NOVA_F1112_PRESET.clockAngle(h,m);return [a.minor,a.reflex]}',[hrs,mins]);
   ck(f'{prefix} exact clock maths {hrs}:{mins:02}',abs(got[0]-minor)<1e-9 and abs(got[1]-reflex)<1e-9)
  ck(prefix+' host requires actual F18-03',page.evaluate('''()=>{try{window.NOVA_F1112_PRESET.registerInto({id:'NOT-F18'});return false}catch(e){return e.message.includes('F18-03')}}'''))
  ck(prefix+' host contract registers both parts',page.evaluate('''()=>{let c=[];let host={id:'F18-03',registerPreset:(id)=>c.push(id),registerOverlay:(id)=>c.push('overlay:'+id),getHandState:()=>({}),setHandState:()=>{}};return window.NOVA_F1112_PRESET.registerInto(host).integrated&&c.includes('F11-12')&&c.includes('overlay:F11-12')}'''))
  page.locator('#reset').click()
  page.locator('#stage').screenshot(path=str(shots/f'F11-12-{width}-watch.png'),animations='disabled')
  page.locator('#mode').select_option('Explore');page.locator('#time').select_option('2,30');page.locator('#reveal').click()
  page.locator('#stage').screenshot(path=str(shots/f'F11-12-{width}-angle-revealed.png'),animations='disabled')
  page.locator('#mode').select_option('Challenge');page.locator('#stage').screenshot(path=str(shots/f'F11-12-{width}-challenge.png'),animations='disabled')
  page.close()
 browser.close()
results['counts']={'passed':len(results['passes']),'failed':len(results['failures'])}
results['previewStatus']='pass' if not results['failures'] else 'fail'
results['presetSourceSha256']=hashlib.sha256((root/'presets/F18-03/F11-12-clock-face-angles.preset.js').read_bytes()).hexdigest()
(root/'tests/F11-12-QA.json').write_text(json.dumps(results,indent=2))
print(results['counts']);print('failures',results['failures']);sys.exit(bool(results['failures']))
