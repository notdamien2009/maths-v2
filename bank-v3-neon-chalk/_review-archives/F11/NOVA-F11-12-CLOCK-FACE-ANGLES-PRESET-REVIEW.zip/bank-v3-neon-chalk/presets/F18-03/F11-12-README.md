# F11-12 — Clock-Face Angles (PRESET ONLY)

**Status: integration-ready preset / visual reviewer preview. Not an installed or GOLD-approved F18-03 engine.**

Source master: `00-master/NOVA-MASTER-FOR-OTHER-AI.md` → F11-12 and F18-03.
F11-12 is an *angle overlay on F18-03 Analogue Clock*. The master explicitly says **do not build a separate engine**. F18-03 is not present in the checked maths-v2 GitHub `main` tree as of 12 October 2026. No new clock host has been fabricated or pushed to GitHub.

## Content produced in this run

- `presets/F18-03/F11-12-clock-face-angles.preset.js` — independent mathematical model, typed preset metadata, narration sequence, eight question/marking rules, host registration contract. No duplicate core.
- `previews/F11-12-clock-face-angles-PREVIEW.html` — *hostless interactive visual REVIEW PAGE*, borrowing the unchanged F0/F1 Neon + Chalk core snapshot from the accepted F11-11 production reference. This is not a replacement F18-03 engine.
- `F11/F11-12-family-entry.json` — gallery manifest entry identifying the true parent.
- `tests/test_F11-12.py`, `tests/F11-12-QA.json`, and mobile/desktop screenshots.

## Maths model

For hour `h` and minute `m` on an ordinary twelve-hour analogue clock:

- minute hand angle from 12 clockwise = `6m` degrees
- hour hand angle from 12 clockwise = `30(h mod 12) + 0.5m` degrees
- smaller unsigned angle = `min(abs(hour-minute), 360-abs(hour-minute))`
- other full-circle sweep = `360 - smaller angle`. For coincident hands, 360° is a **full turn**, not strictly a reflex angle.

Examples: 3:00 = 90°; 2:30 = 105°; 10:10 = 115°; 8:20 = 130°; 5:40 = 70° smaller / 290° reflex. The view draws both hand rays and an accurate SVG arc using the approved `NOVA.neonLine` / `NOVA.neonPath` / `NOVA.chalkText` in the preview.

## How to install when F18-03 is built

1. Keep the actual F0 core and the eventual `F18-03` clock engine as the authority. **Do not replace its clock with this preview.**
2. Include `presets/F18-03/F11-12-clock-face-angles.preset.js` after F18-03 and before its preset registry finalisation.
3. Make the host implement `id:'F18-03'`, `registerPreset(id, spec)`, `registerOverlay(id, spec)`, `getHandState()` and `setHandState(state)`. Use `window.NOVA_F1112_PRESET.registerInto(host)` after host creation.
4. Host must render the F11-12 `angleArc` overlay on its **own existing** clock and switch between all four F0 modes. It must keep its existing mascot dock, current shared styles and live-hand drag. Use the preset's `steps`, `presets`, `challenges` and `mark` data, with distinct Bob/Nova/Izaac poses and narration.
5. Validate the host integration with F18-03 built, including both hand-drag handles, touch pointer cancellation, keyboard, accurate stage scaling and reduced motion. These **cannot** be signed off before F18-03 exists.

## QA evidence and unresolved integration

`tests/F11-12-QA.json` reports automated preview and mathematical checks on 380px and 1280px. It does **not** claim that Watch/Guided/Explore/Challenge behaviours have been integrated with the absent F18-03 host. That remains pending.

**No GitHub changes. Owner approval remains required.**
