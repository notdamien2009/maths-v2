from playwright.sync_api import sync_playwright,TimeoutError as PWTimeout
from pathlib import Path
import json, traceback, math
HTML=Path(__file__).resolve().parents[1] / 'F17-02-Spinner-Builder-PREMIUM-REVIEW.html'.read_text()
R=[]
def ck(name,cond,details=None):
 R.append(dict(test=name,passed=bool(cond),details=details));print(('PASS' if cond else 'FAIL'),name,details or '',flush=True)
def pt(page,x,y):
 return page.evaluate('''([x,y])=>{let s=document.querySelector('svg.f172-plot'),m=s.getScreenCTM(),p=s.createSVGPoint();p.x=x;p.y=y;let q=p.matrixTransform(m);return {x:q.x,y:q.y}}''',[x,y])
def drag(page,x,y,a,b,steps=16):
 page.locator('.f172-plot').scroll_into_view_if_needed()
 A=pt(page,x,y); B=pt(page,a,b)
 page.mouse.move(A['x'],A['y']);page.mouse.down();page.mouse.move(B['x'],B['y'],steps=steps);page.mouse.up();page.wait_for_timeout(650)
def get(page):return page.evaluate('window.NOVA_F17_02_CONFIG._explore.get()')
def cell(i,n,cx,cy,r):
 ang=math.radians(-90+(i+.5)*360/n)
 return cx+math.cos(ang)*r*.71,cy+math.sin(ang)*r*.71
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  page=b.new_page(viewport={'width':width,'height':920 if width>500 else 950},device_scale_factor=1,reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  try:
   page.set_content(HTML,wait_until='domcontentloaded',timeout=35000);page.wait_for_timeout(160)
   for mode in ['watch','guided','explore','challenge']:
    page.locator(f'.nova-tab[data-m="{mode}"]').click();page.wait_for_timeout(120)
    ck(f'{width}/{mode} present',page.locator('svg.f172-plot').count()==1)
    ck(f'{width}/{mode} original stage mascot',page.locator('#F17-02 .nova-stage .nv-dock').count()==1)
    ck(f'{width}/{mode} no JS error',len(errors)==0,errors[-1] if errors else None)
    ck(f'{width}/{mode} 7 wedges Y7',page.locator('[data-sector]').count()==7)
   page.locator('.nova-tab[data-m="explore"]').click();page.wait_for_timeout(90)
   get0=get(page);ck(f'{width}/Y7 start',get0['model']['primary']==[True,False,True,False] and get0['model']['secondary']==[False,True,False])
   # Drag add WIN token onto sector 2
   L={'cx':195,'cy':207,'r':143,'px':79,'py':464,'smx':280,'smy':475,'sr':66} if width<=500 else {'cx':251,'cy':226,'r':165,'px':558,'py':410,'smx':557,'smy':238,'sr':80}
   tx,ty=cell(1,4,L['cx'],L['cy'],L['r'])
   page.locator('.f172-plot').scroll_into_view_if_needed()
   ck(f'{width}/palette hit target',page.evaluate('''([x,y])=>{let s=document.querySelector('svg.f172-plot'),p=s.createSVGPoint();p.x=x;p.y=y;p=p.matrixTransform(s.getScreenCTM());let e=document.elementFromPoint(p.x,p.y);return !!e?.closest('[data-palette]')}''',[L['px'],L['py']]))
   drag(page,L['px'],L['py'],tx,ty,steps=30)
   ck(f'{width}/actual mouse drop adds WIN',get(page)['model']['primary'][1] is True,get(page)['model']['primary'])
   # re-grab green at sector 2 and drag it into empty sector 4
   fx,fy=cell(3,4,L['cx'],L['cy'],L['r'])
   drag(page,tx,ty,fx,fy,steps=14)
   a=get(page)['model']['primary'];ck(f'{width}/real mouse regrab transfers',a[1] is False and a[3] is True,a)
   # invalid zone returns unchanged
   drag(page,fx,fy,L['cx'],L['cy'],steps=2)
   a2=get(page)['model']['primary'];ck(f'{width}/invalid zone springs back',a2==a,a2)
   # keyboard equivalent using indexed controls
   page.locator('.f172-box select[aria-label="Choose sector"]').select_option('1');page.get_by_role('button',name='Mark WIN').first.click()
   ck(f'{width}/keyboard equivalent mark',get(page)['model']['primary'][1] is True)
   page.get_by_role('button',name='Remove WIN').first.click();ck(f'{width}/keyboard equivalent remove',get(page)['model']['primary'][1] is False)
   # Removal zone from 4th sector after regrab
   drag(page,fx,fy,L['px'],L['py']+42,steps=18)
   ck(f'{width}/red remove zone',get(page)['model']['primary'][3] is False,get(page)['model']['primary'])
   # Fast single-hop mouse movement must land without stranding objects.
   drag(page,L['px'],L['py'],fx,fy,steps=1)
   ck(f'{width}/fast pointer snap',get(page)['model']['primary'][3] is True)
   drag(page,fx,fy,L['px'],L['py']+42,steps=1)
   ck(f'{width}/fast pointer remove',get(page)['model']['primary'][3] is False)
   # Cancel a live drag; no state mutation and no floating helper.
   page.locator('.f172-plot').scroll_into_view_if_needed()
   a0=pt(page,L['px'],L['py']);a1=pt(page,tx,ty)
   stateBefore=get(page)['model']['primary'].copy()
   page.mouse.move(a0['x'],a0['y']);page.mouse.down();page.mouse.move(a1['x'],a1['y'],steps=3)
   page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(560)
   ck(f'{width}/Escape returns without state change',get(page)['model']['primary']==stateBefore)
   ck(f'{width}/Escape no stranded drag',page.evaluate('NOVA.ui._drag===null'))
   # On Spinner B, regrab a placed WIN and move it to another sector.
   b0x,b0y=cell(1,3,L['smx'],L['smy'],L['sr']);b1x,b1y=cell(2,3,L['smx'],L['smy'],L['sr'])
   drag(page,b0x,b0y,b1x,b1y,steps=22)
   ck(f'{width}/secondary spinner regrab',get(page)['model']['secondary']==[False,False,True],get(page)['model']['secondary'])
   page.locator('select[aria-label="Choose spinner"]').select_option('b')
   page.locator('select[aria-label="Choose sector"]').select_option('0')
   page.get_by_role('button',name='Mark WIN').first.click()
   ck(f'{width}/secondary keyboard assignment',get(page)['model']['secondary']==[True,False,True])
   ck(f'{width}/secondary selection retained',page.locator('select[aria-label="Choose spinner"]').input_value()=='b')
   # preset switching
   sel=page.locator('.f172-panel-label select');sel.select_option('y8');page.wait_for_timeout(120)
   ck(f'{width}/Y8 6 sectors',page.locator('[data-sector]').count()==6 and get(page)['model']['primary'].count(True)==2)
   # change sector count via selector
   page.locator('select[aria-label="Number of equal sectors"]').select_option('10')
   ck(f'{width}/editable sector count 10',page.locator('[data-sector]').count()==10 and get(page)['model']['primary'].count(True)==2)
   # reset preset
   page.get_by_role('button',name='Reset spinner').click()
   ck(f'{width}/reset reverts to 6',len(get(page)['model']['primary'])==6)
   page.get_by_role('button',name='Run 20 trials').click();page.wait_for_timeout(160)
   x=get(page)['model'];ck(f'{width}/simulation exactly 20',len(x['history'])==20)
   ck(f'{width}/simulation binary outcomes',all(isinstance(v,bool) for v in x['history']))
   page.get_by_role('button',name='Clear trials').click();ck(f'{width}/clear trials',len(get(page)['model']['history'])==0)
   sel.select_option('y9');page.wait_for_timeout(110)
   ck(f'{width}/Y9 8 sectors',len(get(page)['model']['primary'])==8 and get(page)['model']['primary'].count(True)==3)
   sel.select_option('y7');page.wait_for_timeout(110)
   page.get_by_role('button',name='Spin once').click();page.wait_for_timeout(150)
   ck(f'{width}/Y7 two spinner sampled',len(get(page)['model']['history'])==1)
   ck(f'{width}/no detached drag after tests',page.evaluate('NOVA.ui._drag===null'))
   # Challenge checking, wrong then right, next, wrong then right, next, right
   page.locator('.nova-tab[data-m="challenge"]').click();page.wait_for_timeout(200)
   ck(f'{width}/Challenge starts with 0 WIN',page.locator('[data-placed="a:0"]').count()==0 and page.locator('[data-placed="a:2"]').count()==0)
   page.get_by_role('button',name='Check',exact=True).click();ck(f'{width}/Challenge rejects too few',page.locator('.nova-fb.bad').count()>0)
   pick=page.locator('select[aria-label="Select spinner sector"]');pick.select_option('0');page.get_by_role('button',name='Mark WIN').first.click();pick.select_option('2');page.get_by_role('button',name='Mark WIN').first.click()
   page.get_by_role('button',name='Check',exact=True).click();ck(f'{width}/Challenge task0 correct',page.locator('.nova-fb.ok').count()>0)
   page.wait_for_timeout(850)
   ck(f'{width}/Challenge task1 advanced',page.evaluate('NOVA_F17_02_CONFIG._challenge.task()')==1)
   entry=page.locator('.nova-panel input').first
   entry.fill('0.333333');page.get_by_role('button',name='Check',exact=True).click()
   ck(f'{width}/Challenge rejects theory for experiment',page.locator('.nova-fb.bad').count()>0)
   entry.fill('0.35');page.get_by_role('button',name='Check',exact=True).click()
   ck(f'{width}/Challenge task1 correct',page.locator('.nova-fb.ok').count()>0)
   page.wait_for_timeout(850)
   ck(f'{width}/Challenge task2 advanced',page.evaluate('NOVA_F17_02_CONFIG._challenge.task()')==2)
   page.get_by_role('button',name='2 favourable pairs').click();page.get_by_role('button',name='Check',exact=True).click()
   ck(f'{width}/Challenge task2 correct',page.locator('.nova-fb.ok').count()>0)
   ck(f'{width}/final no JS errors',not errors,errors[-2:] if errors else None)
  except Exception as e:
   ck(f'{width}/unexpected exception',False,str(e)[:500]);traceback.print_exc()
  finally:page.close()
 b.close()
Path(__file__).resolve().parent / 'F17-02-STRESS-RESULTS.json'.write_text(json.dumps({'total':len(R),'pass':sum(t['passed'] for t in R),'fail':[t for t in R if not t['passed']],'tests':R},indent=2))
print('TOTAL',len(R),'PASS',sum(t['passed'] for t in R),'FAIL',sum(not t['passed'] for t in R))
