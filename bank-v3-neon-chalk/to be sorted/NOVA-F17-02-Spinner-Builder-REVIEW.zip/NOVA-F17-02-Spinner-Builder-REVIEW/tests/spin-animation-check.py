from playwright.sync_api import sync_playwright
from pathlib import Path
import json,math
p=Path(__file__).resolve().parents[1] / 'F17-02-Spinner-Builder-PREMIUM-REVIEW.html'
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 pg=b.new_page(viewport={'width':1280,'height':970},reduced_motion='no-preference')
 errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 pg.set_content(p.read_text());pg.locator('[data-m="explore"]').click();pg.wait_for_timeout(50)
 pg.get_by_role('button',name='Spin once').click();pg.wait_for_timeout(1700)
 out=pg.evaluate('''() => {const c=window.NOVA_F17_02_CONFIG._explore.get().model;const last=NOVA.events.history().filter(x=>x.type==='value'&&x.detail.key==='spinOutcome').at(-1).detail.value;const P=document.querySelector('[data-pointer="a"]')?.getAttribute('transform');const Q=document.querySelector('[data-pointer="b"]')?.getAttribute('transform');return {angle:c.angle,angleB:c.angleB,last, pointerA:P,pointerB:Q,spins:c.history.length}}''')
 ea=(out['last']['a']-.5)*360/4; eb=(out['last']['b']-.5)*360/3
 valid=abs((out['angle']-ea+180)%360-180)<.1 and abs((out['angleB']-eb+180)%360-180)<.1
 result=dict(passed=valid and not errors and out['spins']==1,valid_math=valid,js_errors=errors,obs=out)
 print(json.dumps(result,indent=2));Path(__file__).resolve().parent / 'spin-animation-result.json'.write_text(json.dumps(result,indent=2))
 b.close()
