# NOVA Maths V2 — F17-02 Spinner Builder — Review QA

**Build:** F17-02 · Probability and Sets · standalone premium review
**Status:** BUILT FOR OWNER REVIEW — NOT GOLD-APPROVED
**GitHub:** unchanged; no commits, pushes or uploads.
**HTML SHA-256:** `3901952640f82570239aec4500eabd1f4ecf6d6bfa69d6d07e4b6f0f64f60055`

## Source authority and visual inheritance
- Authoritative specification: `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md` → `F17-02 Spinner builder` (private `notdamien2009/maths-v2`).
- Handover: `bank-v3-neon-chalk/HANDOVER-v3.md` (consulted during F17 continuation).
- Original reference files recovered from the user's F14 family review ZIP: F14-01, F14-03, F14-13. Original F0/F2 shared core embedded in the F14 component preserved as the style authority.
- CSS keeps original embedded NOVA Chalk fonts, navy-purple stage, neon glass primitives, four-mode shell, helper dock and original mascot; F17-specific rules add only component layout/readout styling.
- Only one mascot is inside the stage; no external duplicate mascot, no decorative divider, no newly invented SVG renderer.

## Mathematics and lesson presets
| Preset | Primary spinner | Secondary spinner | Correct model |
|---|---|---|---|
| Y7-075 Combined events | 2 WIN / 4 equally likely | 1 WIN / 3 equally likely | independent event AND = 2 of 12 = **1/6** |
| Y8-073 Experimental and theoretical probability | 2 WIN / 6 equally likely | none | theory **1/3**; 7 wins / 20 observed gives **0.35**, not the theory |
| Y9-042 Probability models | 3 WIN / 8 equally likely | none | **3/8 = 0.375** |

The standalone renders traditional stacked chalk fractions in the stage readout. The underlying sector model is an exact Boolean event mask, and theoretical probability derives from favourable sector count divided by total equally sized sectors. Combined probabilities multiply independent outcomes. Trial results are sampled through the original seeded `NOVA.rng` API and do not change theoretical chance.

## Four modes and inspectable evidence
- **WATCH:** six named steps with `NOVA.Timeline`, animated focus flashes via `NOVA.motion` and Sir Bob narration slots. Screens: `screenshots/F17-02-380-watch.png` and `screenshots/F17-02-1280-watch.png`.
- **GUIDED:** structured concept sequence and questions, replay/step controls. Screens: `screenshots/F17-02-380-guided.png` and `screenshots/F17-02-1280-guided.png`.
- **EXPLORE:** reusable spinner sectors (3, 4, 5, 6, 8, 10); green WIN palette using core `NOVA.ui.svgDrag`; snap zones, re-grab, invalid-drop return, red removal target, accessible dropdown/button equivalent, independent B spinner, spin once/20/100, empirical/theory comparison. Screens: `screenshots/F17-02-380-explore.png` and `screenshots/F17-02-1280-explore.png`.
- **CHALLENGE:** task 1 builds exactly two favourable outcomes on a four-sector spinner; task 2 distinguishes relative frequency 7/20 from theoretical 2/6; task 3 counts independent favourable pairs 2×1 out of 4×3. Each has error-specific feedback and hint. Screens: `screenshots/F17-02-380-challenge.png` and `screenshots/F17-02-1280-challenge.png`.

## Browser results (executed)
- `tests/F17-02-STRESS-RESULTS.json`: **98/98 PASS; 0 FAIL** using headless Chromium and Playwright.
- Viewports 380 and 1280, modes Watch/Guided/Explore/Challenge; stage original mascot, original seven Y7 wedges, no JavaScript errors.
- Genuine mouse drags (not simulated `onDrop` callbacks): green palette onto sector, green chip regrab between sectors, 1-step fast pointer snap, 1-step fast remove, invalid zone return, red removal zone, second-spinner drag and Escape cancellation. No drag state stranded.
- Keyboard-equivalent sector marking and removal, secondary selection persistence, preset changes Y7/Y8/Y9, sector-count changes, reset, batch-trial history and seeded binary outcomes checked.
- Challenge wrong-answer and right-answer branches tested, with advancement and no JS exceptions.
- `tests/spin-animation-result.json`: **PASS**, standard-motion animated real spin test. Both independent pointer needles landed at the exact angles for the emitted sector indices, zero JS errors, trial history recorded.

## One targeted reliability correction to the embedded F14 core
**What was found:** Shared F2-style `NOVA.ui.svgDrag` calls `setPointerCapture()` **before** moving the grabbed SVG element to the root for lift; in Chromium reparenting can invalidate capture on a one-movement fast drag. This reproduces the F17-01 fast mouse concern but is isolated to this standalone build.

**The repair:** One explicit `setPointerCapture(e.pointerId)` with `hasPointerCapture` check directly **after** `svg.appendChild(el)` in the embedded core. The rest of the original shared drag system, zones, lift, spring-back and event contracts remain unchanged. Evidence: `tests/F17-02-STRESS-RESULTS.json` includes the fast drag, fast removal and Escape checks; the engine HTML contains the searchable comment `F17-02 v3.6.2 capture repair`. **No GitHub core files modified.** This local patch should be considered for canonical integration only with owner approval.

## Outstanding owner review
- Compare directly with canonical F0-02 and F2-03 at both provided viewports, especially diagram size, glow balance and mascot proportions.
- Stress test on a physical touch screen and additional mobile browsers, which this automated Chromium pass does not prove.
- Confirm Year 7 combined-spinner presentation and interaction expectations against your lesson plans.
- This is a premium candidate **awaiting owner review**, not a GOLD-approved engine.
