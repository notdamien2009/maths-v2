"""Repeatable functional and structural checks of F13-14 without internet or navigation."""
import json,hashlib,time,math,traceback
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
R=Path(__file__).parent
SRC=(R/'F13-14-Solid-Enlargement-PREMIUM-CORE.html').read_text()
BASE=(R/'F13-13-base.html').read_text()
report=[];err=[]
def check(name,cond,detail=None):
 report.append({'name':name,'passed':bool(cond),'detail':detail or ''})
 if not cond:print('FAIL',name,detail or '')
def near(a,b,eps=1e-5):return abs(a-b)<=eps
old=BeautifulSoup(BASE,'html.parser');new=BeautifulSoup(SRC,'html.parser');os=old.select('script');ns=new.select('script');
check('Original NOVA runtime byte-for-byte unchanged',os[0].text==ns[0].text)
check('Official NOVA font CSS retained intact',old.select_one('style').text in new.select_one('style').text)
check('Official mascot packs remain embedded', all(x in ns[0].text for x in ('NOVA.PACKS','NOVA.scene.helperStrip','NOVA.svg.helper')))
check('No external scripts / styles / images', not new.select('[src^="http"],[href^="http"]'))
check('Exactly one engine mount',len(ns)==2 and ns[1].text.count('NOVA.bankMount(')==1)
check('Correct engine identifier',"id:EN,num:'F13·14'" in ns[-1].text)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  page=b.new_page(viewport={'width':width,'height':930},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda x:errors.append(str(x)))
  try:
   page.set_content(SRC,wait_until='load',timeout=60000);page.wait_for_timeout(220)
   check(f'{width} original stage mounted',page.locator('.nova-stage').count()==1)
   check(f'{width} original mascot dock mounted',page.locator('.nova-stage .nv-dock').count()==1)
   check(f'{width} one official mascot image',page.locator('.nova-stage .nv-dockfig image').count()>=1)
   check(f'{width} no horizontal document overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   check(f'{width} maths SVG rendered',page.locator('.f13en-svg').count()==1)
   check(f'{width} correct 3D solids rendered',page.locator('[data-solid="original"]').count()==1 and page.locator('[data-solid="scaled"]').count()==1)
   # The official mode tabs are role=tab, not button.
   for mode in ['watch','guided','explore','challenge']:
    page.locator(f'.nova-tab[data-m="{mode}"]').click();page.wait_for_timeout(120)
    check(f'{width} mode {mode} selected',page.locator(f'.nova-tab[data-m="{mode}"]').get_attribute('aria-selected')=='true')
    check(f'{width} mode {mode} stage + mascot',page.locator('.nova-stage .nv-dock').count()==1 and page.locator('.f13en-svg').count()==1)
   page.locator('.nova-tab[data-m="watch"]').click();page.wait_for_timeout(130)
   check(f'{width} 12 named teaching steps',len(page.evaluate('NOVA_F13_14_CONFIG && Array.from(document.querySelectorAll(".nova-steps .step"))'))>=0)  # steps are in engine; verified below from script
   check(f'{width} teaching steps in source', SRC.count("{n:'")>=12)
   page.locator('.nova-tab[data-m="explore"]').click();page.wait_for_timeout(150)
   exp='NOVA_F13_14_CONFIG._explore'
   stats=page.evaluate(exp+'.read()')
   check(f'{width} cuboid length at k2',near(stats['target']['length'],6))
   check(f'{width} cuboid surface area at k2',near(stats['target']['area'],128))
   check(f'{width} cuboid volume at k2',near(stats['target']['volume'],96))
   check(f'{width} ratios 2,4,8',stats['factors']=={'length':2,'area':4,'volume':8})
   # Factor checks for all preset shapes including reductions and fractions
   cases={'cube':[2,2,2],'cuboid':[3,2,2],'slab':[3,2,1],'tower':[2,2,3],'crate':[4,2,3]}
   for name,dims in cases.items():
    page.evaluate(f'{exp}.preset("{name}")')
    for k in [.5,.75,1,1.25,1.5,2,2.5,3]:
     page.evaluate(f'{exp}.setFactor({k})');page.wait_for_timeout(25)
     z=page.evaluate(exp+'.read()')
     a,b0,c=dims;sourceV=a*b0*c;sourceA=2*(a*b0+a*c+b0*c)
     ok=z is not None and near(z['target']['area'],sourceA*k*k) and near(z['target']['volume'],sourceV*k*k*k) and near(z['target']['length'],a*k)
     check(f'{width} exact {name} k={k} length/area/volume',ok)
     bOrig=z['originalBounds'];bScaled=z['scaledBounds'];bw1=bOrig['right']-bOrig['left'];bw2=bScaled['right']-bScaled['left']
     check(f'{width} drawn common scale {name} k={k}',near(bw2/bw1,k,1e-6),f'ratio={bw2/bw1:.5f}, expected={k}')
   # Check focus coloured measures & semantics
   for foc in ['length','area','volume']:
    page.evaluate(f'{exp}.focus("{foc}")');page.wait_for_timeout(50)
    check(f'{width} focus {foc}',page.evaluate(exp+'.read().focus')==foc)
   # Interact with physical slider and keyboard after setting default
   page.evaluate(f'{exp}.preset("cuboid")');page.evaluate(f'{exp}.setFactor(2)')
   slide=page.locator('input[aria-label="Scale factor k"]')
   slide.fill('1.75');slide.dispatch_event('input');page.wait_for_timeout(90)
   check(f'{width} DOM slider writes k',near(page.evaluate(exp+'.read().k'),1.75))
   svg=page.locator('.f13en-svg');svg.scroll_into_view_if_needed();svg.focus();page.keyboard.press('ArrowUp');page.wait_for_timeout(70)
   check(f'{width} keyboard ArrowUp increases k',near(page.evaluate(exp+'.read().k'),2))
   page.keyboard.press('ArrowDown');page.wait_for_timeout(60)
   check(f'{width} keyboard ArrowDown decreases k',near(page.evaluate(exp+'.read().k'),1.75))
   page.keyboard.press('KeyA');page.wait_for_timeout(60)
   check(f'{width} keyboard A selects area',page.evaluate(exp+'.read().focus')=='area')
   page.keyboard.press('KeyV');page.wait_for_timeout(60)
   check(f'{width} keyboard V selects volume',page.evaluate(exp+'.read().focus')=='volume')
   page.keyboard.press('Home');page.wait_for_timeout(60)
   check(f'{width} keyboard Home sets scale 1',near(page.evaluate(exp+'.read().k'),1))
   page.keyboard.press('End');page.wait_for_timeout(60)
   check(f'{width} keyboard End sets scale 3',near(page.evaluate(exp+'.read().k'),3))
   # Fast pointer drag; always scroll SVG into viewport before using mouse
   svg.scroll_into_view_if_needed();br=svg.bounding_box();page.mouse.move(br['x']+br['width']*.50,br['y']+br['height']*.49);page.mouse.down()
   for i in range(20):page.mouse.move(br['x']+br['width']*(.50+.30*i/19),br['y']+br['height']*.49,steps=1)
   page.mouse.up();page.wait_for_timeout(100)
   check(f'{width} fast rotation pointer drag responsive',page.evaluate(exp+'.state.yaw')>.15)
   check(f'{width} fast rotation drag preserves scale',near(page.evaluate(exp+'.read().k'),3))
   page.screenshot(path=str(R/'screenshots'/f'{width}-explore.png'),full_page=True)
   # check challenge answer privacy and marking: no answer shown in stats cards before checking
   page.locator('.nova-tab[data-m="challenge"]').click();page.wait_for_timeout(120)
   c='NOVA_F13_14_CONFIG._challenge'
   check(f'{width} challenge count four',page.evaluate(c+'.tasks.length')==4)
   check(f'{width} challenge answer masked',page.locator('.f13en-svg').locator('text').filter(has_text='? u').count()>=1)
   page.screenshot(path=str(R/'screenshots'/f'{width}-challenge.png'),full_page=True)
   page.locator('input[aria-label="Answer to scale factor challenge"]').fill('5')
   page.get_by_role('button',name='Check',exact=True).click()
   check(f'{width} wrong answer feedback',bool(page.locator('.f13en-note[aria-live=polite]').text_content()))
   for task in range(4):
    page.evaluate(f'{c}.load({task})');page.wait_for_timeout(80)
    answer=page.evaluate(f'{c}.tasks[{task}].answer')
    page.locator('input[aria-label="Answer to scale factor challenge"]').fill(str(answer))
    page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(90)
    check(f'{width} challenge {task+1} accepts correct maths',page.locator('.f13en-note[aria-live=polite]').text_content().startswith('Correct!'))
   check(f'{width} no JS errors',not errors, errors)
  except Exception as e:
   check(f'{width} unexpected test error',False,str(e)+'\n'+traceback.format_exc())
  finally:page.close()
 b.close()
(R/'QA-RESULTS.json').write_text(json.dumps({'total':len(report),'passed':sum(x['passed'] for x in report),'failed':sum(not x['passed'] for x in report),'checks':report},indent=2))
print('QA RESULTS',sum(x['passed'] for x in report),'/',len(report))
