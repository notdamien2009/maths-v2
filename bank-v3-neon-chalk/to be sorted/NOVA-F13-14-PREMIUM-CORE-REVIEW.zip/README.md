# F13-14 · SOLID ENLARGEMENT — Premium review build

Open `F13-14-Solid-Enlargement-PREMIUM-CORE.html` locally in a modern browser.

Modes: Watch (12 guided teaching states), Guided (step-by-step interaction), Explore (five true-scale cuboids, adjustable k from 0.5 to 3), Challenge (four marked questions).

Explore keyboard: Up/Down change scale factor by 0.25; Left/Right rotate; Home k=1; End k=3; L/A/V switch teaching focus. Mouse or touch drags rotate the solids. Mouse or touch slide the scale factor.

`source/build.py` reconstructs the standalone HTML from unchanged F13-13 base + `source/engine.js` + `source/style.css`. Run `python source/build.py` from any directory (the script reads files from its own directory). The base file is included inside `source/`.

The official NOVA runtime, background, fonts and mascot are preserved. No GitHub changes.

See `QA-REPORT.md` and `QA-RESULTS.json` for evidence.
