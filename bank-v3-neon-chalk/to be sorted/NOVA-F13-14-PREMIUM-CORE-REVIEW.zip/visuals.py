from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).parent
content=(R/'F13-14-Solid-Enlargement-PREMIUM-CORE.html').read_text()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (1280,380):
  page=b.new_page(viewport={'width':width,'height':950},device_scale_factor=1)
  page.set_content(content,wait_until='load',timeout=60000)
  page.wait_for_timeout(200)
  page.screenshot(path=str(R/'screenshots'/f'{width}-watch-initial.png'),full_page=True)
  page.locator('.nova-tab[data-m="explore"]').click();page.wait_for_timeout(170)
  p='NOVA_F13_14_CONFIG._explore'
  for key,k,focus in [('cube',2,'length'),('cube',2,'area'),('cube',2,'volume'),('tower',.5,'volume'),('crate',1.5,'area'),('cuboid',3,'volume')]:
   page.evaluate(f'{p}.preset("{key}")');page.evaluate(f'{p}.setFactor({k})');page.evaluate(f'{p}.focus("{focus}")');page.wait_for_timeout(160)
   page.screenshot(path=str(R/'screenshots'/f'{width}-{key}-{str(k).replace(".","p")}-{focus}.png'),full_page=True)
  page.locator('.nova-tab[data-m="challenge"]').click();page.wait_for_timeout(130)
  page.screenshot(path=str(R/'screenshots'/f'{width}-challenge-masked.png'),full_page=True)
  page.close()
 b.close()
print(len(list((R/'screenshots').glob('*.png'))),'screenshots')
