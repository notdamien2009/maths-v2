# NOVA F17-05 — Sample-Space Grid — QA REVIEW

Status: **REVIEW BUILD — NOT GOLD-APPROVED**. No GitHub changes were made.
Source: GitHub master `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, Family F17, F17-05 entry. Visual foundation is the exact embedded shared NOVA core from the previous F17-04 review build (core JavaScript compared byte-identical).

## Evidence summary

- **132/132** Chromium reduced-motion mathematical/interaction assertions passed at 380px and 1280px: `tests/F17-05-STRESS-RESULTS.json` and `tests/F17-05-STRESS-LOG.txt`.
- **28/28** Chromium normal-motion timeline, keyboard, Challenge answer-hiding and JavaScript checks passed at both widths: `tests/F17-05-NORMAL-MOTION-RESULTS.json`.
- **8/8** four-mode/viewport browser screenshots confirmed one stage SVG and one in-stage mascot, zero JS errors and no page-level horizontal overflow: `tests/F17-05-SMOKE.json`, `screenshots/F17-05-380-*.png`, `screenshots/F17-05-1280-*.png`.
- Six extra screenshots cover alternate presets at each width, for 14 screenshots in total.
- HTML SHA-256: `d96fa89307ab9b5f1aa09571c3a32b13df315891f3c7868dbb99c6d9edcb0ef1`.

## Specification and evidence trace

| Requirement | Evidence | Status |
|---|---|---|
| Approved NOVA base, neon tube and chalk writing | HTML first embedded `<script>` unchanged from F17-04; source calls `NOVA.neonBox`, `NOVA.neonLine`, `NOVA.neonRing`, `NOVA.chalkText` in `f175_custom.js` (lines 30–86) | Implemented; screenshot review |
| No second mascot, inside bottom-right dock | `NOVA.scene.helperStrip` from core at `f175_custom.js` line 90; 8/8 mode/viewport browser assertions | Passed |
| All four modes | `steps`, `drawStep`, `explore`, `challenge` and NOVA `bankMount`; smoke JSON 8 screenshots | Passed |
| Six named teacher steps and navigation | `f175_custom.js` lines 94–102, normal-motion 28/28 | Passed |
| Exact model space: every outcome once | unique `[data-cell]` key `(r,c)` in source line 44; 4 presets x 2 viewports; no duplicate keys | Passed |
| Probability is favourable / full sample space | Pure predicate-driven `favourable`, `getCounts`; 1/6, 2/4, 3/12, 6/36 in 4 presets | Passed |
| Traditional stacked fractions | `fractionSVG` source line 21 (numerator, horizontal neon bar, denominator); `fracSpan` source line 22 | Passed visual review |
| Smooth F0 SVG dragging with valid, invalid, re-grab and remove | `NOVA.ui.svgDrag` in source line 75, marked-token drag and removal source line 79; actual pointer tests at both widths | Passed |
| Escape cancels and no stranded markers | Core `NOVA.ui.cancelDrag` plus actual browser tests; `stress` results | Passed |
| Keyboard equivalent / one roving grid tab stop | Source line 47, Arrow movement and Enter marking; normal-motion checks | Passed |
| Misconception-specific Challenge feedback | Four tasks at source line 127 and wrong/right browser marking assertions | Passed |
| Challenge answers not displayed beforehand | `o.challenge` guards in stage; normal-motion assertions for hidden probability | Passed |
| Two real viewport sizes | Screenshots show 380px and 1280px, all modes and all model configurations | Passed visual inspection |
| Student-visible dev markup hidden | Core has collapsed `details.nv-dev`; studio notes are in spec developer card | Passed structural inspection |
| Animation and reduced motion | NOVA timeline and `NOVA.motion.tween`; normal motion and reduced motion browser modes tested | Passed |
| Physical touch gestures on a real device | Only Chromium mouse and keyboard tested, no physical touch device | **Not tested** |
| Other browsers and printer output | No Safari/Firefox/physical print test run | **Not tested** |

## Exact mathematical presets

1. `y7list` — coin × 3-sector fair spinner. Six ordered pairs; Heads AND blue = 1/6.
2. `y7events` — two fair coins. Four ordered pairs; exactly one head = 2/4 = 1/2.
3. `y8` — fair coin × six-sided die. Twelve ordered pairs; Heads AND even = 3/12 = 1/4.
4. `y9` — two fair dice. Thirty-six ordered pairs; sum seven = 6/36 = 1/6.

The outcome cells retain ordered pairs, not unordered combinations, so dice pair reverses are counted separately.

## Corrected issues during this run

- Fixed overlapping row/column headings, probability labels and mobile stacked fraction after 380px / 1280px screenshot inspection.
- Removed advance display of the exact answer from Challenge and delayed solution display during Watch teaching steps.
- Added single roving `tabindex` and arrow-key navigation in the grid.
- Preserved the F17-03 local SVG-drag capture and precision fixes inherited from the unchanged reviewed shared core.

## Exclusions

No final owner sign-off and no GOLD status. Screen-reader quality, real device touch gestures, printed worksheets, Firefox and Safari require separate testing before production acceptance.

Test scripts in `tests/` were run with Python Playwright + Linux Chromium. Original stress scripts expect scratch output paths under `/mnt/data/f17_work`; adapt those paths when running locally.
