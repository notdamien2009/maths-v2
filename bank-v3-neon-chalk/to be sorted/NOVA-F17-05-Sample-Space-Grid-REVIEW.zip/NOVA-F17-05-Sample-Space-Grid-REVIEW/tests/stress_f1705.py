from playwright.sync_api import sync_playwright
from pathlib import Path
import json,traceback,math
html=(Path(__file__).resolve().parents[1] / 'F17-05-Sample-Space-Grid-PREMIUM-REVIEW.html').read_text();tests=[]
def ck(name,ok,data=None):
 tests.append({'test':name,'passed':bool(ok),'detail':data});print(('PASS ' if ok else 'FAIL ')+name+((' '+str(data)[:130]) if data is not None else ''),flush=True)
def st(page):return page.evaluate('NOVA_F17_05_CONFIG._explore.get()')
def xy(page,x,y):return page.evaluate('''v=>{let s=document.querySelector('svg.f175-plot'),p=s.createSVGPoint();p.x=v[0];p.y=v[1];p=p.matrixTransform(s.getScreenCTM());return {x:p.x,y:p.y}}''',[x,y])
def drag(page,x,y,u,v,steps=4):
 page.locator('svg.f175-plot').scroll_into_view_if_needed();a=xy(page,x,y);b=xy(page,u,v)
 page.mouse.move(a['x'],a['y']);page.mouse.down();page.mouse.move(b['x'],b['y'],steps=steps);page.mouse.up();page.wait_for_timeout(570)
with sync_playwright() as pl:
 b=pl.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (1280,380):
  page=b.new_page(viewport={'width':width,'height':1050},reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  try:
   page.set_content(html,wait_until='domcontentloaded',timeout=60000)
   for mode in ('watch','guided','explore','challenge'):
    page.locator(f'.nova-tab[data-m="{mode}"]').click();page.wait_for_timeout(70)
    ck(f'{width}/{mode} stage svg',page.locator('svg.f175-plot').count()==1)
    ck(f'{width}/{mode} single in-stage mascot',page.locator('.nova-stage .nv-dock').count()==1)
    ck(f'{width}/{mode} no JS errors',len(errors)==0,errors[-1] if errors else None)
   ck(f'{width} no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   page.locator('.nova-tab[data-m="explore"]').click()
   state=st(page)
   ck(f'{width}/initial grid has six outcomes',state['total']==6 and len(page.locator('svg.f175-plot [data-cell]').all())==6,state)
   ck(f'{width}/Y7-074 true event exactly one outcome',len(state['favourable'])==1 and state['probability']==1/6)
   geom=(67,175,275,265,2,3,115,679,293) if width==380 else (161,137,516,342,2,3,273,635,660)
   gx,gy,gw,gh,R,C,px,py,remx=geom
   cell=lambda r,c:(gx+(c+.5)*gw/C,gy+(r+.5)*gh/R)
   # Fast mouse drop on correct cell (0,1)
   drag(page,px,py,*cell(0,1),steps=1)
   state=st(page);ck(f'{width}/fast drag to valid cell',state['marked']==['0-1'],state['marked'])
   ck(f'{width}/exact event selection detected',state['exact'],state['exact'])
   ck(f'{width}/placed marker exists',page.locator('svg.f175-plot [data-placed]').count()==1)
   drag(page,*cell(0,1),*cell(1,1),steps=3)
   state=st(page);ck(f'{width}/regrab to another cell',state['marked']==['1-1'],state['marked'])
   ck(f'{width}/wrong marked pair does not count as correct',not state['exact'] and state['hits']==0)
   drag(page,*cell(1,1),remx,py,steps=8)
   state=st(page);ck(f'{width}/drag to red removal tray',not state['marked'],state['marked'])
   ck(f'{width}/no stranded pointer after removal',page.evaluate('NOVA.ui._drag===null'))
   drag(page,px,py,*cell(0,1),steps=2)
   ck(f'{width}/re-add marker',st(page)['marked']==['0-1'])
   # invalid drop onto plot title zone, not a target
   drag(page,*cell(0,1),190 if width==380 else 423,79 if width==380 else 64,steps=3)
   ck(f'{width}/invalid drop keeps the same marker',st(page)['marked']==['0-1'],st(page)['marked'])
   page.locator('svg.f175-plot').scroll_into_view_if_needed();a=xy(page,*cell(0,1));dest=xy(page,remx,py)
   page.mouse.move(a['x'],a['y']);page.mouse.down();page.mouse.move(dest['x'],dest['y'],steps=4);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(520)
   ck(f'{width}/Escape restores marker',st(page)['marked']==['0-1'],st(page)['marked'])
   ck(f'{width}/Escape clears drag',page.evaluate('NOVA.ui._drag===null'))
   page.locator('select[aria-label="Outcome cell"]').select_option('1-2');page.get_by_role('button',name='Mark / unmark').click()
   ck(f'{width}/keyboard select outcome',set(st(page)['marked'])=={'0-1','1-2'})
   page.get_by_role('button',name='Remove selected').click()
   ck(f'{width}/keyboard remove selected',st(page)['marked']==['0-1'])
   page.get_by_role('button',name='Clear markers').click();ck(f'{width}/clear markers',len(st(page)['marked'])==0)
   page.get_by_role('button',name='Reveal correct event').click();ck(f'{width}/reveal correct full event',st(page)['exact'])
   configs={'y7list':(2,3,6,1), 'y7events':(2,2,4,2), 'y8':(2,6,12,3),'y9':(6,6,36,6)}
   for pre,(r,c,total,yes) in configs.items():
    page.locator('select[aria-label="Lesson preset"]').select_option(pre)
    a=st(page)
    ck(f'{width}/{pre} correct rows and columns',a['total']==r*c and page.locator('svg.f175-plot [data-cell]').count()==total,(a['total'],page.locator('svg.f175-plot [data-cell]').count()))
    ck(f'{width}/{pre} exact favourable count',len(a['favourable'])==yes)
    ck(f'{width}/{pre} correct true probability',abs(a['probability']-yes/total)<1e-12)
    ck(f'{width}/{pre} reset selection on preset',len(a['marked'])==0)
    page.get_by_role('button',name='Reveal correct event').click()
    ck(f'{width}/{pre} reveal selects precisely correct cells',st(page)['exact'] and len(st(page)['marked'])==yes)
    ck(f'{width}/{pre} all cells have distinct keys',len(set(page.locator('svg.f175-plot [data-cell]').evaluate_all('(x)=>x.map(y=>y.getAttribute("data-cell"))')))==total)
   page.locator('.nova-tab[data-m="challenge"]').click()
   for i,(wrong,right) in enumerate([('5','6'),('1','2'),('6','3'),('7','1/6')]):
    inp=page.locator('.nova-panel input').first;inp.fill(wrong);page.get_by_role('button',name='Check',exact=True).click();ck(f'{width}/challenge {i+1} rejects wrong',page.locator('.nova-fb.bad').count()>0)
    inp.fill(right);page.get_by_role('button',name='Check',exact=True).click();ck(f'{width}/challenge {i+1} accepts correct',page.locator('.nova-fb.ok').count()>0)
    if i<3:page.wait_for_timeout(860);ck(f'{width}/challenge {i+1} advances',page.evaluate('NOVA_F17_05_CONFIG._challenge.task()')==i+1)
   ck(f'{width}/all mode and interaction testing no JavaScript errors',len(errors)==0,errors)
  except Exception as e:
   ck(f'{width}/uncaught exception',False,str(e));traceback.print_exc()
  finally:page.close()
 b.close()
Path('/mnt/data/f17_work/F17-05-STRESS-RESULTS.json').write_text(json.dumps({'total':len(tests),'passed':sum(x['passed'] for x in tests),'failed':[x for x in tests if not x['passed']],'tests':tests},indent=2,default=str))
print('TOTAL',len(tests),'PASSED',sum(x['passed'] for x in tests),'FAILED',sum(not x['passed'] for x in tests))
