from playwright.sync_api import sync_playwright
from pathlib import Path
import json
html=(Path(__file__).resolve().parents[1] / 'F17-05-Sample-Space-Grid-PREMIUM-REVIEW.html').read_text()
all=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  page=b.new_page(viewport={'width':width,'height':1000},reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  try:
   page.set_content(html,wait_until='domcontentloaded',timeout=50000)
   for mode in ['watch','guided','explore','challenge']:
    try:
     page.locator(f'#F17-05 .nova-tab[data-m="{mode}"]').click(timeout=6000)
     page.wait_for_timeout(150)
     vals={'width':width,'mode':mode,'plot':page.locator('#F17-05 .nova-stage svg.f175-plot').count(),'dock':page.locator('#F17-05 .nova-stage .nv-dock').count(),'jsErrors':errors[:],'pageScrollWidth':page.evaluate('document.documentElement.scrollWidth'),'viewWidth':width,'cells':page.locator('#F17-05 .nova-stage [data-cell]').count()}
     page.locator('#F17-05 .nova-stage').screenshot(path=f'/mnt/data/f17_work/F17-05-{width}-{mode}.png',animations='disabled',timeout=20000)
     print(vals,flush=True);all.append(vals)
    except Exception as e:
     vals={'width':width,'mode':mode,'error':str(e)[:1000],'jsErrors':errors};all.append(vals);print(vals,flush=True)
  finally:page.close()
 b.close()
Path('/mnt/data/f17_work/F17-05-SMOKE.json').write_text(json.dumps(all,indent=2))
