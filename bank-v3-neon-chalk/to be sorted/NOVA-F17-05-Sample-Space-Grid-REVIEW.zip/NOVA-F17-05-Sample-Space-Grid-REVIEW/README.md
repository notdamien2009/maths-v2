# NOVA Maths V2 — F17-05 Sample-Space Grid

**For review; not GOLD-approved.**

Open `F17-05-Sample-Space-Grid-PREMIUM-REVIEW.html` directly in a modern browser. Everything required for the visual engine, mascot, embedded chalk fonts, F0 timeline and interaction kit is in this HTML; no external JS or CSS dependency is required.

Explore has four presets: Y7 systematic listing, Y7 combined events, Y8 coin × die, and Y9 two dice. Mark every ordered outcome that satisfies the event by mouse drag, direct cell activation or keyboard selection, then compare your selection with the exact result by choosing Reveal correct event. Watch has narrated step hooks, Guided presents scaffolding and Challenge has four checking tasks.

`QA-REPORT.md` contains evidence and explicit untested areas. `screenshots/` contains 14 examples. `tests/` contains the Chromium test evidence and runnable Python sources (adjust sandbox paths to local paths).

No GitHub modifications. Owner review is still required.
