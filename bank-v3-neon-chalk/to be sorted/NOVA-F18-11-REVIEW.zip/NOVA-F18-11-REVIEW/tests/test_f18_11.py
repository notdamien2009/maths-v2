from playwright.sync_api import sync_playwright
from pathlib import Path
import json
f='http://127.0.0.1:8765/F18-11-bounds-and-accuracy.html'
shots=Path('/mnt/data/f18_11_qa');shots.mkdir(exist_ok=True)
checks=[]
def check(name,condition,more=''):
 checks.append({'name':name,'ok':bool(condition),'more':more});print(('PASS' if condition else 'FAIL'),name,more)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--disable-web-security'])
 for width in (380,1280):
  ctx=browser.new_context(viewport={'width':width,'height':960},device_scale_factor=1,reduced_motion='reduce')
  page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(Path('/mnt/data/F18-11-bounds-and-accuracy.html').read_text(),wait_until='domcontentloaded');page.wait_for_timeout(180)
  check(f'{width} no page errors',not errors,str(errors)[:700]);check(f'{width} mounted',page.locator('#F18-11').count()==1)
  check(f'{width} no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'),str(page.evaluate('[document.documentElement.scrollWidth,innerWidth]')))
  for mode in ('watch','guided','explore','challenge'):
   # inspect accessible buttons
   tabs=page.locator('#F18-11 .nova-tabs button');print('TABS',tabs.all_text_contents()) if mode=='watch' and width==380 else None
   target=tabs.filter(has_text=mode.capitalize())
   if target.count():target.first.click();page.wait_for_timeout(120)
   check(f'{width} {mode} stage',page.locator('#F18-11 .nova-stage .f1811-svg').count()==1)
   page.locator('#F18-11 .nova-stage').screenshot(path=str(shots/f'F18-11_{width}_{mode}.png'),animations='disabled')
  ctx.close()
 browser.close()
Path('/mnt/data/f18_11_qa/smoke.json').write_text(json.dumps(checks,indent=2))
print('SUM',sum(x['ok'] for x in checks),'/',len(checks))
