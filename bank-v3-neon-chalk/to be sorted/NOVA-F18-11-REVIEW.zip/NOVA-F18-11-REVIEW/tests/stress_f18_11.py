import json,math
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path('/mnt/data');QA=R/'f18_11_qa';QA.mkdir(exist_ok=True)
checks=[]
def ck(name,ok,ev=''):
 checks.append({'name':name,'ok':bool(ok),'evidence':str(ev)[:350]});
 if not ok:print('FAIL',name,ev,flush=True)
def ev(p,j):return p.evaluate(j)
def mode(p,name):p.locator('#F18-11 .nova-tabs button').filter(has_text=name).click();p.wait_for_timeout(45)
def coords(p,x,y):
 r=ev(p,'() => {let e=document.querySelector("#F18-11 .f1811-svg"),r=e.getBoundingClientRect(),v=e.viewBox.baseVal;return {x:r.x,y:r.y,w:r.width,h:r.height,vw:v.width,vh:v.height}}')
 return (r['x']+x*r['w']/r['vw'],r['y']+y*r['h']/r['vh'])
def boundstate(p):return ev(p,'NOVA_F18_11_CONFIG._explore.state()')
def drag(p,which,tick=None,rem=False,invalid=False,steps=12):
 sel=f'#F18-11 .f1811-handle[data-bound="{which}"]';l=p.locator(sel);l.scroll_into_view_if_needed();r=l.bounding_box();src=(r['x']+r['width']/2,r['y']+r['height']/2)
 dst=coords(p,218,552) if rem else (coords(p,220,125) if invalid else coords(p,48+86*tick,254))
 p.mouse.move(*src);p.mouse.down();p.mouse.move(*dst,steps=steps);p.mouse.up();p.wait_for_timeout(80)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  p=browser.new_page(viewport={'width':width,'height':960},reduced_motion='reduce');errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.set_content((R/'F18-11-bounds-and-accuracy.html').read_text(),wait_until='domcontentloaded');p.wait_for_timeout(150)
  ck(f'{width} core numberline shared',ev(p,'typeof NOVA.numberLine')=='function')
  ck(f'{width} six presets',len(ev(p,'Object.keys(NOVA_F18_11_CONFIG.presets)'))==6)
  ck(f'{width} no external assets',ev(p,'document.querySelectorAll("script[src],link[rel=stylesheet]").length')==0)
  for tab in ['Watch','Guided','Explore','Challenge']:
   mode(p,tab)
   ck(f'{width} {tab} scene renders',p.locator('#F18-11 .f1811-svg').count()==1)
   ck(f'{width} {tab} one mascot in stage',p.locator('#F18-11 .nova-stage .nv-dock').count()==1)
   ck(f'{width} {tab} canonical number line',p.locator('#F18-11 .nova-stage .nv-numberline').count()==1)
   ck(f'{width} {tab} no overflow',ev(p,'document.documentElement.scrollWidth<=innerWidth+1'))
  mode(p,'Explore')
  records={'ruler':(11.5,12.5),'decimal':(3.65,3.75),'mass':(245,255),'map':(1150,1250),'rectangle':(7.5,8.5),'speed':(1.95,2.05)}
  for key,(lo,hi) in records.items():
   ev(p,f'NOVA_F18_11_CONFIG._explore.select("{key}")');t=boundstate(p)
   ck(f'{width} preset {key} bounds',math.isclose(t['lower'],lo,abs_tol=1e-7) and math.isclose(t['upper'],hi,abs_tol=1e-7),t)
   ck(f'{width} preset {key} canon line',p.locator('#F18-11 .nv-numberline').count()==1)
   if key=='rectangle':ck(f'{width} area lower upper',all(math.isclose(v,w) for v,w in zip(t['derived'][:2],[33.75,46.75])),t)
   if key=='speed':ck(f'{width} speed derived',math.isclose(t['derived'][0],119.5/2.05) and math.isclose(t['derived'][1],120.5/1.95),t)
  ev(p,'NOVA_F18_11_CONFIG._explore.select("ruler")')
  drag(p,'lower',1);ck(f'{width} real mouse lower drag',boundstate(p)['index']==[1,4],boundstate(p))
  drag(p,'upper',3,steps=3);ck(f'{width} fast mouse upper drag',boundstate(p)['index']==[1,3],boundstate(p))
  drag(p,'lower',2,steps=4);ck(f'{width} mouse regrab move',boundstate(p)['index']==[2,3],boundstate(p))
  drag(p,'lower',rem=True);ck(f'{width} removal zone',boundstate(p)['index']==[None,3],boundstate(p))
  drag(p,'lower',1);ck(f'{width} removed handle can be regrabbed',boundstate(p)['index']==[1,3],boundstate(p))
  drag(p,'upper',invalid=True,steps=3);ck(f'{width} invalid drop recovers',boundstate(p)['index']==[1,3],boundstate(p))
  ck(f'{width} no floating drag',p.locator('#F18-11 .nv-drag-lift').count()==0)
  ll=p.locator('#F18-11 .f1811-handle[data-bound="lower"]');ll.scroll_into_view_if_needed();b=ll.bounding_box();st=(b['x']+b['width']/2,b['y']+b['height']/2)
  p.mouse.move(*st);p.mouse.down();p.mouse.move(st[0]+26,st[1]-44,steps=2);p.keyboard.press('Escape');p.mouse.up();p.wait_for_timeout(80)
  ck(f'{width} Escape preserves positions',boundstate(p)['index']==[1,3],boundstate(p))
  p.locator('#F18-11 .f1811-handle[data-bound="lower"]').focus();p.keyboard.press('ArrowRight')
  ck(f'{width} keyboard arrow changes tick',boundstate(p)['index']==[2,3],boundstate(p))
  p.locator('#F18-11 .f1811-handle[data-bound="lower"]').focus();p.keyboard.press('Delete')
  ck(f'{width} keyboard delete removes',boundstate(p)['index']==[None,3],boundstate(p))
  p.locator('#F18-11 .f1811-handle[data-bound="lower"]').focus();p.keyboard.press('Enter')
  ck(f'{width} keyboard Enter restores',boundstate(p)['index']==[0,3],boundstate(p))
  mode(p,'Challenge')
  T=[(15.5,16.5,'cm'),(5.25,5.35,'m'),(465,475,'g'),(1750,1850,'m'),(8.5,9.5,'m'),(3.15,3.25,'h')]
  for i,(lo,hi,u) in enumerate(T):
   ev(p,f'NOVA_F18_11_CONFIG._challenge.task({i})');q=ev(p,'NOVA_F18_11_CONFIG._challenge.state()')
   ck(f'{width} task {i} expected exact',math.isclose(q['lower'],lo,abs_tol=1e-7) and math.isclose(q['upper'],hi,abs_tol=1e-7),q)
   ck(f'{width} task {i} answer hidden',all(x=='Work it out' for x in p.locator('#F18-11 .f1811-card[data-lower] strong, #F18-11 .f1811-card[data-upper] strong').all_text_contents()))
   a=f'{lo} {u}';b=f'{hi} {u}'
   ck(f'{width} task {i} missing unit rejected',not ev(p,f'NOVA_F18_11_CONFIG._challenge.check("{lo}","{hi}")')[0])
   ck(f'{width} task {i} swapped bounds rejected',not ev(p,f'NOVA_F18_11_CONFIG._challenge.check("{b}","{a}")')[0])
   ck(f'{width} task {i} markers required',not ev(p,f'NOVA_F18_11_CONFIG._challenge.check("{a}","{b}")')[0])
   ev(p,'NOVA_F18_11_CONFIG._challenge.place(0,1)');ev(p,'NOVA_F18_11_CONFIG._challenge.place(1,3)')
   ck(f'{width} task {i} correct',ev(p,f'NOVA_F18_11_CONFIG._challenge.check("{a}","{b}")')[0])
  # Submit actual UI path, the first question.
  ev(p,'NOVA_F18_11_CONFIG._challenge.task(0)')
  ev(p,'NOVA_F18_11_CONFIG._challenge.place(0,1)');ev(p,'NOVA_F18_11_CONFIG._challenge.place(1,3)')
  p.locator('#F18-11 input[aria-label="Lower bound with unit"]').fill('15.5 cm')
  p.locator('#F18-11 input[aria-label="Upper bound with unit"]').fill('16.5 cm')
  p.locator('#F18-11 button').filter(has_text='Check both bounds').click();p.wait_for_timeout(90)
  ck(f'{width} real Check button accepts',p.locator('#F18-11 .f1811-status[data-good]').count()==1)
  ck(f'{width} console errors none',not errors,errors)
  p.close()
 browser.close()
res={'passed':sum(x['ok'] for x in checks),'total':len(checks),'failed':[x for x in checks if not x['ok']],'checks':checks}
(QA/'stress-results.json').write_text(json.dumps(res,indent=2));print('RESULT',res['passed'],'/',res['total'],'FAIL',res['failed'][:20],flush=True)
