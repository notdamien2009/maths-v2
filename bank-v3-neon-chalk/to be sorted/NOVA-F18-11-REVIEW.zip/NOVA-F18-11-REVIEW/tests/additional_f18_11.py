import json,math,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path('/mnt/data');QA=R/'f18_11_qa';checks=[]
def ck(name,ok,details=''):
 checks.append({'name':name,'ok':bool(ok),'evidence':str(details)[:300]});
 if not ok:print('FAIL',name,details,flush=True)
S=(R/'F18-11-bounds-and-accuracy.html').read_text();REF=(R/'F18-10-estimating-in-context.html').read_text()
a=S.index('/* === NOVA FAMILY CORE v1.4 : JS START');b=S.index('/* NOVA F18-11 — Bounds');c=REF.index('/* === NOVA FAMILY CORE v1.4 : JS START');d=REF.index('/* NOVA F18-10 · Estimating');core=S[a:b].strip();old=REF[c:d].strip()
ck('shared JS core byte-for-byte identical',core==old,'sha256 '+hashlib.sha256(core.encode()).hexdigest())
ck('self contained CSS and JS',not any(k in S for k in ['<script src=','<link rel="stylesheet"']))
ck('canonical unit and rounding preset data',all(k in S for k in ['rectangle','speed','ruler','decimal','mass','map']))
with sync_playwright() as w:
 b=w.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  p=b.new_page(viewport={'width':width,'height':960},reduced_motion='reduce');errs=[];p.on('pageerror',lambda e:errs.append(str(e)))
  p.set_content(S,wait_until='domcontentloaded');p.wait_for_timeout(140)
  tab=p.locator('#F18-11 .nova-tabs button')
  tab.filter(has_text='Watch').click()
  ck(f'{width} step sequence six',p.evaluate('NOVA_F18_11_CONFIG && Object.keys(NOVA_F18_11_CONFIG).length')>0)
  ck(f'{width} timeline visible',p.locator('#F18-11 .nova-tl').count()==1)
  ck(f'{width} core number line visible',p.locator('#F18-11 .nv-numberline').count()==1)
  tab.filter(has_text='Explore').click();p.wait_for_timeout(60)
  for key in ['ruler','decimal','mass','map','rectangle','speed']:
   p.evaluate(f'NOVA_F18_11_CONFIG._explore.select("{key}")');p.screenshot(path=str(QA/f'F18-11_{width}_preset-{key}.png'),full_page=True,animations='disabled')
   ck(f'{width} {key} core scale visible',p.locator('#F18-11 .nv-numberline').count()==1)
   ck(f'{width} {key} both endpoint handles',p.locator('#F18-11 .f1811-handle').count()==2)
  p.evaluate('NOVA_F18_11_CONFIG._explore.select("ruler")');p.evaluate('NOVA_F18_11_CONFIG._explore.place(0,1)');p.evaluate('NOVA_F18_11_CONFIG._explore.place(1,3)')
  p.screenshot(path=str(QA/f'F18-11_{width}_correct-placement.png'),full_page=True,animations='disabled')
  ck(f'{width} interval beam with correct markers',p.locator('#F18-11 .f1811-handle[data-index="1"],#F18-11 .f1811-handle[data-index="3"]').count()==2)
  # Pointer-cancel during actual mouse movement (same captured pointer id) must not update the endpoints.
  lo=p.locator('#F18-11 .f1811-handle[data-bound="lower"]');lo.scroll_into_view_if_needed();rect=lo.bounding_box();x=rect['x']+rect['width']/2;y=rect['y']+rect['height']/2
  p.mouse.move(x,y);p.mouse.down();p.mouse.move(x+42,y-36,steps=4)
  p.evaluate('''() => { const e=document.querySelector('#F18-11 .f1811-handle[data-bound="lower"]'); e.dispatchEvent(new PointerEvent('pointercancel',{pointerId:1,bubbles:true})); }''')
  p.mouse.up();p.wait_for_timeout(90)
  ck(f'{width} cancel does not alter marker',p.evaluate('JSON.stringify(NOVA_F18_11_CONFIG._explore.state().index)')=='[1,3]')
  ck(f'{width} cancel leaves no lifted object',p.locator('#F18-11 .nv-drag-lift').count()==0)
  tab.filter(has_text='Guided').click();p.wait_for_timeout(60)
  ck(f'{width} guided panel present',p.locator('#F18-11 .nova-panel').count()>0)
  tab.filter(has_text='Challenge').click();p.wait_for_timeout(60)
  ck(f'{width} challenge has both answer inputs',p.locator('#F18-11 input[aria-label*="bound with unit"]').count()==2)
  ck(f'{width} challenge has no solutions',p.locator('#F18-11 .f1811-card[data-lower] strong').inner_text()=='Work it out')
  ck(f'{width} no JavaScript error',not errs,errs)
  p.close()
 b.close()
result={'passed':sum(v['ok'] for v in checks),'total':len(checks),'failed':[v for v in checks if not v['ok']],'checks':checks};(QA/'additional-results.json').write_text(json.dumps(result,indent=2));print('SUPPLEMENTARY',result['passed'],'/',result['total'],result['failed'])
