NOVA F18-11 — BOUNDS AND ACCURACY — REVIEW BUILD
Standalone file: F18-11-bounds-and-accuracy.html
Canonical NOVA core included without changes. Exactly one in-stage helper.
Four modes: WATCH / GUIDED / EXPLORE / CHALLENGE.
Six built-in presets and six challenge tasks.
Automated test results: 225/225 passed at 380px/1280px.
Screenshots: 22. Details in F18-11-QA-REPORT.html.

This is for owner review only; not GOLD-approved.
Physical touchscreen testing and owner visual QA still pending.
GitHub was not changed.
