from pathlib import Path
from playwright.sync_api import sync_playwright
import json,math,traceback
html=Path('/mnt/data/F18-03-analogue-clock.html').read_text();out=Path('/mnt/data/f18_03_qa');out.mkdir(exist_ok=True)
rows=[]
def test(name,ok,info=None):
 rows.append({'name':name,'passed':bool(ok),'detail':info});print(('PASS' if ok else 'FAIL'),name,info or '')

def loc(pg,kind):
 return pg.locator('#F18-03 [data-hand="'+kind+'"]')

def xy_for(pg,deg):
 return pg.evaluate('''(deg)=>{const v=document.querySelector('#F18-03 .f1803-drawing');const W=+v.getAttribute('viewBox').split(' ')[2],H=+v.getAttribute('viewBox').split(' ')[3];const cx=W===400?200:310,cy=W===400?267:243,r=W===400?160:187;const p=v.createSVGPoint();p.x=cx+Math.sin(deg*Math.PI/180)*r*.74;p.y=cy-Math.cos(deg*Math.PI/180)*r*.74;const q=p.matrixTransform(v.getScreenCTM());return {x:q.x,y:q.y};}''',deg)

def drag(pg,kind,to_deg,steps=18):
 g=loc(pg,kind);g.scroll_into_view_if_needed();pg.wait_for_timeout(120)
 bb=g.bounding_box();start={'x':bb['x']+bb['width']/2,'y':bb['y']+bb['height']/2};target=xy_for(pg,to_deg)
 pg.mouse.move(start['x'],start['y']);pg.mouse.down();pg.mouse.move(target['x'],target['y'],steps=steps);pg.mouse.up();pg.wait_for_timeout(420)
 return start,target

with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in (380,1280):
  pg=b.new_page(viewport={'width':w,'height':960},reduced_motion='reduce');errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  pg.set_content(html,wait_until='domcontentloaded');pg.wait_for_timeout(280)
  c='NOVA_F18_03_CONFIG'
  def state():return pg.evaluate(f'window.{c}._explore.state()')
  def go(mode):pg.locator('#F18-03 .nova-tab[data-m="'+mode+'"]').click();pg.wait_for_timeout(120)
  for mode in ('watch','guided','explore','challenge'):
   go(mode);test(f'{w}-{mode}-loaded',pg.locator('#F18-03 .f1803-drawing').count()==1 and pg.locator('#F18-03 .nv-dockfig').count()==1)
  go('explore');test(f'{w}-initial-clock',state()['h']==7 and state()['m']==25,state())
  # pointer fast move: 10 minute hand at the ten-minute mark, testing true mouse drag
  start,target=drag(pg,'minute',60,steps=15)
  test(f'{w}-mouse-minute-drag',state()['m']==10,{'start':start,'end':target,'state':state()})
  test(f'{w}-drag-not-stranded',pg.evaluate('NOVA.ui._drag===null'))
  # rapid diagonal drag from starting grip to 45-minute tick
  drag(pg,'minute',270,steps=2)
  test(f'{w}-fast-mouse-minute',state()['m']==45,state())
  # hour hand: set at 5; minute stays at 45; actual angle = 5*30+45/2
  drag(pg,'hour',150,steps=10)
  test(f'{w}-mouse-hour-drag',state()['h']==5 and state()['m']==45,state())
  # keyboard minute: focus, arrow increments; shift accelerates
  g=loc(pg,'minute');g.focus();pg.keyboard.press('ArrowRight');test(f'{w}-keyboard-minute',state()['m']==46,state())
  loc(pg,'minute').focus();pg.keyboard.press('Shift+ArrowLeft');test(f'{w}-keyboard-shift-5',state()['m']==41,state())
  # minute crossing zero carries an hour
  pg.evaluate(f'{c}._explore.set(7,59)');loc(pg,'minute').focus();pg.keyboard.press('ArrowRight');test(f'{w}-minute-carries-hour',state()['h']==8 and state()['m']==0,state())
  # Escape and pointer-cancel recovery after moving grip without releasing
  pg.evaluate(f'{c}._explore.set(7,25)');gr=loc(pg,'minute');gr.scroll_into_view_if_needed();bb=gr.bounding_box();sx=bb['x']+bb['width']/2;sy=bb['y']+bb['height']/2
  pg.mouse.move(sx,sy);pg.mouse.down();pg.mouse.move(sx+60,sy-70,steps=5);pg.keyboard.press('Escape');pg.mouse.up();pg.wait_for_timeout(500)
  test(f'{w}-escape-cancel',state()['m']==25 and pg.evaluate('NOVA.ui._drag===null'),state())
  # keyboard angle precision and exact angle math
  for key, expected in [('right',90),('offset',50),('narrow',10),('reflex',240)]:
   pg.evaluate(f'{c}._explore.select({json.dumps(key)})'); st=state();test(f'{w}-preset-{key}-math',abs((st['reflex'] if key=='reflex' else st['smaller'])-expected)<1e-8,st)
  for key,time in [('time',(7,25)),('set',(4,40)),('pm',(16,40))]:
   pg.evaluate(f'{c}._explore.select({json.dumps(key)})');st=state();test(f'{w}-preset-{key}-time', (st['h'],st['m'])==time,st)
  # challenge: all seven expected answers, wrong-unit and moving-hour-hand error cases
  go('challenge')
  values=['7:25','4:40','16:40','90°','50°','10°','240°']
  for i,v in enumerate(values):
   pg.evaluate(f'{c}._challenge.select({json.dumps(["time","set","pm","right","offset","narrow","reflex"][i])})')
   if i==1:pg.evaluate(f'{c}._challenge.solve()')
   good=pg.evaluate(f'({{v}})=>window.{c}._challenge.check(v)',{'v':v});test(f'{w}-challenge-{i+1}-math',good[0],good)
  pg.evaluate(f'{c}._challenge.select("offset")')
  mis=pg.evaluate(f'window.{c}._challenge.check("60°")');test(f'{w}-hour-hand-misconception',not mis[0] and 'hour hand' in mis[1],mis)
  no_unit=pg.evaluate(f'window.{c}._challenge.check("50")');test(f'{w}-unit-required',not no_unit[0] and 'degree' in no_unit[1],no_unit)
  pg.evaluate(f'{c}._challenge.select("reflex")')
  wrong=pg.evaluate(f'window.{c}._challenge.check("120°")');test(f'{w}-reflex-misconception',not wrong[0] and 'smaller' in wrong[1],wrong)
  pg.evaluate(f'{c}._challenge.select("set")')
  not_set=pg.evaluate(f'window.{c}._challenge.check("4:40")');test(f'{w}-set-task-checks-hands',not not_set[0] and 'hands' in not_set[1],not_set)
  test(f'{w}-no-page-errors',not errs,errs)
  pg.close()
 b.close()
(out/'stress-results.json').write_text(json.dumps(rows,indent=2))
print('TOTAL',sum(x['passed'] for x in rows),'/',len(rows))
