from playwright.sync_api import sync_playwright
from pathlib import Path
import json, math
html=Path('/mnt/data/F18-03-analogue-clock.html').read_text();qa=Path('/mnt/data/f18_03_qa');rows=[]
def test(n,ok,detail=''):
 rows.append({'name':n,'passed':bool(ok),'detail':detail});print('PASS' if ok else 'FAIL',n,detail)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  pg=b.new_page(viewport={'width':width,'height':980},reduced_motion='reduce');errs=[];pg.on('pageerror',lambda x:errs.append(str(x)))
  pg.set_content(html);pg.wait_for_timeout(220)
  def go(m):pg.locator('#F18-03 .nova-tab[data-m="'+m+'"]').click();pg.wait_for_timeout(100)
  test(f'{width}-no-horizontal-body-scroll',pg.evaluate('document.documentElement.scrollWidth <= innerWidth'),str(pg.evaluate('[document.documentElement.scrollWidth,innerWidth]')))
  go('guided')
  stepNames=['Notice the dial','Follow the short hand','Place the minute hand','Watch the hour move','Read the time','Check the angles']
  for idx,name in enumerate(stepNames):
   # expose canonical playback timeline via the public UI's next step control
   if idx>0:pg.locator('#F18-03 .nova-tl button[aria-label="Step forward"]').click()
   pg.wait_for_timeout(50)
   stage=pg.locator('#F18-03 .nova-stage').inner_text();test(f'{width}-guided-step-{idx+1}',name in pg.locator('#F18-03').inner_text() or f'STEP {idx+1}/6' in stage,stage[:45].replace('\n',' '))
  go('explore')
  # distinct angle/preset renders; check math with the actual drawn SVG transform angles
  for k in ('offset','narrow','reflex','pm'):
   pg.evaluate(f'NOVA_F18_03_CONFIG._explore.select("{k}")')
   st=pg.evaluate('NOVA_F18_03_CONFIG._explore.state()')
   transform=pg.locator('#F18-03 [data-hand-art="hour"]').get_attribute('transform')
   expected=(st['h']%12)*30+st['m']/2
   test(f'{width}-{k}-drawn-hour-angle',abs(float(transform.split('(')[1].split(' ')[0])-expected)<1e-8,transform)
   pg.screenshot(path=str(qa/f'F18-03_{width}_preset_{k}.png'),full_page=True)
  go('challenge');pg.evaluate('NOVA_F18_03_CONFIG._challenge.select("offset")')
  secret=pg.locator('#F18-03 .nova-stage').inner_text()
  test(f'{width}-challenge-no-numeric-angle-spoiler','50°' not in secret and 'hour hand angle' not in secret, secret[-125:])
  alt=pg.locator('#F18-03 .f1803-drawing title').first.text_content()
  test(f'{width}-challenge-alt-not-answer-spoiler','50' not in alt,alt)
  # PM uses 24-hour time, no 12-hour answer accepted
  pg.evaluate('NOVA_F18_03_CONFIG._challenge.select("pm")')
  v=pg.evaluate('NOVA_F18_03_CONFIG._challenge.check("4:40")')
  test(f'{width}-24hr-rejects-12hr',not v[0] and '12-hour' in v[1],str(v))
  test(f'{width}-page-errors',not errs,str(errs))
  pg.close()
 b.close()
(qa/'additional-results.json').write_text(json.dumps(rows,indent=2))
print('FINAL',sum(r['passed'] for r in rows),'/',len(rows))
