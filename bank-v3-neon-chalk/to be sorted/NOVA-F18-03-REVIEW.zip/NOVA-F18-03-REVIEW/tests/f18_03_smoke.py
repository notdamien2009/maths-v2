import asyncio,os,json
from pathlib import Path
from playwright.async_api import async_playwright
PATH='/mnt/data/F18-03-analogue-clock.html'; OUT=Path('/mnt/data/f18_03_qa');OUT.mkdir(exist_ok=True)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for width in (380,1280):
   page=await browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
   errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
   await page.set_content(Path(PATH).read_text(),wait_until='domcontentloaded');await page.wait_for_timeout(220)
   print('LOAD',width,'title',await page.title(),'tabs',await page.locator('.nova-tab').all_text_contents(),'errors',errs)
   for mode in ('watch','guided','explore','challenge'):
    l=page.locator('.nova-tab').filter(has_text=mode.capitalize())
    if not await l.count():l=page.get_by_role('button',name=mode.capitalize(),exact=False)
    await l.first.click();await page.wait_for_timeout(280)
    await page.screenshot(path=str(OUT/f'F18-03_{width}_{mode}.png'),full_page=True)
    print('MODE',width,mode,'svg',await page.locator('.f1803-drawing').count(),'error',errs[-1:] if errs else [],'text', (await page.locator('#F18-03 .nova-stage').inner_text())[:100])
   await page.close()
  await browser.close()
asyncio.run(main())
