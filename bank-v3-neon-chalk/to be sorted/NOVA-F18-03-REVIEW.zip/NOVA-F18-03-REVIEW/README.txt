NOVA MATHS V2 — F18-03 ANALOGUE CLOCK
STATUS: BUILD FOR OWNER REVIEW · NOT GOLD APPROVED

Open F18-03-analogue-clock.html in a modern browser; all core CSS, JS, embedded chalk and original mascot artwork are included. No network dependencies.
Four working modes: WATCH, GUIDED, EXPLORE, CHALLENGE.
Presets: time reading, set hands, 24h, right angle, moving hour, narrow angle, reflex angle. F11-12 is an internal preset.

QA/screenshots: 16 images (380px/1280px × four modes and four extended presets).
QA/F18-03-QA-REPORT.html: review with gallery and audited test evidence.
QA/stress-results.json: actual Chromium headless pointer/keyboard/math tests (64/64).
QA/additional-results.json: guided, SVG geometry, privacy, misconception tests (30/30).
QA mode screenshots show all 8 combinations (8/8).
TOTAL REPORTED PASS: 102/102.
tests/ contains executed QA scripts.

Outstanding: physical touchscreen, independent design approval, printed output and real screen-reader testing.
GitHub was not changed.
