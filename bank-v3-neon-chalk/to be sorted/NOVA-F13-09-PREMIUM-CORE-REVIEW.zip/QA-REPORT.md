# F13-09 QA — 2026-10-12

**Result: 158/158 checks passed, 0 failures.**

Tested using headless Chromium at 1280px and 380px widths, with the generated self-contained HTML loaded directly. No page-level JavaScript exceptions observed.

## Coverage

- Embedded original NOVA core JS identical to F13-08 source, original shared CSS unmodified before add-ons.
- Original stage, branded background, NOVA Chalk, official embedded mascot dock and 380px horizontal layout.
- Cone/cylinder exact maths: 3 presets, including r=3 h=4 producing 12π vs 36π, r=2 h=6 producing 8π vs 24π.
- Square pyramid/prism maths: 3 presets, including side=6 h=5 producing 60 vs 180 cubic units.
- Every pair satisfies matched volume / source volume = 3.
- Empty state, first, second and third complete pours, bounded fourth pour, removal, reset and intermediate animation fractions.
- Keyboard End/Home/Left controls and actual mouse-pointer rightward drag to pour at both widths.
- Live updates when changing base dimension or perpendicular height.
- Repeated animation redraw reuses SVG clipPath rather than leaking duplicate definitions.
- Switching to Challenge during an animation cancels the previous scene without leaving stale content.
- Watch timeline (12 steps), Guided, Explore, Challenge; all 3 marked challenges including wrong-answer rejection.

## Visual review performed

Rendered both source shapes and the matched solids, empty and full target, plus halfway-through-pour liquid levels. Screenshots are attached in this package. The visual approval remains with the project owner.

## Source integrity

SHA-256 of final HTML: `e16370cd6a57dd847b343b84cee35f4ae2f4228dd2ef4e83f5a5b6ce3bd60c59`.

**No GitHub changes made.**
