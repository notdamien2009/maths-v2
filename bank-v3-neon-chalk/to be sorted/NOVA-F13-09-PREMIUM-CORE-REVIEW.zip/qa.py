import json, hashlib, math, time
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
base=(root/'source'/'F13-08-Cylinder-Unroll-PREMIUM-CORE.html').read_text()
file=root/'F13-09-Pyramid-and-Cone-Fill-PREMIUM-CORE.html'
html=file.read_text()
core=lambda s:s[s.index('/* === NOVA FAMILY CORE v1.4 : JS START'):s.index('</script>',s.index('/* === NOVA FAMILY CORE v1.4 : JS START'))]
checks=[]
def check(name,condition,detail=''):
 checks.append({'name':name,'passed':bool(condition),'detail':str(detail) if not condition else ''});
 if not condition:print('FAIL',name,detail)
def set_mode(page,label):
 tabs=page.locator('.nova-tabs button')
 for i in range(tabs.count()):
  if label.lower() in tabs.nth(i).inner_text().lower():
   tabs.nth(i).click();page.wait_for_timeout(100);return
 raise ValueError('Mode not found '+label+' '+str(tabs.all_inner_texts()))
def metrics(page):
 return page.locator('[data-f13f-root]').evaluate('(el) => ({kind:el.getAttribute("data-kind"),source:+el.getAttribute("data-source-volume"),target:+el.getAttribute("data-target-volume"),fraction:+el.getAttribute("data-fill-fraction"),pours:el.querySelector("[data-pours]")?.getAttribute("data-pours")})')
check('Embedded official core byte-for-byte unchanged',core(base)==core(html))
check('Original shared styles exact before local CSS',base[base.index('<style>'):base.index('/* F13-08 additive component styles')]==html[html.index('<style>'):html.index('/* F13-09 additive styles.')])
check('Fully self-contained: no external scripts',not ('<script src=' in html))
check('Official mascot functions present','NOVA.scene.helperStrip' in core(html))
check('Embedded chalk face present','font-face{font-family:"NOVA Chalk"' in html)
check('F13-09 header', 'data-run="F13 · 3D shapes, volume and surface area · F13-09"' in html)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='load');page.wait_for_timeout(300)
  check(f'{width}: engine mounted',page.locator('.f13f-svg').count()==1)
  check(f'{width}: official stage dock single',page.locator('.nova-stage > .nv-dock').count()==1)
  check(f'{width}: embedded mascot image',page.locator('.nv-dock image').count()>=1)
  check(f'{width}: no additional horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'),page.evaluate('document.documentElement.scrollWidth'))
  check(f'{width}: no extra internal middle row',page.locator('.nova-stage > .nova-stage').count()==0)
  check(f'{width}: core background drawn',page.locator('.nova-stage').count()==1)
  m=metrics(page)
  check(f'{width}: cone source volume 12π',abs(m['source']-12*math.pi)<1e-7,m)
  check(f'{width}: matched cylinder volume 36π',abs(m['target']-36*math.pi)<1e-7,m)
  check(f'{width}: empty start',m['fraction']==0)
  check(f'{width}: original solid drawing present',page.locator('[data-maths="one-third-source"]').count()==1 and page.locator('[data-maths="matching-target"]').count()==1)
  check(f'{width}: clean π notation',not page.locator('[data-f13f-root]').text_content().count('π π'))
  dock=page.locator('.nova-stage > .nv-dock').bounding_box();stage=page.locator('.nova-stage').bounding_box()
  if dock and stage:check(f'{width}: mascot dock confined to stage',dock['x']>=stage['x']-3 and dock['x']+dock['width']<=stage['x']+stage['width']+4 and dock['y']+dock['height']<=stage['y']+stage['height']+6,(dock,stage))
  # teach steps
  check(f'{width}: 12 teaching beats',page.evaluate('window.F13_09 && window.F13_09.timeline && window.F13_09.timeline.steps.length===12')is True)
  for i in [0,1,2,3,4,5,6,7,8,9,10,11]:
   r=page.evaluate('''i => {const eng=window.F13_09; if(!eng)return null; try{if(eng.tl&&typeof eng.tl.go==='function')eng.tl.go(i,'qa'); else if(eng.timeline&&typeof eng.timeline.go==='function')eng.timeline.go(i,'qa'); else if(eng.setStep)eng.setStep(i);return true}catch(e){return String(e)}}''',i)
   page.wait_for_timeout(30)
   check(f'{width}: step {i+1} no runtime error',r is True,r)
  set_mode(page,'Explore')
  check(f'{width}: Explore loads',page.locator('select[aria-label="Matched solids preset"]').count()==1)
  check(f'{width}: Explore API exists',page.evaluate('!!NOVA_F13_09_CONFIG._explore && !!NOVA_F13_09_CONFIG._explore.state'))
  for key,small,large in [('cone',12*math.pi,36*math.pi),('coneSmall',8*math.pi,24*math.pi),('coneTall',21*math.pi,63*math.pi),('pyramid',60,180),('pyramidSmall',32,96),('pyramidWide',64,192)]:
   page.evaluate('(key)=>NOVA_F13_09_CONFIG._explore.preset(key)',key);page.wait_for_timeout(30);a=metrics(page)
   check(f'{width}: {key} source maths',abs(a['source']-small)<1e-7,a)
   check(f'{width}: {key} target maths',abs(a['target']-large)<1e-7,a)
   check(f'{width}: {key} geometric ratio',abs(a['target']/a['source']-3)<1e-8,a)
   check(f'{width}: {key} starts empty',a['fraction']==0,a)
  page.evaluate('NOVA_F13_09_CONFIG._explore.preset("cone")');page.wait_for_timeout(40)
  for n in [1,2,3]:
   page.evaluate('NOVA_F13_09_CONFIG._explore.pour()');page.wait_for_timeout(1100);a=metrics(page)
   check(f'{width}: pour {n} fill amount',abs(a['fraction']-n/3)<1e-8,a)
   check(f'{width}: pour {n} counter',int(a['pours'])==n,a)
  check(f'{width}: fourth pour blocked',page.evaluate('NOVA_F13_09_CONFIG._explore.pour()') is False)
  page.evaluate('NOVA_F13_09_CONFIG._explore.undo()');page.wait_for_timeout(50);check(f'{width}: remove one',abs(metrics(page)['fraction']-2/3)<1e-8)
  page.evaluate('NOVA_F13_09_CONFIG._explore.reset()');page.wait_for_timeout(50);check(f'{width}: reset 0',metrics(page)['fraction']==0)
  page.evaluate('NOVA_F13_09_CONFIG._explore.preset("pyramid")');page.wait_for_timeout(30)
  stage_box=page.locator('.f13f-svg').bounding_box();page.locator('.f13f-svg').focus();page.keyboard.press('End');page.wait_for_timeout(50)
  check(f'{width}: End key fills',abs(metrics(page)['fraction']-1)<1e-8)
  page.keyboard.press('ArrowLeft');page.wait_for_timeout(50);check(f'{width}: Left arrow undo',abs(metrics(page)['fraction']-2/3)<1e-8)
  page.keyboard.press('Home');page.wait_for_timeout(50);check(f'{width}: Home empties',metrics(page)['fraction']==0)
  # pointer gesture from right of source to left of target
  page.locator('.f13f-svg').scroll_into_view_if_needed();box=page.locator('.f13f-svg').bounding_box();y=box['y']+box['height']*.28;x=box['x']+box['width']*.3
  page.mouse.move(x,y);page.mouse.down();page.mouse.move(x+box['width']*.23,y,steps=8);page.mouse.up();page.wait_for_timeout(1050)
  check(f'{width}: real pointer drag pour',abs(metrics(page)['fraction']-1/3)<1e-8,metrics(page))
  # live slider response
  page.locator('input[aria-label="SIDE"]').count() # slider aria is fixed RADIUS; updated visual label only
  page.evaluate('NOVA_F13_09_CONFIG._explore.set(5,6)');page.wait_for_timeout(50);a=metrics(page)
  check(f'{width}: live dims volume',abs(a['target']-150)<1e-8 and abs(a['source']-50)<1e-8,a)
  check(f'{width}: dimensions reset poured',a['fraction']==0,a)
  page.locator('.nova-stage').first.scroll_into_view_if_needed()
  page.screenshot(path=str(root/'screenshots'/f'{width}-explore.png'))
  page.evaluate('NOVA_F13_09_CONFIG._explore.preset("pyramid")');page.wait_for_timeout(80);page.screenshot(path=str(root/'screenshots'/f'{width}-pyramid.png'))
  page.evaluate('NOVA_F13_09_CONFIG._explore.preset("cone")');page.wait_for_timeout(40)
  page.evaluate('NOVA_F13_09_CONFIG._explore.pour()');page.wait_for_timeout(470);middle=metrics(page)
  check(f'{width}: during pour intermediate fraction',0<middle['fraction']<1/3,middle)
  check(f'{width}: no SVG clip memory leak',page.locator('defs #f13f-cone-clip').count()==1,page.locator('defs #f13f-cone-clip').count())
  set_mode(page,'Challenge');page.wait_for_timeout(650)
  check(f'{width}: mode change cancels pour',page.locator('.f13f-svg').count()==1 and metrics(page)['fraction']==0,metrics(page))
  check(f'{width}: mode change keeps mascot in stage',page.locator('.nova-stage > .nv-dock').count()==1)
  check(f'{width}: Challenge present',page.locator('input[aria-label="Matched prism or cylinder volume"]').count()==1)
  for i,ans in enumerate([(36,12),(180,60),(24,8)]):
   page.evaluate('i=>NOVA_F13_09_CONFIG._challenge.load(i)',i)
   if i==0:
    page.locator('input[aria-label="Matched prism or cylinder volume"]').fill('36');page.locator('input[aria-label="Cone or pyramid volume"]').fill('36')
    check(f'{width}: misconception same volume rejected',page.evaluate('NOVA_F13_09_CONFIG._challenge.check()') is False)
   page.locator('input[aria-label="Matched prism or cylinder volume"]').fill(str(ans[0]));page.locator('input[aria-label="Cone or pyramid volume"]').fill(str(ans[1]))
   check(f'{width}: challenge {i+1} answers correct',page.evaluate('NOVA_F13_09_CONFIG._challenge.check()') is True)
   page.wait_for_timeout(20)
  page.locator('.nova-stage').first.scroll_into_view_if_needed();page.screenshot(path=str(root/'screenshots'/f'{width}-challenge.png'))
  check(f'{width}: no javascript errors',not errors,errors)
  page.close()
 browser.close()
result={'total':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'failures':[x for x in checks if not x['passed']],'checks':checks,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
(root/'QA-RESULTS.json').write_text(json.dumps(result,indent=2))
print('QA',result['passed'],'/',result['total'])
