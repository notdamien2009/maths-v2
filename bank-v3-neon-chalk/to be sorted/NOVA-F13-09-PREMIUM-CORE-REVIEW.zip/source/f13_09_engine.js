/* F13-09 PYRAMID AND CONE FILL — additive engine using the unchanged NOVA production core. */
var NOVA_F13_09_CONFIG={startMode:'watch',preset:'cone',presets:{cone:'Cone · r 3 · h 4',coneSmall:'Cone · r 2 · h 6',coneTall:'Cone · r 3 · h 7',pyramid:'Square pyramid · side 6 · h 5',pyramidSmall:'Square pyramid · side 4 · h 6',pyramidWide:'Square pyramid · side 8 · h 3'}};
(function(){'use strict';
var S=NOVA.svg,F=NOVA.f12,h=NOVA.h,CFG=NOVA_F13_09_CONFIG,EN='F13-09';
var COL={cyan:'#45eeff',blue:'#659eff',purple:'#bba3ff',orange:'#ffad7d',gold:'#ffe27d',green:'#76f5bb',white:'#e8f8ff',navy:'#081a35'};
var PRESETS={cone:['cone',3,4],coneSmall:['cone',2,6],coneTall:['cone',3,7],pyramid:['pyramid',6,5],pyramidSmall:['pyramid',4,6],pyramidWide:['pyramid',8,3]};
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function mkState(key){var q=PRESETS[key]||PRESETS.cone;return {preset:key||'cone',kind:q[0],base:q[1],ht:q[2],pours:0,phase:0,flow:false,showMeasure:true,showLabels:true,refresh:null,cleanup:null,anim:0,svg:null};}
function baseArea(st){return st.kind==='cone'?Math.PI*st.base*st.base:st.base*st.base;}
function bigVolume(st){return baseArea(st)*st.ht;}
function smallVolume(st){return bigVolume(st)/3;}
function fmt(n){return Number(n.toFixed(2)).toString();}
function formula(st,small){var c=(st.kind==='cone'?(st.base*st.base):(st.base*st.base))*st.ht/(small?3:1);return st.kind==='cone'?fmt(c)+'π':fmt(c);}
function e(p,tag,attrs){return S.el(tag,attrs||{},p);}
function path(pts){return 'M'+pts.map(function(p){return fmt(p[0])+','+fmt(p[1]);}).join('L')+'Z';}
function text(p,x,y,value,role,size,anchor){return NOVA.chalkText(p,x,y,String(value),{role:role||'given',size:size||17,anchor:anchor||'middle'});}
function line(p,a,b,col,w,opacity,dash){var q=e(p,'path',{d:'M'+fmt(a[0])+','+fmt(a[1])+'L'+fmt(b[0])+','+fmt(b[1]),fill:'none',stroke:col,'stroke-width':w||1.4,opacity:opacity==null?1:opacity,'stroke-linecap':'round'});if(dash)q.setAttribute('stroke-dasharray',dash);return q;}
function grad(d,id,stops,x1,y1,x2,y2){var g=e(d,'linearGradient',{id:id,x1:x1||'0%',y1:y1||'0%',x2:x2||'100%',y2:y2||'100%'});stops.forEach(function(s){e(g,'stop',{offset:s[0],'stop-color':s[1],'stop-opacity':s[2]});});}
function defs(svg){var d=svg.querySelector('defs')||e(svg,'defs');grad(d,'f13f-glass',[['0%','#daffff',.47],['21%','#7bb5f8',.2],['58%','#113e8b',.21],['100%','#4fa8ec',.35]],'5%','0%','95%','100%');grad(d,'f13f-water',[['0%','#d3ffff',.95],['28%','#67eaff',.84],['60%','#1585e0',.88],['100%','#12459a',.85]],'0%','0%','90%','100%');grad(d,'f13f-shine',[['0%','#f7ffff',.64],['100%','#42a8ef',.08]],'0%','0%','100%','0%');grad(d,'f13f-gold',[['0%','#ffe99c',.45],['100%','#fa9562',.08]]);var rad=e(d,'radialGradient',{id:'f13f-aura'});e(rad,'stop',{offset:'0%','stop-color':'#214ca2','stop-opacity':.55});e(rad,'stop',{offset:'100%','stop-color':'#102354','stop-opacity':0});var filt=e(d,'filter',{id:'f13f-blur',x:'-90%',y:'-90%',width:'280%',height:'280%'});e(filt,'feGaussianBlur',{stdDeviation:'6'});}
function cylinder(g,cx,top,bottom,r,amount,mobile){var ry=r*.29,H=bottom-top,fy=bottom-H*amount;
 e(g,'ellipse',{cx:cx,cy:bottom+7,rx:r*1.13,ry:r*.30,fill:'#071c3e',opacity:.55,filter:'url(#f13f-blur)'});
 var clipId='f13f-target-clip';var d=g.ownerSVGElement.querySelector('defs');var cp=e(d,'clipPath',{id:clipId});e(cp,'rect',{x:cx-r,y:top,width:2*r,height:H});
 var li=e(g,'g',{'data-liquid':'target','data-volume-fraction':amount,'clip-path':'url(#'+clipId+')'});
 e(li,'rect',{x:cx-r,y:fy,width:r*2,height:Math.max(0,bottom-fy),fill:'url(#f13f-water)',opacity:.87});
 if(amount>0){e(li,'ellipse',{cx:cx,cy:fy,rx:r,ry:ry,fill:'#7bf7ff',opacity:.77,stroke:COL.cyan,'stroke-width':1.5});for(var i=0;i<5;i++){var bx=cx-r+(i+1)*r/3;var yb=fy+26+(i%2)*29;if(yb<bottom-9)e(li,'circle',{cx:bx,cy:yb,r:1.9+(i%2),fill:'#d9ffff',opacity:.63});}}
 e(g,'path',{d:'M'+fmt(cx-r)+' '+fmt(top)+'V'+fmt(bottom)+' A'+r+' '+ry+' 0 0 0 '+fmt(cx+r)+' '+fmt(bottom)+'V'+fmt(top),fill:'url(#f13f-glass)',stroke:COL.cyan,'stroke-width':2.8,'stroke-linejoin':'round'});
 e(g,'ellipse',{cx:cx,cy:bottom,rx:r,ry:ry,fill:'none',stroke:COL.purple,'stroke-width':1.5,opacity:.72});
 e(g,'ellipse',{cx:cx,cy:top,rx:r,ry:ry,fill:'url(#f13f-glass)',stroke:COL.cyan,'stroke-width':2.6});
 e(g,'path',{d:'M'+fmt(cx-r*.72)+' '+fmt(top+8)+'Q'+fmt(cx-r*.88)+' '+fmt((top+bottom)/2)+' '+fmt(cx-r*.72)+' '+fmt(bottom-13),stroke:'#d5fbff',opacity:.6,'stroke-width':4,fill:'none','stroke-linecap':'round'});
 for(var j=1;j<=2;j++){var yy=bottom-j*H/3;line(g,[cx+r+3,yy],[cx+r+15,yy],COL.gold,1.8,.8);}
 return {top:top,bottom:bottom};}
function cuboid(g,cx,top,bottom,r,amount){var ry=r*.28,depth=r*.58,fy=bottom-(bottom-top)*amount;
 var t0=[cx-r,top],t1=[cx-r+depth,top-ry],t2=[cx+r+depth,top-ry],t3=[cx+r,top],b0=[cx-r,bottom],b1=[cx-r+depth,bottom-ry],b2=[cx+r+depth,bottom-ry],b3=[cx+r,bottom];
 e(g,'ellipse',{cx:cx+depth/2,cy:bottom+10,rx:r*1.2,ry:21,fill:'#071c3e',opacity:.4,filter:'url(#f13f-blur)'});
 var k=clamp(amount,0,1),f0=[cx-r,fy],f1=[cx-r+depth,fy-ry],f2=[cx+r+depth,fy-ry],f3=[cx+r,fy];
 if(k>0){e(g,'path',{d:path([f0,f3,b3,b0]),fill:'url(#f13f-water)',opacity:.91});e(g,'path',{d:path([f3,f2,b2,b3]),fill:'#2363c1',opacity:.76});e(g,'path',{d:path([f0,f1,f2,f3]),fill:'#86eeff',opacity:.79,stroke:COL.cyan,'stroke-width':1.2});}
 e(g,'path',{d:path([t0,t3,b3,b0]),fill:'url(#f13f-glass)',stroke:COL.cyan,'stroke-width':2.1});e(g,'path',{d:path([t3,t2,b2,b3]),fill:'#26376b',opacity:.36,stroke:COL.purple,'stroke-width':2.2});
 e(g,'path',{d:path([t0,t1,t2,t3]),fill:'url(#f13f-glass)',stroke:COL.cyan,'stroke-width':2.4});
 line(g,[cx-r+7,top+10],[cx-r+7,bottom-12],'#d9faff',3,.53);
 for(var j=1;j<=2;j++){var yy=bottom-j*(bottom-top)/3;line(g,[cx+r+depth+4,yy-ry],[cx+r+depth+14,yy-ry],COL.gold,1.8,.8);}
}
function sourceShape(g,st,cx,top,bottom,r,fraction){var f=clamp(fraction,0,1),H=bottom-top,reach=Math.cbrt(f),y=bottom-H*reach,w=r*reach;
 // Both idealised measuring vessels share the same base area and perpendicular height as their matching prism.
 e(g,'ellipse',{cx:cx,cy:bottom+10,rx:r*1.05,ry:12,fill:'#071c3e',opacity:.5,filter:'url(#f13f-blur)'});
 if(st.kind==='cone'){
  // Wide rim at top; apex below. Filled volume fraction equals (filled-height/whole-height)^3.
  var boundary='M'+fmt(cx-r)+','+top+' L'+cx+','+bottom+' L'+fmt(cx+r)+','+top+'Z';
  var d=g.ownerSVGElement.querySelector('defs'),clip=d.querySelector('#f13f-cone-clip');if(!clip)clip=e(d,'clipPath',{id:'f13f-cone-clip'});clip.replaceChildren();e(clip,'path',{d:boundary});
  var liquid=e(g,'g',{'clip-path':'url(#f13f-cone-clip)','data-liquid':'source','data-volume-fraction':f});
  if(f>0){e(liquid,'path',{d:path([[cx-w,y],[cx+w,y],[cx,bottom]]),fill:'url(#f13f-water)',opacity:.94});e(liquid,'ellipse',{cx:cx,cy:y,rx:w,ry:w*.26,fill:'#abfaff',opacity:.82,stroke:COL.cyan,'stroke-width':1});}
  e(g,'path',{d:boundary,fill:'url(#f13f-glass)',stroke:COL.orange,'stroke-width':2.9,'stroke-linejoin':'round'});
  e(g,'ellipse',{cx:cx,cy:top,rx:r,ry:r*.27,fill:'url(#f13f-glass)',stroke:COL.gold,'stroke-width':2.9});
  line(g,[cx-r*.77,top+12],[cx-7,bottom-33],'#fff3c3',2.6,.57);
  if(f>.025)e(g,'ellipse',{cx:cx,cy:y,rx:w,ry:w*.25,fill:'none',stroke:COL.cyan,'stroke-width':1.1,opacity:.58});
 }else{
  // Square pyramid: horizontal square sections similar to the square base. Side length scales as cube root of volume.
  var dep=r*.45,back=[cx,top-r*.27],L=[cx-r,top],R=[cx+r,top],ap=[cx,bottom],yb=bottom-(H+r*.27)*reach,ww=r*reach,dd=dep*reach;
  if(f>0){e(g,'path',{d:path([[cx-ww,y],[cx+ww,y],[cx,bottom]]),fill:'url(#f13f-water)',opacity:.94});e(g,'path',{d:path([[cx+ww,y],[cx,bottom],[cx+dd,y-dd]]),fill:'#1968b8',opacity:.7});e(g,'path',{d:path([[cx-ww,y],[cx+dd,y-dd],[cx+ww,y],[cx,bottom]]).split('Z')[0],fill:'url(#f13f-water)',opacity:.65});e(g,'path',{d:path([[cx-ww,y],[cx,y-dd*.7],[cx+ww,y],[cx,y+dd*.45]]),fill:'#8beeff',opacity:.75,stroke:COL.cyan,'stroke-width':1});}
  e(g,'path',{d:path([L,back,ap]),fill:'url(#f13f-glass)',stroke:COL.orange,'stroke-width':2.2});e(g,'path',{d:path([back,R,ap]),fill:'#35529b',opacity:.4,stroke:COL.gold,'stroke-width':2.4});e(g,'path',{d:path([L,[cx,top+r*.28],R,back]),fill:'url(#f13f-glass)',stroke:COL.gold,'stroke-width':2.3});line(g,[cx-r*.69,top+17],[cx-8,bottom-34],'#fff3c3',2.5,.6);
 }
 return {level:y,reach:reach};}
function card(root,x,y,w,color,title,value,subtitle,mob){e(root,'rect',{x:x,y:y,width:w,height:105,rx:13,fill:'#06162c',stroke:color,'stroke-width':1.7});line(root,[x+14,y+5],[x+w-14,y+5],color,2.2,.65);text(root,x+w/2,y+25,title,'given',mob?13:16);text(root,x+w/2,y+63,value,'result',mob?23:27);text(root,x+w/2,y+88,subtitle,'given',mob?12:14);}
function draw(root,st,W,H){root.replaceChildren();var mob=W<500,top=145,bottom=342,rad=mob?49:76,left=mob?103:218,right=mob?297:546;
 var poured=clamp(st.pours+st.phase,0,3),f=poured/3;
 e(root,'ellipse',{cx:W/2,cy:253,rx:W*.53,ry:203,fill:'url(#f13f-aura)',opacity:.85});
 text(root,W/2,38,st.kind==='cone'?'THE CONE FILLS THE CYLINDER':'THE PYRAMID FILLS THE PRISM','given',mob?15.5:20);
 text(root,left,87,st.kind==='cone'?'CONE':'PYRAMID','given',mob?17:21);text(root,right,87,st.kind==='cone'?'CYLINDER':'PRISM','given',mob?17:21);
 text(root,left,107,'ONE MEASURE','focus',mob?13:17);text(root,right,107,'THREE MEASURES','op',mob?13:17);
 var a=e(root,'g',{'data-maths':'one-third-source','data-base':st.base,'data-height':st.ht,'data-kind':st.kind});
 sourceShape(a,st,left,top,bottom,rad,st.flow?1-st.phase:1);
 var b=e(root,'g',{'data-maths':'matching-target','data-volume-fraction':f,'data-pours':st.pours});
 if(st.kind==='cone')cylinder(b,right,top,bottom,rad,f,mob);else cuboid(b,right-(mob?8:18),top,bottom,rad*.79,f);
 text(root,left,373,st.kind==='cone'?'r = '+st.base:'side = '+st.base,'given',mob?15:19);text(root,right,373,'h = '+st.ht,'given',mob?15:19);
 var between=mob?194:382,ay=200;
 e(root,'path',{d:'M'+(between-24)+','+ay+'h48 m-11,-9 l11,9 -11,9',fill:'none',stroke:COL.gold,'stroke-width':3.5,'stroke-linecap':'round','stroke-linejoin':'round',opacity:st.flow?1:.63});
 if(st.flow){for(var i=0;i<7;i++){var xx=(left+rad+14)+(right-left-2*rad-28)*(i+1)/8,yy=228-16*Math.sin(Math.PI*(i+1)/8)+(i%2)*7;e(root,'ellipse',{cx:xx,cy:yy,rx:3.5,ry:5.2,fill:COL.cyan,opacity:.45+.5*Math.sin(Math.PI*(i+1)/8)});}}
 var pg=e(root,'g',{'data-maths':'three-equal-fills'}),cy=408,spacing=mob?48:65,x0=W/2-spacing;
 for(var z=0;z<3;z++){var sx=x0+z*spacing;var on=f*3>=z+1-.001; e(pg,'circle',{cx:sx,cy:cy,r:mob?14:17,fill:on?'#235e81':'#0b2248',stroke:on?COL.green:COL.purple,'stroke-width':2.2});text(pg,sx,cy+5,String(z+1),on?'result':'given',mob?14:17);}
 var label=f<.001?'EMPTY TARGET':f>.999?'FULL · 3 OF 3':fmt(f*3)+' OF 3 MEASURES';text(root,W/2,445,label,f>=.999?'result':'given',mob?15:18);
 var v1=formula(st,true),v3=formula(st,false),units='units³';
 card(root,mob?11:116,461,mob?193:264,COL.gold,st.kind==='cone'?'CONE VOLUME':'PYRAMID VOLUME',v1+' '+units,'⅓ × base area × height',mob);
 card(root,mob?215:400,461,mob?194:264,COL.cyan,st.kind==='cone'?'CYLINDER VOLUME':'PRISM VOLUME',v3+' '+units,'base area × height',mob);
 var v=st.kind==='cone'?'π × '+st.base+'² × '+st.ht:' '+st.base+'² × '+st.ht;
 text(root,W/2,585,'ONE THIRD: '+(st.kind==='cone'?'⅓πr²h':'⅓ × base area × h'),'result',mob?14.5:18);
 if(st.showMeasure){line(root,[left+rad+(mob?5:13),top],[left+rad+(mob?5:13),bottom],COL.orange,1.2,.7,'5 5');}
 root.setAttribute('data-kind',st.kind);root.setAttribute('data-source-volume',smallVolume(st).toFixed(8));root.setAttribute('data-target-volume',bigVolume(st).toFixed(8));root.setAttribute('data-fill-fraction',f.toFixed(8));}
function makeStage(stage,st,message,pose,allowDrag){if(stage._f13Cleanup)stage._f13Cleanup();stage.replaceChildren();var mob=innerWidth<=580,W=mob?420:780,H=606;
 NOVA.cap(stage,'PYRAMID + CONE FILL · '+(st.kind==='cone'?'r ':'s ')+st.base+' · h '+st.ht,'1 : 3');
 var svg=S.root(W,H,'A hollow cone holds exactly one third the volume of a cylinder with the same circular base and perpendicular height. A square pyramid similarly holds one third of a square prism. Three matching measures fill the larger solid.');svg.classList.add('f13f-svg');svg.setAttribute('tabindex','0');svg.setAttribute('role','group');svg.setAttribute('aria-label','Compare matched solid volumes. In Explore, drag the arrow right or press right arrow to pour a measure; left arrow removes one.');stage.appendChild(svg);defs(svg);var root=e(svg,'g',{'data-f13f-root':'true'}),raf=0,ctrl=new AbortController(),pointer=null,pStart=0,dragging=false;
 function render(){draw(root,st,W,H);var capLabel=stage.querySelector('.nv-cap span');if(capLabel)capLabel.textContent='PYRAMID + CONE FILL · '+(st.kind==='cone'?'r ':'s ')+st.base+' · h '+st.ht;var n=stage.querySelectorAll('.f12-strip .nv-ntile .mt');var vals=[String(st.pours)+'/3',formula(st,true),formula(st,false)];vals.forEach(function(v,i){if(n[i])n[i].textContent=v;});}
 function refresh(){if(raf)cancelAnimationFrame(raf);raf=requestAnimationFrame(function(){raf=0;render();NOVA.events.emit('value',{engine:EN,control:'fill',value:{kind:st.kind,base:st.base,h:st.ht,pours:st.pours,phase:st.phase,sourceVolume:smallVolume(st),matchedVolume:bigVolume(st)}});});}
 st.refresh=refresh;st.svg=svg;render();F.strip(stage,[['pours',st.pours+'/3','focus'],['⅓',formula(st,true),'op'],['whole',formula(st,false),'result']]);
 NOVA.scene.helperStrip(stage,pose||'explain',message||'Three equal cone or pyramid measures fill the matched solid.');
 st.cleanup=function(){ctrl.abort();if(raf)cancelAnimationFrame(raf);if(st.anim)cancelAnimationFrame(st.anim);st.anim=0;pointer=null;svg.classList.remove('f13f-drag');};stage._f13Cleanup=st.cleanup;
 function finishPointer(ev){if(pointer!==ev.pointerId)return;var far=ev.clientX-pStart;pointer=null;svg.classList.remove('f13f-drag');try{if(svg.hasPointerCapture(ev.pointerId))svg.releasePointerCapture(ev.pointerId);}catch(x){}if(allowDrag&&far>42)pour(st);else if(allowDrag&&far< -42)undoPour(st);}
 svg.addEventListener('pointerdown',function(ev){if(!allowDrag||ev.pointerType==='mouse'&&ev.button!==0)return;pointer=ev.pointerId;pStart=ev.clientX;try{svg.setPointerCapture(pointer);}catch(x){}svg.classList.add('f13f-drag');ev.preventDefault();},{signal:ctrl.signal});
 svg.addEventListener('pointerup',finishPointer,{signal:ctrl.signal});svg.addEventListener('pointercancel',function(ev){if(ev.pointerId===pointer){pointer=null;svg.classList.remove('f13f-drag');}},{signal:ctrl.signal});svg.addEventListener('lostpointercapture',function(ev){if(ev.pointerId===pointer){pointer=null;svg.classList.remove('f13f-drag');}},{signal:ctrl.signal});window.addEventListener('blur',function(){pointer=null;svg.classList.remove('f13f-drag');},{signal:ctrl.signal});
 svg.addEventListener('keydown',function(ev){if(['ArrowRight','ArrowLeft','Home','End'].indexOf(ev.key)<0||!allowDrag)return;ev.preventDefault();if(ev.key==='ArrowRight')pour(st);else if(ev.key==='ArrowLeft')undoPour(st);else{stopAnimation(st);st.pours=ev.key==='End'?3:0;st.phase=0;st.flow=false;st.refresh();}},{signal:ctrl.signal});
 return svg;}
function stopAnimation(st){if(st.anim)cancelAnimationFrame(st.anim);st.anim=0;st.flow=false;st.phase=0;}
function pour(st,after){if(st.anim||st.pours>=3){if(st.pours>=3&&after)after();return false;}st.flow=true;var start=performance.now(),dur=NOVA.reducedMotion()?1:950;function frame(now){var t=clamp((now-start)/dur,0,1);st.phase=t*t*(3-2*t);st.refresh();if(t<1){st.anim=requestAnimationFrame(frame);}else{st.anim=0;st.pours++;st.phase=0;st.flow=false;st.refresh();if(after)after();}}st.anim=requestAnimationFrame(frame);return true;}
function undoPour(st){if(st.anim)return false;st.pours=clamp(st.pours-1,0,3);st.phase=0;st.refresh();return true;}
function btn(label,fn,cls){return h('button',{class:'nova-btn'+(cls?' '+cls:''),text:label,onclick:fn});}
function row(panel,arr){panel.appendChild(h('div',{class:'pr-row'},arr));}
function range(label,min,max,value,onChange){var input=h('input',{type:'range',min:String(min),max:String(max),value:String(value),step:'1','aria-label':label}),number=h('span',{class:'f13f-value',text:String(value)}),lab=h('label',{class:'f13f-label'},[label+' ',input,number]);input.oninput=function(){number.textContent=input.value;onChange(+input.value);};return {node:lab,input:input,set:function(v){input.value=v;number.textContent=v;}};}
var STEPS=[
 {n:'A pair of matching solids',key:'cone',p:0,pose:'explain',m:'These solids have the same circular base and the same perpendicular height. Only their shapes are different.',q:'What must match for this comparison to be fair?'},
 {n:'Look at the cone',key:'cone',p:0,pose:'point-right',m:'The cone narrows from the circular base towards one vertex. Its base radius is three units and its perpendicular height is four.',q:'Which height do we measure?'},
 {n:'Compare the cylinder',key:'cone',p:0,pose:'think',m:'The matching cylinder is straight all the way down. Its volume is thirty-six pi cubic units.',q:'What formula finds a cylinder volume?'},
 {n:'First cone measure',key:'cone',p:1,pose:'explain',m:'One whole cone measure fills exactly one third of our matching cylinder.',q:'How much of the cylinder is full?'},
 {n:'Second cone measure',key:'cone',p:2,pose:'point-right',m:'Pour a second identical cone measure. The cylinder is now two thirds full.',q:'What fraction remains empty?'},
 {n:'Third cone measure',key:'cone',p:3,pose:'celebrate',m:'Three identical cone measures fill the cylinder. So the cone must have one third of its volume.',q:'How many cone measures make one cylinder?'},
 {n:'Calculate the cone',key:'cone',p:3,pose:'explain',m:'Divide thirty-six pi by three. The cone volume is twelve pi cubic units.',q:'Why do we divide by three?'},
 {n:'Change the cone size',key:'coneSmall',p:1,pose:'think',m:'With radius two and height six, the cylinder is twenty-four pi cubic units. The cone is eight pi.',q:'Does the one-third relationship change?'},
 {n:'Now compare a pyramid',key:'pyramid',p:0,pose:'explain',m:'The square pyramid and matching square prism share the same square base and perpendicular height.',q:'Which shape has the same base area as the pyramid?'},
 {n:'Pour pyramid measures',key:'pyramid',p:2,pose:'point-right',m:'Two full pyramid measures would fill two thirds of the matching prism.',q:'How much space is left?'},
 {n:'Complete the prism',key:'pyramid',p:3,pose:'celebrate',m:'Three pyramid measures fill the prism. The pyramid volume is base area times height, divided by three.',q:'What is the volume formula for a pyramid?'},
 {n:'Use the general rule',key:'pyramidSmall',p:3,pose:'think',m:'This works whenever the two solids have equal base areas and equal perpendicular heights. A pyramid or cone takes one third.',q:'What stays the same when we change the dimensions?'}
];
function stepState(s){var st=mkState(s.key);st.pours=s.p;return st;}
var def={id:EN,title:'Pyramid and cone fill',config:CFG,steps:STEPS.map(function(s){return {name:s.n,narration:s.m,prompt:s.q,dur:1800};}),
 alt:'Two carefully matched transparent solids in NOVA neon glass. An inverted cone or square pyramid measuring vessel on the left, a cylinder or square prism on the right; three numbered fill indicators and area-and-volume calculations. Filling the right-hand solid requires exactly three matching measures.',
 staticAlt:'For equal base area A and perpendicular height h, prism or cylinder volume is Ah. The matching pyramid or cone has one third that volume, Ah/3. Cone V=πr²h/3. Square pyramid V=s²h/3. With r=3 and h=4, cone=12π units³, cylinder=36π units³.',
 render:function(i,stage){var s=STEPS[i];makeStage(stage,stepState(s),s.m,s.pose,false);},
 exploreIntro:'Choose matched 3D solids. Pour the same measure three times; the target fills at one third, two thirds and completely full. Use the sliders to change dimensions.',
 explore:function(panel,stage,api){var st=mkState('cone');if(api.onCleanup)api.onCleanup(function(){if(stage._f13Cleanup)stage._f13Cleanup();});
 var sel=h('select',{class:'nova-input','aria-label':'Matched solids preset'});Object.keys(CFG.presets).forEach(function(k){sel.appendChild(h('option',{value:k,text:CFG.presets[k]}));});
 row(panel,[h('label',{class:'f13f-label'},['SHAPES ',sel])]);
 var base=range('RADIUS',2,8,st.base,function(v){stopAnimation(st);st.base=v;st.pours=0;st.refresh();}),height=range('HEIGHT',2,8,st.ht,function(v){stopAnimation(st);st.ht=v;st.pours=0;st.refresh();});
 row(panel,[base.node,height.node]);
 function setPreset(k){var p=PRESETS[k];stopAnimation(st);st.preset=k;st.kind=p[0];st.base=p[1];st.ht=p[2];st.pours=0;base.set(st.base);height.set(st.ht);base.node.firstChild.textContent=st.kind==='cone'?'RADIUS ':'SIDE ';base.input.setAttribute('aria-label',st.kind==='cone'?'RADIUS':'SIDE');st.refresh();}
 sel.onchange=function(){setPreset(sel.value);};
 row(panel,[btn('Pour one measure',function(){pour(st);},'primary'),btn('Remove one',function(){undoPour(st);},'ghost'),btn('Fill 3 measures',function(){stopAnimation(st);st.pours=3;st.refresh();},'ghost'),btn('Reset',function(){setPreset(sel.value);},'ghost')]);
 panel.appendChild(h('p',{class:'f13f-instructions',text:'Drag right across the drawing or press → to pour one measure. Press ← to remove one; Home empties and End fills. All volume calculations use perpendicular height, not sloping side length.'}));
 makeStage(stage,st,'Try pouring three identical measures. Compare the two volumes!','explain',true);
 CFG._explore={state:st,preset:function(k){sel.value=k;sel.onchange();},pour:function(){return pour(st);},undo:function(){return undoPour(st);},full:function(){stopAnimation(st);st.pours=3;st.refresh();},reset:function(){setPreset(sel.value);},set:function(b,z){base.input.value=b;base.input.oninput();height.input.value=z;height.input.oninput();}};
 },
 challenge:function(panel,api,stage){var tasks=[
 {key:'cone',big:36,small:12,q:'A cone has radius 3 and perpendicular height 4. Give the cylinder and cone volume coefficients of π.',hint:'First calculate π × 3² × 4, then divide by THREE.'},
 {key:'pyramid',big:180,small:60,q:'A square pyramid has base side 6 and perpendicular height 5. Give the matching prism volume and pyramid volume (whole cubic units).',hint:'Find square base area 6², multiply by perpendicular height 5, then divide by three.'},
 {key:'coneSmall',big:24,small:8,q:'A cone has radius 2 and perpendicular height 6. Find the cylinder and cone volume coefficients of π.',hint:'Use base area π × 2², then multiply by height 6. Divide the cylinder result by 3.'}
 ];var k=0,timer=0,st=mkState('cone'),question=h('p',{class:'pr-task'}),large=h('input',{type:'number',step:'any',class:'nova-input','aria-label':'Matched prism or cylinder volume'}),small=h('input',{type:'number',step:'any',class:'nova-input','aria-label':'Cone or pyramid volume'}),feedback=h('p',{class:'f13f-feedback','aria-live':'polite'}),name1=h('span',{text:'CYLINDER ×π '}),name2=h('span',{text:'CONE ×π '});
 function load(i){k=i;var t=tasks[k],s=mkState(t.key);stopAnimation(st);Object.assign(st,s);st.pours=0;large.value='';small.value='';question.textContent=(k+1)+' / '+tasks.length+' · '+t.q;name1.textContent=st.kind==='cone'?'CYLINDER ×π ':'PRISM units³ ';name2.textContent=st.kind==='cone'?'CONE ×π ':'PYRAMID units³ ';feedback.textContent='';makeStage(stage,st,'Both solids have the same base area and perpendicular height. Start with the larger volume.','think',false);}
 function check(){var t=tasks[k],a=Number(large.value),b=Number(small.value),provided=large.value.trim()!==''&&small.value.trim()!=='',ok=provided&&a===t.big&&b===t.small;
 var msg=!provided?'Enter BOTH volumes.':ok?'Correct. The smaller volume is exactly one third of the matched solid.':a!==t.big?'Check the base area multiplied by PERPENDICULAR height for the prism or cylinder.':b===t.big?'The cone or pyramid is NOT the same volume. Divide by three.':b===t.big/2?'You divided by two. Three identical measures fill the matching solid.':'The larger volume is right. Divide by three for the pyramid or cone.';
 feedback.textContent=msg;api.check(ok,msg,{task:k,matchedVolume:a,oneThirdVolume:b,expectedMatched:t.big,expectedOneThird:t.small});if(ok&&k<tasks.length-1){if(timer)clearTimeout(timer);timer=setTimeout(function(){load(k+1);},1100);}return ok;}
 if(api.onCleanup)api.onCleanup(function(){if(timer)clearTimeout(timer);if(stage._f13Cleanup)stage._f13Cleanup();});
 panel.appendChild(question);row(panel,[h('label',{class:'f13f-answer'},[name1,large]),h('label',{class:'f13f-answer'},[name2,small])]);row(panel,[btn('Check answers',check,'primary'),btn('Hint',function(){api.hint(tasks[k].hint);},'ghost'),btn('Show three fills',function(){stopAnimation(st);st.pours=3;st.refresh();},'ghost')]);panel.appendChild(feedback);panel.appendChild(h('p',{class:'f13f-instructions',text:'In cone questions enter only the coefficient of π. Example: type 12 for 12π. In pyramid questions enter the whole-number volume.'}));load(0);
 CFG._challenge={tasks:tasks,inputs:[large,small],load:load,check:check,task:function(){return k;},state:st};
 }
};
NOVA.bankMount({id:EN,num:'F13·09',title:'Pyramid and cone fill',def:def,linked:['F0-01','F0-02','F0-03','F0-04','F0-05','F13-01','F13-05','F13-06','F13-07','F13-08'],spec:{
 purpose:'Compare the volume of a pyramid/cone to a matching prism/cylinder with the same base area and perpendicular height (Year 9).',
 params:'Six accurate presets; radius or square-base side 2–8; height 2–8; exact cone volumes in multiples of π, square pyramid volumes in cubic units.',
 presets:'Three circular pairs and three square-base pairs with equal-area and equal-height volume comparisons.',
 steps:STEPS.map(function(x){return x.n;}).join(' → '),
 interactions:'Twelve Watch and Guided teaching steps, three-measure fill animation, radius/side/height sliders, pointer and keyboard pour, three marked challenge questions.',
 traps:'The ratio is one third, not one half; use PERPENDICULAR height, not slant height; the matching prism/cylinder must share both base area and perpendicular height.',
 gcse:'Derive and use V=⅓πr²h and V=⅓Ah. Relate pyramids to prisms and cones to cylinders.'}});
var log=document.getElementById('log'),ev=function(ev){log.textContent=new Date(ev.time).toLocaleTimeString()+' '+ev.type+' '+JSON.stringify(ev.detail)+'\n'+log.textContent.slice(0,4000);};NOVA.events.history().forEach(ev);NOVA.events.on('*',ev);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
