"""Build NOVA F13-09 against the official, unmodified F13-08 embedded NOVA core."""
from pathlib import Path
root=Path(__file__).resolve().parent
base=(root/'F13-08-Cylinder-Unroll-PREMIUM-CORE.html').read_text()
css=(root/'f13_09_addon.css').read_text()
js=(root/'f13_09_engine.js').read_text()
idx=base.index('/* F13-08 additive component styles')
end=base.index('</style>',idx)
base=base[:idx]+css+'\n'+base[end:]
a=base.index('/* F13-08 CYLINDER UNROLL')
b=base.rfind('</script>')
base=base[:a]+js+'\n'+base[b:]
base=base.replace('NOVA F13-05 · Premium Cube-Stacking Volume','NOVA F13-09 · Premium Pyramid and Cone Fill')
base=base.replace('F13-08" data-title="Cylinder unroll" data-sub="Slide a cross-section through a 3D prism and discover why volume equals area × perpendicular length."', 'F13-09" data-title="Pyramid and cone fill" data-sub="Three cone or pyramid measures fill the matching cylinder or prism. Discover one-third volume."')
target=root.parent/'F13-09-Pyramid-and-Cone-Fill-PREMIUM-CORE.html'
target.write_text(base)
print('Built',target, f'({target.stat().st_size:,} bytes)')
