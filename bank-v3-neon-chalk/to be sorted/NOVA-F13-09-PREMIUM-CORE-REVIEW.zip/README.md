# NOVA Maths — F13-09 Pyramid and Cone Fill — Premium-Core Review

**Status:** Complete for local visual review only; not yet final GOLD approval. **GitHub was not touched.**

## Open and test

Open `F13-09-Pyramid-and-Cone-Fill-PREMIUM-CORE.html` in a browser. No network or server is needed.

- Watch: 12 narrated learning stages using the NOVA Timeline.
- Guided: the same learning sequence with prompted responses.
- Explore: choose cone/cylinder or square-pyramid/square-prism, adjust base dimension and perpendicular height, pour three matching measures using the button, the rightward drag or ArrowRight. Undo with ArrowLeft; Home empties and End fills.
- Challenge: three questions covering exact multiples of π and square pyramid volume; both matched and smaller volumes must be entered.

## Mathematical rules

- Equal **base areas** and equal **perpendicular heights** are necessary for each valid 1:3 comparison.
- Cylinder volume = πr²h; cone volume = πr²h / 3.
- Square prism volume = s²h; square pyramid volume = s²h / 3.
- Main cone example: r=3, h=4; cylinder=36π and cone=12π cubic units.
- Main square pyramid example: side=6, h=5; prism=180 and pyramid=60 cubic units.
- The filling is an idealised mathematical measuring experiment; the animation tracks equal **volumes**, not equal heights in the tapered cone.

## Production integrity

The HTML is built from the same original F13-08 premium-core HTML source (included under `source/`) with the original core CSS and JS **unchanged**. Only the engine-specific CSS/JS add-ons, page title and heading metadata are replaced. This preserves the original background, stage, NOVA neon/Chalk fonts and official mascot dock.

## Rebuild

Run `python source/build.py` in the extracted review folder. It regenerates the HTML in this folder.

`python qa.py` requires Python + Playwright + Chromium to reproduce the 158 browser assertions. In environments that block local URL navigation the script uses Playwright `set_content`.

## Contents

- Main standalone HTML
- `source/f13_09_engine.js` and `source/f13_09_addon.css` editable local engine source
- `source/build.py` reproducible build procedure
- `source/F13-08-Cylinder-Unroll-PREMIUM-CORE.html` prior premium-core reference
- Actual Chromium screenshots in `screenshots/`
- `QA-REPORT.md`, `QA-RESULTS.json`, `qa.py`
