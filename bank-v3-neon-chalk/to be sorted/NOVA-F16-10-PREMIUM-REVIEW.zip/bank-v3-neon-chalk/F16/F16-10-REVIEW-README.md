# F16-10 — Scatter Graph and Line of Best Fit

**Premium review only. GitHub unchanged.**

Open `F16/F16-10-scatter-and-best-fit.html` directly in your browser. This is fully standalone and contains the exact pinned F0/F2 NOVA shared runtime, fonts, assets, controls and F16-10 activity.

## Modes and presets

- WATCH — 10 progressive steps, from paired observations to best-fit lines and cautious extrapolation.
- GUIDED — step-by-step plotting, reading trends and prediction.
- EXPLORE — move plotted observations and both line endpoints; drag a new-data card onto the plot; remove observations in the red zone, regrab and recover from invalid drops; keyboard and sliders supported.
- CHALLENGE — check correlation direction, balance a reasonable line, estimate a value by interpolation; misconception-specific feedback.
- Presets — Y8-066, Y9-050, Y9-051.

## Folder map

- `F16/` — final standalone HTML and QA summary.
- `src/F16-10.js|css` — additive activity source only.
- `build/F16-10.src.html`, `build/build-f16-10.py` — deterministic, SHA-pinned builder.
- `tests/pinned-core.js|css` — exact read-only runtime snapshots to allow reproducible offline builds.
- `tests/stress_f1610.py`, `tests/challenge_presets.py`, `tests/*RESULTS.json`, `tests/*FINAL-LOG.txt` — actual browser and maths evidence.
- `shots/F16/` — selected 380px and 1280px review captures.

`python3 build/build-f16-10.py` rebuilds the HTML after verifying SHA-256 digests. It modifies only the extracted local pack, not your GitHub repository.

**Review focus:** Readability at 380px, the feel of fast drags, numerical scaling of x/y axes, meaningful correlation explanations, and whether an extrapolated prediction is sufficiently cautious. No GOLD sign-off has been assumed.
