"""Complete all three live Challenge tasks for each required preset at two widths."""
import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
R=Path(__file__).resolve().parents[1];HTML=(R/'F16/F16-10-scatter-and-best-fit.html').read_text();res=[]
def record(name,ok,details=''):
 res.append({'name':name,'ok':bool(ok),'details':str(details)})
async def main():
 async with async_playwright() as pl:
  b=await pl.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for w in [380,1280]:
   for key in ['y8-scatter','y9-correlation','y9-prediction']:
    page=await b.new_page(viewport={'width':w,'height':2400});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_default_timeout(5000);print('open',w,key,flush=True);await page.set_content(HTML)
    await page.locator('button').filter(has_text='Explore').first.click()
    await page.locator('select[aria-label="Lesson preset"]').select_option(key)
    await page.locator('button').filter(has_text='Challenge').first.click()
    data=await page.evaluate('window.NOVA_F16_10_CONFIG._challengeState()')
    record(f'{w}:{key}:task0',data['task']==0)
    choice= {'positive':'Positive','negative':'Negative','none':'Little or none'}[data['direction']]
    print('choice',choice,flush=True);await page.locator('.rs-opts button').filter(has_text=choice).click()
    print('checking',flush=True);await page.locator('.pr-row button').filter(has_text='Check').click()
    await page.wait_for_timeout(950)
    data=await page.evaluate('window.NOVA_F16_10_CONFIG._challengeState()')
    print('task after 1',data['task'],flush=True);record(f'{w}:{key}:correlation correct and advances',data['task']==1,data)
    if data['task']!=1:
     await page.close();continue
    # Fill visible slider equivalences; both change the same line endpoint positions as drag.
    t=[max(0,round(x/2)*2) for x in data['target']]
    await page.locator('input[aria-label="Move left end of best fit line"]').fill(str(t[0]))
    await page.locator('input[aria-label="Move right end of best fit line"]').fill(str(t[1]))
    data=await page.evaluate('window.NOVA_F16_10_CONFIG._challengeState()')
    record(f'{w}:{key}:sensible fitted line',all(abs(x-y)<=10 for x,y in zip(data['line'],data['target'])),data)
    print('checking',flush=True);await page.locator('.pr-row button').filter(has_text='Check').click();await page.wait_for_timeout(930)
    data=await page.evaluate('window.NOVA_F16_10_CONFIG._challengeState()')
    print('task after 2',data['task'],flush=True);record(f'{w}:{key}:line task advances',data['task']==2,data)
    if data['task']!=2:
     await page.close();continue
    inputs=await page.locator('.pr-task').count()
    fields=await page.locator('.nova-panel input').count()
    # The NOVA entry kit uses a text/number input within the Challenge control.
    number=page.locator('input[type="number"],input[type="text"]').last
    record(f'{w}:{key}:number entry present',await number.count()>=1,fields)
    await number.fill(str(round(data['prediction'],2)))
    print('checking',flush=True);await page.locator('.pr-row button').filter(has_text='Check').click();await page.wait_for_timeout(220)
    record(f'{w}:{key}:final prediction accepted',await page.get_by_text('Reasonable interpolation',exact=False).count()>0 or await page.get_by_text('Correct',exact=False).count()>0)
    record(f'{w}:{key}:no page exceptions',len(errors)==0,errors)
    # screenshot collected in separate evidence pass
    await page.close()
  await b.close()
 (R/'tests/CHALLENGE-RESULTS.json').write_text(json.dumps({'total':len(res),'passed':sum(r['ok'] for r in res),'failed':[r for r in res if not r['ok']],'results':res},indent=2))
 print('CHALLENGE',sum(r['ok'] for r in res),'/',len(res));print('FAILURES',[r for r in res if not r['ok']]);
asyncio.run(main())
