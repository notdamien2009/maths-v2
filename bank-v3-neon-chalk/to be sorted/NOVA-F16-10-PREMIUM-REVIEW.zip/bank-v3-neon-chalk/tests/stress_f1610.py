"""Browser and real-pointer regression, rendered from the exact standalone bytes using set_content.
File/localhost navigations can be blocked by the sandbox, so no network access is required.
"""
import asyncio,json,math,statistics,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
R=Path(__file__).resolve().parents[1]; html=(R/'F16/F16-10-scatter-and-best-fit.html').read_text()
results=[];fail=[]
def check(label,ok,details=None):
 results.append({'label':label,'ok':bool(ok),'details':details})
 if not ok:fail.append(label)
async def mode(page,label):
 await page.locator('button').filter(has_text=label).first.click();await page.wait_for_timeout(120)
async def locate(page,selector):
 return await page.locator(selector).first.bounding_box()
async def svg_point(page,x,y):
 return await page.evaluate('''([x,y])=>{const svg=document.querySelector('.f1610-svg'),m=svg.getScreenCTM();return{x:m.a*x+m.c*y+m.e,y:m.b*x+m.d*y+m.f}}''',[x,y])
async def drag(page,sel,target,fast=True):
 b=await locate(page,sel); assert b and b['width']>0,sel
 sx=b['x']+b['width']/2;sy=b['y']+b['height']/2
 await page.mouse.move(sx,sy);await page.mouse.down()
 if fast:await page.mouse.move(target['x'],target['y'],steps=1)
 else:await page.mouse.move(target['x'],target['y'],steps=15)
 await page.mouse.up();await page.wait_for_timeout(420)
async def openp(browser,w,mode_name=None):
 p=await browser.new_page(viewport={'width':w,'height':2400});errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 await p.set_content(html,wait_until='domcontentloaded');await p.wait_for_timeout(450)
 if mode_name:await mode(p,mode_name)
 return p,errors
async def main():
 async with async_playwright() as pl:
  browser=await pl.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for width in [380,1280]:
   page,errors=await openp(browser,width)
   check(f'{width}: shell has no page errors',not errors,str(errors));check(f'{width}: no document horizontal overflow',await page.evaluate('document.documentElement.scrollWidth<=document.documentElement.clientWidth'))
   for preset in ['y8-scatter','y9-correlation','y9-prediction']:
    await mode(page,'Explore');await page.locator('select[aria-label="Lesson preset"]').select_option(preset);await page.wait_for_timeout(90)
    C=await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get()')
    xs=[p[0] for p in C['pairs']];ys=[p[1] for p in C['pairs']]
    expected_r=statistics.correlation(xs,ys)
    check(f'{width} {preset}: 9 distinct observation rings',await page.locator('[data-point]').count()==9)
    check(f'{width} {preset}: correct Pearson correlation',abs(expected_r-C['regression']['r'])<1e-9)
    check(f'{width} {preset}: correct regression predicted midpoint',abs(C['regression']['intercept']+C['regression']['slope']*5-(sum(ys)/9-C['regression']['slope']*sum(xs)/9+C['regression']['slope']*5))<1e-8)
    check(f'{width} {preset}: single stage mascot dock',await page.locator('.nova-stage .nv-dock').count()==1)
    check(f'{width} {preset}: outside extra mascot hidden',await page.evaluate("[...document.querySelectorAll('.nova-bob .nova-side')].every(x=>getComputedStyle(x).display==='none')"))
    check(f'{width} {preset}: no errors',not errors)
    await page.screenshot(path=str(R/f'shots/F16-10-{width}-{preset}-explore.png'),full_page=True)
    await mode(page,'Watch');check(f'{width} {preset}: opening has paired source',await page.locator('.f1610-svg').count()==1)
    check(f'{width} {preset}: no full plot at opening',await page.locator('.nv-plot').count()==0)
    await mode(page,'Guided');check(f'{width} {preset}: guided visible',await page.locator('.f1610-svg').count()==1)
    await mode(page,'Challenge');check(f'{width} {preset}: challenge numeric graph',await page.locator('.nv-plot').count()==1)
    check(f'{width} {preset}: challenge 3 tasks specified',bool(await page.locator('.pr-task').inner_text()))
   await page.close()
   page,errors=await openp(browser,width,'Explore')
   # Fast real mouse drop. Move the first observation from x=1,y=22 to x=3,y=46.
   tgt=await svg_point(page,83+305*3/10 if width==380 else 100+570*3/10,176+438*(1-46/100) if width==380 else 152+430*(1-46/100))
   before=await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get()')
   await drag(page,'[data-point="0"]',tgt,True)
   after=await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get()')
   check(f'{width}: real fast pointer changes exact point',after['pairs'][0]==[3,46],str(after['pairs'][0]))
   check(f'{width}: no stranded drag after point',await page.evaluate('NOVA.ui._drag===null'))
   # Endpoints must reposition by genuine native mouse movement.
   b=await locate(page,'[data-line-end="0"]');old=after['line'][0]
   t={'x':b['x']+b['width']/2,'y':b['y']-40};await drag(page,'[data-line-end="0"]',t,True)
   after2=await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get()')
   check(f'{width}: real pointer moves line A',after2['line'][0]!=old,str([old,after2['line'][0]]))
   check(f'{width}: no stranded line drag',await page.evaluate('NOVA.ui._drag===null'))
   # Cancel a new fast drag by Escape without mutating value.
   b=await locate(page,'[data-point="1"]');pre=await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get().pairs[1]')
   await page.mouse.move(b['x']+b['width']/2,b['y']+b['height']/2);await page.mouse.down();await page.mouse.move(b['x']+80,b['y']-80,steps=1)
   await page.keyboard.press('Escape');await page.mouse.up();await page.wait_for_timeout(480)
   post=await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get().pairs[1]')
   check(f'{width}: Escape leaves data unchanged',pre==post)
   check(f'{width}: Escape clears drag state',await page.evaluate('NOVA.ui._drag===null'))
   # Regrab and use keyboard equivalent.
   await page.locator('[data-point="2"]').focus();pre=await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get().pairs[2]')
   await page.keyboard.press('ArrowRight');post=await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get().pairs[2]')
   check(f'{width}: keyboard point arrow changes x',post[0]==pre[0]+1)
   # Original source token add (mouse) and removal (mouse).
   token=await locate(page,'[data-source]')
   tgt=await svg_point(page,83+305*5/10 if width==380 else 100+570*5/10,176+438*(1-50/100) if width==380 else 152+430*(1-50/100))
   size=len((await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get()'))['pairs'])
   await drag(page,'[data-source]',tgt,True)
   check(f'{width}: native new-data card adds observation',len((await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get()'))['pairs'])==size+1)
   rm=await svg_point(page,277+71 if width==380 else 569+79,814+27 if width==380 else 733+21)
   await drag(page,'[data-point="0"]',rm,True)
   await page.wait_for_timeout(360)
   check(f'{width}: native red removal removes observation',len((await page.evaluate('window.NOVA_F16_10_CONFIG._explore.get()'))['pairs'])==size)
   check(f'{width}: no runtime errors after native pointer stress',not errors,str(errors))
   await page.screenshot(path=str(R/f'shots/F16-10-{width}-stressed-explore.png'),full_page=True)
   await page.close()
  await browser.close()
 (R/'tests/STRESS-RESULTS.json').write_text(json.dumps({'checks':len(results),'passed':len(results)-len(fail),'failed':len(fail),'failures':fail,'results':results},indent=2))
 print('STRESS',len(results)-len(fail),'/',len(results),'FAILURES',fail)
if __name__=='__main__':asyncio.run(main())
