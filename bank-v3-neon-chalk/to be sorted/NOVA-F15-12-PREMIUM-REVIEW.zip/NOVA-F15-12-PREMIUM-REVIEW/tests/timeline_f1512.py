from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path('/mnt/data');QA=ROOT/'F15-12-QA';checks=[]
def check(n,cond):checks.append({'test':n,'passed':bool(cond)});print(('PASS' if cond else 'FAIL'),n)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  pg=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content((ROOT/'NOVA-F15-12-Circle-Theorems-Explorer.html').read_text(),wait_until='domcontentloaded');pg.wait_for_timeout(90)
  bpause=pg.locator('#F15-12 button[aria-label="Pause"]');
  if bpause.count():bpause.click()
  sr=pg.locator('#F15-12 input[aria-label="Scrub through steps"]')
  check(f'{width} timeline scrub exists',sr.count()==1)
  for i in range(16):
   sr.fill(str(i));sr.dispatch_event('input');pg.wait_for_timeout(55)
   stepname=pg.locator('#F15-12 .nova-stepname').inner_text();check(f'{width} state {i+1} correct label',('Step '+str(i+1)+' of 16') in stepname)
   check(f'{width} state {i+1} stage present',pg.locator('#F15-12 svg.f1512-board').count()==1)
   if i in [0,4,6,8,10,12,14,15]:
    pg.screenshot(path=str(QA/'screenshots'/f'{width}-watch-state-{i+1:02}.png'),full_page=True)
  sr.fill('0');sr.dispatch_event('input');pg.wait_for_timeout(80)
  pg.locator('#F15-12 button[aria-label="Step forward"]').click();pg.wait_for_timeout(110)
  check(f'{width} forward',pg.locator('#F15-12 .nova-stepname').inner_text().startswith('Step 2 of 16'))
  pg.locator('#F15-12 button[aria-label="Step back"]').click();pg.wait_for_timeout(110)
  check(f'{width} rewind',pg.locator('#F15-12 .nova-stepname').inner_text().startswith('Step 1 of 16'))
  check(f'{width} timeline no errors',not errors)
  pg.close()
 b.close()
(QA/'tests'/'timeline.json').write_text(json.dumps(checks,indent=2))
print('TIMELINE',sum(x['passed'] for x in checks),'/',len(checks))
if not all(x['passed'] for x in checks):raise SystemExit(1)
