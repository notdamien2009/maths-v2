from pathlib import Path
from playwright.sync_api import sync_playwright
import json,math,hashlib,re,traceback
ROOT=Path('/mnt/data'); QA=ROOT/'F15-12-QA';(QA/'screenshots').mkdir(parents=True,exist_ok=True)
source=(ROOT/'NOVA-F15-12-Circle-Theorems-Explorer.html').read_text()
checks=[]
def ck(name,cond,detail=''):
 ok=bool(cond);checks.append({'test':name,'passed':ok,'detail':str(detail)});print(('PASS' if ok else 'FAIL'),name,detail if not ok else '')
def screenpoint(pg,angle):
 return pg.evaluate('''a=>{let sv=document.querySelector('#F15-12 .f1512-board'),m=sv.getScreenCTM(),g=NOVA_F15_12_MATH.geo(NOVA_F15_12_CONFIG._explore.state());let x=g.cx+g.r*Math.cos(a*Math.PI/180),y=g.cy-g.r*Math.sin(a*Math.PI/180);return{x:m.a*x+m.c*y+m.e,y:m.b*x+m.d*y+m.f};}''',angle)
def mid(box):return box['x']+box['width']/2,box['y']+box['height']/2
def drag(pg,loc,xy,steps=2):
 a=mid(loc.bounding_box());pg.mouse.move(*a);pg.mouse.down();pg.mouse.move(xy['x'],xy['y'],steps=steps);pg.mouse.up();pg.wait_for_timeout(450)
def locpoint(pg,key):return pg.locator('[data-point="'+key+'"]')
def stage_coord(pg,x,y):return pg.evaluate('''p=>{let m=document.querySelector('#F15-12 .f1512-board').getScreenCTM();return{x:m.a*p[0]+m.c*p[1]+m.e,y:m.b*p[0]+m.d*p[1]+m.f}}''',[x,y])
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  pg=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(source,wait_until='domcontentloaded',timeout=90000)
  C='NOVA_F15_12_CONFIG';pg.locator('.nova-tabs button').nth(2).click()
  ck(f'{width} explore selected',pg.evaluate('NOVA_F15_12_CONFIG._explore.state().kind')=='centre')
  ck(f'{width} labelled mathematical sectors',pg.locator('[data-label]').count()==3)
  # Actual mouse drag, from 72° to 115°, with a single fast pointermove.
  try:
   drag(pg,locpoint(pg,'P'),screenpoint(pg,115),steps=1)
   ck(f'{width} real mouse fast drag point P 115°',pg.evaluate('NOVA_F15_12_CONFIG._explore.state().p')==115)
  except Exception as e:ck(f'{width} real mouse fast drag point P 115°',False,str(e)[:160])
  # Actual mouse drag second circumference point, changing central angle 130° to 105°.
  try:
   locpoint(pg,'B').scroll_into_view_if_needed();drag(pg,locpoint(pg,'B'),screenpoint(pg,310),steps=1)
   ck(f'{width} B drag recalculates centre angle',pg.evaluate('NOVA_F15_12_CONFIG._explore.state().arc')==105)
  except Exception as e:ck(f'{width} B drag recalculates centre angle',False,str(e)[:160])
  ck(f'{width} inscribed half central',pg.evaluate('NOVA_F15_12_CONFIG._explore.state().arc / 2')==52.5)
  # Drag to invalid region: returns rather than stranded.
  try:
   before=pg.evaluate('NOVA_F15_12_CONFIG._explore.state().p')
   drag(pg,locpoint(pg,'P'),stage_coord(pg,215 if width==380 else 276,230 if width==380 else 242))
   ck(f'{width} invalid drop returns to previous angle',pg.evaluate('NOVA_F15_12_CONFIG._explore.state().p')==before)
   ck(f'{width} invalid drop has no floating drag',pg.evaluate('!NOVA.ui._drag'))
  except Exception as e:ck(f'{width} invalid drop safe',False,str(e)[:160])
  try:
   before=pg.evaluate('NOVA_F15_12_CONFIG._explore.state().p')
   loc=locpoint(pg,'P');x,y=mid(loc.bounding_box());pg.mouse.move(x,y);pg.mouse.down();q=screenpoint(pg,145);pg.mouse.move(q['x'],q['y'],steps=1);pg.keyboard.press('Escape');pg.mouse.up();pg.wait_for_timeout(500)
   ck(f'{width} Escape recovers original position',pg.evaluate('NOVA_F15_12_CONFIG._explore.state().p')==before)
  except Exception as e:ck(f'{width} Escape recovery',False,str(e)[:160])
  # Keyboard alternative.
  try:
   loc=locpoint(pg,'P');loc.focus();before=pg.evaluate('NOVA_F15_12_CONFIG._explore.state().p');pg.keyboard.press('ArrowLeft');pg.wait_for_timeout(60)
   ck(f'{width} point keyboard movement',pg.evaluate('NOVA_F15_12_CONFIG._explore.state().p')==before-5)
  except Exception as e:ck(f'{width} point keyboard movement',False,str(e)[:160])
  # Pointer placed semantic label onto centre, then dragged out to red removal zone.
  try:
   st=pg.evaluate('NOVA_F15_12_CONFIG._explore.state()');g=pg.evaluate('NOVA_F15_12_MATH.geo(NOVA_F15_12_CONFIG._explore.state())');
   pg.locator('[data-label="centre"]').scroll_into_view_if_needed();drag(pg,pg.locator('[data-label="centre"]'),stage_coord(pg,g['cx'],g['cy']),steps=8)
   ck(f'{width} mouse label centre snap',pg.evaluate('!!NOVA_F15_12_CONFIG._explore.state().placed.centre'))
  except Exception as e:ck(f'{width} mouse label centre snap',False,str(e)[:160])
  try:
   loc=pg.locator('[data-label="centre"]');g=pg.evaluate('NOVA_F15_12_MATH.geo(NOVA_F15_12_CONFIG._explore.state())');tx=13 if width==380 else 445;ty=574 if width==380 else 447
   drag(pg,loc,stage_coord(pg,tx+60,ty+18),steps=9)
   ck(f'{width} mouse label red tray removal',not pg.evaluate('!!NOVA_F15_12_CONFIG._explore.state().placed.centre'))
  except Exception as e:ck(f'{width} mouse label red tray removal',False,str(e)[:160])
  try:
   loc=pg.locator('[data-label="chord"]');loc.focus();pg.keyboard.press('Enter')
   ck(f'{width} keyboard label place',pg.evaluate('!!NOVA_F15_12_CONFIG._explore.state().placed.chord'))
   loc=pg.locator('[data-label="chord"]');loc.focus();pg.keyboard.press('Enter')
   ck(f'{width} keyboard label remove',not pg.evaluate('!!NOVA_F15_12_CONFIG._explore.state().placed.chord'))
  except Exception as e:ck(f'{width} keyboard label place/remove',False,str(e)[:160])
  # seven independently rendered theorem presets with semantic content and no errors.
  presets=['centre','segment','semicircle','cyclic','tangent','alternate','gcse'];
  for k in presets:
   try:
    pg.evaluate('(k)=>NOVA_F15_12_CONFIG._explore.select(k)',k);pg.wait_for_timeout(45)
    kind=pg.evaluate('NOVA_F15_12_CONFIG._explore.state().kind');n=pg.locator('.f1512-board').count()
    ck(f'{width} preset {k}',n==1 and kind==('centre' if k=='gcse' else k))
    if k in ['centre','cyclic','tangent','alternate']:
     pg.screenshot(path=str(QA/'screenshots'/f'{width}-{k}-explore.png'),full_page=True)
   except Exception as e:ck(f'{width} preset {k}',False,str(e)[:160])
  # Independent geometry identities using rendered mathematical model.
  data=pg.evaluate('''() => {let x=NOVA_F15_12_MATH,vals=[];for(let a=60;a<=150;a+=5){let g=x.geo({kind:'centre',arc:a,p:70});vals.push([a,x.ang3(g.A,g.P,g.B)]);}let sc=x.geo({kind:'semicircle',arc:180,p:80});let cy=x.geo({kind:'cyclic',arc:130,p:130});return{inscribed:vals,semi:x.ang3(sc.A,sc.P,sc.B),cyclic:x.ang3(x.geo({kind:'cyclic',arc:130,p:130}).A,x.geo({kind:'cyclic',arc:130,p:130}).B,x.geo({kind:'cyclic',arc:130,p:130}).P),cyclic1:cy.cyclic1,cyclic2:cy.cyclic2};}''')
  for a,actual in data['inscribed']: ck(f'{width} central {a} yields half-angle',abs(actual-a/2)<1e-7)
  ck(f'{width} semicircle exact 90°',abs(data['semi']-90)<1e-7)
  ck(f'{width} cyclic angles supplement',abs(data['cyclic1']+data['cyclic2']-180)<1e-7)
  # Actual Challenge checking for every task; wrong answers rejected and correct accepted.
  pg.locator('.nova-tabs button').nth(3).click();q=pg.evaluate('NOVA_F15_12_CONFIG._questions.map(q=>({ans:q.ans,kind:q.kind}))')
  ck(f'{width} twelve independent challenges',len(q)==12)
  for i,x in enumerate(q):
   rv=pg.evaluate('''o=>NOVA_F15_12_CONFIG._check(NOVA_F15_12_CONFIG._questions[o.i],o.v)''',{'i':i,'v':x['ans']})
   ck(f'{width} task {i+1} correct accepted',rv[0] is True)
   wrong=pg.evaluate('''o=>NOVA_F15_12_CONFIG._check(NOVA_F15_12_CONFIG._questions[o.i],o.v)''',{'i':i,'v':x['ans']+13})
   ck(f'{width} task {i+1} wrong rejected',wrong[0] is False)
  # Actual form submission, not just the mathematical check function.
  try:
   inp=pg.locator('.nova-panel input').first;inp.fill('65');pg.get_by_text('Check',exact=True).last.click(timeout=4000);pg.wait_for_timeout(150)
   body=pg.locator('#F15-12').inner_text()
   ck(f'{width} real Challenge submission',('Correct' in body or 'correct' in body),body[-200:])
  except Exception as e:ck(f'{width} real Challenge submission',False,str(e)[:160])
  ck(f'{width} browser errors = 0',not errors,';'.join(errors[:3]))
  pg.close()
 browser.close()
(QA/'tests'/'stress.json').write_text(json.dumps(checks,indent=2))
print('STRESS:',sum(x['passed'] for x in checks),'/',len(checks))
if not all(x['passed'] for x in checks):raise SystemExit(1)
