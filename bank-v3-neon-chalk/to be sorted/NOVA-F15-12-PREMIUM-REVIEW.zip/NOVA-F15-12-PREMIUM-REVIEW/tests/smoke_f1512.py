from pathlib import Path
import json
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data'); QA=ROOT/'F15-12-QA';(QA/'screenshots').mkdir(exist_ok=True,parents=True)
source=(ROOT/'NOVA-F15-12-Circle-Theorems-Explorer.html').read_text()
checks=[]
def ck(name,truth,detail=''):
 checks.append({'test':name,'passed':bool(truth),'detail':detail});print(('PASS' if truth else 'FAIL'),name,detail)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
  errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content(source,wait_until='domcontentloaded',timeout=90000)
  ck(f'{width}: title and master shell',page.title().startswith('NOVA F15-12') and page.locator('#nova-header').count()==1)
  ck(f'{width}: core loaded',page.evaluate('typeof NOVA.bankMount')=='function')
  ck(f'{width}: 4 modes',page.locator('.nova-tabs button').count()==4)
  for j,mode in enumerate(['watch','guided','explore','challenge']):
   page.locator('.nova-tabs button').nth(j).click(timeout=10000)
   page.wait_for_timeout(120)
   ck(f'{width}: {mode} SVG',page.locator('#F15-12 svg.f1512-board').count()==1)
   ck(f'{width}: {mode} helper in stage',page.evaluate("document.querySelectorAll('#F15-12 .nova-stage .nv-dock').length")>=1)
   if mode=='challenge':
    ck(f'{width}: challenge does not reveal answer',page.locator('svg.f1512-board text').filter(has_text='65°').count()==0)
   if mode=='explore':
    ck(f'{width}: explore two points and three labels',page.locator('[data-point]').count()==2 and page.locator('[data-label]').count()==3)
   page.screenshot(path=str(QA/'screenshots'/f'{width}-{mode}.png'),full_page=True)
  ck(f'{width}: no browser JS errors',not errs,'; '.join(errs[:2]))
  page.close()
 b.close()
(QA/'tests'/'smoke.json').write_text(json.dumps(checks,indent=2))
print('SMOKE',sum(x['passed'] for x in checks),'/',len(checks))
if not all(x['passed'] for x in checks):raise SystemExit(1)
