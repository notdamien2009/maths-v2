# NOVA F15-12 — Circle Theorems Explorer

Standalone premium NOVA Maths V2 review build. Open the HTML locally in a modern browser; no network or libraries needed.

Learning modes: WATCH (16 teaching states), GUIDED, EXPLORE (7 presets, constrained circle-point drag and draggable labels), CHALLENGE (12 diagnostic tasks).

Theorem families: central/circumference angles, equal same-segment angles, semicircle right angle, opposite cyclic angles supplementary, tangent-radius perpendicular, alternate-segment theorem.

This ZIP contains the standalone HTML, QA report, test scripts/results and selected review screenshots. Not GOLD-approved. No GitHub modifications.
