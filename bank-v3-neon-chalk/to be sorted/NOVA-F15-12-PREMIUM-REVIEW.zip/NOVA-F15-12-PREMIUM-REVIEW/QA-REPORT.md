# F15-12 — Circle Theorems Explorer · QA evidence

Status: **BUILT FOR OWNER REVIEW — NOT GOLD APPROVED**. The original NOVA core is unchanged. No GitHub commits or uploads.

## Build and source identity

- Source: `NOVA-F15-12-Circle-Theorems-Explorer.html` (self-contained HTML, core CSS/JS, fonts and helper artwork embedded).
- Master specification: `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, exact F15-12 section, inspected 13 October 2026.
- Visual/structural reference: `NOVA-F15-11-Circle-Parts-Diagram.html`.
- Embedded core script SHA256: `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc`. **Byte-for-byte identical** to the core script in F15-11 (automatic extraction and SHA check). The previous engine's core was not modified.
- CONFIG line 1811; 7 named presets; event key list.
- Teaching timeline line 1812; 16 named steps, relevant tutor prompts/poses.
- Mathematical geometry line 1833; constructions use exact trigonometric coordinates.
- Premium scene line 1856; core NOVA neonPath, neonBox, neonRing, chalkText, and stage helperStrip.
- Core WATCH/GUIDED render line 1945.
- EXPLORE line 1968; point drag with valid circle snap ranges, semantic draggable labels, keyboard, tray recovery.
- CHALLENGE line 1996; 12 tasks and diagnostic feedback; answer not drawn on challenge diagram.
- Pointer-release/cancel bridge line 2025; original shared drag helper remains unchanged.
- Four-mode bankMount integration line 2031.

## Browser test evidence

| Suite | Checks passed | Test script | Results |
|---|---:|---|---|
| Rendering/modes | 28/28 | `tests/smoke_f1512.py` | `tests/smoke.json` |
| Mathematics/drag/challenge | 136/136 | `tests/stress_f1512.py` | `tests/stress.json` |
| Timeline/reduced motion | 72/72 | `tests/timeline_f1512.py` | `tests/timeline.json` |
| **Total** | **236/236** | | |

All browser scripts ran in local headless Chromium using Playwright, **380px and 1280px**. They used `page.set_content` because this environment blocks navigation to local file/HTTP URLs; the HTML itself contains no external resources.

### Tested interactions and mathematics

- All four modes show one main mathematical SVG and one helper dock inside the stage.
- Seven presets rendered separately at both viewport sizes: centre, same-segment, semicircle, cyclic, tangent, alternate segment and GCSE combined.
- True pointer down → fast pointer move → pointer up on circle point P, with verified 115° snap; point B updates angle, using same exact displayed values.
- Invalid drop springs back without leaving a floating drag; Escape cancels a drag; keyboard arrows move point in 5° increments.
- A label is mouse-dragged to the correct centre target, removed by red tray, then keyboard-placed and removed. No detached labels.
- Nineteen independent central angles from 60° to 150° each independently computed to have an inscribed angle of exactly half, at both widths.
- Exact right angle in a semicircle; cyclic quadrilateral supplementary angle identity.
- All 12 Challenge tasks checked with independently supplied correct and incorrect answers at both widths; actual Challenge `Check` button submitted an answer and showed success feedback.
- Challenge does not draw unknown answer values, including the sample 65° result.
- 16 WATCH teaching states scrubbed and rendered at both viewport sizes, plus forward and rewind controls, under `reduced_motion=reduce`.
- Zero recorded page JavaScript errors in all suites.

### Screenshots inspected

`380-watch.png`, `380-guided.png`, `380-explore.png`, `380-challenge.png`, their `1280-` equivalents, plus mobile theorem close-ups (`380-cyclic-explore.png`, `380-tangent-explore.png`, `380-alternate-explore.png`) and watch proof reveal states (`380-watch-state-09.png`, `380-watch-state-11.png`, `380-watch-state-15.png`). The house neon frames, glass depth, chalk mathematical labels, docked original cat/helper and stage all remain present.

## Teaching accuracy gates

- Centre angle double the circumference angle: fixed endpoints, correct intercepted arc.
- Angles in the same segment equal: both vertices kept on the same major arc.
- Angle in a semicircle: diameter endpoint gap 180°, inscribed angle 90°.
- Cyclic quadrilateral: opposite vertices sum to 180° even after moving B along its valid arc.
- Radius and tangent: perpendicular derivative to circle at the contact point.
- Alternate segment: tangent-chord angle at A equals the inscribed angle on the opposite arc.
- WATCH progressively reveals each result only at its intended teaching state; Challenge never reveals its unknown numerical angle.

## Owner acceptance gate

No GOLD approval is implied. Manual owner stress-testing and visual acceptance remain outstanding; apply only targeted fixes if issues are found. Do not push to GitHub without explicit permission.
