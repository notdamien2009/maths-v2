# F14-12 Vector Builder — Premium Review QA

**Status:** Owner review, not GOLD-approved. GitHub was not changed.

## Production provenance

- F14-12 was built from the F14 master specification (`NOVA-MASTER-FOR-OTHER-AI.md`) and the user's supplied F0/F2 premium references.
- The HTML includes the **exact unchanged canonical NOVA core JavaScript** from the established F14-11 F0/F2 shell, including fonts, mascot artwork, neon primitives and drag engine. The HTML is standalone.
- Standard navy/purple stage gradient, premium stage borders and one mascot inside its lower-right dock. The maths is the dominant artwork with no extra teaching row dividing the stage.

## Automated QA

**169 checks passed, 0 failed** across three suites:

| Suite | Pass | Fail |
|---|---:|---:|
| Mode/preset/maths/challenge regression | 120 | 0 |
| Real-pointer drag/cancel/keyboard stress | 24 | 0 |
| Final screenshots/layout/core integrity/reduced motion | 25 | 0 |

The suites covered **380px and 1280px** in Chromium. They verified all four modes, single internal mascot, no horizontal overflow, no page exceptions, working focusable keyboard controls, and no stranded pointer after Escape. Eight challenge tasks advance on correct answers at both sizes. The final challenge **begins with an unsolved vector** and requires construction. The final drag-to-answer task also succeeded with actual mouse movement at both sizes using viewport-calibrated displacement.

### Mathematical presets verified

| Preset | Verified vector computation |
|---|---|
| Y8 head-to-tail | (4, 1) + (2, 3) = (6, 4) |
| Translation | (3, −2) + (2, −1) = (5, −3) |
| Negative components | (−3, 3) + (2, −4) = (−1, −1) |
| Vector subtraction | (4, 2) − (1, 3) = (3, −1) |
| Repeat a vector | (2, 2) + (2, 2) = (4, 4) |
| Opposite vectors | (4, 3) + (−4, −3) = (0, 0) |
| GCSE extension | (−3, 4) + (2, 1) = (−1, 5) |

The challenges also check horizontal/vertical component order, negative signs, point-to-point vector subtraction, scalar multiplication and zero vector reasoning. Challenge scenes were adjusted to match their question numbers exactly.

### Interactions and lessons learned

- The original F2 `NOVA.ui.svgDrag` is used for the blue u endpoint, gold v control, and green resultant endpoint, with snap zones, lift effects, focus/keyboard alternatives, snap-back and Escape recovery.
- The gold v handle is positioned off a shared endpoint where the second vector is short; this avoids a pointer collision with the green resultant and includes a visible short guide line.
- The blue, purple and green vectors are drawn as mathematical arrows, joined head-to-tail; column notation uses proper **stacked two-row vector components** in NOVA Chalk.
- The animation names and six teaching explanations are distinct; reduced-motion handling was exercised step-by-step.

### Visual evidence and human acceptance

The `screenshots/` folder contains **12 real Chromium screenshots**: Watch, Guided, Explore and Challenge at 380px and 1280px, plus subtraction and zero-vector views at each width.

For acceptance, inspect the drawing scale, arrowheads and column-vector brackets against F0/F2 references. Manual touch-device, assistive-technology and high-speed edge-case stress testing is still recommended. **Do not mark as GOLD until approved by the owner.**
