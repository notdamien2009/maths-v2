# NOVA Maths V2 · F13-02 Premium Net Folder

Open `F13-02-Net-Folder-PREMIUM-CORE.html` in Chrome or Edge. Original NOVA core, mascot and chalk assets are fully inlined, so no network needed.

Watch: 8 teaching steps. Guided: Bob prompts. Explore: choose a cube, cuboid, triangular prism or square pyramid; fold slider, true hinged 3D, camera rotation, detachable end square, face highlights. Challenge: three marked tasks.

Source files are included in `source/`. Running `source/build.py` requires the user-uploaded `F12-03-geoboard-builder(1).html` at the documented original location; the standalone HTML needs no extra files.

Review build only. GitHub was not changed.
