# NOVA Maths V2 — F18-05 Money and Change

Status: Built and tested for owner review. NOT GOLD-approved.

The HTML is fully standalone and includes the previously established NOVA shared F0/F2 core, original chalk fonts, controls and in-stage mascot. GitHub was not changed.

Includes six lesson presets: checkout change, café change, unit price/best buy, wages and spending, percent discount, further change. The mathematically correct calculations are in the HTML and the QA report.

Four modes: WATCH (6 teaching/narration beats), GUIDED, EXPLORE (actual draggable coins/notes), CHALLENGE (6 money-and-units-checked tasks).

Controls: drag and release coins onto the money mat, re-grab a placed coin and return it to the tray, Escape to cancel, Enter/Space to place and Enter/Delete to remove, left/right arrows between coins.

Automated checks: 198 / 198 across 380px and 1280px. See F18-05-QA-REPORT.html and tests/*.json for exact evidence.

Open F18-05-money-and-change.html locally in a modern browser. No web access required.

Touchscreen hardware and owner visual acceptance are outstanding.
