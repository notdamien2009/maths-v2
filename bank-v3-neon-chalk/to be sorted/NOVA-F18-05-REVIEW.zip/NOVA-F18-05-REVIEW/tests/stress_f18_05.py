import json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data');QA=ROOT/'f18_05_qa';QA.mkdir(exist_ok=True)
HTML=(ROOT/'F18-05-money-and-change.html').read_text()
checks=[]
def ck(name,ok,detail=''):
 checks.append({'name':name,'ok':bool(ok),'detail':str(detail)[:300]})
 if not ok:print('FAIL',name,detail,flush=True)
def ms(page, mode):
 page.locator('#F18-05 .nova-tabs button').filter(has_text=mode.title()).click()
 page.wait_for_timeout(50)
def get(page,script):return page.evaluate(script)
def coins(page):return get(page,'NOVA_F18_05_CONFIG._explore.state()')

def drag(page,value,where='bay',steps=25,placed=False):
 token=page.locator('#F18-05 .f1805-svg [data-kind="'+('placed' if placed else 'source')+'"][data-value="'+str(value)+'"]').first
 token.scroll_into_view_if_needed(timeout=4000)
 b=token.bounding_box();orig=(b['x']+b['width']*.5,b['y']+b['height']*.5)
 svg=page.locator('#F18-05 .f1805-svg')
 data=svg.evaluate('(e)=>({rect:e.getBoundingClientRect().toJSON(),vb:{width:e.viewBox.baseVal.width,height:e.viewBox.baseVal.height}})')
 r=data['rect'];vb=data['vb'];scale=r['width']/vb['width']
 mx=(vb['width']/2)*scale+r['x']
 my=({'bay':528,'tray':318,'invalid':70}[where])*scale+r['y']
 page.mouse.move(*orig);page.mouse.down();page.mouse.move(mx,my,steps=steps);page.mouse.up();page.wait_for_timeout(470 if where=='tray' else 80)
 return orig,(mx,my)

with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1,reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(HTML,wait_until='domcontentloaded')
  ck(f'{width} canonical core exposes svgDrag',get(page,'typeof NOVA.ui.svgDrag')=='function')
  ck(f'{width} one stage helper',page.locator('#F18-05 .nv-dock').count()==1)
  ck(f'{width} outside tutor portrait hidden',page.locator('#F18-05 .nova-bob').first.evaluate('(e)=>getComputedStyle(e).display')=='none')
  ck(f'{width} 6 named presets',len(get(page,'Object.keys(NOVA_F18_05_CONFIG.presets)'))==6)
  ck(f'{width} no horizontal overflow',get(page,'document.documentElement.scrollWidth <= innerWidth+1'),str(get(page,'document.documentElement.scrollWidth')))
  for mode in ['watch','guided','explore','challenge']:
   ms(page,mode)
   ck(f'{width} {mode} SVG rendered',page.locator('#F18-05 .f1805-svg').count()==1)
   ck(f'{width} {mode} one mascot',page.locator('#F18-05 .nova-stage .nv-dock').count()==1)
   ck(f'{width} {mode} mathematically filled stage',page.locator('#F18-05 .f1805-svg .nv-neon-box').count()>=2)
   page.screenshot(path=str(QA/f'F18-05_{width}_{mode}.png'),full_page=True,animations='disabled')
  ms(page,'watch')
  ck(f'{width} watch steps = six',get(page,'NOVA_F18_05_CONFIG && document.querySelectorAll("#F18-05 input[type=range]").length')>=1)
  ck(f'{width} watch named step events',len(get(page,"NOVA.events.query({type:'step'}).filter(e=>e.detail.engine==='F18-05')"))>=1)
  # Example canonical preset values and independent penny arithmetic
  pp=get(page,'NOVA_F18_05_CONFIG.presets')
  maths=[pp['till']['paid']-pp['till']['cost']==pp['till']['amount'],pp['cafe']['paid']-pp['cafe']['cost']==pp['cafe']['amount'],pp['cash']['paid']-pp['cash']['cost']==pp['cash']['amount'],pp['budget']['gross']-pp['budget']['bills']==pp['budget']['amount'],pp['discount']['cost']*(100-pp['discount']['percentage'])//100==pp['discount']['amount'],pp['unit']['offers'][0]['price']/pp['unit']['offers'][0]['count']-pp['unit']['offers'][1]['price']/pp['unit']['offers'][1]['count']==pp['unit']['amount']]
  for i,v in enumerate(maths):ck(f'{width} preset maths {i+1}',v)
  ms(page,'explore')
  drag(page,200,'bay',steps=30)
  ck(f'{width} real pointer drop creates £2 token',coins(page)['total']==200,coins(page))
  page.locator('#F18-05 .f1805-svg [data-kind="source"][data-value="100"]').focus();page.keyboard.press('Enter')
  ck(f'{width} keyboard coin adds £1',coins(page)['total']==300)
  drag(page,200,'tray',placed=True)
  ck(f'{width} real pointer regrab removes £2',coins(page)['total']==100,coins(page))
  drag(page,50,'invalid',steps=17)
  ck(f'{width} invalid drop springs back',coins(page)['total']==100)
  # Escape and pointer cancellation
  tk=page.locator('#F18-05 .f1805-svg [data-kind="source"][data-value="20"]');tk.scroll_into_view_if_needed()
  bb=tk.bounding_box();at=(bb['x']+bb['width']/2,bb['y']+bb['height']/2)
  page.mouse.move(*at);page.mouse.down();page.mouse.move(at[0]+50,at[1]+80,steps=9);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(70)
  ck(f'{width} Escape cancel has no floating object',coins(page)['total']==100 and page.locator('#F18-05 [data-kind="source"] .nv-drag-lift').count()==0)
  page.locator('#F18-05 .f1805-svg [data-kind="placed"][data-value="100"]').focus();page.keyboard.press('Delete')
  ck(f'{width} keyboard Delete removes placed coin',coins(page)['total']==0)
  # Check all presets are manipulable and that all denominations are present
  for k,pr in pp.items():
   get(page,f'NOVA_F18_05_CONFIG._explore.select("{k}")')
   ck(f'{width} explore preset {k} target',coins(page)['target']==pr['amount'])
   ck(f'{width} explore preset {k} denoms',page.locator('#F18-05 [data-kind="source"]').count()==len(pr['denoms']))
  ms(page,'challenge')
  for i,(test,expected) in enumerate([('£3.65',365),('615p',615),('5p per item',5),('£72.35',7235),('£17.00',1700),('£7.10',710)]):
   get(page,f'NOVA_F18_05_CONFIG._challenge.task({i})')
   state=get(page,'NOVA_F18_05_CONFIG._challenge.state()')
   ck(f'{width} challenge task {i+1} stage privacy','£'+str(expected/100)+' = ' not in page.locator('#F18-05 .f1805-side').inner_text())
   # Correct value without coins must be rejected
   check=get(page,f'()=>NOVA_F18_05_CONFIG._challenge.check({json.dumps(test)},0,{1 if i==2 else 'null'})')
   ck(f'{width} challenge {i+1} requires physical counted money',not check[0])
   # wrong units/misconception rejection
   wrong=get(page,f'()=>NOVA_F18_05_CONFIG._challenge.check({json.dumps(str(expected))},{expected},{1 if i==2 else 'null'})')
   ck(f'{width} challenge {i+1} rejects missing money unit',not wrong[0])
   bad=get(page,f'()=>NOVA_F18_05_CONFIG._challenge.check({json.dumps(test)},{expected+10},{1 if i==2 else 'null'})')
   ck(f'{width} challenge {i+1} mismatched coins rejected',not bad[0])
   if i==2:
    wrongOffer=get(page,'()=>NOVA_F18_05_CONFIG._challenge.check("5p per item",5,0)')
    ck(f'{width} best-buy requires correct offer selection',not wrongOffer[0])
   rem=get(page,'NOVA_F18_05_CONFIG._challenge.solve()')
   ck(f'{width} challenge {i+1} constructible ≤9 pieces',rem==0,get(page,'NOVA_F18_05_CONFIG._challenge.state()'))
   passed=get(page,f'()=>NOVA_F18_05_CONFIG._challenge.check({json.dumps(test)})')
   ck(f'{width} challenge {i+1} exact answer with coins accepted',passed[0],passed)
  check=get(page,'()=>NOVA_F18_05_CONFIG._challenge.check("£3.00",365)')
  ck(f'{width} mismatch answer rejected',not check[0])
  ck(f'{width} no JS page errors',len(errors)==0,errors)
  page.close()
 browser.close()
res={'passed':sum(c['ok'] for c in checks),'total':len(checks),'failures':[c for c in checks if not c['ok']],'checks':checks}
(QA/'stress-results.json').write_text(json.dumps(res,indent=2))
print(json.dumps({'passed':res['passed'],'total':res['total'],'failures':res['failures']},indent=2))
