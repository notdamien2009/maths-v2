from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path('/mnt/data');QA=ROOT/'f18_05_qa';HTML=(ROOT/'F18-05-money-and-change.html').read_text();checks=[]
def check(name,ok,detail=''):
 checks.append(dict(name=name,ok=bool(ok),detail=str(detail)[:180]))
 if not ok:print('FAILED',name,detail,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(HTML)
  engine=page.evaluate('({timeline:typeof F18_05.timeline,mode:typeof F18_05.setMode,config:F18_05.config})')
  check(f'{width} bank mounts shared timeline',engine['timeline']=='object')
  check(f'{width} shared engine switches modes',engine['mode']=='function')
  check(f'{width} core 6 watch narration beats',page.evaluate('F18_05.config && F18_05.timeline ? F18_05.timeline.steps.length : 0')==6)
  check(f'{width} watch step scrub 0–5',page.locator('#F18-05 input[type=range]').first.get_attribute('max')=='5')
  page.locator('#F18-05 .nova-tabs button').filter(has_text='Guided').click()
  check(f'{width} guided narrative visible','?' in page.locator('#F18-05').inner_text())
  page.locator('#F18-05 .nova-tabs button').filter(has_text='Explore').click()
  for key in ['till','cafe','unit','budget','discount','cash']:
   page.evaluate(f'NOVA_F18_05_CONFIG._explore.select("{key}")')
   page.screenshot(path=str(QA/f'F18-05_{width}_preset_{key}.png'),full_page=True,animations='disabled')
   ctx=page.locator('#F18-05 .f1805-card').all_text_contents()
   check(f'{width} {key} preset has teaching cards',len(ctx)>=4)
  # Snapshot full change counting sequence using only the actual public interface.
  page.evaluate('NOVA_F18_05_CONFIG._explore.select("till")')
  for v in (200,100,50,10,5):page.evaluate(f'NOVA_F18_05_CONFIG._explore.add({v})')
  check(f'{width} 5 coins add up to £3.65',page.evaluate('NOVA_F18_05_CONFIG._explore.state().total')==365)
  page.screenshot(path=str(QA/f'F18-05_{width}_coins_placed.png'),full_page=True,animations='disabled')
  # Genuine visible Challenge submit & feedback
  page.locator('#F18-05 .nova-tabs button').filter(has_text='Challenge').click()
  chk=page.locator('#F18-05 button').filter(has_text='Check money').first
  inp=page.locator('#F18-05 .nova-input[type=text]')
  check(f'{width} money entry is present',inp.count()==1)
  inp.fill('£3.65');chk.click()
  message=page.locator('#F18-05 .f1805-status').inner_text()
  check(f'{width} right answer but empty tray rejected','Place coins' in message,message)
  page.evaluate('NOVA_F18_05_CONFIG._challenge.solve()')
  chk.click();page.wait_for_timeout(150)
  feedback=page.locator('#F18-05 .f1805-status').inner_text()
  check(f'{width} entered money plus real coin total accepted','Correct:' in feedback,feedback)
  check(f'{width} green success ring displayed',page.locator('#F18-05 .f1805-svg .nv-ring').count()>0)
  check(f'{width} no errors with modes and presets',not errors,errors)
  page.close()
 b.close()
res={'total':len(checks),'passed':sum(c['ok'] for c in checks),'failed':[c for c in checks if not c['ok']],'checks':checks};(QA/'additional-results.json').write_text(json.dumps(res,indent=2));print(json.dumps({'passed':res['passed'],'total':res['total'],'failed':res['failed']},indent=2))
