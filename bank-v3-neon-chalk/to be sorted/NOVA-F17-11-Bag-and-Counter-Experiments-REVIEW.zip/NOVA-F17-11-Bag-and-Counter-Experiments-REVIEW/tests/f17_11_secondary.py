import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
DOC=Path('/mnt/data/F17-11-Bag-and-Counter-Experiments-PREMIUM-REVIEW.html').read_text()
checks=[]
def add(name,ok,detail=''): checks.append({'name':name,'passed':bool(ok),'detail':detail})
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for w in [380,1280]:
   pg=await b.new_page(viewport={'width':w,'height':900},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
   await pg.set_content(DOC,wait_until='domcontentloaded');await pg.locator('.nova-tab[data-m="explore"]').click()
   get='window.NOVA_F17_11_CONFIG._explore.get()';m=await pg.evaluate(get)
   # invalid drop: fast move from supply to non-zone text. No mutation allowed.
   tok=pg.locator('[data-counter="r3"]');await tok.scroll_into_view_if_needed();q=await tok.bounding_box();svg=pg.locator('svg.f1711-plot');box=await svg.bounding_box()
   await pg.mouse.move(q['x']+q['width']/2,q['y']+q['height']/2);await pg.mouse.down();await pg.mouse.move(box['x']+box['width']*.52,box['y']+box['height']*.11,steps=1);await pg.mouse.up();await pg.wait_for_timeout(250)
   n=await pg.evaluate(get);add(f'{w} invalid drop springs back',n['placed']==m['placed'] and n['total']==6,str((m['placed'],n['placed'])))
   # escape during picked up drag
   tok=pg.locator('[data-counter="r3"]');q=await tok.bounding_box();await pg.mouse.move(q['x']+q['width']/2,q['y']+q['height']/2);await pg.mouse.down();await pg.mouse.move(q['x']+60,q['y']-80,steps=5);await pg.keyboard.press('Escape');await pg.mouse.up();await pg.wait_for_timeout(200)
   n=await pg.evaluate(get);add(f'{w} Escape returns held counter',n['placed']==m['placed']);add(f'{w} no stranded DOM counter',await pg.locator('[data-counter]').count()==12)
   # simulated pointer cancel on active node
   tok=pg.locator('[data-counter="r3"]');q=await tok.bounding_box();await pg.mouse.move(q['x']+q['width']/2,q['y']+q['height']/2);await pg.mouse.down();await pg.mouse.move(q['x']+48,q['y']-51,steps=5);await pg.evaluate("()=>{let d=NOVA.ui._drag;if(d&&d.el)d.el.dispatchEvent(new PointerEvent('pointercancel',{pointerId:1,bubbles:true,pointerType:'mouse'}));}");await pg.mouse.up();await pg.wait_for_timeout(190)
   n=await pg.evaluate(get);add(f'{w} pointercancel returns held counter',n['placed']==m['placed']);add(f'{w} pointercancel not stranded',await pg.locator('[data-counter]').count()==12)
   # Model integrity property tests
   await pg.evaluate("window.NOVA_F17_11_CONFIG._explore.setPreset('y8')");await pg.evaluate("window.NOVA_F17_11_CONFIG._explore.run(30)");n=await pg.evaluate(get);add(f'{w} Y8 trials',n['trials']==30)
   await pg.evaluate("window.NOVA_F17_11_CONFIG._explore.place('r2',10)");n=await pg.evaluate(get);add(f'{w} changing bag clears old trials',n['trials']==0 and n['total']==7 and n['p']==[9,49],str(n))
   # Challenge all 4 correct and wrong feedback
   await pg.locator('.nova-tab[data-m="challenge"]').click();await pg.wait_for_timeout(130)
   answers=['0.5','2/3','1/6','1/5']
   wrongs=['0.33333','1/3','1/5','1/6']
   snippets=['3 red','NOT blue','With replacement','Without replacement']
   for i,(a,z) in enumerate(zip(answers,wrongs)):
    query=await pg.locator('.nova-panel').inner_text();add(f'{w} challenge {i+1} question',snippets[i].lower() in query.lower(),query[:130]);inp=pg.locator('.nova-panel input');await inp.fill(z);await pg.locator('.nova-panel button',has_text='Check').click();await pg.wait_for_timeout(80)
    feedback=(await pg.locator('.nova-panel').inner_text()).lower();add(f'{w} challenge {i+1} misconception feedback',not ('correct.' in feedback),feedback[-200:]);await inp.fill(a);await pg.locator('.nova-panel button',has_text='Check').click();await pg.wait_for_timeout(80)
    good=(await pg.locator('.nova-panel').inner_text()).lower();add(f'{w} challenge {i+1} correct answer', 'correct.' in good,good[-200:]);
    if i<3:await pg.wait_for_timeout(1900)
   add(f'{w} JavaScript errors',not errors,str(errors));await pg.close()
  await b.close()
 Path('/mnt/data/F17-11-review/QA-challenge-cancellation-results.json').write_text(json.dumps(checks,indent=2))
 print('SECONDARY',len(checks),'PASSED',sum(x['passed'] for x in checks),'FAILS',json.dumps([x for x in checks if not x['passed']],indent=2)[:5000])
if __name__=='__main__':asyncio.run(main())
