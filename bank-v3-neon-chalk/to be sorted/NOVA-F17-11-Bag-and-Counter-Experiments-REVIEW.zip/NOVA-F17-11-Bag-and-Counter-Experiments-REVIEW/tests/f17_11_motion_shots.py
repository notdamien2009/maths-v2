import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
DOC=Path('/mnt/data/F17-11-Bag-and-Counter-Experiments-PREMIUM-REVIEW.html').read_text()
checks=[]
def add(s,b):checks.append({'name':s,'passed':bool(b)})
async def main():
 folder=Path('/mnt/data/F17-11-review/screenshots');folder.mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],headless=True)
  for width in (380,1280):
   pg=await browser.new_page(viewport={'width':width,'height':900},reduced_motion='no-preference');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
   await pg.set_content(DOC,wait_until='domcontentloaded');await pg.wait_for_timeout(210)
   keys=await pg.evaluate('()=>Object.keys(NOVA.Timeline.prototype)');await pg.evaluate('()=>NOVA.engines["F17-11"].timeline.pause()');
   for step in (0,2,3,4,5):
    await pg.evaluate('(i)=>NOVA.engines["F17-11"].timeline.go(i,"qa")',step);await pg.wait_for_timeout(210 if step!=4 else 550)
    cur=await pg.evaluate('()=>NOVA.engines["F17-11"].timeline.i');add(f'{width} Watch go({step})',cur==step)
   await pg.screenshot(path=str(folder/f'F17-11-{width}-watch-step6.png'),full_page=True,animations='disabled');add(f'{width} Watch no JS errors',not errors)
   await pg.locator('.nova-tab[data-m="explore"]').click();await pg.wait_for_timeout(190)
   await pg.evaluate("window.NOVA_F17_11_CONFIG._explore.setPreset('y8')");await pg.screenshot(path=str(folder/f'F17-11-{width}-Y8-with-replacement.png'),full_page=True,animations='disabled')
   m=await pg.evaluate('window.NOVA_F17_11_CONFIG._explore.get()');add(f'{width} Y8 with replacement',m['p']==[1,6])
   await pg.evaluate("window.NOVA_F17_11_CONFIG._explore.setReplacement(false)");await pg.screenshot(path=str(folder/f'F17-11-{width}-Y8-without-replacement.png'),full_page=True,animations='disabled')
   m=await pg.evaluate('window.NOVA_F17_11_CONFIG._explore.get()');add(f'{width} Y8 without replacement',m['p']==[1,5])
   await pg.evaluate("window.NOVA_F17_11_CONFIG._explore.run(100)");m=await pg.evaluate('window.NOVA_F17_11_CONFIG._explore.get()');add(f'{width} observed frequency produced',m['trials']==100 and m['relative'] is not None)
   await pg.screenshot(path=str(folder/f'F17-11-{width}-Y8-100-trials.png'),full_page=True,animations='disabled');await pg.close()
  await browser.close()
 path=Path('/mnt/data/F17-11-review/QA-watch-motion-results.json');path.write_text(json.dumps(checks,indent=2));print('WATCH',len(checks),'PASSED',sum(c['passed'] for c in checks),'FAILS',[x for x in checks if not x['passed']])
if __name__=='__main__':asyncio.run(main())
