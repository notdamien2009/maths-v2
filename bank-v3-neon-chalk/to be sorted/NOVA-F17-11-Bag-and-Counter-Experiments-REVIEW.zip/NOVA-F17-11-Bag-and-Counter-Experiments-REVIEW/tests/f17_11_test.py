import asyncio,json,sys
from pathlib import Path
from playwright.async_api import async_playwright
URL='file:///mnt/data/F17-11-Bag-and-Counter-Experiments-PREMIUM-REVIEW.html'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);report=[];errors=[];out=Path('/mnt/data/F17-11-review/screenshots');out.mkdir(parents=True,exist_ok=True)
  for width in (380,1280):
   page=await browser.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');page.on('pageerror',lambda e:errors.append(str(e)))
   await page.goto('about:blank');await page.set_content(Path('/mnt/data/F17-11-Bag-and-Counter-Experiments-PREMIUM-REVIEW.html').read_text(),wait_until='domcontentloaded',timeout=60000);await page.wait_for_timeout(1000)
   print('viewport',width,'page title',await page.title(),'nova',await page.locator('.nova-stage').count(), 'errors',errors)
   for mode in ['watch','guided','explore','challenge']:
    await page.locator('.nova-tab[data-m="'+mode+'"]').click();await page.wait_for_timeout(320)
    svg=page.locator('svg.f1711-plot');report.append({'width':width,'mode':mode,'svg':await svg.count(),'mascot':await page.locator('.nova-stage .nv-dock').count(),'errors':len(errors)})
    await page.screenshot(path=str(out/f'F17-11-{width}-{mode}.png'),full_page=True,animations='disabled')
   await page.close()
  print('REPORT',json.dumps(report),'ERRORS',errors);await browser.close()
if __name__=='__main__':asyncio.run(main())
