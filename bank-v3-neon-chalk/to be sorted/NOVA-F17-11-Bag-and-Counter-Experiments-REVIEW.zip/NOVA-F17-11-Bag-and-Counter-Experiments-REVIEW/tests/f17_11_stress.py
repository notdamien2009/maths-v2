import asyncio,json,math,traceback
from pathlib import Path
from playwright.async_api import async_playwright
DOC=Path('/mnt/data/F17-11-Bag-and-Counter-Experiments-PREMIUM-REVIEW.html').read_text()
REPORT={'checks':[],'failures':[]};
def check(name,condition,detail=None):
 x={'name':name,'passed':bool(condition)}
 if detail is not None:x['detail']=detail
 REPORT['checks'].append(x)
 if not condition:REPORT['failures'].append(x)
 return bool(condition)
async def evaluate(page,s): return await page.evaluate(s)
async def svgpoint(page,x,y):
 return await page.evaluate('([x,y])=>{const svg=document.querySelector("svg.f1711-plot"),p=svg.createSVGPoint();p.x=x;p.y=y;const q=p.matrixTransform(svg.getScreenCTM());return {x:q.x,y:q.y}}',[x,y])
async def drag(page,src,xy,steps=16):
 el=page.locator(src);await el.scroll_into_view_if_needed();a=await el.bounding_box();b=await svgpoint(page,*xy)
 await page.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);await page.mouse.down();await page.mouse.move(b['x'],b['y'],steps=steps);await page.mouse.up();await page.wait_for_timeout(280)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'],headless=True)
  for width in (380,1280):
   page=await browser.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
   await page.goto('about:blank');await page.set_content(DOC,wait_until='domcontentloaded');await page.wait_for_timeout(250)
   for mode in ('watch','guided','explore','challenge'):
    await page.locator(f'.nova-tab[data-m="{mode}"]').click();await page.wait_for_timeout(230)
    check(f'{width}/{mode}/SVG',await page.locator('svg.f1711-plot').count()==1)
    check(f'{width}/{mode}/one mascot',await page.locator('.nova-stage .nv-dock').count()==1)
   await page.locator('.nova-tab[data-m="explore"]').click();await page.wait_for_timeout(230)
   get="window.NOVA_F17_11_CONFIG._explore.get()"
   t=await evaluate(page,get);check(f'{width}/Y7 initial counts', (t['red'],t['blue'],t['gold'],t['total'])==(3,2,1,6),str(t));check(f'{width}/Y7 exact probability',t['p']==[1,2]);
   await evaluate(page,"window.NOVA_F17_11_CONFIG._explore.run(100)");t=await evaluate(page,get);check(f'{width}/Y7 100 trials',t['trials']==100);check(f'{width}/success counts',0<=t['successes']<=100);check(f'{width}/experiment tally', t['relative']==t['successes']/100)
   await evaluate(page,"window.NOVA_F17_11_CONFIG._explore.setPreset('y8')");t=await evaluate(page,get);check(f'{width}/Y8 default counts',(t['red'],t['blue'],t['gold'],t['total'])==(2,3,1,6));check(f'{width}/Y8 independent',t['p']==[1,6]);
   await evaluate(page,"window.NOVA_F17_11_CONFIG._explore.setReplacement(false)");t=await evaluate(page,get);check(f'{width}/without replacement',t['p']==[1,5]);
   await evaluate(page,"window.NOVA_F17_11_CONFIG._explore.run(150)");t=await evaluate(page,get);check(f'{width}/150 two draw trials',t['trials']==150);check(f'{width}/two draw successes valid',0<=t['successes']<=150);
   await evaluate(page,"window.NOVA_F17_11_CONFIG._explore.setPreset('y7')");
   l=await evaluate(page,"(()=>{const svg=document.querySelector('svg.f1711-plot'),w=Number(svg.viewBox.baseVal.width);return {w}})()");sm=width<500
   # In preset y7: r3 in supply; drop in empty bag slot8 (the model initial six use slots 0..5)
   xy=(99+0*80,280+2*78) if sm else (172+0*98,298+2*95)
   try:
    await drag(page,'[data-counter="r3"]',xy)
    t=await evaluate(page,get)
    check(f'{width}/drag supply into bag',t['red']==4 and t['total']==7 and t['placed'].get('r3')==8, str(t))
   except Exception as e:check(f'{width}/drag supply into bag',False,str(e))
   try:
    # re-grab placed r3 and snap into slot9
    xy=(99+1*80,280+2*78) if sm else (172+1*98,298+2*95)
    await drag(page,'[data-counter="r3"]',xy,22);t=await evaluate(page,get)
    check(f'{width}/re-grab placed counter',t['placed'].get('r3')==9,str(t.get('placed')))
   except Exception as e:check(f'{width}/re-grab placed counter',False,str(e))
   try:
    target=(240+176/2,929+67/2) if sm else (710+220/2,616+73/2)
    await drag(page,'[data-counter="r3"]',target);t=await evaluate(page,get)
    check(f'{width}/drag to REMOVE', t['total']==6 and 'r3' not in t['placed'],str(t))
   except Exception as e:check(f'{width}/drag to REMOVE',False,str(e))
   # standard keyboard placement
   await page.get_by_label('Choose counter token').select_option('r3');await page.get_by_label('Choose bag position').select_option('10');await page.get_by_role('button',name='Place / re-place').click();t=await evaluate(page,get)
   check(f'{width}/keyboard alternative place',t['placed'].get('r3')==10)
   await page.get_by_role('button',name='Return to supply').click();t=await evaluate(page,get)
   check(f'{width}/keyboard alternative remove', 'r3' not in t['placed'])
   # challenge panel: ensure no leaked numerator before pupils type
   await page.locator('.nova-tab[data-m="challenge"]').click();await page.wait_for_timeout(160)
   check(f'{width}/Challenge hides probability', '?' in (await page.locator('.f1711-readouts').inner_text()))
   check(f'{width}/no JS errors',not errs,str(errs))
   await page.close()
  await browser.close()
  Path('/mnt/data/F17-11-review/QA-interaction-results.json').write_text(json.dumps(REPORT,indent=2))
  print('TESTS',len(REPORT['checks']),'PASSED',len(REPORT['checks'])-len(REPORT['failures']),'FAILS',len(REPORT['failures']))
  print(json.dumps(REPORT['failures'],indent=2)[:7500]);
if __name__=='__main__':asyncio.run(main())
