# NOVA F17-11 — Bag and Counter Experiments — QA report

**Status:** COMPLETE FOR REVIEW only. No owner GOLD approval.
**Build type:** One standalone HTML. NOVA shared core is embedded without modification.
**Test environment:** Headless Chromium via Playwright; 380px and 1280px; reduced-motion and normal-motion contexts.
**Test result:** 108/108 completed assertions passed, 0 failures in the final suites.
**Evidence:** `tests/QA-interaction-results.json` (50/50), `tests/QA-challenge-cancellation-results.json` (40/40), `tests/QA-watch-motion-results.json` (18/18). Replayable Python scripts in `tests/`.

## Implementation evidence

| Requirement | Evidence |
|---|---|
| NOVA core and original fonts/helper | Embedded core first script SHA-256 `bc8b287a321aff1b3aeda8383879c68a6e7abf7542a6a9b72576a1c027bc4c6e` identical to F17-10; HTML includes NOVA core + font data and original NOVA `scene.helperStrip` |
| Actual number of mascots | Browser checks verify exactly one `.nova-stage .nv-dock` in each mode at both widths (8 checks) |
| House-style mathematical construction | App JS lines 33–56: `NOVA.neonRing`, `NOVA.neonPath`, `NOVA.neonBox`, `NOVA.chalkText`; no external font or script URLs |
| Two named lesson presets | App JS line 4: Y7-076 single random draw, Y8-071 independent ordered pair with replacement |
| WATCH/GUIDED | App JS lines 90–99 with six step names, tutor narration and prompts; core timeline includes rewind, scrub, play and pause |
| EXPLORE drag | App JS line 71: shared SVG drag system, 12 bag snap zones, removal, re-grabbing and keyboard alternative; tested fast mouse movement |
| Exact calculations | App JS line 20: singles `red / total`; two draws with replacement `(red/total)*(blue/total)`; without `(red/total)*(blue/(total-1))` |
| Experiment correctness | App JS lines 26–28: repeatable seeded random trials, replacement rule and trial tallies; changing the model resets old trial data |
| Challenge | App JS line 119: four tasks; each wrong and correct answer tested at both widths (16 decisions) |
| Static/print | Core print renderer embedded, F17-11 specific black/white print overrides in HTML; not tested against a physical printer |
| Responsive screenshots | `screenshots/` contains 16 PNGs, including four modes at each width and two Year 8 replacement comparisons |

## Exact mathematical spot checks

- Y7 default: 3 red, 2 blue, 1 gold; total 6, P(red) = 3/6 = **1/2**.
- Y7 P(NOT blue) = (3 + 1)/6 = **2/3**.
- Y8: 2 red, 3 blue, 1 gold. With replacement, P(red then blue) = (2/6)(3/6) = **1/6**.
- Y8 without replacement: P(red then blue) = (2/6)(3/5) = **1/5**.
- Y8 after adding one red: 3 red, 3 blue, 1 gold; probability with replacement = (3/7)(3/7) = **9/49**. Earlier QA had an incorrect test expectation (1/7); the assertion was corrected, not the engine.

## Test issues resolved

1. Initial HTML construction inserted CSS into a core JavaScript string (template substitution error). Fixed by inserting stylesheet only at the first closing `style` element. All modes rerun with zero JavaScript errors.
2. Passing a single DOM child to the NOVA `h()` helper raised a JavaScript error in Explore. Fixed to pass an array of children; all modes rerun.
3. The desktop bag caption collided with the stage subtitle. Corrected the SVG coordinates, then regenerated screenshots.
4. The Watch timeline automatically starts playing; one early manual step test expected it to remain on step 4. Test harness now pauses before manually stepping. No timeline code changed.

## Outstanding acceptance limits

- **Physical touchscreen gestures** were not tested.
- **Firefox and Safari** were not tested. Browser automated checks used Chromium.
- **Owner visual review** required for GOLD approval; no GOLD status granted.
- Full screen-reader audit and printer tests have not been completed.

## Source and changes

No GitHub files were modified, committed, uploaded or pushed. F17-11 uses the original shared NOVA core byte-for-byte. All engine-specific changes live in the standalone HTML's second script and added CSS rules.
