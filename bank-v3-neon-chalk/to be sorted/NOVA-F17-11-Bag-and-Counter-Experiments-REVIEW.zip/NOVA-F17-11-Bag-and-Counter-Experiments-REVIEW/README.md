# NOVA Maths V2 — F17-11 Bag and Counter Experiments

Standalone HTML: `F17-11-Bag-and-Counter-Experiments-PREMIUM-REVIEW.html`

Modes: WATCH / GUIDED / EXPLORE / CHALLENGE.
Presets: Y7-076 Experimental probability; Y8-071 Independent repeated events.

To review: open the HTML in a modern browser. No external dependencies are required. Use EXPLORE to drag coloured counters into slots in the bag or remove them via the red REMOVE zone. Use the buttons below to run actual random trials; the keyboard selection controls offer the equivalent of drag-and-drop. Switch the replacement option to compare independent repeated trials with no-replacement sampling. Use the four Challenge questions to verify reasoning. Consult `QA-REPORT.md` and `tests/` for acceptance evidence. This is a review build and has not been GOLD approved.
