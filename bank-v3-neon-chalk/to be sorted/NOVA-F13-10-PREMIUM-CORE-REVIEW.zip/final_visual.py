from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
html=(root/'F13-10-Sphere-Volume-and-Surface-Area-PREMIUM-CORE.html').read_text()
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in [1280,380]:
  pg=browser.new_page(viewport={'width':w,'height':900},device_scale_factor=1)
  pg.set_content(html,wait_until='load');pg.wait_for_timeout(160)
  for m in ['watch','explore','challenge']:
   if m!='watch':
    tabs=pg.locator('.nova-tabs button')
    for i in range(tabs.count()):
     if m in tabs.nth(i).inner_text().lower():tabs.nth(i).click();break
   pg.wait_for_timeout(100)
   if m=='explore':
    for key in ['globe','surface','slice','cylinder']:
     pg.evaluate('k=>NOVA_F13_10_CONFIG._explore.setView(k)',key);pg.wait_for_timeout(110)
     pg.locator('.nova-stage').screenshot(path=str(root/'screenshots'/f'{w}-stage-{key}.png'))
    pg.evaluate('NOVA_F13_10_CONFIG._explore.setRadius(2)');pg.evaluate('NOVA_F13_10_CONFIG._explore.setView("radius")');pg.wait_for_timeout(120)
    pg.locator('.nova-stage').screenshot(path=str(root/'screenshots'/f'{w}-stage-fraction.png'))
   else:
    pg.locator('.nova-stage').screenshot(path=str(root/'screenshots'/f'{w}-stage-{m}.png'))
  pg.close()
 browser.close()
