"""Reproducible F13-10 build: immutable full NOVA F13-09 embedded core + additive sphere component."""
from pathlib import Path
root=Path(__file__).resolve().parent
base=(root/'F13-09-Pyramid-and-Cone-Fill-PREMIUM-CORE.html').read_text()
css=(root/'f13_10_addon.css').read_text()
js=(root/'f13_10_engine.js').read_text()
idx=base.index('/* F13-09 additive styles.')
end=base.index('</style>',idx)
base=base[:idx]+css+'\n'+base[end:]
a=base.index('/* F13-09 PYRAMID AND CONE FILL')
b=base.rfind('</script>')
base=base[:a]+js+'\n'+base[b:]
base=base.replace('NOVA F13-09 · Premium Pyramid and Cone Fill','NOVA F13-10 · Premium Sphere Volume and Surface Area')
base=base.replace('data-run="F13 · 3D shapes, volume and surface area · F13-09" data-title="Pyramid and cone fill" data-sub="Three cone or pyramid measures fill the matching cylinder or prism. Discover one-third volume."','data-run="F13 · 3D shapes, volume and surface area · F13-10" data-title="Sphere volume and surface area" data-sub="Explore curved area, radii, cross-sections and the enclosing-cylinder volume relationship."')
target=root.parent/'F13-10-Sphere-Volume-and-Surface-Area-PREMIUM-CORE.html'
target.write_text(base)
print('Built',target,f'({target.stat().st_size:,} bytes)')
