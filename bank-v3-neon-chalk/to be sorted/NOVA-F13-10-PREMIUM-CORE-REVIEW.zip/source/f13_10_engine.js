/* F13-10 SPHERE VOLUME + SURFACE AREA — additive engine; unmodified NOVA F0–F12 core. */
var NOVA_F13_10_CONFIG={startMode:'watch',preset:'r3',presets:{r3:'Radius 3 · benchmark',r2:'Radius 2 · stacked fractions',r4:'Radius 4 · larger sphere',r5:'Radius 5 · large sphere',r6:'Radius 6 · exact whole π coefficients'}};
(function(){'use strict';
var S=NOVA.svg,F=NOVA.f12,h=NOVA.h,CFG=NOVA_F13_10_CONFIG,EN='F13-10';
var C={cyan:'#45eeff',blue:'#659eff',purple:'#bca4ff',orange:'#ffad7d',gold:'#ffe27d',green:'#76f5bb',white:'#e8f8ff'};
var PRESETS={r2:2,r3:3,r4:4,r5:5,r6:6};
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function state(p,view){return {preset:p||'r3',r:PRESETS[p]||3,view:view||'globe',yaw:.48,pitch:-.14,cut:0,showHidden:false,spin:false,anim:0,refresh:null,cleanup:null};}
function area(s){return 4*Math.PI*s.r*s.r;}
function volume(s){return 4*Math.PI*s.r*s.r*s.r/3;}
function cylinder(s){return 2*Math.PI*s.r*s.r*s.r;}
function sliceArea(s){var z=s.cut*s.r;return Math.PI*(s.r*s.r-z*z);}
function gcd(a,b){while(b){var t=a%b;a=b;b=t;}return a;}
function coeff(num,den){var g=gcd(num,den);return {num:num/g,den:den/g};}
function vCoef(r){return coeff(4*r*r*r,3);}
function exact(n,d){var f=coeff(n,d||1);return f.den===1?f.num+'π':f.num+'π/'+f.den;}
function fmt(n){return Math.round(n*100)/100+'';}
function el(p,tag,a){return S.el(tag,a||{},p);}
function tx(p,x,y,str,role,size,anchor){return NOVA.chalkText(p,x,y,String(str),{role:role||'given',size:size||18,anchor:anchor||'middle'});}
function path(p,d,stroke,w,opacity,fill,dash){var t=el(p,'path',{d:d,fill:fill||'none',stroke:stroke||C.cyan,'stroke-width':w||1.5,opacity:opacity==null?1:opacity,'stroke-linecap':'round','stroke-linejoin':'round'});if(dash)t.setAttribute('stroke-dasharray',dash);return t;}
function ln(p,a,b,c,w,opa,dash){return path(p,'M'+fmt(a[0])+','+fmt(a[1])+'L'+fmt(b[0])+','+fmt(b[1]),c,w,opa,'none',dash);}
function gradient(d,id,stops,attrs,tag){var g=el(d,tag||'linearGradient',Object.assign({id:id},attrs||{}));stops.forEach(function(q){el(g,'stop',{offset:q[0],'stop-color':q[1],'stop-opacity':q[2]});});return g;}
function defs(svg){var d=svg.querySelector('defs')||el(svg,'defs');
 gradient(d,'f13s-body', [['0%','#f7ffff',.98],['10%','#b6f6ff',.99],['31%','#76c5ff',.99],['60%','#2854a0',1],['86%','#10295f',1],['100%','#061b40',1]],{cx:'27%',cy:'21%',r:'82%',fx:'26%',fy:'21%'},'radialGradient');
 gradient(d,'f13s-depth',[['0%','#79cbff',.38],['62%','#193e96',.15],['100%','#0b183c',.03]],{cx:'50%',cy:'50%',r:'60%'},'radialGradient');
 gradient(d,'f13s-sheen',[['0%','#efffff',.8],['100%','#d9ffff',0]],{cx:'30%',cy:'25%',r:'70%'},'radialGradient');
 gradient(d,'f13s-surface',[['0%','#7ef4ff',.75],['49%','#4375cc',.28],['100%','#071932',.2]],{x1:'0%',y1:'0%',x2:'100%',y2:'100%'});
 gradient(d,'f13s-gold',[['0%','#fff6bf',.95],['100%','#e98854',.16]],{x1:'0%',y1:'0%',x2:'100%',y2:'100%'});
 gradient(d,'f13s-aura',[['0%','#2b6de5',.37],['100%','#15244f',0]],{cx:'50%',cy:'50%',r:'60%'},'radialGradient');
 var filt=el(d,'filter',{id:'f13s-blur',x:'-70%',y:'-70%',width:'240%',height:'240%'});el(filt,'feGaussianBlur',{stdDeviation:8});
}
// Orthographic 3D camera. z>0 faces the viewer. Rotate longitude and pitch using true sphere coordinates.
function project(lat,lon,yaw,pitch){var x=Math.cos(lat)*Math.sin(lon),y=Math.sin(lat),z=Math.cos(lat)*Math.cos(lon);var cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);var xx=x*cy+z*sy,zz=-x*sy+z*cy;return [xx,y*cp-zz*sp,y*sp+zz*cp];}
function curveGroup(g,cx,cy,R,s,kind,value,hidden){var buf=[],last=null;for(var i=0;i<=160;i++){var t=i/160,lat=kind==='lat'?value:(t-.5)*Math.PI,lon=kind==='lat'?t*Math.PI*2:value;var q=project(lat,lon,s.yaw,s.pitch),front=q[2]>=-.003;if(front===hidden){if(buf.length>1){path(g,'M'+buf.map(function(a){return fmt(a[0])+','+fmt(a[1]);}).join('L'),hidden?C.blue:C.cyan,hidden?1.15:1.28,hidden?.22:.67,'none',hidden?'3 6':null);}buf=[];}if(front!==hidden){buf.push([cx+R*q[0],cy-R*q[1]]);}last=front;}if(buf.length>1)path(g,'M'+buf.map(function(a){return fmt(a[0])+','+fmt(a[1]);}).join('L'),hidden?C.blue:C.cyan,hidden?1.1:1.3,hidden?.22:.68,'none',hidden?'3 6':null);}
function globe(g,s,cx,cy,R){var q=el(g,'g',{'data-maths':'sphere-body','data-radius':s.r,'data-yaw':fmt(s.yaw),'data-pitch':fmt(s.pitch),'aria-label':'Rotatable spherical geometry with latitude and longitude'});
 el(q,'ellipse',{cx:cx,cy:cy+R+18,rx:R*.87,ry:R*.16,fill:'#030b2e',opacity:.55,filter:'url(#f13s-blur)'});
 el(q,'circle',{cx:cx,cy:cy,r:R+10,fill:'url(#f13s-aura)',opacity:.65});
 el(q,'circle',{cx:cx,cy:cy,r:R,fill:'url(#f13s-body)',stroke:'#67eaff','stroke-width':2.3});
 el(q,'circle',{cx:cx,cy:cy,r:R*.978,fill:'url(#f13s-depth)',opacity:.6});
 // Hidden meridians may be toggled, and are always drawn inside the silhouette.
 if(s.showHidden){for(var a=-70;a<=70;a+=35)curveGroup(q,cx,cy,R,s,'lat',a*Math.PI/180,true);for(var b=0;b<180;b+=30)curveGroup(q,cx,cy,R,s,'lon',b*Math.PI/180,true);}
 for(var z=-75;z<=75;z+=25)curveGroup(q,cx,cy,R,s,'lat',z*Math.PI/180,false);
 for(var m=0;m<180;m+=30)curveGroup(q,cx,cy,R,s,'lon',m*Math.PI/180,false);
 el(q,'ellipse',{cx:cx-R*.32,cy:cy-R*.37,rx:R*.29,ry:R*.12,transform:'rotate(-38 '+fmt(cx-R*.32)+' '+fmt(cy-R*.37)+')',fill:'url(#f13s-sheen)',opacity:.45});
 path(q,'M'+fmt(cx-R*.84)+','+fmt(cy-R*.53)+' A'+fmt(R)+','+fmt(R)+' 0 0 1 '+fmt(cx-R*.51)+','+fmt(cy-R*.85),C.white,3,.56);
 el(q,'circle',{cx:cx,cy:cy,r:R,fill:'none',stroke:C.cyan,'stroke-width':1.35,opacity:.55});
 if(s.view==='radius'||s.view==='globe'){
   var theta=-.28,x1=cx+R*.82*Math.cos(theta),y1=cy+R*.82*Math.sin(theta);el(q,'circle',{cx:cx,cy:cy,r:4,fill:C.gold,stroke:C.white,'stroke-width':1.1});ln(q,[cx,cy],[x1,y1],C.gold,2.6,.94);el(q,'circle',{cx:x1,cy:y1,r:3.8,fill:C.gold});tx(q,cx+R*.44,cy-17,'r = '+s.r,'focus',R<115?14:18);
 }
 if(s.view==='radius'){
   ln(q,[cx-R*.84,cy+R*.49],[cx+R*.84,cy-R*.49],C.orange,2.3,.8,'4 4');tx(q,cx,cy+R*.70,'diameter = '+2*s.r,'given',R<115?13.5:18);
 }
 if(s.view==='slice'){
   var zz=clamp(s.cut,-1,1),sr=Math.sqrt(Math.max(0,1-zz*zz))*R;
   var yy=cy-zz*R;
   var pg=el(q,'g',{'data-maths':'cutting-plane','data-slice-height':fmt(zz*s.r),'data-slice-radius':fmt(sr/R*s.r)});
   el(pg,'ellipse',{cx:cx,cy:yy,rx:sr,ry:sr*.32,fill:'#56e5ff',opacity:.18,stroke:C.gold,'stroke-width':2.3});
   ln(pg,[cx-R-12,yy],[cx+R+12,yy],C.gold,1.5,.45,'5 5');
   if(sr>1){ln(pg,[cx,yy],[cx+sr,yy],C.gold,2,.95);el(pg,'circle',{cx:cx,cy:yy,r:3.2,fill:C.gold});}
 }
 return q;
}
function card(g,x,y,w,title,col,main,sub,mob){el(g,'rect',{x:x,y:y,width:w,height:104,rx:12,fill:'#06162e',stroke:col,'stroke-width':1.65});ln(g,[x+13,y+5],[x+w-13,y+5],col,2,.6);tx(g,x+w/2,y+24,title,'given',mob?13:16);if(typeof main==='string'){tx(g,x+w/2,y+66,main,'result',mob?25:30);}else{var f=main,n=f.num,d=f.den;if(d===1){tx(g,x+w/2,y+65,n+'π','result',mob?26:31);}else{var xx=x+w/2;tx(g,xx,y+49,n+'π','result',mob?20:24);ln(g,[xx-24,y+56],[xx+24,y+56],col,2.4,1);tx(g,xx,y+80,d,'result',mob?19:21);}}tx(g,x+w/2,y+94,sub,'given',mob?10:12);}
function panel(g,s,W,mob){var x=mob?298:541,cY=230;
 if(s.view==='slice'){
   tx(g,x,cY-133,'CROSS-SECTION','focus',mob?14.5:19);
   var radius=mob?57:88,rs=Math.sqrt(Math.max(0,1-s.cut*s.cut))*radius;
   el(g,'circle',{cx:x,cy:cY,r:radius,fill:'#092044',stroke:'#3765ab','stroke-width':1.8,opacity:.6});
   el(g,'circle',{cx:x,cy:cY,r:rs,fill:'url(#f13s-surface)',stroke:C.gold,'stroke-width':2.3,'data-maths':'section-circle','data-exact-radius':fmt(s.r*Math.sqrt(Math.max(0,1-s.cut*s.cut)))});
   el(g,'circle',{cx:x,cy:cY,r:3.4,fill:C.gold});ln(g,[x,cY],[x+rs,cY],C.gold,2.3,.92);
   tx(g,x,cY+radius+27,'area = π(r² − z²)','given',mob?13:17);
   tx(g,x,cY+radius+49,fmt(sliceArea(s))+' units²','result',mob?13:19);
 }else if(s.view==='cylinder'){
   tx(g,x,cY-133,'ENCLOSING CYLINDER','focus',mob?13.5:18);
   var R=mob?62:83,H=R*2,top=cY-R,bottom=cY+R;
   el(g,'ellipse',{cx:x,cy:bottom,rx:R,ry:R*.28,fill:'#04142d',opacity:.35});
   el(g,'path',{d:'M'+(x-R)+','+top+'V'+bottom+' A'+R+','+(R*.28)+' 0 0 0 '+(x+R)+','+bottom+'V'+top,fill:'url(#f13s-surface)',opacity:.35,stroke:C.purple,'stroke-width':2.1});
   el(g,'ellipse',{cx:x,cy:top,rx:R,ry:R*.28,fill:'url(#f13s-surface)',stroke:C.cyan,'stroke-width':2.5});
   el(g,'circle',{cx:x,cy:cY,r:R,fill:'url(#f13s-body)',stroke:C.gold,'stroke-width':2,opacity:.94});
   el(g,'circle',{cx:x,cy:cY,r:R,fill:'none',stroke:C.gold,'stroke-width':1.4});
   ln(g,[x+R+8,top],[x+R+8,bottom],C.orange,1.8,.9);tx(g,x+R+8,cY,'2r','focus',mob?13:17);
   tx(g,x,cY+R+23,'SPHERE ÷ CYLINDER','given',mob?11:15);
   tx(g,x,cY+R+46,'2','result',mob?16:19);ln(g,[x-16,cY+R+51],[x+16,cY+R+51],C.gold,2,.96);tx(g,x,cY+R+73,'3','result',mob?16:19);
 }else if(s.view==='surface'){
   tx(g,x,cY-133,'FOUR GREAT DISCS','focus',mob?13.5:18);
   var cr=mob?25:37,centers=[[x-cr-6,cY-cr-7],[x+cr+6,cY-cr-7],[x-cr-6,cY+cr+7],[x+cr+6,cY+cr+7]];
   centers.forEach(function(v,k){el(g,'circle',{cx:v[0],cy:v[1],r:cr,fill:'url(#f13s-surface)',stroke:k%2?C.purple:C.cyan,'stroke-width':2.1});el(g,'circle',{cx:v[0]-cr*.25,cy:v[1]-cr*.32,r:cr*.16,fill:C.white,opacity:.22});});
   tx(g,x,cY+cr*2+35,'4 × πr²','result',mob?17:22);
   tx(g,x,cY+cr*2+54,'area comparison · not a net','given',mob?10:13);
 }else{
   tx(g,x,cY-132,'RADIUS + DIAMETER','focus',mob?13.5:19);
   var rr=mob?58:84;el(g,'circle',{cx:x,cy:cY,r:rr,fill:'url(#f13s-surface)',stroke:C.cyan,'stroke-width':2.4});
   ln(g,[x-rr,cY],[x+rr,cY],C.orange,3,.92);
   ln(g,[x,cY],[x+rr,cY],C.gold,3,.96);
   el(g,'circle',{cx:x,cy:cY,r:4,fill:C.gold});
   tx(g,x,cY-18,'r = '+s.r,'focus',mob?18:23);tx(g,x,cY+rr+26,'d = 2r = '+s.r*2,'given',mob?14:18);
 }
}
function draw(root,s,W,H){root.replaceChildren();var mob=W<500,xc=mob?137:244,yc=245,R=mob?105:131;
 el(root,'ellipse',{cx:W/2,cy:270,rx:W*.53,ry:225,fill:'url(#f13s-aura)',opacity:.8});
 tx(root,W/2,34,'SPHERE · 3D SHAPE WITHOUT EDGES','given',mob?15:20);
 tx(root,xc,83,s.view==='surface'?'CURVED SURFACE':s.view==='slice'?'SLICING THE SOLID':s.view==='cylinder'?'VOLUME COMPARISON':'ROTATABLE SPHERE','focus',mob?15:20);
 globe(root,s,xc,yc,R);panel(root,s,W,mob);
 tx(root,xc,403,s.view==='slice'?'slice z = '+fmt(s.cut*s.r):'r = '+s.r+'  ·  d = '+s.r*2,'given',mob?16:19);
 var total=volume(s),surface=area(s),fraction=vCoef(s.r);
 card(root,mob?11:113,456,mob?193:268,'SURFACE AREA',C.cyan,{num:4*s.r*s.r,den:1},'4 × π × r²   ·   units²',mob);
 card(root,mob?215:399,456,mob?194:268,'SPHERE VOLUME',C.gold,fraction,'4 × π × r³ ÷ 3   ·   units³',mob);
 tx(root,W/2,593,s.view==='cylinder'?'SPHERE VOLUME IS TWO THIRDS OF CYLINDER VOLUME':s.view==='surface'?'FOUR GREAT-DISC AREAS · NOT A SPHERE NET':s.view==='slice'?'SECTION RADIUS² = r² − z²':'SURFACE USES r²  ·  VOLUME USES r³','result',mob?12.5:17);
 root.setAttribute('data-radius',s.r);root.setAttribute('data-surface',surface);root.setAttribute('data-volume',total);root.setAttribute('data-cylinder',cylinder(s));root.setAttribute('data-slice-area',sliceArea(s));root.setAttribute('data-cut',s.cut);root.setAttribute('data-view',s.view);
}
function makeStage(stage,s,msg,pose,interactive){if(stage._f13Cleanup)stage._f13Cleanup();stage.replaceChildren();var mob=innerWidth<=580,W=mob?420:780,H=612;
 NOVA.cap(stage,'SPHERE VOLUME + SURFACE AREA · r = '+s.r,'3D GEOMETRY');
 var svg=S.root(W,H,'Sphere. Rotate to inspect great circles, use the radius to calculate curved surface area and volume, or slice it to see circular cross-sections.');svg.classList.add('f13s-svg');svg.setAttribute('tabindex','0');svg.setAttribute('role','group');svg.setAttribute('aria-label','Rotatable 3D sphere. Arrow keys rotate the sphere, plus/minus adjust radius, Home returns orientation. Explore exposes slice and view controls.');stage.appendChild(svg);defs(svg);
 var root=el(svg,'g',{'data-f13s-root':'true'}),raf=0,controller=new AbortController(),pointer=null,last=null,moved=0;
 function render(){draw(root,s,W,H);var capLabel=stage.querySelector('.nv-cap span');if(capLabel)capLabel.textContent='SPHERE VOLUME + SURFACE AREA · r = '+s.r;var t=stage.querySelectorAll('.f12-strip .nv-ntile .mt'),v=[String(s.r),String(2*s.r),String(4*s.r*s.r)+'π'];v.forEach(function(n,i){if(t[i])t[i].textContent=n;});}
 function refresh(){if(raf)cancelAnimationFrame(raf);raf=requestAnimationFrame(function(){raf=0;render();NOVA.events.emit('value',{engine:EN,control:'sphere',value:{radius:s.r,area:area(s),volume:volume(s),sliceArea:sliceArea(s),view:s.view,yaw:s.yaw,pitch:s.pitch}});});}
 s.refresh=refresh;render();F.strip(stage,[['radius',s.r,'focus'],['diameter',2*s.r,'op'],['area ÷ π',4*s.r*s.r,'result']]);NOVA.scene.helperStrip(stage,pose||'explain',msg||'The sphere has one curved surface. Let’s see how its radius controls its area and volume.');
 s.cleanup=function(){controller.abort();if(raf)cancelAnimationFrame(raf);if(s.anim)cancelAnimationFrame(s.anim);s.anim=0;pointer=null;svg.classList.remove('f13s-drag');};stage._f13Cleanup=s.cleanup;
 if(interactive){svg.addEventListener('pointerdown',function(ev){if(ev.pointerType==='mouse'&&ev.button!==0)return;pointer=ev.pointerId;last=[ev.clientX,ev.clientY];moved=0;try{svg.setPointerCapture(pointer);}catch(e){}svg.classList.add('f13s-drag');ev.preventDefault();},{signal:controller.signal});
 svg.addEventListener('pointermove',function(ev){if(pointer!==ev.pointerId||!last)return;var dx=ev.clientX-last[0],dy=ev.clientY-last[1];last=[ev.clientX,ev.clientY];moved+=Math.abs(dx)+Math.abs(dy);var k=2.4/(svg.getBoundingClientRect().width||420);s.yaw+=dx*k;s.pitch=clamp(s.pitch+dy*k,-1.15,1.15);refresh();},{signal:controller.signal});
 function release(ev){if(pointer!==ev.pointerId)return;pointer=null;last=null;svg.classList.remove('f13s-drag');try{if(svg.hasPointerCapture(ev.pointerId))svg.releasePointerCapture(ev.pointerId);}catch(e){}}
 svg.addEventListener('pointerup',release,{signal:controller.signal});svg.addEventListener('pointercancel',release,{signal:controller.signal});svg.addEventListener('lostpointercapture',function(ev){if(ev.pointerId===pointer){pointer=null;last=null;svg.classList.remove('f13s-drag');}},{signal:controller.signal});window.addEventListener('blur',function(){pointer=null;last=null;svg.classList.remove('f13s-drag');},{signal:controller.signal});}
 svg.addEventListener('keydown',function(ev){var step=Math.PI/18;if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','+','=','-'].includes(ev.key))return;ev.preventDefault();if(ev.key==='ArrowLeft')s.yaw-=step;if(ev.key==='ArrowRight')s.yaw+=step;if(ev.key==='ArrowUp')s.pitch=clamp(s.pitch-step,-1.15,1.15);if(ev.key==='ArrowDown')s.pitch=clamp(s.pitch+step,-1.15,1.15);if(ev.key==='+'||ev.key==='=')s.r=clamp(s.r+1,2,8);if(ev.key==='-')s.r=clamp(s.r-1,2,8);if(ev.key==='Home'){s.yaw=.48;s.pitch=-.14;}refresh();},{signal:controller.signal});
 return svg;}
function button(label,fn,cl){return h('button',{class:'nova-btn'+(cl?' '+cl:''),text:label,onclick:fn});}
function row(panel,children){panel.appendChild(h('div',{class:'pr-row'},children));}
function slider(label,min,max,value,change,step){var control=h('input',{type:'range',min:String(min),max:String(max),value:String(value),step:String(step||1),'aria-label':label}),number=h('span',{class:'f13s-value',text:String(value)}),node=h('label',{class:'f13s-label'},[label+' ',control,number]);control.oninput=function(){number.textContent=control.value;change(+control.value);};return {node:node,input:control,set:function(x){control.value=x;number.textContent=x;}};}
var STEPS=[
 {n:'Meet the sphere',r:3,v:'globe',p:'explain',m:'A sphere has one continuous curved surface, no straight edges and no vertices. Every surface point is equally far from its centre.',q:'How many edges does the sphere have?'},
 {n:'Find the centre',r:3,v:'radius',p:'point-right',m:'The centre sits inside the sphere. Its distance to the surface is the radius.',q:'Where does a radius start?'},
 {n:'Radius and diameter',r:3,v:'radius',p:'think',m:'A diameter passes through the centre and stretches all the way across. It is twice the radius.',q:'What is the diameter when r is three?'},
 {n:'Turn the sphere',r:3,v:'globe',p:'explain',m:'Turn the model. Lines of longitude and latitude help you recognise the curved surface. The sphere stays the same size.',q:'Does a sphere change its measurements when rotated?'},
 {n:'Surface is the outside',r:3,v:'surface',p:'point-right',m:'Surface area measures the outside skin, not the space inside. Its area equals four times the area of a great circular disc.',q:'Does the sphere unfold into those four discs?'},
 {n:'Surface area formula',r:3,v:'surface',p:'explain',m:'Four times pi times radius squared. With radius three, the surface area is thirty-six pi square units.',q:'What unit do we use for surface area?'},
 {n:'Take a central slice',r:3,v:'slice',cut:0,p:'think',m:'A cut through the centre produces the biggest circle. Its radius is the sphere radius.',q:'Which slice makes the largest circle?'},
 {n:'Move the slice away',r:3,v:'slice',cut:.65,p:'point-right',m:'Move the plane towards the top. The circular cross-section gets smaller, although the sphere does not change size.',q:'What happens to the slice area as we move away from the centre?'},
 {n:'Volume is space inside',r:3,v:'cylinder',p:'explain',m:'Volume is the space inside the sphere. We use radius cubed because volume is measured in cubic units.',q:'Which exponent appears in the volume formula?'},
 {n:'Compare with a cylinder',r:3,v:'cylinder',p:'think',m:'A cylinder of radius r and height two r surrounds the sphere. The sphere takes two thirds of that cylinder’s volume.',q:'What fraction of the surrounding cylinder is taken up by the sphere?'},
 {n:'Calculate sphere volume',r:3,v:'cylinder',p:'explain',m:'Four thirds times pi times radius cubed. When the radius is three, the sphere volume is thirty-six pi cubic units.',q:'Does volume use square or cubic units?'},
 {n:'A sphere of radius two',r:2,v:'globe',p:'celebrate',m:'Change the radius to two. Surface area becomes sixteen pi square units, while volume is thirty-two pi over three cubic units.',q:'What stays the same about the formulas when the radius changes?'}
];
var def={id:EN,title:'Sphere volume and surface area',config:CFG,steps:STEPS.map(function(s){return {name:s.n,narration:s.m,prompt:s.q,dur:1900};}),
 alt:'A precise semi-transparent spherical globe with luminous meridians and parallels, clearly marked radius and diameter. Four secondary teaching views show great-circle area, circular slice, and the enclosing cylinder for comparing volumes.',
 staticAlt:'A sphere has no edges or vertices. Diameter = 2r. Surface area = 4πr² square units. Volume = (4/3)πr³ cubic units. The sphere is two thirds the volume of its enclosing cylinder with radius r and height 2r.',
 render:function(i,stage){var o=STEPS[i],st=state('r'+o.r,o.v);if(o.cut)st.cut=o.cut;makeStage(stage,st,o.m,o.p,false);},
 exploreIntro:'Rotate the sphere. Adjust its radius, switch between the surface-area, radius, cross-section and enclosing-cylinder views, and see each calculation update.',
 explore:function(panel,stage,api){var st=state('r3'),select=h('select',{class:'nova-input','aria-label':'Sphere radius preset'});Object.keys(CFG.presets).forEach(function(k){select.appendChild(h('option',{value:k,text:CFG.presets[k]}));});select.value='r3';row(panel,[h('label',{class:'f13s-label'},['PRESET ',select])]);
 var radius=slider('RADIUS',2,8,st.r,function(v){st.r=v;st.refresh();}),cut=slider('SLICE POSITION %',-100,100,0,function(v){st.cut=v/100;st.view='slice';view.value='slice';st.refresh();});
 var view=h('select',{class:'nova-input','aria-label':'Teaching view'});[['globe','Rotatable globe'],['radius','Radius / diameter'],['surface','Curved surface area'],['slice','Circular cross-section'],['cylinder','Enclosing cylinder · volume']].forEach(function(q){view.appendChild(h('option',{value:q[0],text:q[1]}));});
 row(panel,[radius.node,h('label',{class:'f13s-label'},['VISUAL ',view])]);row(panel,[cut.node]);
 function preset(k){st.preset=k;st.r=PRESETS[k];st.yaw=.48;st.pitch=-.14;st.cut=0;radius.set(st.r);cut.set(0);st.refresh();}
 select.onchange=function(){preset(select.value);};view.onchange=function(){st.view=view.value;st.refresh();};
 row(panel,[button('Rotate ↶',function(){st.yaw-=Math.PI/12;st.refresh();},'ghost'),button('Rotate ↷',function(){st.yaw+=Math.PI/12;st.refresh();},'ghost'),button('Show hidden grid',function(){st.showHidden=!st.showHidden;st.refresh();},'ghost'),button('Reset',function(){view.value='globe';st.view='globe';select.value='r3';preset('r3');},'ghost')]);
 panel.appendChild(h('p',{class:'f13s-instructions',text:'Drag the sphere to rotate it; arrow keys rotate when the drawing is focused. Use the slice slider to see how a cross-sectional circle changes. Surface area is always in square units; volume is in cubic units.'}));makeStage(stage,st,'Rotate the globe and test how changing the radius changes its area and volume.','explain',true);if(api.onCleanup)api.onCleanup(function(){if(stage._f13Cleanup)stage._f13Cleanup();});
 CFG._explore={state:st,preset:preset,setRadius:function(v){st.r=clamp(v,2,8);radius.set(st.r);st.refresh();},setCut:function(v){st.cut=clamp(v,-1,1);cut.set(Math.round(st.cut*100));st.view='slice';view.value='slice';st.refresh();},setView:function(v){st.view=v;view.value=v;st.refresh();},turn:function(a,b){st.yaw+=a;st.pitch=clamp(st.pitch+b,-1.15,1.15);st.refresh();},reset:function(){view.value='globe';st.view='globe';preset('r3');}};
 },
 challenge:function(panel,api,stage){var tasks=[{r:3,s:36,v:'36',q:'Radius 3 units. Give the surface area coefficient of π (square units) and the sphere volume coefficient of π (cubic units).',hint:'Surface uses 4r²; volume uses (4/3)r³.'},{r:2,s:16,v:'32/3',q:'Radius 2 units. Enter surface area and volume coefficients of π. Use a fraction for a non-whole coefficient (example 32/3).',hint:'Surface = 4 × 2². Volume = (4 × 2³)/3; keep it as a fraction.'},{r:6,s:144,v:'288',q:'Radius 6 units. Find the surface area and volume coefficients of π. Watch the squared and cubed units.',hint:'4 × 6² gives surface area. (4/3) × 6³ gives volume.'}];
 var k=0,timer=0,question=h('p',{class:'pr-task'}),a=h('input',{class:'nova-input',type:'text',inputmode:'decimal','aria-label':'Surface area coefficient of pi'}),b=h('input',{class:'nova-input',type:'text',inputmode:'decimal','aria-label':'Volume coefficient of pi'}),feedback=h('p',{class:'f13s-feedback','aria-live':'polite'});
 function load(i){k=i;var t=tasks[i];a.value='';b.value='';feedback.textContent='';question.textContent=(i+1)+' / '+tasks.length+' · '+t.q;makeStage(stage,state('r'+t.r,'radius'),'Remember: r squared for area; r cubed for volume.','think',false);}
 function parse(t){t=String(t).trim().replace(/π/g,'').replace(/\s/g,'');if(!t)return NaN;var m=/^(-?\d+(?:\.\d+)?)(?:\/(-?\d+(?:\.\d+)?))?$/.exec(t);return m&&(+m[2]!==0||!m[2])?+m[1]/(m[2]?+m[2]:1):NaN;}
 function check(){var t=tasks[k],x=parse(a.value),y=parse(b.value),ok=Math.abs(x-t.s)<1e-9&&Math.abs(y-parse(t.v))<1e-9;var msg=ok?'Correct. You distinguished the curved square-unit area from the cubic-unit volume.':!Number.isFinite(x)||!Number.isFinite(y)?'Enter both coefficients. Fractions use a slash: 32/3.':x!==t.s?(x===t.r*t.r?'Surface area needs FOUR times the circle area, 4πr².':'Check the radius SQUARED and multiply by four.'):Math.abs(y-(t.r*t.r*t.r*4))<.00001?'Volume needs the factor one third: (4/3)πr³.':'The area is correct. Use r CUBED and then multiply by four thirds for volume.';
 feedback.textContent=msg;api.check(ok,msg,{task:k,radius:t.r,area:x,volume:y});if(ok&&k<tasks.length-1){if(timer)clearTimeout(timer);timer=setTimeout(function(){load(k+1);},1050);}return ok;}
 panel.appendChild(question);row(panel,[h('label',{class:'f13s-answer'},['SURFACE AREA ×π ',a]),h('label',{class:'f13s-answer'},['VOLUME ×π ',b])]);row(panel,[button('Check answers',check,'primary'),button('Hint',function(){api.hint(tasks[k].hint);},'ghost')]);panel.appendChild(feedback);panel.appendChild(h('p',{class:'f13s-instructions',text:'Enter the coefficient of π only, not π itself. Example: enter 36 for 36π; use 32/3 for 32π over 3.'}));if(api.onCleanup)api.onCleanup(function(){if(timer)clearTimeout(timer);if(stage._f13Cleanup)stage._f13Cleanup();});load(0);CFG._challenge={tasks:tasks,load:load,check:check,inputs:[a,b],task:function(){return k;}};
 }
};
NOVA.bankMount({id:EN,num:'F13·10',title:'Sphere volume and surface area',def:def,linked:['F0-01','F0-02','F0-03','F0-04','F0-05','F13-01','F13-06','F13-08','F13-09'],spec:{
 purpose:'Explore radii, great circles and spherical cross-sections, then calculate sphere area 4πr² and volume (4/3)πr³.',
 params:'Radius from 2 to 8 units. Exact π coefficients and proper NOVA Chalk stacked fractions for non-integer volume coefficients. Slice from z=-r to z=r.',
 presets:'Five radii: 2,3,4,5,6. Visuals: rotatable globe, diameter/radius, equivalent surface comparison, circular slices and enclosing cylinder.',
 steps:STEPS.map(function(x){return x.n;}).join(' → '),
 interactions:'12 Watch/Guided teaching beats, pointer and keyboard sphere rotation, radius and slice sliders, five visual modes, three marked challenge tasks.',
 traps:'Radius versus diameter; sphere curved surface has no exact planar net; area uses squared units; volume uses cubic units; enclosing cylinder relation is 2/3.',
 gcse:'Use and interpret 4πr², 4πr³/3. Cylinder of radius r, height 2r gives volume 2πr³; sphere volume is two thirds of this.'}});
var log=document.getElementById('log'),ev=function(x){log.textContent=new Date(x.time).toLocaleTimeString()+' '+x.type+' '+JSON.stringify(x.detail)+'\n'+log.textContent.slice(0,4000);};NOVA.events.history().forEach(ev);NOVA.events.on('*',ev);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
