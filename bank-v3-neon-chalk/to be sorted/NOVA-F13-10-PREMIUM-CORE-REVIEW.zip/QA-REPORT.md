# F13-10 QA Report · Sphere Volume and Surface Area

- **Automated browser checks:** 175 / 175 passed; 0 failed.
- **Widths tested:** 1280px desktop and 380px mobile, Chromium.
- **Shared NOVA core:** exact byte-for-byte match to F13-09 reference.
- **Core CSS:** exact byte-for-byte match before the F13 component addition.
- **Official cat:** embedded existing production pose art, single in-stage dock.
- **No reported browser JavaScript errors**, external requests, or horizontal overflow in the tested states.
- **Browser interactions checked:** all 12 teaching steps, five radii, four visual views, five cross-section locations, 25 fast drag gestures at each width, plus/minus, arrow/Home, and all three challenge answers and one wrong-answer misconception.
- **Exact geometry checked:** surface area `4πr²`, volume `4πr³/3`, sphere/enclosing-cylinder 2/3, circular cut area `π(r²-z²)`.
- **Fraction formatting:** numerator + bar + denominator in actual NOVA Chalk SVG.
- **Snapshot SHA256:** `c16cec12489a9374a9a1bc6cfa471c900fc23558d459b8a9f01197edf1cd2761`.
- **Build status:** Functional NOVA-core review only. Browser QA is not user visual approval / GOLD sign-off.
- **GitHub:** unchanged.

Screenshots include original-stage crops at mobile/desktop of globe, surface comparison, slice, cylinder comparison, fractions, Watch and Challenge.
