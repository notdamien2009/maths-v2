# NOVA F13-10 · Sphere Volume and Surface Area

**Build type:** F13 premium-core review; not a GOLD sign-off. User visual approval is required.

**Launch:** `F13-10-Sphere-Volume-and-Surface-Area-PREMIUM-CORE.html` directly in Chrome/Edge. No server, network, external fonts, or package install needed.

## Production basis
The self-contained HTML reuses the F13-09 premium production build and its embedded original NOVA runtime and styling. The shared JavaScript was verified byte-for-byte identical to the original; the F13-10-specific layer replaces only prior F13-09-specific engine/CSS. This preserves the actual F0-derived rendering runtime, original theme background, embedded Chalk fonts and official mascot image/pose system.

## Maths and interactions
- True shaded rotatable 3D sphere with latitude/longitude grid, centre, radius and diameter.
- Five radius presets plus radius control from 2–8 units.
- Curved surface area: `4πr²` in square units. Show equivalent area of four great-circle discs **for area comparison only**; this is **not a physical net of the sphere**.
- Volume: `(4/3)πr³` in cubic units; proper traditional stacked chalk fractions for non-integer coefficients (for example `32π/3` for radius 2).
- Continuous circular cross-section moving from `-r` to `+r`, circle radius `sqrt(r²-z²)` and area `π(r²-z²)`.
- Enclosing-cylinder comparison: cylinder radius `r`, height `2r`, sphere/cylinder volume `2/3` shown with a stacked fraction.
- 12 named teaching steps in Watch/Guided, full Explore with pointer/keyboard rotation, and 3 marked Challenges.

## Robustness
- One approved NOVA stage; official cat inside the stage bottom-right; no invented central control row.
- Pointer capture, cancel / lostcapture / blur recovery; requestAnimationFrame render coalescing; keyboard rotation and radius control.
- Built at desktop width 1280 and mobile 380 with tests covering math, 12 beats, modes, controls and input validation.

## Reproduction
Run `python source/build.py` from any working directory. It extracts the F13-09 component-only layer and inlines `source/f13_10_engine.js` plus `source/f13_10_addon.css` without altering the shared NOVA runtime. `QA-REPORT.md`, `QA-RESULTS.json`, screenshots and automated test script are included.

**GitHub:** No edits or pushes made.
