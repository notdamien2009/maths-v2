import json, hashlib, math, time
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
html=(root/'F13-10-Sphere-Volume-and-Surface-Area-PREMIUM-CORE.html').read_text()
base=(root/'source'/'F13-09-Pyramid-and-Cone-Fill-PREMIUM-CORE.html').read_text()
def core(t):
 a=t.index('/* === NOVA FAMILY CORE v1.4 : JS START');b=t.index('</script>',a);return t[a:b]
checks=[]
def check(name,success,detail=''):
 checks.append({'name':name,'passed':bool(success),'detail':str(detail) if not success else ''})
 if not success:print('FAIL',name,detail)
def mode(page,name):
 tabs=page.locator('.nova-tabs button');found=False
 for i in range(tabs.count()):
  if name.lower() in tabs.nth(i).inner_text().lower():tabs.nth(i).click();found=True;break
 if not found:raise RuntimeError('mode not found: '+name)
 page.wait_for_timeout(110)
def read(page):
 return page.locator('[data-f13s-root]').evaluate('''e=>({r:+e.getAttribute('data-radius'),a:+e.getAttribute('data-surface'),v:+e.getAttribute('data-volume'),cy:+e.getAttribute('data-cylinder'),slice:+e.getAttribute('data-slice-area'),cut:+e.getAttribute('data-cut'),view:e.getAttribute('data-view')})''')
def approx(a,b):return abs(a-b)<1e-7
check('Official complete NOVA JS core retained byte-for-byte',core(base)==core(html))
check('Original shared stylesheet exact until local F13-10 CSS',base[base.index('<style>'):base.index('/* F13-09 additive styles.')]==html[html.index('<style>'):html.index('/* F13-10 Sphere: additive production-component styles.')])
check('Official original embedded Chalk font available','font-face{font-family:"NOVA Chalk"' in html)
check('No network / external script dependencies','<script src=' not in html and 'https://fonts.googleapis' not in html)
check('Correct F13-10 header','data-run="F13 · 3D shapes, volume and surface area · F13-10"' in html)
check('Official dock helper', 'NOVA.scene.helperStrip' in core(html))
check('Stacked fraction in geometry engine', 'function card(' in html and 'f.den' in html)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='load');page.wait_for_timeout(250)
  check(f'{width}: component loads',page.locator('.f13s-svg').count()==1)
  check(f'{width}: official dock single and inside stage',page.locator('.nova-stage > .nv-dock').count()==1)
  check(f'{width}: official mascot image embedded',page.locator('.nv-dock image').count()>=1)
  check(f'{width}: one stage only',page.locator('.nova-stage').count()==1)
  check(f'{width}: background body topic',page.locator('body[data-topic="geometry"]').count()==1)
  check(f'{width}: no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'),page.evaluate('document.documentElement.scrollWidth'))
  d=page.locator('.nova-stage > .nv-dock').bounding_box();st=page.locator('.nova-stage').bounding_box()
  if d and st:check(f'{width}: dock inside stage bounds',d['x']>=st['x']-3 and d['x']+d['width']<=st['x']+st['width']+5 and d['y']+d['height']<=st['y']+st['height']+5,(d,st))
  x=read(page);check(f'{width}: initial surface r3 =36π',approx(x['a'],36*math.pi),x);check(f'{width}: initial volume r3 =36π',approx(x['v'],36*math.pi),x)
  check(f'{width}: sphere has 3D glass body',page.locator('[data-maths="sphere-body"] circle').count()>=3)
  check(f'{width}: 12 teaching steps',page.evaluate('!!(window.F13_10 && window.F13_10.timeline && window.F13_10.timeline.steps.length===12)'))
  for i in range(12):
   r=page.evaluate('''i=>{const x=window.F13_10;try{(x.tl||x.timeline).go(i,'qa');return true}catch(e){return String(e)}}''',i)
   page.wait_for_timeout(15)
   check(f'{width}: teaching step {i+1} executes',r is True,r)
   check(f'{width}: step {i+1} single stage and dock',page.locator('.nova-stage > .nv-dock').count()==1)
  mode(page,'Explore')
  check(f'{width}: Explore control selection',page.locator('select[aria-label="Teaching view"]').count()==1)
  check(f'{width}: Explore API ready',page.evaluate('!!NOVA_F13_10_CONFIG._explore'))
  for r in [2,3,4,5,6]:
   page.evaluate('r=>NOVA_F13_10_CONFIG._explore.setRadius(r)',r);page.wait_for_timeout(20);q=read(page)
   check(f'{width}: radius {r} displayed',q['r']==r,q)
   check(f'{width}: radius {r} surface calculation',approx(q['a'],4*math.pi*r*r),q)
   check(f'{width}: radius {r} volume calculation',approx(q['v'],4*math.pi*r**3/3),q)
   check(f'{width}: radius {r} cylinder comparison',approx(q['v']*3,q['cy']*2),q)
  page.evaluate('NOVA_F13_10_CONFIG._explore.setRadius(2)');page.wait_for_timeout(40)
  # Verify the stacked numerator/denominator are actually drawn rather than a slash string.
  svg=page.locator('.f13s-svg')
  labels=svg.locator('text').all_text_contents()
  check(f'{width}: fraction numerator 32π and denominator 3 rendered separately','32π' in labels and '3' in labels,labels[-20:])
  check(f'{width}: NO inline 32π/3 inside SVG', '32π/3' not in labels)
  page.evaluate('NOVA_F13_10_CONFIG._explore.setRadius(3)');
  for v in ['radius','surface','slice','cylinder','globe']:
   page.evaluate('v=>NOVA_F13_10_CONFIG._explore.setView(v)',v);page.wait_for_timeout(45)
   check(f'{width}: visual view {v} shows',read(page)['view']==v)
   if v=='slice':
    check(f'{width}: cross section circle exists',page.locator('[data-maths="section-circle"]').count()==1)
    for cut,val in [(0,9*math.pi),(.6,9*math.pi*.64),(.8,9*math.pi*.36),(1,0),(-1,0)]:
     page.evaluate('cut=>NOVA_F13_10_CONFIG._explore.setCut(cut)',cut);page.wait_for_timeout(35);q=read(page)
     check(f'{width}: slice {cut} correct area',approx(q['slice'],val),q)
    page.evaluate('NOVA_F13_10_CONFIG._explore.setCut(0)');page.wait_for_timeout(50)
    page.locator('.nova-stage').scroll_into_view_if_needed();page.screenshot(path=str(root/'screenshots'/f'{width}-slice.png'))
   if v=='cylinder':
    page.locator('.nova-stage').scroll_into_view_if_needed();page.screenshot(path=str(root/'screenshots'/f'{width}-cylinder.png'))
   if v=='surface':
    page.locator('.nova-stage').scroll_into_view_if_needed();page.screenshot(path=str(root/'screenshots'/f'{width}-surface.png'))
  svg.scroll_into_view_if_needed()
  svg.focus();old=page.evaluate('NOVA_F13_10_CONFIG._explore.state.yaw');page.keyboard.press('ArrowRight');page.wait_for_timeout(50)
  check(f'{width}: keyboard yaw rotates',page.evaluate('NOVA_F13_10_CONFIG._explore.state.yaw')>old)
  old=page.evaluate('NOVA_F13_10_CONFIG._explore.state.pitch');page.keyboard.press('ArrowUp');page.wait_for_timeout(40)
  check(f'{width}: keyboard pitch rotates',page.evaluate('NOVA_F13_10_CONFIG._explore.state.pitch')<old)
  page.keyboard.press('+');page.wait_for_timeout(50);check(f'{width}: keyboard plus increases radius',read(page)['r']==4)
  page.keyboard.press('-');page.wait_for_timeout(50);check(f'{width}: keyboard minus decreases radius',read(page)['r']==3)
  page.keyboard.press('Home');page.wait_for_timeout(50);check(f'{width}: Home resets yaw',approx(page.evaluate('NOVA_F13_10_CONFIG._explore.state.yaw'),.48))
  # 25 rapid gestures at native pointer input on visible drawing
  svg.scroll_into_view_if_needed();box=svg.bounding_box();startYaw=page.evaluate('NOVA_F13_10_CONFIG._explore.state.yaw')
  for n in range(25):
   xa=box['x']+box['width']*.23; ya=box['y']+box['height']*.39
   page.mouse.move(xa,ya);page.mouse.down();page.mouse.move(xa+35+(n%4)*7,ya+(n%5)*2,steps=1);page.mouse.up()
  page.wait_for_timeout(170)
  check(f'{width}: fast 25 pointer rotations commit',abs(page.evaluate('NOVA_F13_10_CONFIG._explore.state.yaw')-startYaw)>.5)
  check(f'{width}: fast rotation releases capture',page.locator('.f13s-svg.f13s-drag').count()==0)
  # interrupt gesture safely by switching tabs
  page.mouse.move(box['x']+box['width']*.2,box['y']+box['height']*.3);page.mouse.down();page.mouse.move(box['x']+box['width']*.4,box['y']+box['height']*.33,steps=2)
  page.mouse.up();mode(page,'Challenge')
  check(f'{width}: Challenge view loads',page.locator('input[aria-label="Surface area coefficient of pi"]').count()==1)
  check(f'{width}: mode change leaves one mascot dock',page.locator('.nova-stage > .nv-dock').count()==1)
  for i,(a,v) in enumerate([(36,'36'),(16,'32/3'),(144,'288')]):
   page.evaluate('i=>NOVA_F13_10_CONFIG._challenge.load(i)',i)
   if i==0:
    page.locator('input[aria-label="Surface area coefficient of pi"]').fill('9');page.locator('input[aria-label="Volume coefficient of pi"]').fill('36')
    check(f'{width}: circle-area misconception rejected',page.evaluate('NOVA_F13_10_CONFIG._challenge.check()') is False)
   page.locator('input[aria-label="Surface area coefficient of pi"]').fill(str(a));page.locator('input[aria-label="Volume coefficient of pi"]').fill(v)
   check(f'{width}: challenge {i+1} marks correctly',page.evaluate('NOVA_F13_10_CONFIG._challenge.check()') is True)
  page.locator('.nova-stage').scroll_into_view_if_needed();page.screenshot(path=str(root/'screenshots'/f'{width}-challenge-final.png'))
  check(f'{width}: no JS errors',len(errors)==0,errors)
  page.close()
 browser.close()
result={'total':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'failures':[x for x in checks if not x['passed']],'checks':checks,'sha256':hashlib.sha256((root/'F13-10-Sphere-Volume-and-Surface-Area-PREMIUM-CORE.html').read_bytes()).hexdigest()}
(root/'QA-RESULTS.json').write_text(json.dumps(result,indent=2));print('QA',result['passed'],'/',result['total'])
