#!/usr/bin/env python3
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib
R=Path(__file__).resolve().parents[1];code=(R/'F16/F16-05-stem-and-leaf-plot.html').read_text();results=[]
def check(name,v):
 results.append({'name':name,'passed':bool(v)});print(('PASS' if v else 'FAIL'),name,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for w in (380,1280):
  pg=b.new_page(viewport={'width':w,'height':960},reduced_motion='reduce');err=[];pg.on('pageerror',lambda e:err.append(str(e)))
  pg.set_content(code,wait_until='load',timeout=90000);pg.wait_for_timeout(130)
  pg.evaluate("F16_05.timeline.pause();F16_05.timeline.go(0,'test')");pg.wait_for_timeout(110)
  check(f'{w} first Watch step contains raw observations',pg.locator('.f16s-plot .nv-neon-box').count()>=16)
  check(f'{w} first Watch step hides completed STEM rows',pg.locator('.f16s-plot .f16s-leaf').count()==0)
  pg.locator('.f16s-plot').screenshot(path=str(R/'shots'/f'F16-05-{w}-watch-first.png'))
  pg.locator('.nova-tab[data-m="guided"]').click();pg.evaluate("F16_05.timeline.go(5,'test')");pg.wait_for_timeout(90)
  check(f'{w} Guided step explains explicit key',pg.locator('.f16s-plot').text_content().find('2 | 6 = 26')>=0)
  pg.locator('.f16s-plot').screenshot(path=str(R/'shots'/f'F16-05-{w}-guided-key.png'))
  pg.locator('.nova-tab[data-m="explore"]').click();pg.wait_for_timeout(110)
  check(f'{w} construct 3 cards start in tray',pg.locator('.f16s-plot [data-chip]').count()==3)
  pg.evaluate("C=>{C._explore.place('A-2',1);C._explore.place('A-7',2);C._explore.place('A-14',4);}",None) if False else None
  pg.evaluate("()=>{let C=NOVA_F16_05_CONFIG;C._explore.place('A-2',1);C._explore.place('A-7',2);C._explore.place('A-14',4);}")
  check(f'{w} full 16 leaves constructed',pg.locator('.f16s-plot .f16s-leaf').count()==16)
  check(f'{w} repeated scores retained',pg.evaluate("()=>{let p=[...document.querySelectorAll('.f16s-leaf text')].map(x=>x.textContent);return p.filter(x=>x==='4').length>=3&&p.filter(x=>x==='6').length>=2}"))
  check(f'{w} exactly four tens stems',pg.evaluate("()=>[...document.querySelectorAll('.f16s-plot text')].filter(t=>t.textContent==='1'||t.textContent==='2'||t.textContent==='3'||t.textContent==='4').length>=4"))
  pg.locator('.f16s-plot').screenshot(path=str(R/'shots'/f'F16-05-{w}-full-construct.png'))
  pg.locator('select[aria-label="Lesson preset"]').select_option('compare');pg.wait_for_timeout(115)
  pg.evaluate("()=>{const C=NOVA_F16_05_CONFIG;for(const chip of ['A-6','A-12','B-4','B-11']){const p=C.presets.compare;const group=chip[0];const idx=Number(chip.split('-')[1]);C._explore.place(chip,Math.floor(p[group][idx]/10));}}")
  check(f'{w} 30 back-to-back leaves constructed',pg.locator('.f16s-plot .f16s-leaf').count()==30)
  check(f'{w} no unplaced chips after completion',not pg.evaluate('Object.values(NOVA_F16_05_CONFIG._explore.get().placed).some(x=>!x)'))
  pg.locator('.f16s-plot').screenshot(path=str(R/'shots'/f'F16-05-{w}-full-compare.png'))
  # restore scores mode for alternate third challenge question.
  pg.locator('.nova-tab[data-m="explore"]').click();pg.locator('select[aria-label="Lesson preset"]').select_option('construct')
  pg.locator('.nova-tab[data-m="challenge"]').click();pg.wait_for_timeout(130)
  pg.get_by_role('button',name='Place 26 in stem 2').click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(950)
  pg.locator('.pr-task + div input').first.fill('37');pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(980)
  check(f'{w} score challenge asks actual median',pg.locator('.pr-task').inner_text()=='What is the median of the complete dataset?')
  pg.locator('.pr-task + div input').first.fill('26');pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(130)
  check(f'{w} score median 26 accepted',pg.locator('.nova-fb.ok').count()>0)
  pg.locator('.f16s-plot').screenshot(path=str(R/'shots'/f'F16-05-{w}-challenge-solved.png'))
  check(f'{w} no page errors across both lesson presets',len(err)==0)
  pg.close()
 b.close()
(R/'tests/PRESET-RESULTS.json').write_text(json.dumps({'passed':sum(x['passed'] for x in results),'total':len(results),'failures':[x for x in results if not x['passed']],'tests':results},indent=2))
print('PRESETS',sum(x['passed'] for x in results),'/',len(results))
