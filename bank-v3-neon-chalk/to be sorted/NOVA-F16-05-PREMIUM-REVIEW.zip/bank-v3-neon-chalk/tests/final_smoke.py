from pathlib import Path
from playwright.sync_api import sync_playwright
import hashlib,json
R=Path(__file__).resolve().parents[1];data=(R/'F16/F16-05-stem-and-leaf-plot.html').read_text();checks=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for w in [380,1280]:
  pg=b.new_page(viewport={'width':w,'height':970},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(data,wait_until='load');pg.wait_for_timeout(100)
  pg.evaluate("F16_05.timeline.pause();F16_05.timeline.go(0,'final')");pg.wait_for_timeout(75)
  pg.locator('.f16s-plot').screenshot(path=str(R/'shots'/f'F16-05-{w}-watch-first.png'))
  raw=pg.locator('.f16s-plot').text_content();checks.append((f'{w} unsorted raw and repeated values', 'unsorted quiz scores' in raw and 'Count every repeated score' in raw))
  pg.locator('.nova-tab[data-m="explore"]').click();pg.wait_for_timeout(80)
  checks.append((f'{w} rendered stage and original dock',pg.locator('.f16s-plot').count()==1 and pg.locator('.nv-dock').count()==1))
  checks.append((f'{w} no overflow',pg.evaluate('document.documentElement.scrollWidth<=innerWidth+2')))
  checks.append((f'{w} no runtime errors',len(errors)==0))
  pg.close()
 b.close()
(R/'tests/FINAL-SMOKE.json').write_text(json.dumps({'passed':sum(v for _,v in checks),'total':len(checks),'checks':[{'check':x,'passed':v} for x,v in checks]},indent=2))
print('FINAL',sum(v for _,v in checks),'/',len(checks),'sha256',hashlib.sha256(data.encode()).hexdigest())
