from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path('/mnt/data/nova-f16-05-work');f=p/'F16/F16-05-stem-and-leaf-plot.html'
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  pg=b.new_page(viewport={'width':width,'height':980},reduced_motion='reduce')
  errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(f.read_text(),wait_until='load',timeout=90000);pg.wait_for_timeout(350)
  for mode in ['watch','guided','explore','challenge']:
   pg.locator(f'.nova-tab[data-m="{mode}"]').click();pg.wait_for_timeout(200)
   print(width,mode,'plot',pg.locator('.f16s-plot').count(),'dock',pg.locator('.nv-dock').count(),'errors',len(errors),'overflow',pg.evaluate('document.documentElement.scrollWidth-innerWidth'),flush=True)
   pg.locator('.f16s-plot').screenshot(path=str(p/'shots'/f'F16-05-{width}-{mode}.png'))
  pg.locator('.nova-tab[data-m="explore"]').click();pg.locator('select[aria-label="Lesson preset"]').select_option('compare');pg.wait_for_timeout(160)
  pg.locator('.f16s-plot').screenshot(path=str(p/'shots'/f'F16-05-{width}-compare.png'))
  pg.locator('.nova-tab[data-m="watch"]').click();pg.evaluate("window.F16_05.timeline.pause();window.F16_05.timeline.go(8,'test')");pg.wait_for_timeout(150)
  pg.locator('.f16s-plot').screenshot(path=str(p/'shots'/f'F16-05-{width}-watch-complete.png'))
  print('errors',errors[:5]);pg.close()
 b.close()
