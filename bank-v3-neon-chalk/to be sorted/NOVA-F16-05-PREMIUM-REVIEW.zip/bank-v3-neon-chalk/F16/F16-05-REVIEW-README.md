# NOVA Maths V2 · F16-05 Stem-and-leaf Plot

**Premium review only** — not GOLD approval. No GitHub writes.

## Review

Open `F16/F16-05-stem-and-leaf-plot.html` directly in a browser; no network required. Test Watch (raw to ordered plot), Guided, Explore (drag and remove the score cards), and Challenge (place a value, interpret key notation, calculate and compare medians).

Switch between Y7-068 construction and Y7-070 comparison. The comparison preset renders one common central stem with Team A's leaves extending to the left and Team B's to the right.

## Included (scoped incremental ZIP)

- `F16/F16-05-stem-and-leaf-plot.html` — final standalone; embedded original NOVA shared runtime
- `src/F16-05.js`, `src/F16-05.css` — additive component source
- `build/F16-05.src.html`, `build/build-f16-05.py` — local builder, with strict shared-core hash guard
- `tests/` — runnable Playwright testing and evidence JSON/logs
- `shots/F16-05/` — 380px/1280px review captures
- `F16/F16-05-QA.md` — transparent QA report

## Integration

Merge only F16-05-scoped files into your local `bank-v3-neon-chalk/` project. The builder uses the **unmodified** original `F2/F2-03-base-ten-blocks.html` as a reference to inline the shared NOVA core. Keep F0/F1/F2, master documents and current GitHub untouched. Do not replace the repository core or run a general all-family builder.
