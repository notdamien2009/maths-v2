# NOVA F11-10 — Bearings · Premium Review Candidate

Status: **Premium review only; owner approval pending.** GitHub has not been modified.

## Review
Open `F11/F11-10-bearings.html` directly; it contains the complete embedded existing F0/F1 core (including fonts, mascot poses and styles) plus F11-10. No runtime network connections or external dependencies.

## Mathematics and scenes
- Single clockwise bearing from north; three-figure notation including leading zeros.
- Reverse bearings use `(forward + 180) mod 360` and measure from north at the return point.
- Multi-leg route A–B–C uses **a new north reference at B**; the direct A–C segment is shown separately.
- Two ray bearings from A and B intersect exactly at P.
- Named presets: Y8-052, Y9-039, Y9-027, multi-step route, due east, 225° and 315° bearings.
- Four F0 modes, 27 progressive teaching states, live compass-arm drag, second-route-handle drag, keyboard, Escape rollback, reason-card drop and eight checked Challenges.

## Files
`src/F11-10.js` is only the bearing engine; `src/F11-10.css` holds scoped enhancements. `build/F11-10.src.html` and `build/build-F11-10.py` reproduce the file using the **existing** `core/nova-core.js` and `.css` from the installed repository. This ZIP deliberately does not contain or overwrite those shared core files.

To rebuild after extracting files into the `bank-v3-neon-chalk/` repository folder:

```bash
python build/build-F11-10.py
python tests/test_f110.py
```

## Acceptance and remaining review
- 184/184 automated Chromium checks passed at 380px and 1280px; see `tests/F11-10-QA.json`.
- Validated bearing vector model, reverse and direct bearings, exact intersecting rays, all Challenge solutions and incorrect-answer feedback, keyboard, pointer capture, Escape cancellation, reason drag and mascot containment.
- Screenshots cover all four modes and seven presets at both widths. Test script produces this evidence.
- Numerical Challenge input accepts the numeric degree value (e.g. `65`) while pupil-facing labels use the mandated `065°` notation; the narrative also calls out the leading-zero rule.
- Review on actual touch devices remains with the owner before GOLD approval.

## Important design locks
- Original F0/F1 core and F9-scale mascot, fully inside the blue learning container.
- No second row inserted into the stage. SVG drawn using the existing NOVA helpers; all stage handwriting is NOVA Chalk.
- The supported exact 5° drag snap follows previous F11 interactions; component does not change the global core.
