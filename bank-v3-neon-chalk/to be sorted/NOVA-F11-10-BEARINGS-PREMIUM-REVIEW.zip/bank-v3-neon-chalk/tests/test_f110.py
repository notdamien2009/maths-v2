#!/usr/bin/env python3
"""F11-10 Chromium acceptance tests: master modes, geometry, challenge, drags and viewport screenshots."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import hashlib,json,math,sys
root=Path(__file__).resolve().parents[1]
s=(root/'F11/F11-10-bearings.html').read_text()
shots=root/'shots/F11-10';shots.mkdir(parents=True,exist_ok=True)
passed=[];failed=[]
def ck(label,condition):
 try:
  if not condition:raise AssertionError('false')
  passed.append(label)
 except Exception as e:failed.append({'test':label,'error':str(e)})
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  page=b.new_page(viewport={'width':width,'height':1000},reduced_motion='reduce');errs=[];page.on('pageerror',lambda e:errs.append(str(e)));page.set_content(s,wait_until='load');page.wait_for_timeout(150)
  ck(f'{width}: shell built',page.locator('#F11-10').count()==1)
  ck(f'{width}: four modes',page.get_by_role('tab').count()==4)
  ck(f'{width}: real NOVA Chalk embedded',page.evaluate('document.fonts.check("20px NOVA Chalk")'))
  ck(f'{width}: stage rendered',page.locator('[data-testid=f110-stage]').count()==1)
  ck(f'{width}: mascot inside stage',page.evaluate('''()=>{const a=document.querySelector('#F11-10 .f110-theatre').getBoundingClientRect(),b=document.querySelector('#F11-10 .nv-dockfig').getBoundingClientRect();return b.left>=a.left-2&&b.right<=a.right+2&&b.top>=a.top-2&&b.bottom<=a.bottom+2}'''))
  ck(f'{width}: stage labels never outside body',page.locator('[data-testid=f110-svg]').count()==1)
  ck(f'{width}: no startup errors',not errs)
  for mode in ('Watch','Guided','Explore','Challenge'):
   page.get_by_role('tab',name=mode,exact=True).click();page.wait_for_timeout(55)
   ck(f'{width}: {mode} SVG visible',page.locator('[data-testid=f110-svg]').count()==1)
   ck(f'{width}: {mode} runtime clean',not errs)
   page.screenshot(path=str(shots/f'F11-10-{width}-{mode.lower()}.png'),full_page=True,animations='disabled')
  ck(f'{width}: Challenge hides answer',page.locator('[data-testid=f110-aside] .f110-main').all_inner_texts()[-1]=='?')
  tasks=[(90,'clockwise'),(65,'three'),(245,'reverse'),(315,'clockwise'),(285,'reverse'),(125,'route'),(105,'origin'),(45,'intersection')]
  for i,(ans,why) in enumerate(tasks):
   page.locator('[data-testid=f110-answer]').fill(str(ans))
   page.locator(f'button[data-reason="{why}"]').click()
   page.get_by_role('button',name='Check answer + reason').click();page.wait_for_timeout(55)
   if i!=7:
    ck(f'{width}: challenge {i+1} accepted',page.get_by_role('button',name='Next challenge →').count()==1)
    page.get_by_role('button',name='Next challenge →').click()
    ck(f'{width}: challenge {i+2} result hidden',page.locator('[data-testid=f110-aside] .f110-main').all_inner_texts()[-1]=='?')
   else:ck(f'{width}: full challenge mastery',page.get_by_text('8 / 8 · BEARINGS MASTERY').count()==1)
  ck(f'{width}: Challenge error-free',not errs)
  page.get_by_role('tab',name='Explore',exact=True).click()
  for kind,preset in [('single','y8_052'),('reverse','y9_039'),('intersection','y9_027'),('route','y9_route'),('single','y8_cardinals'),('single','y9_obtuse'),('single','y9_northwest')]:
   page.locator('[data-testid=f110-preset]').select_option(preset);page.wait_for_timeout(60)
   ck(f'{width}: {preset} matches scene',page.locator('[data-testid=f110-kind]').input_value()==kind)
   ck(f'{width}: {preset} geometry rendered',page.locator('[data-testid=f110-geometry]').count()==1)
   page.locator('[data-testid=f110-stage]').screenshot(path=str(shots/f'F11-10-{width}-{preset}.png'),animations='disabled')
  for value in (0,20,45,90,135,180,225,270,315,355):
   data=page.evaluate('''b=>{let M=__F110_MATH__.model({kind:'single',bearing:b});return{b:__F110_MATH__.bearing(M.O,M.P),reverse:M.reverse}}''',value)
   ck(f'{width}: exact ray angle {value}',abs(data['b']-value)<1e-6)
   ck(f'{width}: correct reverse {value}',data['reverse']==(value+180)%360)
  for angle in (30,35,40,45,55,65):
   dat=page.evaluate('''a=>{let m=__F110_MATH__.model({kind:'intersection',bearing:a});let f=__F110_MATH__.bearing;return [f(m.A,m.P),f(m.B,m.P),m.P.y]}''',angle)
   ck(f'{width}: intersecting bearings {angle}',abs(dat[0]-angle)<1e-7 and abs(dat[1]-(360-angle))<1e-7)
   ck(f'{width}: intersection within visible page {angle}',100<=dat[2]<=410)
  for a,c in ((40,125),(25,90),(80,155)):
   dat=page.evaluate('''t=>{let m=__F110_MATH__.model({kind:'route',bearing:t[0],second:t[1]}),f=__F110_MATH__.bearing;return [f(m.A,m.B),f(m.B,m.C),f(m.A,m.C),m.direct]}''',[a,c]);ck(f'{width}: route bearings {a}/{c}',abs(dat[0]-a)<1e-7 and abs(dat[1]-c)<1e-7 and abs(dat[2]-dat[3])<1e-7)
  # Negative feedback and reason matching remain mandatory.
  page.get_by_role('tab',name='Challenge',exact=True).click()
  page.locator('[data-testid=f110-answer]').fill('270');page.locator('button[data-reason=clockwise]').click();page.get_by_role('button',name='Check answer + reason').click();page.wait_for_timeout(60)
  ck(f'{width}: incorrect bearing refused',page.get_by_role('button',name='Next challenge →').count()==0)
  page.locator('[data-testid=f110-answer]').fill('90');page.locator('button[data-reason=reverse]').click();page.get_by_role('button',name='Check answer + reason').click();page.wait_for_timeout(60)
  ck(f'{width}: wrong reason refused',page.get_by_role('button',name='Next challenge →').count()==0)
  page.locator('button[data-reason=clockwise]').click();page.get_by_role('button',name='Check answer + reason').click();page.wait_for_timeout(60)
  ck(f'{width}: can recover from mistakes',page.get_by_role('button',name='Next challenge →').count()==1)
  # Actual pointer drag of reason into drop zone, not a click simulation.
  page.get_by_role('tab',name='Challenge',exact=True).click();src=page.locator('button[data-reason=clockwise]');dest=page.locator('[data-testid=f110-reason-drop]');src.scroll_into_view_if_needed();a=src.bounding_box();q=dest.bounding_box();page.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);page.mouse.down();page.mouse.move(q['x']+q['width']/2,q['y']+q['height']/2,steps=6);page.mouse.up();page.wait_for_timeout(70)
  ck(f'{width}: reason card pointer-drop',dest.get_attribute('data-set')=='true')
  ck(f'{width}: no lingering reason drag',page.evaluate('window.NOVA.ui._drag===null'))
  page.get_by_role('tab',name='Explore',exact=True).click();page.locator('[data-testid=f110-preset]').select_option('y8_052');h=page.locator('[data-testid=f110-angle-handle]');h.scroll_into_view_if_needed();h.focus()
  start=int(h.get_attribute('aria-valuenow'));page.keyboard.press('ArrowRight');page.wait_for_timeout(50);ck(f'{width}: keyboard rotate',int(h.get_attribute('aria-valuenow'))==start+5)
  h.scroll_into_view_if_needed();bb=h.bounding_box();x=bb['x']+bb['width']/2;y=bb['y']+bb['height']/2
  page.mouse.move(x,y);page.mouse.down();page.mouse.move(x-65,y-55,steps=1);page.wait_for_timeout(180)
  dragValue=int(h.get_attribute('aria-valuenow'));ck(f'{width}: fast drag updates live',dragValue!=start+5)
  page.keyboard.press('Escape');page.wait_for_timeout(90);ck(f'{width}: Escape restores angle',int(h.get_attribute('aria-valuenow'))==start+5);page.mouse.up()
  ck(f'{width}: no stranded pointer',page.evaluate('window.NOVA.ui._drag===null'))
  page.locator('[data-testid=f110-preset]').select_option('y9_route');h=page.locator('[data-testid=f110-second-handle]');h.focus();v=int(h.get_attribute('aria-valuenow'));page.keyboard.press('ArrowLeft');page.wait_for_timeout(45)
  ck(f'{width}: second leg keyboard adjustment',int(h.get_attribute('aria-valuenow'))==v-5)
  ck(f'{width}: zero uncaught runtime errors',not errs)
  if errs:print('ERRORS',width,errs)
  page.close()
 b.close()
report={'engine':'F11-10','status':'premium-review','passed':len(passed),'failed':failed,'count':len(passed)+len(failed),'viewports':[380,1280],'source_sha256':hashlib.sha256(s.encode()).hexdigest()}
(root/'tests/F11-10-QA.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2));sys.exit(1 if failed else 0)
