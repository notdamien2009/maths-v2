NOVA Maths V2 — F18-08 Compound Measures
STATUS: BUILT FOR REVIEW; owner has not approved GOLD.

Open F18-08-compound-measures.html directly in Chrome, Edge or Firefox.
It is standalone, with the original embedded NOVA core, local Chalk font, and helper artwork.

Learning modes: Watch / Guided / Explore / Challenge.
Six presets: speed, density, speed conversion, multi-step speed, mass, pressure.

TEST RECORD: 194/194 main browser checks and 52/52 supplementary checks PASS
at browser viewports 380px and 1280px. 20 review screenshots included.
Not tested on physical touchscreen hardware; owner visual sign-off outstanding.

PRESERVATION: The reference shared core is unchanged. No GitHub push, commit,
modification or upload. One engine only; do not create separate preset engines.

Review report: F18-08-QA-REPORT.html
Tests: tests/*.py ; tests/*.json
Screenshots: screenshots/*.png
