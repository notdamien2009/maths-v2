import json, math
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data');QA=ROOT/'f18_08_qa';QA.mkdir(exist_ok=True)
checks=[]
def ck(name,ok,evidence=''):
 checks.append({'check':name,'ok':bool(ok),'evidence':str(evidence)[:350]})
 if not ok:print('FAIL',name,evidence,flush=True)
def go(p,mode):p.locator('#F18-08 .nova-tabs button').filter(has_text=mode).click();p.wait_for_timeout(50)
def ev(p,script):return p.evaluate(script)
def st(p):return ev(p,'NOVA_F18_08_CONFIG._explore.state()')
def cs(p):return ev(p,'NOVA_F18_08_CONFIG._challenge.state()')
def rect(p,selector):
 l=p.locator(selector);l.scroll_into_view_if_needed(timeout=5000);return l.bounding_box()
def point(b):return b['x']+b['width']/2,b['y']+b['height']/2
def target(p,x,y):
 i=ev(p,'''() => {let s=document.querySelector('#F18-08 .f1808-svg'),r=s.getBoundingClientRect(),v=s.viewBox.baseVal;return {x:r.x,y:r.y,w:r.width,h:r.height,bw:v.width,bh:v.height}}''');return i['x']+x*i['w']/i['bw'],i['y']+y*i['h']/i['bh']
def drag(p,role,slot=0,placed=False,dest='slot',steps=15):
 sel=f'#F18-08 .f1808-chip[data-role="{role}"]'+(f'[data-placed="{slot}"]' if placed else '[data-source]')
 b=rect(p,sel);a=point(b);xy={'slot':target(p,125 if slot==0 else 310,478),'remove':target(p,220,653),'invalid':target(p,220,170)}[dest]
 p.mouse.move(*a);p.mouse.down();p.mouse.move(*xy,steps=steps);p.mouse.up();p.wait_for_timeout(120)
with sync_playwright() as x:
 b=x.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  p=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');err=[];p.on('pageerror',lambda e:err.append(str(e)))
  p.set_content((ROOT/'F18-08-compound-measures.html').read_text(),wait_until='domcontentloaded');p.wait_for_timeout(130)
  ck(f'{width} one engine',p.locator('#F18-08').count()==1)
  ck(f'{width} shared svgDrag present',ev(p,'typeof NOVA.ui.svgDrag')=='function')
  ck(f'{width} no external styles/scripts',ev(p,'document.querySelectorAll("script[src],link[rel=stylesheet]").length')==0)
  ck(f'{width} six presets',len(ev(p,'Object.keys(NOVA_F18_08_CONFIG.presets)'))==6)
  ck(f'{width} no overflow',ev(p,'document.documentElement.scrollWidth<=innerWidth+1'))
  for mode in ('Watch','Guided','Explore','Challenge'):
   go(p,mode)
   ck(f'{width} {mode} SVG',p.locator('#F18-08 .f1808-svg').count()==1)
   ck(f'{width} {mode} mascot inside',p.locator('#F18-08 .nova-stage .nv-dock').count()==1)
   ck(f'{width} {mode} neon primitives',p.locator('#F18-08 .f1808-svg .nv-neon-box').count()>=3)
   ck(f'{width} {mode} no extra mascot',ev(p,'getComputedStyle(document.querySelector("#F18-08 .nova-bob")).display')=='none')
   ck(f'{width} {mode} no overflow',ev(p,'document.documentElement.scrollWidth<=innerWidth+1'))
   p.screenshot(path=str(QA/f'F18-08_{width}_{mode.lower()}.png'),full_page=True,animations='disabled')
  go(p,'Explore')
  for key,expected,unit in [('speed',60,'km h⁻¹'),('density',2.7,'g cm⁻³'),('conversion',25,'m s⁻¹'),('multistep',48,'km h⁻¹'),('mass',20,'kg'),('pressure',500,'Pa')]:
   ev(p,f'NOVA_F18_08_CONFIG._explore.select("{key}")');state=st(p)
   ck(f'{width} {key} selected',state['preset']==key)
   ck(f'{width} {key} maths',math.isclose(state['expected'],expected,rel_tol=1e-9),state)
   ck(f'{width} {key} two available chips',p.locator('#F18-08 .f1808-chip[data-source]').count()==2)
   ck(f'{width} {key} correct operator',state['target']==0 or state['pair'][0]==0)
  ev(p,'NOVA_F18_08_CONFIG._explore.select("speed")')
  first=st(p)['pair'][0];second=st(p)['pair'][1]
  drag(p,first,slot=0)
  ck(f'{width} actual pointer places first value',st(p)['slots']==[first,None],st(p))
  drag(p,second,slot=1,steps=3)
  ck(f'{width} rapid pointer places second value',st(p)['slots']==[first,second],st(p))
  drag(p,first,slot=0,placed=True,dest='remove')
  ck(f'{width} re-grab returns chip',st(p)['slots']==[None,second],st(p))
  drag(p,first,slot=0,dest='invalid',steps=3)
  ck(f'{width} invalid drop restores previous position',st(p)['slots']==[None,second],st(p))
  ck(f'{width} no floating drag after invalid',p.locator('#F18-08 .nv-drag-lift').count()==0)
  bb=rect(p,f'#F18-08 .f1808-chip[data-source="{first}"]');src=point(bb);p.mouse.move(*src);p.mouse.down();p.mouse.move(src[0]+50,src[1]-50,steps=3);p.keyboard.press('Escape');p.mouse.up();p.wait_for_timeout(90)
  ck(f'{width} escape retains state',st(p)['slots']==[None,second])
  ck(f'{width} escape clears lift',p.locator('#F18-08 .nv-drag-lift').count()==0)
  p.locator(f'#F18-08 .f1808-chip[data-source="{first}"]').focus();p.keyboard.press('Enter');
  ck(f'{width} keyboard placement',st(p)['slots']==[first,second])
  p.locator(f'#F18-08 .f1808-chip[data-placed="0"]').focus();p.keyboard.press('Delete')
  ck(f'{width} keyboard removal',st(p)['slots']==[None,second])
  ev(p,'NOVA_F18_08_CONFIG._explore.select("mass")')
  ck(f'{width} mass multiply mode',st(p)['target']==0)
  ev(p,'NOVA_F18_08_CONFIG._explore.target(1)')
  ck(f'{width} unknown selector updates formula',st(p)['target']==1)
  go(p,'Challenge')
  val=[(60,'km/h'),(2.1,'g/cm³'),(20,'m/s'),(72,'km/h'),(20,'kg'),(500,'Pa')]
  for i,(v,u) in enumerate(val):
   ev(p,f'NOVA_F18_08_CONFIG._challenge.task({i})')
   t=cs(p);ck(f'{width} task{i} exact maths',math.isclose(t['expected'],v,rel_tol=1e-8),t)
   ck(f'{width} task{i} units necessary',not ev(p,f'NOVA_F18_08_CONFIG._challenge.check("{v}")')[0])
   ck(f'{width} task{i} wrong number rejected',not ev(p,f'NOVA_F18_08_CONFIG._challenge.check("{v+2} {u}")')[0])
   ck(f'{width} task{i} requires formula placement',not ev(p,f'NOVA_F18_08_CONFIG._challenge.check("{v} {u}")')[0])
   for k,role in enumerate([0,2] if i<4 else [1,2] if i==4 else [0,2]):ev(p,f'NOVA_F18_08_CONFIG._challenge.place({role},{k})')
   ck(f'{width} task{i} correct accepted',ev(p,f'NOVA_F18_08_CONFIG._challenge.check("{v} {u}")')[0])
   ck(f'{width} task{i} hidden result before submit',f'{v} {u}' not in p.locator('#F18-08 .f1808-side').inner_text())
  ck(f'{width} JS errors absent',not err,err)
  p.close()
 b.close()
r={'passed':sum(x['ok'] for x in checks),'total':len(checks),'failed':[x for x in checks if not x['ok']],'checks':checks};(QA/'stress-results.json').write_text(json.dumps(r,indent=2));print('STRESS',r['passed'],'/',r['total']);print('FAILED',r['failed'][:12]);
