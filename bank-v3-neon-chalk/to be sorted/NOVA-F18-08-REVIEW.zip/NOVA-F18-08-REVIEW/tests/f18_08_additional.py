import json, re
from pathlib import Path
from playwright.sync_api import sync_playwright
QA=Path('/mnt/data/f18_08_qa');C=[]
def ck(name,passed,evidence=''):
 C.append({'name':name,'ok':bool(passed),'evidence':str(evidence)[:400]});
 if not passed:print('FAIL',name,evidence,flush=True)
def go(p,name):p.locator('#F18-08 .nova-tabs button').filter(has_text=name).click();p.wait_for_timeout(60)
def evaluate(p,s):return p.evaluate(s)
with sync_playwright() as b:
 browser=b.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  p=browser.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[];p.on('pageerror',lambda x:errors.append(str(x)))
  p.set_content(Path('/mnt/data/F18-08-compound-measures.html').read_text(),wait_until='domcontentloaded')
  ck(f'{width} inline font embedded',evaluate(p,'document.querySelector("style").textContent.includes("data:font/woff2;base64")'))
  ck(f'{width} standard NOVA motion',evaluate(p,'typeof NOVA.motion.tween')=='function')
  ck(f'{width} NOVA helper skins available',evaluate(p,'!!NOVA.skins && !!NOVA.skins.pip && !!NOVA.skins.nova'))
  go(p,'Guided')
  r=p.locator('#F18-08 input[aria-label="Scrub through steps"]')
  ck(f'{width} guide has six steps',r.get_attribute('max')=='5')
  for step in range(6):
   (p.locator('#F18-08 .nova-tl button[aria-label="Step forward"]').click() if step>0 else None);p.wait_for_timeout(55);stage=p.locator('#F18-08 .nova-stage').inner_text()
   ck(f'{width} guided step {step} visible',('STEP '+str(step+1)+' / 6') in stage)
   if step==0:ck(f'{width} guide masks early answer', 'Work it out' in stage)
   if step==5:ck(f'{width} guide shows answer', '60 km h⁻¹' in stage)
  go(p,'Explore');evaluate(p,'NOVA_F18_08_CONFIG._explore.select("multistep")')
  ck(f'{width} 45 minutes displayed exactly', '45 min' in p.locator('#F18-08 .nova-stage').inner_text())
  ck(f'{width} no rounded 1.166667 default', '1.166667' not in p.locator('#F18-08 .nova-stage').inner_text())
  evaluate(p,'NOVA_F18_08_CONFIG._explore.select("pressure")')
  ck(f'{width} pressure force/area formula',all(x in p.locator('#F18-08 .nova-stage').inner_text().lower() for x in ['force','pressure','area']))
  go(p,'Challenge');qa=p.locator('#F18-08 .nova-stage').inner_text()
  ck(f'{width} Challenge answer private', 'FIND Speed\nWork it out' in qa)
  ck(f'{width} correct amount initially obscured', '60 km h⁻¹' not in qa)
  ck(f'{width} missing units rejected',not evaluate(p,'NOVA_F18_08_CONFIG._challenge.check("60")')[0])
  ck(f'{width} incorrect unit rejected',not evaluate(p,'NOVA_F18_08_CONFIG._challenge.check("60 m/s")')[0])
  ck(f'{width} division order required',not evaluate(p,'(()=>{let c=NOVA_F18_08_CONFIG._challenge;c.place(2,0);c.place(0,1);return c.check("60 km/h");})()')[0])
  ck(f'{width} correct order accepted',evaluate(p,'(()=>{let c=NOVA_F18_08_CONFIG._challenge;c.place(0,0);c.place(2,1);return c.check("60 km/h");})()')[0])
  # Go through the actual button and check that events/state are updated, not just direct helper calls.
  evaluate(p,'NOVA_F18_08_CONFIG._challenge.task(0)');evaluate(p,'NOVA_F18_08_CONFIG._challenge.place(0,0);NOVA_F18_08_CONFIG._challenge.place(2,1)')
  inp=p.locator('#F18-08 input[aria-label="Answer with correct units"]');inp.fill('60 km/h');p.get_by_role('button',name='Check answer').click();p.wait_for_timeout(60)
  ck(f'{width} button gives correct feedback','Correct' in p.locator('#F18-08 .f1808-status').inner_text())
  ck(f'{width} correct event emitted',evaluate(p,'NOVA.events.history().some(e=>e.type==="correct"&&e.detail.engine==="F18-08")'))
  p.screenshot(path=str(QA/f'F18-08_{width}_correct.png'),full_page=True,animations='disabled')
  go(p,'Explore');p.locator('#F18-08 .f1808-chip[data-source="0"]').scroll_into_view_if_needed()
  element=p.locator('#F18-08 .f1808-chip[data-source="0"]');bb=element.bounding_box();src=(bb['x']+bb['width']/2,bb['y']+bb['height']/2)
  p.mouse.move(*src);p.mouse.down();p.mouse.move(src[0]+10,src[1]-20,steps=3)
  p.dispatch_event('#F18-08 .f1808-chip[data-source="0"]','pointercancel',{'pointerId':1,'pointerType':'mouse'})
  p.mouse.up();p.wait_for_timeout(80)
  ck(f'{width} pointercancel recovery',evaluate(p,'NOVA_F18_08_CONFIG._explore.state().slots.every(x=>x===null)'))
  ck(f'{width} pointercancel no detached item',p.locator('#F18-08 .nv-drag-lift').count()==0)
  ck(f'{width} no runtime errors',not errors,errors)
  p.close()
 browser.close()
result={'passed':sum(c['ok'] for c in C),'total':len(C),'failed':[c for c in C if not c['ok']],'checks':C};(QA/'additional-results.json').write_text(json.dumps(result,indent=2));print('ADDITIONAL',result['passed'],'/',result['total'],result['failed'][:8],flush=True)
