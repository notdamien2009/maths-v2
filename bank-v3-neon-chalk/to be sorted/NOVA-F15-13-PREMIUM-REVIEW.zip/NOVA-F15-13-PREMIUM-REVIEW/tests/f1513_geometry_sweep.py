from pathlib import Path
from playwright.sync_api import sync_playwright
import json,math
ROOT=Path('/mnt/data'); QA=ROOT/'F15-13-QA'; qa=[]
def ck(msg,ok,details=None):qa.append({'test':msg,'passed':bool(ok),'details':details}); print(('PASS ' if ok else 'FAIL ')+msg)
source=(ROOT/'NOVA-F15-13-Sine-and-Cosine-Rule.html').read_text()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  pg=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce'); errors=[]; pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(source,wait_until='domcontentloaded');pg.locator('.nova-tabs button').nth(2).click()
  names=list(pg.evaluate('Object.keys(NOVA_F15_13_CONFIG.presets)'))
  for name in names:
   pg.evaluate('(name)=>NOVA_F15_13_CONFIG._explore.select(name)',name)
   t=pg.evaluate('''()=>{const st=NOVA_F15_13_CONFIG._explore.state();const el=document.querySelector('#F15-13 input[aria-label="Change angle A"]');return {min:+el.min,max:+el.max};}''')
   for angle in sorted(set([int(t['min']),int(t['max']),round((int(t['min'])+int(t['max']))/10)*5])):
    if name=='gcse-ambiguous':continue
    pg.evaluate('(a)=>NOVA_F15_13_CONFIG._explore.setVertex("B",a)',angle)
    p=pg.evaluate('NOVA_F15_13_MATH.solve(NOVA_F15_13_CONFIG._explore.state())')
    v=all(math.isfinite(p[k]) and p[k]>0 for k in ['a','b','c','A','B','C']) and abs(p['A']+p['B']+p['C']-180)<1e-6
    ck(f'{width} {name} A={angle} valid triangle',v, None if v else p)
   pg.evaluate('(name)=>NOVA_F15_13_CONFIG._explore.select(name)',name)
   if name=='gcse-ambiguous':
    pg.locator('#F15-13 .f1513-buttons button').first.click()
    q=pg.evaluate('NOVA_F15_13_MATH.solve(NOVA_F15_13_CONFIG._explore.state())')
    ck(f'{width} secondary SSA branch valid',q['C']>0 and abs(q['A']+q['B']+q['C']-180)<1e-7)
  ck(f'{width} no JavaScript errors',not errors,errors[:2]);pg.close()
 b.close()
(QA/'geometry-sweep.json').write_text(json.dumps(qa,indent=2))
print('SWEEP',sum(c['passed'] for c in qa),'/',len(qa))
if not all(c['passed'] for c in qa):raise SystemExit(1)
