from pathlib import Path
from playwright.sync_api import sync_playwright
import json,math,traceback
ROOT=Path('/mnt/data'); QA=ROOT/'F15-13-QA';QA.mkdir(exist_ok=True)
source=(ROOT/'NOVA-F15-13-Sine-and-Cosine-Rule.html').read_text()
checks=[]
def ck(name,ok,detail=''):
 checks.append({'test':name,'passed':bool(ok),'detail':str(detail)});print(('PASS ' if ok else 'FAIL ')+name+('  '+str(detail)[:140] if not ok else ''))
def sp(pg,x,y):return pg.evaluate('''p=>{let m=document.querySelector('#F15-13 .f1513-svg').getScreenCTM();return{x:m.a*p[0]+m.c*p[1]+m.e,y:m.b*p[0]+m.d*p[1]+m.f};}''',[x,y])
def mid(box):return box['x']+box['width']/2,box['y']+box['height']/2
def drag(pg,loc,x,y,steps=1):
 loc.scroll_into_view_if_needed();xx,yy=mid(loc.bounding_box());pg.mouse.move(xx,yy);pg.mouse.down();pg.mouse.move(x,y,steps=steps);pg.mouse.up();pg.wait_for_timeout(420)
def exp(pg):return pg.evaluate('NOVA_F15_13_CONFIG._explore.state()')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'])
 for width in [380,1280]:
  pg=browser.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(source,wait_until='domcontentloaded',timeout=60000)
  pg.locator('.nova-tabs button').nth(2).click()
  ck(f'{width} explore SVG',pg.locator('#F15-13 .nova-stage .f1513-svg').count()==1)
  ck(f'{width} one stage mascot',pg.locator('#F15-13 .nova-stage .nv-dock').count()==1)
  # Actual movement of apex B, A moves from 42° to 60°; SVG maps are stable.
  try:
   pg.locator('[data-vertex="B"]').scroll_into_view_if_needed();st=exp(pg);pp=pg.evaluate('NOVA_F15_13_MATH.solve(NOVA_F15_13_CONFIG._explore.state())')
   k=18.5 if width==380 else 21;x0=112 if width==380 else 145;y0=385 if width==380 else 425
   t=sp(pg,x0+k*pp['c']*math.cos(math.radians(60)),y0-k*pp['c']*math.sin(math.radians(60)))
   drag(pg,pg.locator('[data-vertex="B"]'),t['x'],t['y'],steps=1)
   ck(f'{width} fast mouse drag B 42 to 60',abs(exp(pg)['A']-60)<.001,exp(pg)['A'])
  except Exception as e:ck(f'{width} fast mouse drag B',False,str(e))
  # Actual movement of C to base length 13 with single pointer event.
  try:
   pg.locator('[data-vertex="C"]').scroll_into_view_if_needed();q=sp(pg,x0+k*13,y0);drag(pg,pg.locator('[data-vertex="C"]'),q['x'],q['y'],steps=1)
   ck(f'{width} fast mouse drag C sets b=13',abs(exp(pg)['b']-13)<.001,exp(pg)['b'])
  except Exception as e:ck(f'{width} fast mouse drag C',False,str(e))
  # Mouse invalid drop: stays original and no floating drag.
  try:
   before=exp(pg)['b'];q=sp(pg,x0+60,y0-85);drag(pg,pg.locator('[data-vertex="C"]'),q['x'],q['y'])
   ck(f'{width} C invalid drop springs back',exp(pg)['b']==before)
   ck(f'{width} no stranded drag',pg.evaluate('!NOVA.ui._drag'))
  except Exception as e:ck(f'{width} invalid-drop check',False,str(e))
  # Escape cancellation.
  try:
   before=exp(pg)['A'];loc=pg.locator('[data-vertex="B"]');loc.scroll_into_view_if_needed();mx,my=mid(loc.bounding_box());pg.mouse.move(mx,my);pg.mouse.down();q=sp(pg,x0+k*8*math.cos(math.radians(95)),y0-k*8*math.sin(math.radians(95)));pg.mouse.move(q['x'],q['y'],steps=1);pg.keyboard.press('Escape');pg.mouse.up();pg.wait_for_timeout(240)
   ck(f'{width} Escape recovers vertex B',exp(pg)['A']==before)
  except Exception as e:ck(f'{width} Escape recovery',False,str(e))
  # Keyboard vertex movement.
  try:
   loc=pg.locator('[data-vertex="B"]');loc.focus();before=exp(pg)['A'];pg.keyboard.press('ArrowRight');pg.wait_for_timeout(90)
   ck(f'{width} keyboard B plus 5°',exp(pg)['A']==before+5)
  except Exception as e:ck(f'{width} keyboard B',False,str(e))
  # Re-select first preset to reset all placements.
  pg.evaluate('NOVA_F15_13_CONFIG._explore.select("sine-aas")');pg.wait_for_timeout(120)
  # Actual label drag a onto opposite BC side.
  try:
   loc=pg.locator('[data-label="a"]');pp=pg.evaluate('NOVA_F15_13_MATH.solve(NOVA_F15_13_CONFIG._explore.state())');A=st=exp(pg)['A']
   qB=(x0+k*pp['c']*math.cos(math.radians(A)),y0-k*pp['c']*math.sin(math.radians(A)))
   qC=(x0+k*pp['b'],y0)
   Q=((qB[0]+qC[0])/2,(qB[1]+qC[1])/2)
   # target is outward offset from centroid, reproduce engine sidePt.
   centroid=((x0+qB[0]+qC[0])/3,(y0+qB[1]+qC[1])/3)
   dx,dy=Q[0]-centroid[0],Q[1]-centroid[1];d=math.hypot(dx,dy);q=sp(pg,Q[0]+29*dx/d,Q[1]+29*dy/d)
   drag(pg,loc,q['x'],q['y'],steps=10)
   ck(f'{width} label a actual mouse snap',bool(exp(pg)['placed'].get('a')))
  except Exception as e:ck(f'{width} label a actual mouse',False,str(e))
  # Label remove via tray
  try:
   bx=11 if width==380 else 492;ty=567 if width==380 else 464;bw=124 if width==380 else 105;q=sp(pg,bx+bw/2,ty+15)
   drag(pg,pg.locator('[data-label="a"]'),q['x'],q['y'],steps=9)
   ck(f'{width} label a actual mouse remove',not exp(pg)['placed'].get('a'))
  except Exception as e:ck(f'{width} label a actual mouse remove',False,str(e))
  try:
   loc=pg.locator('[data-label="b"]');loc.focus();pg.keyboard.press('Enter');ck(f'{width} keyboard label place',bool(exp(pg)['placed'].get('b')))
   loc=pg.locator('[data-label="b"]');loc.focus();pg.keyboard.press('Enter');ck(f'{width} keyboard label remove',not exp(pg)['placed'].get('b'))
  except Exception as e:ck(f'{width} keyboard label',False,str(e))
  # All named presets, numerical identity from independent math, under SVG rendering
  for name in ['sine-aas','sine-second','sine-angle','cosine-sas','cosine-sss','cosine-obtuse','cosine-angle','gcse-ambiguous']:
   try:
    pg.evaluate('(name)=>NOVA_F15_13_CONFIG._explore.select(name)',name)
    pp=pg.evaluate('NOVA_F15_13_MATH.solve(NOVA_F15_13_CONFIG._explore.state())')
    ok=pg.locator('.f1513-svg').count()==1 and abs(pp['A']+pp['B']+pp['C']-180)<1e-7 and all(pp[k]>0 for k in ['a','b','c'])
    ck(f'{width} preset {name} triangle',ok)
    ck(f'{width} preset {name} sine identity',abs(pp['a']/math.sin(math.radians(pp['A']))-pp['b']/math.sin(math.radians(pp['B'])))<1e-7)
    ck(f'{width} preset {name} cosine identity',abs(pp['a']**2-(pp['b']**2+pp['c']**2-2*pp['b']*pp['c']*math.cos(math.radians(pp['A']))))<1e-7)
   except Exception as e:ck(f'{width} preset {name}',False,str(e))
  # SSS movable vertex must switch to SAS without freezing its coordinates.
  try:
   pg.evaluate('NOVA_F15_13_CONFIG._explore.select("cosine-sss")')
   before=pg.evaluate('NOVA_F15_13_MATH.solve(NOVA_F15_13_CONFIG._explore.state()).A')
   pg.evaluate('NOVA_F15_13_CONFIG._explore.setVertex("B",70)')
   after=pg.evaluate('NOVA_F15_13_MATH.solve(NOVA_F15_13_CONFIG._explore.state()).A')
   ck(f'{width} SSS moves apex and recalculates',abs(after-70)<1e-5 and abs(after-before)>1)
  except Exception as e:ck(f'{width} SSS moves apex',False,str(e))
  # SSA ambiguous: two valid triangles preserve givens.
  try:
   pg.evaluate('NOVA_F15_13_CONFIG._explore.select("gcse-ambiguous")');q1=pg.evaluate('NOVA_F15_13_MATH.solve(NOVA_F15_13_CONFIG._explore.state())')
   pg.evaluate('document.querySelector("#F15-13 .f1513-buttons button").click()');q2=pg.evaluate('NOVA_F15_13_MATH.solve(NOVA_F15_13_CONFIG._explore.state())')
   ck(f'{width} SSA two distinct B angles',abs(q1['B']+q2['B']-180)<1e-7 and abs(q1['B']-q2['B'])>15)
   ck(f'{width} SSA keeps sides a b and A',all(abs(q1[k]-q2[k])<1e-7 for k in ['a','b','A']))
  except Exception as e:ck(f'{width} SSA 2 solutions',False,str(e))
  # Challenge checks, no mathematical answer leaks in labelled drawing.
  pg.locator('.nova-tabs button').nth(3).click()
  qs=pg.evaluate('NOVA_F15_13_CONFIG._questions.map(x=>({q:x.q,preset:x.preset,find:x.find,dp:x.dp}))')
  ck(f'{width} 12 challenges loaded',len(qs)==12)
  for i,q in enumerate(qs):
   try:
    rv=pg.evaluate('(i)=>NOVA_F15_13_CONFIG._answer(NOVA_F15_13_CONFIG._questions[i])',i)
    ck(f'{width} Q{i+1} finite answer',math.isfinite(rv))
    ok=pg.evaluate('q=>NOVA_F15_13_CONFIG._check(NOVA_F15_13_CONFIG._questions[q.i],q.v)',{'i':i,'v':rv})
    ck(f'{width} Q{i+1} correct accepted',ok[0] is True)
    wrong=pg.evaluate('q=>NOVA_F15_13_CONFIG._check(NOVA_F15_13_CONFIG._questions[q.i],q.v)',{'i':i,'v':rv+31})
    ck(f'{width} Q{i+1} wrong rejected',wrong[0] is False)
   except Exception as e:ck(f'{width} challenge Q{i+1}',False,str(e))
  try:
   inp=pg.locator('#F15-13 .nova-panel input').first;inp.fill(str(pg.evaluate('NOVA_F15_13_CONFIG._answer(NOVA_F15_13_CONFIG._questions[0])')))
   pg.get_by_text('Check',exact=True).last.click(timeout=4500);pg.wait_for_timeout(100)
   body=pg.locator('#F15-13').inner_text();ck(f'{width} actual challenge submit',('Correct' in body or 'correct' in body),body[-140:])
  except Exception as e:ck(f'{width} actual challenge submit',False,str(e))
  ck(f'{width} zero browser errors',not errors,' | '.join(errors))
  pg.close()
 browser.close()
(QA/'stress.json').write_text(json.dumps(checks,indent=2))
print('RESULT',sum(v['passed'] for v in checks),'/',len(checks))
if not all(v['passed'] for v in checks):raise SystemExit(1)
