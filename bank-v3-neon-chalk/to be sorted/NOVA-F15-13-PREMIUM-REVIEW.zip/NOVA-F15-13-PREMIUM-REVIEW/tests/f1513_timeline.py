from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path('/mnt/data');QA=ROOT/'F15-13-QA';(QA/'screenshots').mkdir(exist_ok=True)
source=(ROOT/'NOVA-F15-13-Sine-and-Cosine-Rule.html').read_text();out=[]
def check(msg,ok):out.append({'test':msg,'passed':bool(ok)});print(('PASS' if ok else 'FAIL'),msg)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in [380,1280]:
  pg=b.new_page(viewport={'width':w,'height':900},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(source,wait_until='domcontentloaded');pg.wait_for_timeout(100)
  pause=pg.locator('#F15-13 button[aria-label="Pause"]');
  if pause.count():pause.click()
  slider=pg.locator('#F15-13 input[aria-label="Scrub through steps"]');check(f'{w} timeline scrub',slider.count()==1)
  for i in range(16):
   slider.fill(str(i));slider.dispatch_event('input');pg.wait_for_timeout(38)
   label=pg.locator('#F15-13 .nova-stepname').inner_text()
   check(f'{w} step {i+1:02} index',('Step '+str(i+1)+' of 16') in label)
   check(f'{w} step {i+1:02} SVG',pg.locator('#F15-13 svg.f1513-svg').count()==1)
   if i in [0,3,4,6,8,10,12,14,15]:
    pg.locator('#F15-13 .nova-stage').screenshot(path=str(QA/'screenshots'/f'{w}-watch-state-{i+1:02}.png'))
  slider.fill('0');slider.dispatch_event('input');pg.wait_for_timeout(40)
  pg.locator('#F15-13 button[aria-label="Step forward"]').click();pg.wait_for_timeout(65)
  check(f'{w} step forward',pg.locator('#F15-13 .nova-stepname').inner_text().startswith('Step 2 of 16'))
  pg.locator('#F15-13 button[aria-label="Step back"]').click();pg.wait_for_timeout(65)
  check(f'{w} step rewind',pg.locator('#F15-13 .nova-stepname').inner_text().startswith('Step 1 of 16'))
  check(f'{w} zero errors',not errors)
  # Preset closeups beyond four-mode screen grabs.
  pg.locator('.nova-tabs button').nth(2).click()
  for name in ['sine-angle','cosine-sas','cosine-sss','cosine-obtuse','gcse-ambiguous']:
   pg.evaluate('(v)=>NOVA_F15_13_CONFIG._explore.select(v)',name)
   pg.locator('#F15-13 .nova-stage').screenshot(path=str(QA/'screenshots'/f'{w}-{name}-explore.png'))
   check(f'{w} {name} one SVG',pg.locator('#F15-13 svg.f1513-svg').count()==1)
  pg.close()
 b.close()
(QA/'timeline.json').write_text(json.dumps(out,indent=2))
print('TIMELINE',sum(x['passed'] for x in out),'/',len(out))
if not all(x['passed'] for x in out):raise SystemExit(1)
