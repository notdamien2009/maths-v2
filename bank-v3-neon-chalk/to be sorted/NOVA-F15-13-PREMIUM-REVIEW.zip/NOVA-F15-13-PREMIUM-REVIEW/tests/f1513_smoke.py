from pathlib import Path
from playwright.sync_api import sync_playwright
import json
s=Path('/mnt/data/NOVA-F15-13-Sine-and-Cosine-Rule.html').read_text()
shot=Path('/mnt/data/F15-13-QA/screenshots');shot.mkdir(parents=True,exist_ok=True)
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path="/usr/bin/chromium",args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'])
 for width in [380,1280]:
  page=browser.new_page(viewport={'width':width,'height':900},reduced_motion='reduce',device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(s,wait_until='load',timeout=60000)
  page.wait_for_timeout(400)
  print('WIDTH',width,'errors',errors,'page',page.title(),'tabs',page.locator('.nova-tabs button').all_text_contents()[:7], 'stages',page.locator('.nova-stage').count())
  results.append([width,'initial',errors])
  for mode in ['WATCH','GUIDED','EXPLORE','CHALLENGE']:
   btn=page.locator('.nova-tabs button').filter(has_text=mode.title())
   if btn.count(): btn.first.click()
   else:
    buttons=page.locator('.nova-tabs button').all_text_contents()
    print('no mode',mode,buttons)
    continue
   page.wait_for_timeout(300)
   page.locator('#F15-13 .nova-stage').screenshot(path=str(shot/f'{width}-{mode.lower()}.png'))
   print(mode,'SVGS',page.locator('#F15-13 .nova-stage .f1513-svg').count(),'err',errors[-1:] if errors else '', 'stageHeight',page.locator('#F15-13 .nova-stage').bounding_box())
   results.append([width,mode,len(errors),page.locator('#F15-13 .nova-stage .f1513-svg').count()])
  page.close()
 browser.close()
Path('/mnt/data/F15-13-QA/smoke.json').write_text(json.dumps(results,indent=2))
