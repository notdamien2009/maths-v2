# NOVA F15-13 — Premium Review QA Report

**Status:** complete for owner review. **Not GOLD approved.** No GitHub writes.

## Scope and source integrity
- File: `NOVA-F15-13-Sine-and-Cosine-Rule.html` (standalone inline HTML; no third-party runtime dependencies).
- Mathematical focus: non-right triangles, sine rule and cosine rule, SAS/SSS, angle-solving and two valid SSA solutions.
- Core: embedded JavaScript extracted from prior F15-12 file is byte-for-byte identical, SHA-256 `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc`. No changes to the NOVA shared core.
- Master spec: `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, F15-13.
- Named presets: eight (Y9 extension/GCSE-ready); 12 Challenge tasks.

## Executed browser tests
| Evidence file | Checks | Result |
| --- | ---: | --- |
| `tests/stress.json` and `tests/stress-output.log` | 156 | 156 passes, 0 failures |
| `tests/timeline.json` and `tests/timeline-output.log` | 82 | 82 passes, 0 failures |
| `tests/geometry-sweep.json` and `tests/geometry-sweep.log` | 46 | 46 passes, 0 failures |
| **Total** | **284** | **284 passes, 0 failures** |

Browser: installed Chromium through Playwright; responsive widths 380px and 1280px; real mouse input (not just keyboard simulation). Smoke mode checks logged in `tests/smoke-output.log`.

## Contract-by-contract evidence

1. **Original design/core:** HTML first `<script>` matches F15-12 core byte-for-byte. Same core navy stage, neon drawing helpers and chalk style. Screenshots `380-explore.png`, `1280-explore.png`.
2. **Stage/mobile:** Mobile SVG viewport is cropped to the content (`viewBox 0 120 430 468`) without changing drawing coordinates; actual mouse tests rerun following change. Lines 1911–1913, screenshots `380-watch.png`, `380-explore.png`.
3. **Precise geometry:** Lines 1834–1844 solve triangles using sine/cosine rules, with independent sine-rule and cosine-rule identities checked in `tests/stress.json`. Mobile bound and positive-angle sweep in `geometry-sweep.json`.
4. **Stacked fractions:** The sine-rule ratio cards use NOVA neon-lined horizontal fraction bars with numerator over denominator, line 1879 ff; screenshot `380-explore.png`. No raw fraction as principal diagram equation.
5. **Watch teaching:** 16 named learning steps, narration slots, proper rule transitions, scrub and next/back verified in `tests/timeline.json` (lines 1846 ff). Screenshots `380-watch-state-07.png` and `1280-watch-state-13.png`.
6. **Guided reasoning:** Full guided mode renders on both widths with no script errors, screenshots `380-guided.png`, `1280-guided.png`.
7. **Explore controls:** Vertex B rotates on constrained locus; C slides along the baseline; 3 draggable side labels snap to correct opposite sides. The shared `NOVA.ui.svgDrag` is used unchanged (lines 1928–1954). Real 1-step fast mouse motion, regrab/remove, invalid-drop, Escape and keyboard verified in `tests/stress.json`.
8. **Valid domain:** The fixed-opposite-angle sine-rule presets clamp the adjustable angle so the third interior angle remains positive. See `validMaxA` at ~1819, `setVertex` near 1985 and `tests/geometry-sweep.json` (46 passed).
9. **Assessment:** 12 Challenge tasks with correct/incorrect answer verification and a real UI Check submission, screenshots `380-challenge.png` and `1280-challenge.png`, task checker at lines 1993–2027. Hidden unknowns prevent answer leaks.
10. **SSA ambiguity:** The two valid solutions are separately displayed and preserve all three givens, checked at both viewports; screenshot `1280-gcse-ambiguous-explore.png`.
11. **Mascot:** Only one in-stage NOVA helper artwork. The twin external portrait is hidden using page-local CSS without removing narration. Test `one stage mascot` at each width in `tests/stress.json`.
12. **Accessibility:** SVG control labels, focusable labels/vertices, keyboard alternatives; correct answer and feedback live-region support. Print rule and motion preference respected in page-local styling and NOVA core; accessibility spot checks, not a formal WCAG audit.
13. **No errors:** Smoke and stress browser logs recorded no page errors at either width in all four modes.

## Review caveat
This is a tested review build, not a user-approved GOLD master. The automated tests and screenshot inspection do not replace final user stress testing on a physical touchscreen or teaching review in lesson context.
