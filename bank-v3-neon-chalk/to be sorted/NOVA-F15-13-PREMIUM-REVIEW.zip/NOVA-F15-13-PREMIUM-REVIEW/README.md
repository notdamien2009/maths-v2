# NOVA F15-13 · Sine and Cosine Rule

Single-engine review pack. Open `NOVA-F15-13-Sine-and-Cosine-Rule.html` directly in Chrome/Edge/Firefox.

The HTML is self-contained, uses the exact shared NOVA core found in F15-12, and has WATCH / GUIDED / EXPLORE / CHALLENGE.

- 16 watch states, 8 presets, 12 challenge tasks.
- Sine rule, cosine rule, SAS, SSS, angle calculation, obtuse cases and ambiguous SSA.
- Drag vertex B or C, or match side labels with opposite angles in Explore. Keyboard controls included.
- The QA report and the tests document what was actually exercised; **284/284 passing checks**.
- Owner review required. **NOT GOLD-approved**. GitHub unchanged.
