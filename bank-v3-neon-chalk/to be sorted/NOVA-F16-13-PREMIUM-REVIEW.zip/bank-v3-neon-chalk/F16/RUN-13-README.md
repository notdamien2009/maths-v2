# F16-13 Premium Review · Box Plot and Cumulative Frequency

Open `F16/F16-13-box-plot-and-cumulative-frequency.html` directly in a modern browser. No server, internet connection, dependencies or CDN are needed.

To rebuild from source at the project root: `python3 build/build-f16-13.py`. The builder reads **only** the pinned baseline files in `tests/` and component-specific `src/F16-13.js` and `src/F16-13.css`, refuses core hash drift, and produces the standalone HTML under `F16/`.

Review modes at 380px and desktop and try the Y9 grouped, outlier and back-to-back comparison presets. Try real fast dragging, Escape, keyboard arrow controls and the red removal zone. The ZIP is review-only: none of its files was written to GitHub. No GOLD approval is asserted.
