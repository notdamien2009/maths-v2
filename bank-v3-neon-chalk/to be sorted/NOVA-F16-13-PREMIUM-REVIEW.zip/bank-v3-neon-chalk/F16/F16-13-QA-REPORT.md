# F16-13 · Box Plot and Cumulative Frequency — Premium Review

**Status:** Built for owner review; not GOLD-approved. GitHub has not been modified.

## Component specification

- Maths purpose: cumulative-frequency representations linked to the five-number summary and box-and-whisker plot. The lower and upper quartiles identify the middle 50%; IQR = Q3 − Q1.
- Data convention: exact individual-data quartiles are **medians of the lower and upper halves**. Even sample sizes in the production presets avoid ambiguous central cases. The grouped preset uses **linear interpolation within each class** and labels its results as estimates.
- Lesson presets: Y8-069 Compare spread, Y9-047 Grouped representations, Y9-048 Outliers, Y9-049 Evidence-based distribution comparisons.
- Watch: ten step-linked scenes; Guided: core scaffolded timeline and prompts; Explore: draggable and keyboard-adjustable observations, group frequencies and quartile handles; Challenge: move Q1, calculate IQR, find median.
- GCSE extension: grouped ogives, quartile interpolation, evidence-based comparison, outlier impact.
- Linked: F0-02, F0-04, F16-06, F16-08 and F16-09.

## Verification results — independently run against the final standalone

| Acceptance item | Evidence | Outcome |
|---|---|---|
| Original shared NOVA core used unchanged | `tests/pinned-core.js` and `.css` checked by builder SHA-256, against core snapshots used in preceding F16 builds. Embedded files are in the HTML via unchanged `@@JS@@` / `@@CSS@@` placeholders. | Verified against pinned F16 reference |
| Repeatable offline file | `build/build-f16-13.py` SHA-256 output `0bdff36648cd6865f81d50dc3f8ec00f0fc119be11a854777ea432a010d62a68` matches delivered HTML | Pass |
| Mathematical quartiles and cumulative monotonicity | `tests/STRESS-380-RESULTS.json`, `tests/STRESS-1280-RESULTS.json`; 4 presets at 2 widths, exact median-of-halves and grouped Q1=17.5, median=25, Q3=32.5 | 98/98 browser/maths checks passed in combined suite |
| Actual native pointer use | `tests/NATIVE-DRAG-RESULTS.json`; quartile handle moves and re-grabs, invalid drop, group token transfer, Escape, red remove, page errors, both widths | 14/14 passing |
| Four modes and original mascot dock | `tests/STRESS-{380,1280}-RESULTS.json` check stage fill >=60%, one `.nv-dock` and no page overflow in all four modes; 14 final screenshots | Pass |
| Drag re-grabbing and cancellation | `tests/NATIVE-DRAG-RESULTS.json`, plus observation drag in both width suites | Pass |
| Challenge answer checking | `tests/STRESS-{380,1280}-RESULTS.json` tasks 1–3 completed on each of 4 presets, at both widths, including grouped estimate tolerance | Pass |
| No page exceptions | Both 49-check suites and the 14-check pointer suite collect page errors at both widths | Zero errors reported |
| Printed page fallback | Shared core stylesheet retained | Not independently printed |
| Real touch hardware | Emulated pointer/mouse checks only | Owner device test outstanding |
| Gold approval | Requires owner to compare visually and interact with the component | Not granted |
| Latest GitHub core comparison | Current private GitHub core is large; comparison here is to the pinned source from F16-12, not freshly retrieved GitHub bytes | Outstanding |

### Visual evidence

`shots/` includes 14 final screenshots: 380px and 1280px for the four Explore lesson presets (8) plus final Watch, Guided and Challenge screens at both widths (6). The SVG fills 69–85% of the stage in the recorded Explore configurations; one dock per stage and no horizontal document overflow.

### Known limits and design choices

- A pupil can freely adjust the demonstration quartile handles without changing the source data; calculated source quartiles remain separate from those candidate marker positions. Moving an observation or class frequency recalculates both the cumulative curve and source box plot.
- The grouped cumulative-frequency graph is a piecewise-linear ogive through cumulative class boundaries. Quartile estimates are not exact observations.
- The other group is displayed as a second comparative box plot, while the active group determines the cumulative graph. The Explore dataset selector switches groups.
- The interaction rig is built around the canonical F2 `NOVA.ui.svgDrag` and original NOVA SVG/text helpers. No additional global drawing kit or replacement mascot was introduced.
