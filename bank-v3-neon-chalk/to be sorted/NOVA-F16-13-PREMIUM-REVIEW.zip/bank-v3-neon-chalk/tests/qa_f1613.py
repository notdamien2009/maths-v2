from playwright.sync_api import sync_playwright
from pathlib import Path
import json, traceback
ROOT=Path(__file__).resolve().parents[1]
uri=(ROOT/'F16/F16-13-box-plot-and-cumulative-frequency.html').as_uri()
results=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content((ROOT/'F16/F16-13-box-plot-and-cumulative-frequency.html').read_text(),wait_until='domcontentloaded',timeout=60000);page.wait_for_timeout(700)
  print('SIZE',width,'tabs',page.locator('button').all_text_contents()[:20],'errors',errors)
  page.screenshot(path=str(ROOT/'shots'/f'F16-13-{width}-watch-initial.png'),full_page=True)
  for mode in ['Watch','Guided','Explore','Challenge']:
   try:
    candidate=page.get_by_role('tab',name=mode,exact=True)
    print('candidate',mode,candidate.count());candidate.first.click(timeout=3500)
    page.wait_for_timeout(300)
    print('MODE',mode,'svg',page.locator('svg.f1613-svg').count(),'dock',page.locator('.nv-dock').count(),'errors',errors[-1:])
    if mode=='Explore':page.screenshot(path=str(ROOT/'shots'/f'F16-13-{width}-explore.png'),full_page=True)
    elif mode=='Challenge':page.screenshot(path=str(ROOT/'shots'/f'F16-13-{width}-challenge.png'),full_page=True)
    results.append({'width':width,'mode':mode,'errors':list(errors),'svg':page.locator('svg.f1613-svg').count(),'dock':page.locator('.nv-dock').count(),'overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth')})
   except Exception as e:print('ERR',mode,str(e)[:500]);results.append({'width':width,'mode':mode,'error':str(e)[:1000]})
  page.close()
 browser.close()
(ROOT/'tests/SMOKE-RESULTS.json').write_text(json.dumps(results,indent=2))
