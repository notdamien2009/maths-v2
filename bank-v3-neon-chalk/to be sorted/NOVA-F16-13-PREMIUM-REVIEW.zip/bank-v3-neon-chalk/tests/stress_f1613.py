from pathlib import Path
import sys
from playwright.sync_api import sync_playwright
from statistics import median
from math import isclose
import json
R=Path(__file__).resolve().parents[1]; HTML=(R/'F16/F16-13-box-plot-and-cumulative-frequency.html').read_text(); results=[]
def chk(label,ok,detail=None):
 v={'check':label,'pass':bool(ok)}
 if not ok:v['detail']=detail
 results.append(v);print(('PASS ' if ok else 'FAIL ')+label,flush=True)
def expected(s):
 a=sorted(s); n=len(a);k=n//2
 return [a[0],median(a[:k]),median(a),median(a[n-k:]),a[-1]]
def state(pg):return pg.evaluate('NOVA_F16_13_CONFIG._explore.get()')
def screen(pg,x,y):return pg.locator('.f1613-svg').evaluate('''(e,p)=>{let q=e.createSVGPoint();q.x=p[0];q.y=p[1];let a=q.matrixTransform(e.getScreenCTM());return {x:a.x,y:a.y}}''',[x,y])
def native_drag(pg,loc,x,y,scroll=True):
 if scroll:loc.scroll_into_view_if_needed(timeout=7000)
 bb=loc.bounding_box();assert bb, 'no bounding box'
 goal=screen(pg,x,y)
 pg.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);pg.mouse.down();pg.mouse.move(goal['x'],goal['y'],steps=1);pg.wait_for_timeout(100);pg.mouse.up();pg.wait_for_timeout(460)
with sync_playwright() as py:
 b=py.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in ([int(sys.argv[1])] if len(sys.argv)>1 else [380,1280]):
  pg=b.new_page(viewport={'width':w,'height':900},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(HTML,wait_until='domcontentloaded',timeout=60000)
  for mode in ['Watch','Guided','Explore','Challenge']:
   pg.get_by_role('tab',name=mode,exact=True).click();pg.wait_for_timeout(90)
   m=pg.evaluate('''()=>{let s=document.querySelector('.nova-stage')?.getBoundingClientRect(),a=document.querySelector('.f1613-svg')?.getBoundingClientRect();return {ratio:a?.height/s?.height,dock:document.querySelectorAll('.nova-stage .nv-dock').length,overflow:document.documentElement.scrollWidth>innerWidth}}''');chk(f'{w} {mode} responsive',m['ratio']>=.6 and m['dock']==1 and not m['overflow'],m)
   if False:pass
  pg.get_by_role('tab',name='Explore',exact=True).click()
  for key in ['y8-compare','y9-grouped','y9-outlier','y9-compare']:
   pg.locator('.f1613-form select').first.select_option(key);pg.wait_for_timeout(130)
   s=state(pg)
   q=s['five']
   chk(f'{w} {key} five ordered',len(q)==5 and all(q[i]<=q[i+1] for i in range(4)),q)
   chk(f'{w} {key} monotonic cumulative',all(s['cum'][i][1]<=s['cum'][i+1][1] for i in range(len(s['cum'])-1)),s['cum'])
   chk(f'{w} {key} sample count',s['cum'][-1][1]==(sum(s['data']) if s['grouped'] else len(s['data'])),s)
   if key=='y9-grouped':chk(f'{w} y9 grouped 17.5 25 32.5',[round(x,2) for x in q]==[0,17.5,25,32.5,50],q)
   if not s['grouped']:chk(f'{w} {key} exact quartiles',q==expected(s['data']),q)
   if key=='y9-outlier':
    before=s['five'];a=pg.locator('[data-point="0"]').first;a.focus();pg.keyboard.press('ArrowRight');pg.wait_for_timeout(110);after=state(pg)
    chk(f'{w} outlier observation keyboard update',after['data'][0]==s['data'][0]+1 and after['five']==expected(after['data']),after)
    pg.get_by_role('button',name='Reset',exact=True).click();pg.wait_for_timeout(90)
    # Drag value 6 to value 8 using the actual pointer and native NOVA svgDrag
    l=pg.evaluate('''()=>{const el=document.querySelector('.f1613-svg'),p=NOVA_F16_13_CONFIG.presets[NOVA_F16_13_CONFIG.preset],m=innerWidth<=540;return {W:m?450:800,x0:m?74:114,x1:m?404:731,H:m?1260:1200}}''')
    native_drag(pg,pg.locator('[data-point="0"]').first,l['x0']+8*(l['x1']-l['x0'])/30,l['H']-(103 if w==380 else 76)-20)
    aft=state(pg);chk(f'{w} native point drag 6 to 8',aft['data'][0]==8,aft['data'])
    pg.get_by_role('button',name='Reset',exact=True).click();pg.wait_for_timeout(90)
    loc=pg.locator('[data-point="0"]').first;loc.scroll_into_view_if_needed();bb=loc.bounding_box();pg.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);pg.mouse.down();pg.mouse.move(bb['x']+34,bb['y']-8,steps=1);pg.keyboard.press('Escape');pg.mouse.up();pg.wait_for_timeout(520)
    chk(f'{w} ESC cancels without stranding',state(pg)['data']==s['data'] and pg.evaluate('!NOVA.ui._drag'))
   if key=='y9-grouped':
    before=state(pg);freq=before['data'];pg.locator('[data-token="0"]').focus();pg.keyboard.press('ArrowRight');pg.wait_for_timeout(150)
    after=state(pg);chk(f'{w} grouped keyboard frequency transfer',after['data'][0]==freq[0]-1 and after['data'][1]==freq[1]+1 and sum(after['data'])==sum(freq),after)
    pg.get_by_role('button',name='Reset',exact=True).click()
   if key=='y8-compare':
    pg.locator('[data-handle="1"]').first.focus();before=state(pg)['pins'][1];pg.keyboard.press('ArrowRight');pg.wait_for_timeout(90);after=state(pg)['pins'][1]
    chk(f'{w} re-position Q1 keyboard',after==before+.5,(before,after))
    pg.get_by_role('button',name='Reset',exact=True).click()
   if False:pass
  # Challenge for each preset. Selected preset persists when switching mode.
  for key in ['y8-compare','y9-grouped','y9-outlier','y9-compare']:
   pg.get_by_role('tab',name='Explore',exact=True).click();pg.locator('.f1613-form select').first.select_option(key);pg.get_by_role('tab',name='Challenge',exact=True).click();pg.wait_for_timeout(110)
   c=pg.evaluate('NOVA_F16_13_CONFIG._challengeState()')
   chk(f'{w} {key} Q1 deliberately wrong',c['pins'][1]!=c['correct'][1],c)
   target=c['correct'][1];got=c['pins'][1];direction='ArrowLeft' if got>target else 'ArrowRight';n=int(round(abs(got-target)/.5))
   for i in range(n):pg.locator('[data-handle="1"]').first.focus();pg.keyboard.press(direction);pg.wait_for_timeout(55)
   chk(f'{w} {key} Q1 restored keyboard',abs(pg.evaluate('NOVA_F16_13_CONFIG._challengeState().pins[1]')-target)<1e-8)
   pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(900)
   chk(f'{w} {key} challenge 1 accepted',pg.evaluate('NOVA_F16_13_CONFIG._challenge.task()')==1)
   for task,val in [(1,c['iqr']),(2,c['median'])]:
    input_=pg.locator('.nova-panel input[type="text"], .nova-panel input[type="number"]').last
    if input_.count()==0:input_=pg.locator('input').last
    input_.fill(str(val));pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(1000)
    chk(f'{w} {key} challenge {task+1}',pg.evaluate('NOVA_F16_13_CONFIG._challenge.task()')==min(2,task+1) or pg.locator('.nova-panel').get_by_text('Correct',exact=False).count()>0)
   chk(f'{w} {key} no browser errors',not errors,errors)
  pg.close()
 b.close()
R.joinpath(f'tests/STRESS-{sys.argv[1] if len(sys.argv)>1 else "ALL"}-RESULTS.json').write_text(json.dumps({'checks':len(results),'passed':sum(x['pass'] for x in results),'failed':[x for x in results if not x['pass']],'results':results},indent=2))
print('TOTAL',sum(x['pass'] for x in results),'/',len(results))
raise SystemExit(0 if all(x['pass'] for x in results) else 1)
