from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1]
html=(R/'F16/F16-13-box-plot-and-cumulative-frequency.html').read_text()
out=[]
def chk(name,ok,more=None):
 out.append({'check':name,'pass':bool(ok),'detail':more if not ok else None});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
def drag(page,loc,x,y):
 loc.scroll_into_view_if_needed(); bb=loc.bounding_box(); assert bb
 pt=page.locator('.f1613-svg').evaluate('''(e,p)=>{let q=e.createSVGPoint();q.x=p[0];q.y=p[1];let a=q.matrixTransform(e.getScreenCTM());return {x:a.x,y:a.y}}''',[x,y]);page.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);page.mouse.down();page.mouse.move(pt['x'],pt['y'],steps=1);page.wait_for_timeout(150);page.mouse.up();page.wait_for_timeout(540)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in [380,1280]:
  pg=b.new_page(viewport={'width':w,'height':900},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda x:errors.append(str(x)));pg.set_content(html);pg.get_by_role('tab',name='Explore').click();pg.wait_for_timeout(90)
  # initial exact Q1 = 5.5; move to 6 with a real pointer, then drag back
  l={'x0':74 if w==380 else 114,'x1':404 if w==380 else 731,'boxY':827 if w==380 else 812,'scale':20}
  x=lambda v:l['x0']+v*(l['x1']-l['x0'])/l['scale']
  drag(pg,pg.locator('[data-handle="1"]').first,x(6),l['boxY']-62)
  chk(f'{w} quartile handle real mouse drag',pg.evaluate('NOVA_F16_13_CONFIG._explore.get().pins[1]')==6,pg.evaluate('NOVA_F16_13_CONFIG._explore.get().pins'))
  drag(pg,pg.locator('[data-handle="1"]').first,x(5.5),l['boxY']-62)
  chk(f'{w} quartile handle re-grab',pg.evaluate('NOVA_F16_13_CONFIG._explore.get().pins[1]')==5.5)
  # invalid drop outside stage zones must return home
  loc=pg.locator('[data-handle="1"]').first;loc.scroll_into_view_if_needed();bb=loc.bounding_box();pg.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);pg.mouse.down();pg.mouse.move(bb['x']+70,bb['y']-90,steps=2);pg.mouse.up();pg.wait_for_timeout(500)
  chk(f'{w} quartile invalid drop safe',pg.evaluate('NOVA_F16_13_CONFIG._explore.get().pins[1]')==5.5 and pg.evaluate('!NOVA.ui._drag'))
  # grouped dataset counter 0 -> 1
  pg.locator('.f1613-form select').first.select_option('y9-grouped');pg.wait_for_timeout(120)
  H=1280 if w==380 else 1200;start=74 if w==380 else 114;wide=(330 if w==380 else 617)/5;sy=H-155
  drag(pg,pg.locator('[data-token="0"]').first,start+wide*1.5,sy-12)
  f=pg.evaluate('NOVA_F16_13_CONFIG._explore.get().data');chk(f'{w} grouped frequency native transfer',f==[1,7,10,6,2],f)
  # after moving it, pointercancel/Escape return without altering counts
  loc=pg.locator('[data-token="1"]').first;loc.scroll_into_view_if_needed();bb=loc.bounding_box();pg.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);pg.mouse.down();pg.mouse.move(bb['x']+36,bb['y']-10,steps=2);pg.keyboard.press('Escape');pg.mouse.up();pg.wait_for_timeout(450)
  chk(f'{w} escape cancels grouped card',pg.evaluate('NOVA_F16_13_CONFIG._explore.get().data')==f and pg.evaluate('!NOVA.ui._drag'))
  # removal into red zone
  g={'x':312 if w==380 else 647,'w':115 if w==380 else 123,'y':1215 if w==380 else 1135,'h':53 if w==380 else 51}
  drag(pg,pg.locator('[data-token="1"]').first,g['x']+g['w']/2,g['y']+g['h']/2)
  d=pg.evaluate('NOVA_F16_13_CONFIG._explore.get().data');chk(f'{w} red-zone remove',sum(d)==sum(f)-1,d)
  chk(f'{w} no page errors',not errors,errors)
  pg.close()
 b.close()
(R/'tests/NATIVE-DRAG-RESULTS.json').write_text(json.dumps({'checks':len(out),'passed':sum(i['pass'] for i in out),'results':out},indent=2))
print('TOTAL',sum(i['pass'] for i in out),'/',len(out))
raise SystemExit(0 if all(i['pass'] for i in out) else 1)
