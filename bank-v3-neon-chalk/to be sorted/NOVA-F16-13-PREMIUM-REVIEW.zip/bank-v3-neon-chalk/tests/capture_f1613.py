from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];h=(R/'F16/F16-13-box-plot-and-cumulative-frequency.html').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in (380,1280):
  pg=b.new_page(viewport={'width':w,'height':900},reduced_motion='reduce');pg.set_content(h)
  for m in ['Watch','Guided','Challenge']:
   pg.get_by_role('tab',name=m,exact=True).click();pg.wait_for_timeout(110)
   pg.screenshot(path=str(R/'shots'/f'F16-13-{w}-{m.lower()}-final.png'),full_page=True,timeout=20000)
  pg.close()
 b.close()
