# NOVA Maths V2 · F16-06 Dot Plot and Averages — PREMIUM REVIEW

**Status:** built, browser QA completed, awaiting owner visual/touch sign-off. NOT GOLD.
**GitHub:** READ-ONLY, no commits, pushes, or uploads.

## What is included
- `F16/F16-06-dot-plot-and-averages.html` — standalone self-contained HTML (embedded NOVA core CSS, JS, Chalk fonts and mascot art; no network needed).
- `src/F16-06.js`, `src/F16-06.css` — additive component implementation (no edits to original shared core).
- `build/F16-06.src.html`, `build/build-f16-06.py` — reproducible local build. Requires **the exact F2-03 source already in the user's maths-v2 checkout** at `bank-v3-neon-chalk/F2/F2-03-base-ten-blocks.html`. The builder refuses a core SHA mismatch and never writes GitHub.
- `tests/` — real native Chromium input and formula regressions, deterministic results and logs.
- `shots/F16-06/` — 22 actual mobile/desktop screenshots, Watch stages, Guided, Explore, Challenge, four special lesson presets.

## Six named curriculum presets
Y7-068 · Read a dot plot; Y7-069 · Mean/median/mode/range; Y7-070 · Comparing distributions; Y8-069 · Averages and spread; Y9-048 · Outliers and averages; Y9-049 · Evidence-based comparisons.

## Maths principles
Each dot = one observation. Repetitions form vertical stacks. Core NOVA number lines provide identical scale spacing from zero to twelve; dot positions are exact. Mean, median, all modes and range are computed from the current observations, not from visual assumptions. Multiple equally frequent modes are displayed explicitly. The mean marker has exact fractional position on the scale. Challenge validates the complete frequency multiset rather than just the sample count.

## How to rebuild locally
From the extracted project folder, run `python build/build-f16-06.py` after placing it next to the existing F2 baseline. The builder reads only the F2 core from that baseline and the new component sources, then writes F16-06 only. SHA of the reviewed standalone: `436526f41be32961aab3f5c7282b9f7778a997cef22035a441ecdde84ea77f0e`. Do not update shared core, F0/F2 files or GitHub as part of this review.

## Acceptance status
Browser QA is not a substitute for a physical touchscreen test or owner final visual sign-off. The checked core is the F2/F14-family shared runtime embedded in previous approved-style standalone files, pinned to the SHA values below. A fresh byte-for-byte comparison against GitHub's current separate core files has not been established.

JS core SHA-256: `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc`
CSS core SHA-256: `d96c7240025e60b209915f027963aaa3914da30e4e60856f6a90b66c680ebba2`
