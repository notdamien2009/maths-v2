from playwright.sync_api import sync_playwright
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[1];ht=(R/'F16/F16-06-dot-plot-and-averages.html').read_text();records=[]
def chk(s,p):records.append({'name':s,'passed':bool(p)});print(('PASS' if p else 'FAIL'),s,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in (380,1280):
  p=b.new_page(viewport={'width':width,'height':940},reduced_motion='reduce');p.set_content(ht);p.locator('.nova-tab[data-m="challenge"]').click();p.wait_for_timeout(150)
  d=p.locator('[data-missing]');chk(f'{width} missing card exists',d.count()==1)
  def drag(x,y,steps=10):
   p.locator('.f16d-plot').scroll_into_view_if_needed();r=p.locator('[data-missing]').bounding_box()
   a=p.evaluate('''v=>{let s=document.querySelector('.f16d-plot'),p=s.createSVGPoint();p.x=v[0];p.y=v[1];let q=p.matrixTransform(s.getScreenCTM());return{x:q.x,y:q.y}}''',[x,y]);p.mouse.move(r['x']+r['width']/2,r['y']+r['height']/2);p.mouse.down();p.mouse.move(a['x'],a['y'],steps=steps);p.mouse.up();p.wait_for_timeout(160)
  a=43 if width==380 else 95;ww=364 if width==380 else 580;baseline=430 if width==380 else 385
  drag(a+2/12*ww,baseline-60)
  chk(f'{width} wrong position is rejected',p.locator('[data-missing]').count()==1)
  chk(f'{width} rejected position retains 11 observations',len(p.evaluate('NOVA_F16_06_CONFIG._challengeState().values'))==11)
  drag(a+8/12*ww,baseline-65,steps=1)
  chk(f'{width} fast native drag restores missing 8',p.locator('[data-missing]').count()==0)
  chk(f'{width} correct value and count recovered',len(p.evaluate('NOVA_F16_06_CONFIG._challengeState().values'))==12)
  chk(f'{width} no stranded pointer',p.evaluate('NOVA.ui._drag===null'))
  p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(130)
  chk(f'{width} pointer solution marks task correct',p.locator('.nova-fb.ok').count()>0)
  p.close()
 b.close()
(R/'tests/CHALLENGE-DRAG-RESULTS.json').write_text(json.dumps({'passed':sum(x['passed'] for x in records),'total':len(records),'checks':records},indent=2))
print('CHALLENGE DRAG',sum(x['passed'] for x in records),'/',len(records))
if not all(x['passed'] for x in records):sys.exit(1)
