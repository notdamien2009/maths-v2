from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1];ht=(R/'F16/F16-06-dot-plot-and-averages.html').read_text()
records=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for w in (380,1280):
  p=b.new_page(viewport={'width':w,'height':960},reduced_motion='reduce');errs=[];p.on('pageerror',lambda e:errs.append(str(e)));p.set_content(ht,wait_until='load');p.wait_for_timeout(120)
  for mode in ['watch','guided','explore','challenge']:
   if mode=='challenge':p.evaluate("NOVA_F16_06_CONFIG.preset='y7-stems'")
   p.locator(f'.nova-tab[data-m="{mode}"]').click();p.wait_for_timeout(180)
   if mode=='watch':
    for i,tag in [(0,'start'),(4,'all-dots'),(9,'complete')]:
     p.evaluate('i=>{F16_06.timeline.pause();F16_06.timeline.go(i,"test")}',i);p.wait_for_timeout(140)
     fn=f'F16-06-{w}-watch-{tag}.png';p.locator('.nova-stage').screenshot(path=str(R/'shots'/fn));records.append(fn)
   else:
    fn=f'F16-06-{w}-{mode}.png';p.locator('.nova-stage').screenshot(path=str(R/'shots'/fn));records.append(fn)
   if mode=='explore':
    for preset in ['y7-compare','y8-compare','y9-outliers','y9-compare']:
     p.locator('select[aria-label="Lesson preset"]').select_option(preset);p.wait_for_timeout(140)
     fn=f'F16-06-{w}-{preset}.png';p.locator('.nova-stage').screenshot(path=str(R/'shots'/fn));records.append(fn)
     stage=p.locator('.nova-stage');bounding=stage.bounding_box();sv=p.locator('.f16d-plot').bounding_box()
     print(w,preset,{'stageH':bounding['height'],'svgH':sv['height'],'ratio':round(sv['height']/bounding['height'],3)},flush=True)
   if mode=='challenge':
    p.get_by_role('button',name='Restore observation 8').click();p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(850)
    fn=f'F16-06-{w}-challenge-median.png';p.locator('.nova-stage').screenshot(path=str(R/'shots'/fn));records.append(fn)
  print(w,'errors',errs,'scrollX',p.evaluate('document.documentElement.scrollWidth-innerWidth'),flush=True)
  p.close()
 b.close()
(R/'tests/VISUAL-RESULTS.json').write_text(json.dumps({'screenshots':records,'total':len(records)},indent=2))
