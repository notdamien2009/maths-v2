#!/usr/bin/env python3
"""Real Chromium input and maths tests for F16-06. No pre-recorded PASS claims."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, math, sys
R=Path(__file__).resolve().parents[1]
HTML=(R/'F16/F16-06-dot-plot-and-averages.html').read_text(encoding='utf8')
checks=[]
def check(name,passed,details=None):
 checks.append(dict(name=name,pass_=bool(passed),detail=str(details)[:350]))
 print(('PASS' if passed else 'FAIL'),name,details or '',flush=True)
def key_state(p):return p.evaluate('NOVA_F16_06_CONFIG._explore.get()')
def svgpoint(p,x,y):return p.evaluate('''v=>{let svg=document.querySelector('.f16d-plot'),q=svg.createSVGPoint();q.x=v[0];q.y=v[1];let pt=q.matrixTransform(svg.getScreenCTM());return {x:pt.x,y:pt.y};}''',[x,y])
def drag(p,g,i,target,steps=10,kind='axis'):
 p.locator('.f16d-plot').scroll_into_view_if_needed();locator=p.locator(f'[data-dot="{g}:{i}"]');locator.wait_for(state='visible'); r=locator.bounding_box();assert r,r
 w=p.viewport_size['width'];x=43+target/12*364 if w==380 else 95+target/12*580;y=430 if w==380 else 385
 if kind=='remove':x,y=(346,780) if w==380 else (610,746)
 else:y=y-50
 q=svgpoint(p,x,y)
 p.mouse.move(r['x']+r['width']/2,r['y']+r['height']/2);p.mouse.down();p.mouse.move(q['x'],q['y'],steps=steps);p.mouse.up();p.wait_for_timeout(130)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in (380,1280):
  p=browser.new_page(viewport={'width':width,'height':940},reduced_motion='reduce');errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.set_content(HTML,wait_until='load',timeout=90000);p.wait_for_timeout(160)
  for mode in ['watch','guided','explore','challenge']:
   p.locator(f'.nova-tab[data-m="{mode}"]').click();p.wait_for_timeout(280)
   check(f'{width} {mode} stage SVG',p.locator('.nova-stage .f16d-plot').count()==1)
   check(f'{width} {mode} single stage helper',p.locator('.nova-stage .nv-dock').count()==1)
   check(f'{width} {mode} no page overflow',p.evaluate('document.documentElement.scrollWidth <= innerWidth+2'))
   check(f'{width} {mode} master core present',p.evaluate('typeof NOVA.numberLine==="function" && typeof NOVA.ui.svgDrag==="function" && typeof NOVA.motion.arrive==="function"'))
  p.locator('.nova-tab[data-m="watch"]').click();p.wait_for_timeout(160)
  for i in range(10):
   p.evaluate('i=>{F16_06.timeline.pause();F16_06.timeline.go(i,"test")}',i);p.wait_for_timeout(80)
   check(f'{width} watch {i} visible visual',p.locator('.nova-stage .f16d-plot').count()==1)
   if i==0:check(f'{width} first slide genuine source cards',p.locator('.f16d-plot .nv-numberline').count()==0)
   if i>=1:check(f'{width} step {i} canonical numberline',p.locator('.f16d-plot .nv-numberline').count()==1)
  p.locator('.nova-tab[data-m="explore"]').click();p.wait_for_timeout(200)
  cfg=p.evaluate('NOVA_F16_06_CONFIG.presets');
  def median(v):
   z=sorted(v);n=len(z);return z[n//2] if n%2 else (z[n//2-1]+z[n//2])/2
  for name,d in cfg.items():
   p.locator('select[aria-label="Lesson preset"]').select_option(name);p.wait_for_timeout(120)
   actual=key_state(p)
   check(f'{width} {name}: current preset',actual['preset']==name)
   check(f'{width} {name}: original observations',actual['values']['A']==d['A'])
   for g in ['A']+(['B'] if 'B'in d else []):
    a=actual['values'][g];stat=actual[g]
    check(f'{width} {name} {g} mean exact',abs(stat['mean']-sum(a)/len(a))<1e-8)
    check(f'{width} {name} {g} median exact',stat['median']==median(a))
    check(f'{width} {name} {g} range exact',stat['range']==max(a)-min(a))
    counts={v:a.count(v) for v in set(a)};z=max(counts.values());m=sorted(k for k,n in counts.items() if n==z) if z>1 else []
    check(f'{width} {name} {g} modes exact',stat['mode']==m)
   check(f'{width} {name}: numberline for each group',p.locator('.f16d-plot .nv-numberline').count()==(2 if 'B'in d else 1))
   check(f'{width} {name}: SVG observation count',p.locator('.f16d-dot').count()==len(d['A'])+len(d.get('B',[])))
  p.locator('select[aria-label="Lesson preset"]').select_option('y7-stems');p.wait_for_timeout(140)
  orig=key_state(p)['values']['A'][:]
  drag(p,'A',0,10,1)
  check(f'{width} fast native pointer move changes data',key_state(p)['values']['A'][0]==10,key_state(p)['values']['A'])
  check(f'{width} mean actually recomputed',abs(key_state(p)['A']['mean']-(sum(orig)-orig[0]+10)/len(orig))<1e-8)
  check(f'{width} no stranded drag',p.evaluate('NOVA.ui._drag === null'))
  # Wrong/invalid drops must spring back without modifying model.
  prior=key_state(p)['values']['A'][:];r=p.locator('[data-dot="A:0"]').bounding_box()
  q=svgpoint(p,215,90);p.mouse.move(r['x']+r['width']/2,r['y']+r['height']/2);p.mouse.down();p.mouse.move(q['x'],q['y'],steps=5);p.mouse.up();p.wait_for_timeout(180)
  check(f'{width} invalid drop leaves data intact',key_state(p)['values']['A']==prior)
  # Re-grab placed dot, Escape cancel.
  r=p.locator('[data-dot="A:0"]').bounding_box();q=svgpoint(p,230,290)
  p.mouse.move(r['x']+r['width']/2,r['y']+r['height']/2);p.mouse.down();p.mouse.move(q['x'],q['y'],steps=8);p.keyboard.press('Escape');p.mouse.up();p.wait_for_timeout(160)
  check(f'{width} Escape recovers',p.evaluate('NOVA.ui._drag === null'))
  check(f'{width} Escape leaves model unchanged',key_state(p)['values']['A']==prior)
  # Keyboard equivalence.
  p.locator('[data-dot="A:0"]').focus();p.keyboard.press('ArrowRight');p.wait_for_timeout(120)
  check(f'{width} keyboard increments dot',key_state(p)['values']['A'][0]==11)
  p.locator('[data-dot="A:0"]').focus();p.keyboard.press('Home');p.wait_for_timeout(120)
  check(f'{width} Home returns to zero',key_state(p)['values']['A'][0]==0)
  # Remove through red-zone dragging.
  before=len(key_state(p)['values']['A']);drag(p,'A',0,0,10,kind='remove')
  check(f'{width} pointer Remove deletes exactly one',len(key_state(p)['values']['A'])==before-1)
  check(f'{width} no stranded pointer after remove',p.evaluate('NOVA.ui._drag === null'))
  # Reset and static data consistency.
  p.get_by_role('button',name='Reset data').click();p.wait_for_timeout(80)
  check(f'{width} reset restores originals',key_state(p)['values']['A']==orig)
  # Challenge all three, including deliberately wrong answers.
  p.locator('.nova-tab[data-m="challenge"]').click();p.wait_for_timeout(160)
  p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(90)
  check(f'{width} Challenge missing dot rejected',p.locator('.nova-fb.bad').count()>0)
  p.get_by_role('button',name='Restore observation 8').click();p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(950)
  check(f'{width} Challenge median task loaded',p.locator('.pr-task').inner_text().startswith('Find the median'))
  p.locator('.pr-task + div input').first.fill('99');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(110)
  check(f'{width} Challenge incorrect median rejected',p.locator('.nova-fb.bad').count()>0)
  p.locator('.pr-task + div input').first.fill('4.5');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(940)
  check(f'{width} Challenge range loaded',p.locator('.pr-task').inner_text().startswith('What is the range'))
  p.locator('.pr-task + div input').first.fill('6');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(150)
  check(f'{width} Challenge final range accepted',p.locator('.nova-fb.ok').count()>0)
  check(f'{width} no browser page errors',len(errors)==0,errors)
  p.close()
 browser.close()
result={'passed':sum(z['pass_'] for z in checks),'total':len(checks),'failed':[{k:v for k,v in z.items() if k!='pass_'} for z in checks if not z['pass_']],'checks':[{**z,'passed':z.pop('pass_')} for z in checks]}
(R/'tests/RESULTS.json').write_text(json.dumps(result,indent=2));print('RESULT',result['passed'], '/',result['total'],'failures',len(result['failed']),flush=True)
if result['failed']:sys.exit(1)
