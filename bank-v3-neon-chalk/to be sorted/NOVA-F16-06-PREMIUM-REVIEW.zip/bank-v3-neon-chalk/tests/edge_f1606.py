from pathlib import Path
from playwright.sync_api import sync_playwright
import json,sys
R=Path(__file__).resolve().parents[1];html=(R/'F16/F16-06-dot-plot-and-averages.html').read_text();results=[]
def test(n,ok):results.append({'name':n,'passed':bool(ok)});print(('PASS' if ok else 'FAIL'),n,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in (380,1280):
  p=b.new_page(viewport={'width':width,'height':940},reduced_motion='reduce');p.set_content(html);p.locator('.nova-tab[data-m="explore"]').click();p.wait_for_timeout(140)
  p.locator('select[aria-label="Lesson preset"]').select_option('y9-outliers');p.wait_for_timeout(120)
  before=p.evaluate('NOVA_F16_06_CONFIG._explore.get()');test(f'{width} outlier starts at 12',before['values']['A'][-1]==12)
  p.evaluate('NOVA_F16_06_CONFIG._explore.set("A",10,7)');after=p.evaluate('NOVA_F16_06_CONFIG._explore.get()');test(f'{width} removing outlier lowers mean exactly',abs((before['A']['mean']-after['A']['mean'])-5/11)<1e-10)
  test(f'{width} removing outlier keeps median four',before['A']['median']==after['A']['median']==4)
  test(f'{width} removing outlier halves range',before['A']['range']==10 and after['A']['range']==5)
  p.locator('select[aria-label="Lesson preset"]').select_option('y7-stems');p.wait_for_timeout(90)
  r=p.locator('[data-dot="A:0"]').bounding_box();p.mouse.move(r['x']+r['width']/2,r['y']+r['height']/2);p.mouse.down();p.mouse.move(r['x']+48,r['y']-42,steps=3)
  p.evaluate('''() => {let a=document.querySelector('[data-dot="A:0"]');let e=new PointerEvent('pointercancel',{bubbles:true,pointerId:1,pointerType:'mouse'});a.dispatchEvent(e);}''');p.mouse.up();p.wait_for_timeout(180)
  test(f'{width} synthetic pointercancel clears active drag',p.evaluate('NOVA.ui._drag===null'))
  test(f'{width} synthetic pointercancel does not modify data',p.evaluate('JSON.stringify(NOVA_F16_06_CONFIG._explore.get().values.A)===JSON.stringify(NOVA_F16_06_CONFIG.presets["y7-stems"].A)'))
  p.close()
 b.close()
(R/'tests/EDGE-RESULTS.json').write_text(json.dumps({'passed':sum(t['passed'] for t in results),'total':len(results),'checks':results},indent=2));print('EDGE RESULT',sum(t['passed'] for t in results),'/',len(results))
if not all(t['passed'] for t in results):sys.exit(1)
