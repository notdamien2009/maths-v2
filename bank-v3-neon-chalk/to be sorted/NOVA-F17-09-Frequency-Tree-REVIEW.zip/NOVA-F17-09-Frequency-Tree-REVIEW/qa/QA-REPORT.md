# NOVA Maths V2 — F17-09 Frequency Tree — QA report

**Status:** Built for user review, **not GOLD-approved**. Date: 13 October 2026. No repository writes.

## Canonical source and specification
- Specification: `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, section `F17-09 Frequency tree`.
- Preserves the exact inlined NOVA core, page, chalk fonts, mathematical colours, stage/background, controls, SVG helpers, motion, mouse drag and single helper dock from the recent NOVA F17-08 review shell.
- The local F17-09 source implementation is in `qa/F17-09-engine-local.js`; the deliverable HTML is standalone with all artwork, CSS, core JavaScript and fonts embedded. No external libraries or CDN links are necessary.
- Not a GitHub submission. No modifications to the original shared core.

## Results actually executed
| Suite | Passed | Failed | Evidence |
|---|---:|---:|---|
| Chromium viewport, all modes, model maths, SVG mouse moves, drag recovery, keyboard and editing | 118 / 118 | 0 | `qa/QA-CORE-RESULTS.json`; `qa/tests/test_core.py` |
| Watch timeline, play/pause, rewind/scrub, all Challenge questions and mistake-specific marking | 56 / 56 | 0 | `qa/QA-EXTRA-RESULTS.json`; `qa/tests/test_watch_challenge.py` |
| Equal-valued tile interchangeability and active-drag cancellation at 380/1280 | 4 / 4 | 0 | `qa/QA-EDGE-RESULTS.json`; `qa/tests/test_equal_counts_and_cancel.py` |
| **Total** | **178 / 178** | **0** | All suites above |

## Preset mathematical audit
- Y7-077: leaves 16, 6, 14, 4; first branches 22 + 18 = 40; late = 10, `P(late)=1/4`.
- Y8-067: leaves 18, 9, 8, 13; first branches 27 + 21 = 48; team = 26, `P(team)=13/24`.
- Y8-068: leaves 12, 24, 18, 6; first branches 36 + 24 = 60; vegetarian = 30, `P(vegetarian)=1/2`.
- Y8-072: leaves 8, 12, 9, 21; branches 20 + 30 = 50; union = 29, `P(A union B)=29/50`.
- Y9-044: leaves 20, 26, 14, 20; branches 46 + 34 = 80; union = 60, `P(A union B)=3/4`.
- Edited frequencies example [11,21,17,5] recomputes total 54, branches 32 + 22, vegetarian 28, `P(vegetarian)=14/27`.
- Equal-valued tiles are mathematically interchangeable; a swap of both 20-valued Y9 tiles is accepted.

## Behaviour and visual evidence
- `F17-09-380-{watch,guided,explore,challenge}.png` and corresponding `1280` files show each mode at the two required widths.
- `F17-09-{width}-{preset}-completed.png` images show all five completed preset trees at 380 and 1280 (10 further screenshots).
- `qa/F17-09-engine-local.js`: top config, `DATA` defines presets, `tally` enforces totals, `render` draws through NOVA neon primitives, `NOVA.ui.svgDrag` supplies valid target snapping/re-grab/remove/escape, `renderStep` provides six teaching states, `explore` provides accessible keyboard tools and editable datasets, `challenge` checks answers with individual misconception feedback.
- 118 core assertions cover 8 mode viewport checks, one dock per screen, all five preset totals/fractions, actual fast mouse movement, re-grabbing, invalid-drop rebound, Escape, removal, accessible keyboard alternatives and count editing.
- 56 Watch/Challenge assertions cover step forward/back, pause, scrub, four incorrect and four correct answers at both widths, with no reported script errors.
- Four edge assertions confirm duplicate-count interchangeability and cancellation through the existing NOVA UI drag cancellation API at both widths.

## Review limitations
- Physical touchscreen gestures (on actual iOS/Android devices) have **not** been performed. Likewise, no exhaustive assistive-technology screen-reader audit was performed.
- The signed-off GOLD acceptance visual comparison belongs to the user. This is a **review candidate**, not GOLD approval.
- The shared NOVA core remains exactly the embedded recent review-core version; F17-09 does not alter the source repository or canonical core.
