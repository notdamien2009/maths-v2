import asyncio,pathlib,json
from playwright.async_api import async_playwright
HTML=(pathlib.Path(__file__).resolve().parents[2]/'F17-09-Frequency-Tree-PREMIUM-REVIEW.html').read_text();OUT=(pathlib.Path(__file__).resolve().parents[2]/'qa'/'test-output');OUT.mkdir(parents=True,exist_ok=True)
checks=[]
def ck(k,v,detail=None):
 checks.append({'test':k,'passed':bool(v),'detail':detail})
 if not v:print('FAIL',k,detail)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for width in [380,1280]:
   page=await b.new_page(viewport={'width':width,'height':1400},reduced_motion='no-preference')
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',HTML)
   await page.get_by_role('tab',name='Watch').click();await page.wait_for_timeout(70)
   ar=await page.locator('button[aria-label]').evaluate_all('(x)=>x.map(e=>e.getAttribute("aria-label"))')
   for n in ['Reset','Step back','Step forward']:
    ck(f'{width}/watch-{n}',n in ar,ar)
   ck(f'{width}/watch-play-pause',('Play' in ar or 'Pause' in ar),ar)
   ck(f'{width}/watch-scrub',await page.locator('input[type="range"]').count()>=1)
   if 'Pause' in ar:await page.get_by_role('button',name='Pause',exact=True).click()
   await page.get_by_role('button',name='Reset',exact=True).click();await page.get_by_role('button',name='Step forward',exact=True).click()
   await page.wait_for_timeout(65)
   ck(f'{width}/watch-next','STEP 2/6' in await page.locator('body').inner_text())
   await page.get_by_role('button',name='Step back',exact=True).click()
   await page.wait_for_timeout(65)
   ck(f'{width}/watch-back','STEP 1/6' in await page.locator('body').inner_text())
   ck(f'{width}/normal-motion',await page.evaluate('()=>!matchMedia("(prefers-reduced-motion: reduce)").matches'))
   await page.get_by_role('tab',name='Challenge').click();await page.wait_for_timeout(110)
   for i,(ans,wrong,trap) in enumerate([('1/4','6/40','Only bus'),('26','18','only indoor'),('1/2','12/60','hot vegetarian'),('3/4','20/80','intersection')]):
    q=await page.locator('.pr-task').inner_text()
    ck(f'{width}/challenge-{i+1}-has-question',len(q)>35,q)
    # In Challenge the answer card must be hidden even when the final tree counts are presented.
    ck(f'{width}/challenge-{i+1}-answer-hidden',await page.locator('.f179-readouts').inner_text() and '?' in await page.locator('.f179-readouts').inner_text())
    inp=page.locator('input[type="text"]');await inp.fill(wrong);await page.get_by_role('button',name='Check',exact=True).click();await page.wait_for_timeout(80)
    response=(await page.locator('body').inner_text())
    ck(f'{width}/challenge-{i+1}-wrong-trap',trap.lower() in response.lower(),response[-340:])
    await inp.fill(ans);await page.get_by_role('button',name='Check',exact=True).click();await page.wait_for_timeout(800 if i<3 else 90)
    txt=await page.locator('body').inner_text()
    ck(f'{width}/challenge-{i+1}-correct','Correct' in txt,txt[-250:])
    if i<3:ck(f'{width}/challenge-{i+1}-advance',q!=await page.locator('.pr-task').inner_text())
   ck(f'{width}/no-errors',not errors,errors[-3:])
   await page.close()
  await b.close()
 total=len(checks);passed=sum(c['passed'] for c in checks)
 (OUT/'QA-EXTRA-RESULTS.json').write_text(json.dumps({'total':total,'passed':passed,'failed':total-passed,'checks':checks},indent=2))
 print('EXTRA',total,passed,'FAIL',total-passed)
asyncio.run(main())
