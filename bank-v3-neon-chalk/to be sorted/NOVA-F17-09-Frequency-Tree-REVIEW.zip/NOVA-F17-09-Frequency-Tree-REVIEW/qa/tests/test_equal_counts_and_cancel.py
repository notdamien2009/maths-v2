import asyncio,pathlib,json
from playwright.async_api import async_playwright
H=(pathlib.Path(__file__).resolve().parents[2]/'F17-09-Frequency-Tree-PREMIUM-REVIEW.html').read_text()
async def main():
 checks=[]
 pathlib.Path(__file__).resolve().parents[2].joinpath('qa','test-output').mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for width in [380,1280]:
   page=await browser.new_page(viewport={'width':width,'height':1800},reduced_motion='reduce')
   await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',H)
   await page.get_by_role('tab',name='Explore').click()
   a=await page.evaluate('()=>{let e=NOVA_F17_09_CONFIG._explore;e.setPreset("y9sets");e.place(0,3);e.place(1,1);e.place(2,2);e.place(3,0);e.check?.();return e.get();}')
   checks.append({'test':f'{width}/equal-value-tiles-interchangeable','pass':a['complete'] and a['correct']==4,'detail':a})
   await page.evaluate('()=>NOVA_F17_09_CONFIG._explore.setPreset("y8tree")')
   await page.evaluate('()=>{let e=document.querySelector("svg.f179-plot");window.scrollTo(0,e.getBoundingClientRect().top+scrollY-110)}')
   v=await page.locator('[data-frequency-item="0"]').bounding_box();point={'x':v['x']+v['width']/2,'y':v['y']+v['height']/2}
   dest=await page.evaluate('()=>{let e=document.querySelector("svg.f179-plot");let p=e.createSVGPoint();p.x=340;p.y=165;let z=p.matrixTransform(e.getScreenCTM());return {x:z.x,y:z.y}}')
   await page.mouse.move(point['x'],point['y']);await page.mouse.down();await page.mouse.move(dest['x'],dest['y'],steps=2)
   act=await page.evaluate('()=>!!NOVA.ui._drag')
   await page.evaluate('()=>NOVA.ui.cancelDrag()');await page.mouse.up()
   q=await page.evaluate('()=>NOVA_F17_09_CONFIG._explore.get()')
   checks.append({'test':f'{width}/active-drag-cancellation','pass':act and not q['assignments'],'detail':q['assignments']})
   await page.close()
  await browser.close()
 print([(x['test'],x['pass']) for x in checks])
 (pathlib.Path(__file__).resolve().parents[2]/'qa'/'test-output'/'QA-EDGE-RESULTS.json').write_text(json.dumps(checks,indent=2))
asyncio.run(main())
