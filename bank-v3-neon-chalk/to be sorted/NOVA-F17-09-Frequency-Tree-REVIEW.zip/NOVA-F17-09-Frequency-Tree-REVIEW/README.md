# NOVA F17-09 — Frequency Tree — Premium Review

**Open** `F17-09-Frequency-Tree-PREMIUM-REVIEW.html` directly in a browser. It is fully self-contained.

Modes: WATCH, GUIDED, EXPLORE, CHALLENGE. In Explore, drag the four count tiles into leaf targets. Green targets snap; REMOVE returns a tile; press Escape to cancel a drag. All actions have keyboard-accessible controls beneath the board. Pick a lesson, change the event, or edit the four endpoint counts. Parent totals and the probability update immediately.

Five lesson presets: Y7-077, Y8-067, Y8-068, Y8-072, Y9-044. Four Challenge questions with checks.

**QA:** See `qa/QA-REPORT.md` and `qa/*.json` for 178 checked assertions, all passing. 18 screenshots are in `screenshots/` (4 modes at each of 2 widths + 5 completed presets at each width).

**Replay tests:** Requires Python 3, Playwright and local Chromium. From the extracted package, run:
```
python qa/tests/test_core.py
python qa/tests/test_watch_challenge.py
python qa/tests/test_equal_counts_and_cancel.py
```
Test scripts are browser tests and may generate `qa/test-output/` working files. They do not modify the standalone HTML.

**Status:** Owner review required; **not GOLD-approved**. No GitHub changes.
