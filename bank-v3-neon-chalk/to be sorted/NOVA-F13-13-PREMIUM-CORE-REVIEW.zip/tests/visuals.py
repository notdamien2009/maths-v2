from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path(__file__).resolve().parent
s=(P/'F13-13-Surface-Area-Unfolder-PREMIUM-CORE.html').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  page=b.new_page(viewport={'width':width,'height':1050});page.set_content(s);page.locator('.nova-tab[data-m="explore"]').click();page.wait_for_timeout(90)
  for name in ['cuboid','cube3','prism','pyramid']:
   for fold,label in [(0,'solid'),(.5,'half'),(1,'net')]:
    page.evaluate('(a)=>{NOVA_F13_13_CONFIG._explore.preset(a[0]);NOVA_F13_13_CONFIG._explore.unfold(a[1]);}',[name,fold]);page.wait_for_timeout(60)
    page.locator('.nova-stage').screenshot(path=str(P/'screenshots'/f'{width}-{name}-{label}-stage.png'),animations='disabled')
  page.close()
 b.close()
