from pathlib import Path
from playwright.sync_api import sync_playwright
import math,json,hashlib,re,time
P=Path(__file__).resolve().parent
html=(P/'F13-13-Surface-Area-Unfolder-PREMIUM-CORE.html').read_text()
checks=[]
def check(ok,label,detail=None):
 checks.append({'name':label,'passed':bool(ok),'detail':detail})
 if not ok: print('FAIL',label,detail)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  page=browser.new_page(viewport={'width':width,'height':950},device_scale_factor=1,has_touch=width==380,is_mobile=False)
  errors=[]
  page.on('pageerror',lambda exc: errors.append(str(exc)))
  page.set_content(html,wait_until='domcontentloaded');page.wait_for_timeout(90)
  check(page.locator('.nova-engine').count()==1,f'{width}: single NOVA engine')
  check(page.locator('.f13sa-svg').count()==1,f'{width}: NOVA stage renders')
  check(page.locator('.nv-dock').count()==1,f'{width}: exactly one official mascot dock')
  check(page.locator('.nv-dockfig image').count()>=1,f'{width}: official embedded mascot art')
  check(page.locator('.nv-dock').evaluate('(el)=>!!el.closest(".nova-stage")'),f'{width}: mascot inside stage')
  check(page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),f'{width}: no horizontal overflow',page.evaluate('[document.documentElement.scrollWidth,innerWidth]'))
  check(page.locator('.f13sa-svg').get_attribute('aria-label') is not None,f'{width}: accessible SVG')
  for mode in ['watch','guided','explore','challenge']:
   page.locator(f'.nova-tab[data-m="{mode}"]').click();page.wait_for_timeout(60)
   check(page.locator('.f13sa-svg').count()==1,f'{width}: {mode} stage')
   check(page.locator('.nv-dock').count()==1,f'{width}: {mode} has 1 mascot')
   check(page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),f'{width}: {mode} no overflow')
  page.locator('.nova-tab[data-m="explore"]').click()
  cfg='window.NOVA_F13_13_CONFIG._explore'
  for key,n,expected in [('cube2',6,24),('cube3',6,54),('cuboid',6,52),('parcel',6,34),('prism',5,72+8*math.sqrt(3)),('prismSmall',5,45+4.5*math.sqrt(3)),('pyramid',5,40),('pyramidLarge',5,96)]:
   page.evaluate(f'({cfg}).preset({json.dumps(key)})');page.wait_for_timeout(42)
   r=page.evaluate(f'({cfg}).read()')
   check(r['faceCount']==n,f'{width}: {key} face count {n}',r['faceCount'])
   check(abs(r['total']-expected)<1e-5,f'{width}: {key} exact area',r['total'])
   check(len(r['faces'])==n,f'{width}: {key} sum enumerates faces')
   check(abs(sum(f['area'] for f in r['faces'])-r['total'])<1e-8,f'{width}: {key} per-face sum')
   page.evaluate(f'({cfg}).unfold(1)');page.wait_for_timeout(42)
   r=page.evaluate(f'({cfg}).read()')
   check(abs(r['fold'])<1e-8,f'{width}: {key} flat net 100%')
   check(page.locator('.f13sa-face').count()==n,f'{width}: {key} all flat net faces visible',page.locator('.f13sa-face').count())
   for index in [0,.25,.5,.75,1]:
    geo=page.evaluate('([c,i])=>{c.unfold(i);return c.geometry()}',[page.evaluate(cfg),index]) if False else page.evaluate(f'(v)=>{{{cfg}.unfold(v);return {cfg}.geometry()}}',index)
    # 3D face area via cross-product triangulation, should remain invariant through rotation
    def tri_area(f):
     pts=f['pts'];origin=pts[0];tot=0
     for ii in range(1,len(pts)-1):
      a=[pts[ii][k]-origin[k] for k in range(3)];b=[pts[ii+1][k]-origin[k] for k in range(3)];c=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];tot+=math.sqrt(sum(q*q for q in c))/2
     return tot
    check(all(abs(tri_area(f)-f['f']['area'])<1e-5 for f in geo),f'{width}: {key} rigid faces at unfold {index}')
    # every hinged face contains its parent's shared hinge vertices throughout motion
    for f in geo:
     if f['hinge']:
      a,b=f['hinge'];mn=lambda q,minpts: min(math.dist(q,p) for p in minpts)
      check(mn(a,f['pts'])<1e-5 and mn(b,f['pts'])<1e-5,f'{width}: {key} connected hinge at unfold {index} · {f["f"]["id"]}')
   if key in ['cuboid','pyramid','prism']:
    page.evaluate(f'({cfg}).unfold(.48)');page.screenshot(path=str(P/'screenshots'/f'{width}-{key}-hinges.png'),full_page=False)
    page.evaluate(f'({cfg}).unfold(1)');page.screenshot(path=str(P/'screenshots'/f'{width}-{key}-net.png'),full_page=False)
   page.evaluate(f'({cfg}).countAll()');page.wait_for_timeout(42)
   r=page.evaluate(f'({cfg}).read()');check(abs(r['subtotal']-expected)<1e-5,f'{width}: {key} count all subtotal')
   page.evaluate(f'({cfg}).clear()');page.wait_for_timeout(42);r=page.evaluate(f'({cfg}).read()');check(abs(r['subtotal'])<1e-8,f'{width}: {key} clear tally')
  # real face tap on an unfolded cuboid
  page.evaluate(f'({cfg}).preset("cuboid");{cfg}.unfold(1)');page.wait_for_timeout(42)
  page.locator('.f13sa-face[data-face="base"]').click(force=True);page.wait_for_timeout(45)
  check(abs(page.evaluate(f'({cfg}).read().subtotal')-12)<.01,f'{width}: tap a face counts exact area')
  page.locator('.f13sa-face[data-face="base"]').click(force=True);page.wait_for_timeout(45)
  check(abs(page.evaluate(f'({cfg}).read().subtotal'))<.01,f'{width}: second tap removes face area')
  # keyboard controls on main SVG
  page.locator('.f13sa-svg').focus();before=page.evaluate(f'{cfg}.read().fold');page.keyboard.press('Home');page.wait_for_timeout(70)
  check(abs(page.evaluate(f'{cfg}.read().fold')-1)<1e-6,f'{width}: Home closes solid')
  page.keyboard.press('End');page.wait_for_timeout(70)
  check(abs(page.evaluate(f'{cfg}.read().fold')-0)<1e-6,f'{width}: End opens flat net')
  # fast drag without reconstruction errors
  box=page.locator('.f13sa-svg').bounding_box();sx=box['x']+box['width']*.5;sy=box['y']+box['height']*.38
  page.mouse.move(sx,sy);page.mouse.down()
  for i in range(20):page.mouse.move(sx+(i%2)*110,sy+((i%3)-1)*10)
  page.mouse.up();page.wait_for_timeout(70)
  check(page.locator('.f13sa-svg.is-dragging').count()==0,f'{width}: rapid drag releases capture')
  # step teaching 12
  page.locator('.nova-tab[data-m="watch"]').click()
  for i in range(12):
   page.evaluate('(i)=>{var tabs=document.querySelectorAll(".nova-tl button");}',i)
   if i==0:pass
  page.locator('.nova-tab[data-m="challenge"]').click();page.wait_for_timeout(60)
  ch='window.NOVA_F13_13_CONFIG._challenge'
  for i,expect in enumerate([54,52,40,round((72+8*math.sqrt(3))*100)/100]):
   page.evaluate(f'{ch}.load({i})');page.wait_for_timeout(42)
   check(page.locator('.f13sa-svg').text_content().find('? u²')>=0,f'{width}: challenge {i+1} hides total before marking')
   page.evaluate(f'v=>{ch}.answer.value=String(v)',expect)
   ok=page.evaluate(f'{ch}.check()');check(ok is True,f'{width}: challenge {i+1} correct')
   page.wait_for_timeout(42);check(page.locator('.f13sa-svg').text_content().find('? u²')<0,f'{width}: challenge {i+1} reveals total on correct answer')
  page.evaluate(f'{ch}.load(0)');page.evaluate(f'{ch}.answer.value="9"');bad=page.evaluate(f'{ch}.check()');check(bad is False,f'{width}: incorrect answer rejected')
  check(not errors,f'{width}: no JS errors',errors[:3])
  page.screenshot(path=str(P/'screenshots'/f'{width}-challenge.png'),full_page=True)
  page.close()
 browser.close()
P.joinpath('QA-RESULTS.json').write_text(json.dumps({'total':len(checks),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'checks':checks},indent=2))
print('RESULT:',sum(c['passed'] for c in checks),'/',len(checks))
