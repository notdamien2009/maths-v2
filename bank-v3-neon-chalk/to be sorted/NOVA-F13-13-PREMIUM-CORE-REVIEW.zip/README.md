# NOVA F13-13 · Surface-Area Unfolder

Review build only. Open `F13-13-Surface-Area-Unfolder-PREMIUM-CORE.html` directly in a browser. No internet connection or separate runtime files are required.

This component preserves the exact original NOVA CSS and JavaScript core from the included approved F13-12 base. Its local F13-13 engine and styles are additive replacements.

**Modes:** Watch, Guided, Explore and Challenge. **Shapes:** two cubes, two cuboids, two equilateral triangular prisms and two square pyramids.

**Explore:** choose solid; move slider or tap Open/Close; rotate the solid by dragging; tap individual faces to count their area; Count all faces / Clear tally; keyboard left/right rotate, up/down fold, Home closed solid, End flat net. Mouse, touch and keyboard are supported.

**Rebuild:** `python source/build.py` writes the HTML file in the parent folder. Shared core code is not edited. `qa.py` and `visuals.py` contain browser-based verification scripts (require Python Playwright and Chromium). `QA-REPORT.md` contains the full review summary.

No GitHub operations have been performed.
