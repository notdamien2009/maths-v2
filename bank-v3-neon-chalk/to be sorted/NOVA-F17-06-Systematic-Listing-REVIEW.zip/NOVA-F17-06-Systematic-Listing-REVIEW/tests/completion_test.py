import asyncio, json
from playwright.async_api import async_playwright
H=open('/mnt/data/F17-06-Systematic-Listing-PREMIUM-REVIEW.html').read()
checks=[]
def ck(label,v):checks.append((label,bool(v)));print(('PASS' if v else 'FAIL'),label,flush=True)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for width in (380,1280):
   page=await b.new_page(viewport={'width':width,'height':1050},reduced_motion='reduce');err=[];page.on('pageerror',lambda x:err.append(str(x)));await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',H)
   for mode in ['Watch','Guided','Explore','Challenge']:
    await page.locator('[role="tab"]',has_text=mode).click();await page.wait_for_timeout(60);ck(f'{width} {mode} mode plot',await page.locator('.f176-plot').count()==1);ck(f'{width} {mode} no JS errors',not err);ck(f'{width} {mode} original in-stage mascot',await page.locator('.nv-dock').count()==1)
    if width==380:await page.screenshot(path=f'/mnt/data/f17_06_work/F17-06-380-{mode.lower()}-final.png',full_page=True)
   await page.locator('[role="tab"]',has_text='Explore').click()
   for name,total,wins in [('y7',6,1),('y8',12,3),('y9',36,6)]:
    await page.locator('select[aria-label="Lesson preset"]').select_option(name)
    c=await page.evaluate('()=>NOVA_F17_06_CONFIG._explore.get()')
    ck(f'{width} {name} exhaustive ordered pairs',c['total']==total and await page.locator('[data-outcome]').count()==total)
    ck(f'{width} {name} favourable exact mathematics',len(c['favourable'])==wins and abs(c['probability']-wins/total)<1e-9)
    ck(f'{width} {name} change resets marks',c['selected']==0)
    if width==380:await page.screenshot(path=f'/mnt/data/f17_06_work/F17-06-380-{name}-final.png',full_page=True)
   ck(f'{width} Developer event log collapsed',await page.locator('details.nv-dev:has-text("Developer: show event log")').evaluate('(e)=>!e.open'))
   ck(f'{width} no external mascot images visible',await page.locator('.nova-engine .nova-bob img').evaluate_all('(es)=>es.every(e=>getComputedStyle(e).display==="none"||getComputedStyle(e.parentElement).display==="none")'))
   await page.close()
  page=await b.new_page(viewport={'width':1280,'height':1000},reduced_motion='reduce');err=[];page.on('pageerror',lambda e:err.append(str(e)));await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',H);await page.locator('[role="tab"]',has_text='Challenge').click()
  # First question wrong to trigger misconception-specific response.
  await page.locator('input[aria-label="Number of outcomes"]').fill('5');await page.get_by_role('button',name='Check').click();txt=await page.locator('.nova-engine').inner_text();ck('Challenge wrong answer explicitly distinguishes add/multiply','Two plus three' in txt or 'multiply' in txt)
  # The four challenge tasks must be checkable, ordered, and mathematically correct.
  for i,(name,val) in enumerate([('Number of outcomes','6'),('Favourable outcomes','3'),('Favourable ordered pairs','6'),('Probability','1/6')]):
   await page.locator('input[aria-label="'+name+'"]').fill(val);await page.get_by_role('button',name='Check').click();await page.wait_for_timeout(100)
   status=(await page.locator('.nova-engine').inner_text())[-900:]
   ck('Challenge task '+str(i+1)+' correct', 'Correct' in status or 'exactly right' in status.lower())
   if i<3:await page.wait_for_timeout(850)
  ck('Challenge no JavaScript errors',not err)
  await b.close()
  with open('/mnt/data/f17_06_work/QA-COMPLETION.json','w') as f:json.dump({'total':len(checks),'passed':sum(v for _,v in checks),'failed':sum(not v for _,v in checks),'checks':[{'label':k,'passed':v} for k,v in checks]},f,indent=2)
  print('RESULT',sum(v for _,v in checks),'/',len(checks),flush=True)
asyncio.run(main())
