import asyncio,json
from playwright.async_api import async_playwright
H=open('/mnt/data/F17-06-Systematic-Listing-PREMIUM-REVIEW.html').read()
records=[]
def rec(width,gesture,model,expected):
 ok=model['marked']==expected;records.append({'viewport':width,'gesture':gesture,'passed':ok,'marked':model['marked']});print(('PASS' if ok else 'FAIL'),width,gesture,model['marked'],flush=True)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for W in [380,1280]:
   x=await b.new_page(viewport={'width':W,'height':950},reduced_motion='reduce');await x.goto('about:blank');await x.evaluate('(h)=>{document.open();document.write(h);document.close()}',H);await x.locator('[role="tab"]',has_text='Explore').click()
   state=lambda:x.evaluate('()=>NOVA_F17_06_CONFIG._explore.get()')
   async def drag(s,d,steps=4):
    a=await s.bounding_box(timeout=1200);b=await d.bounding_box(timeout=1200)
    if not a or not b:return False
    await x.evaluate('(v)=>scrollTo(0,v)',max(0,min(a['y'],b['y'])+await x.evaluate('scrollY')-175));await x.wait_for_timeout(100)
    a=await s.bounding_box();b=await d.bounding_box();print(W,'drag',round(a['y']),round(b['y']))
    await x.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);await x.mouse.down();await x.mouse.move(b['x']+b['width']/2,b['y']+b['height']/2,steps=steps);await x.mouse.up();await x.wait_for_timeout(120);return True
   print(W,'init',await state())
   await drag(x.locator('[data-list-token]'),x.locator('[data-outcome="0-1"]'),8);rec(W,'place from palette',await state(),['0-1'])
   await drag(x.locator('[data-placed="0-1"]'),x.locator('[data-outcome="1-2"]'),1);rec(W,'fast regrab',await state(),['1-2'])
   # invalid drop via static cell label near source (root ring is not a target)
   src=x.locator('[data-placed="1-2"]');a=await src.bounding_box();svg=x.locator('.f176-plot');A=await svg.bounding_box();v=await x.evaluate('''()=>{let e=document.querySelector('.f176-plot');let b=e.getBoundingClientRect(),r=e.viewBox.baseVal,m=innerWidth<=500;return {x:b.x+(m?41:100)/r.width*b.width,y:b.y+(m?220:250)/r.height*b.height}}''')
   await x.evaluate('(v)=>scrollTo(0,v)',max(0,min(a['y'],v['y'])+await x.evaluate('scrollY')-175));await x.wait_for_timeout(110)
   a=await src.bounding_box();v=await x.evaluate('''()=>{let e=document.querySelector('.f176-plot');let b=e.getBoundingClientRect(),r=e.viewBox.baseVal,m=innerWidth<=500;return {x:b.x+(m?41:100)/r.width*b.width,y:b.y+(m?220:250)/r.height*b.height}}''')
   await x.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);await x.mouse.down();await x.mouse.move(v['x'],v['y'],steps=6);await x.mouse.up();await x.wait_for_timeout(200);rec(W,'invalid drop returns',await state(),['1-2'])
   # Escape cancel in progress
   src=x.locator('[data-placed="1-2"]');a=await src.bounding_box();await x.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);await x.mouse.down();await x.mouse.move(a['x']+80,a['y']-50,steps=4);await x.keyboard.press('Escape');await x.mouse.up();await x.wait_for_timeout(120);rec(W,'Escape cancellation',await state(),['1-2'])
   src=x.locator('[data-placed="1-2"]');a=await src.bounding_box();pos=await x.evaluate('''()=>{let e=document.querySelector('.f176-plot');let b=e.getBoundingClientRect(),r=e.viewBox.baseVal,m=innerWidth<=500;return {x:b.x+(m?297:684)/r.width*b.width,y:b.y+(m?713:704)/r.height*b.height}}''')
   await x.evaluate('(v)=>scrollTo(0,v)',max(0,min(a['y'],pos['y'])+await x.evaluate('scrollY')-175));await x.wait_for_timeout(100)
   a=await src.bounding_box();pos=await x.evaluate('''()=>{let e=document.querySelector('.f176-plot');let b=e.getBoundingClientRect(),r=e.viewBox.baseVal,m=innerWidth<=500;return {x:b.x+(m?297:684)/r.width*b.width,y:b.y+(m?713:704)/r.height*b.height}}''')
   await x.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);await x.mouse.down();await x.mouse.move(pos['x'],pos['y'],steps=8);await x.mouse.up();await x.wait_for_timeout(220);rec(W,'red-zone removal',await state(),[]);records.append({'viewport':W,'gesture':'no stranded drag', 'passed':not await x.evaluate('Boolean(NOVA.ui._drag)')});await x.close()
  await b.close()
  with open('/mnt/data/f17_06_work/QA-POINTER.json','w') as f: json.dump({'passed':sum(v['passed'] for v in records),'total':len(records),'results':records},f,indent=2)
  print('POINTER TOTAL',sum(v['passed'] for v in records),'/',len(records))
asyncio.run(main())
