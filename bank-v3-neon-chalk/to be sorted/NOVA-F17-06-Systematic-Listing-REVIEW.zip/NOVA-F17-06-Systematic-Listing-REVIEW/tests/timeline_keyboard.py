import asyncio,json
from playwright.async_api import async_playwright
H=open('/mnt/data/F17-06-Systematic-Listing-PREMIUM-REVIEW.html').read();a=[]
def check(label,cond):
 a.append({'name':label,'passed':bool(cond)});print(('PASS' if cond else 'FAIL'),label)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for w in (380,1280):
   page=await b.new_page(viewport={'width':w,'height':980},reduced_motion='reduce');await page.goto('about:blank');await page.evaluate('(h)=>{document.open();document.write(h);document.close()}',H)
   check(str(w)+' timeline six named steps',len(page.locator('input[aria-label="Scrub through steps"]') and await page.locator('input[aria-label="Scrub through steps"]').get_attribute('max'))>0)
   timeline=page.locator('input[aria-label="Scrub through steps"]')
   await timeline.fill('5'); await page.wait_for_timeout(70);check(str(w)+' watch scrub last step',await page.locator('.nova-stage').get_by_text('STEP 6/6').count()==1)
   await timeline.fill('0');await page.wait_for_timeout(70);check(str(w)+' watch rewind to first step',await page.locator('.nova-stage').get_by_text('STEP 1/6').count()==1)
   await page.locator('[role="tab"]',has_text='Explore').click()
   cell=page.locator('[data-outcome="0-0"]');await cell.focus();await page.keyboard.press('ArrowRight');check(str(w)+' roving arrow keyboard',await page.locator('[data-outcome="0-1"]').evaluate('(e)=>document.activeElement===e'))
   check(str(w)+' exactly one roving outcome',await page.locator('[data-outcome][tabindex="0"]').count()==1)
   await page.keyboard.press('Enter');check(str(w)+' keyboard mark via Enter',(await page.evaluate('()=>NOVA_F17_06_CONFIG._explore.get()'))['selected']==1)
   await page.locator('select[aria-label="Ordered outcome"]').select_option('0-1');await page.get_by_role('button',name='Remove selected').click();check(str(w)+' keyboard-equivalent removal',(await page.evaluate('()=>NOVA_F17_06_CONFIG._explore.get()'))['selected']==0)
   await page.close()
  await b.close()
  with open('/mnt/data/f17_06_work/QA-KEYBOARD.json','w') as f:json.dump({'passed':sum(x['passed'] for x in a),'total':len(a),'checks':a},f,indent=2)
asyncio.run(main())
