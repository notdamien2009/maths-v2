# NOVA Maths V2 · F17-06 Systematic Listing

Standalone Premium Review component, **not GOLD-approved**.

Open `F17-06-Systematic-Listing-PREMIUM-REVIEW.html` in a browser. It contains all required CSS, JavaScript, NOVA Chalk fonts and helper artwork inline (no network required).

Four engine modes: WATCH (six narrated steps), GUIDED (step scaffold), EXPLORE (drag/snap/keyboard list branches), CHALLENGE (four maths tasks).

Presets: Year 7 coin × spinner; Year 8 coin × die; Year 9 two dice.

Folder `screenshots/` contains 14 recorded viewport/preset shots. `tests/` contains three suites of recorded automated checks and their result JSON. The scripts are included as QA source/evidence and use temporary container paths; if rerunning on another machine, adjust their file paths to your local HTML location. See `QA-REPORT.md` for scope and known limitations.

**No GitHub modifications.** Review before approving.
