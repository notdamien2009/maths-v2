# NOVA Maths V2 — F17-06 Systematic Listing — QA evidence

**Review build only. Owner GOLD approval not granted.** GitHub untouched.

## Source / visual fidelity
- Embedded F0/F2 NOVA core and NOVA Chalk fonts were retained directly from the F17-05 review HTML; the only appended CSS is F17-06 layout/scoping and pupil-safety overrides.
- One original NOVA helper artwork docks inside the stage; additional external avatar images from the inherited narration strip are hidden, while narration text remains available.
- Original NOVA mathematical primitives used: `NOVA.neonLine`, `NOVA.neonRing`, `NOVA.neonBox`, `NOVA.chalkText`, `NOVA.svg.root`, `NOVA.motion.flash`, `NOVA.ui.svgDrag`, `NOVA.bankMount`, `NOVA.challengeRun`.
- Mathematical fractions use proper stacked numerators and denominators in NOVA Chalk; no visible raw `a/b` notation in the stage.
- Developer event log is collapsed; lesson-facing view does not expose event JSON.

## Mathematical specification
- Y7-074: fair coin H/T crossed with equal three-colour spinner R/B/G = **6 ordered outcomes**. Heads AND Blue = **1 favourable**; **1/6**.
- Y8-070: fair coin H/T crossed with fair die 1–6 = **12 ordered outcomes**. Heads AND Even = **3 favourable**; **3/12 = 1/4**.
- Y9-043: two distinguishable fair dice, 1–6 × 1–6 = **36 ordered outcomes**. Sum seven = **6 favourable**; **6/36 = 1/6**.
- All lists are exhaustive and order-aware. In the 36-outcome mobile view, each first die result is shown at the branch node and all six second die results at the endpoints; together they constitute ordered pairs, avoiding unreadable overlapping text.

## Browser QA (Chromium, 380px and 1280px)
| Suite | Passed | Failed | Evidence |
|---|---:|---:|---|
| Mode, preset and Challenge | 52/52 | 0 | `tests/QA-COMPLETION.json` |
| Watch timeline and keyboard | 14/14 | 0 | `tests/QA-KEYBOARD.json` |
| Pointer drag and recovery | 12/12 | 0 | `tests/QA-POINTER.json` |

- All four modes were rendered on both widths with no recorded JavaScript errors.
- Challenge tasks 1–4 were checked with correct input. A wrong answer on task 1 was checked for its addition-versus-multiplication misconception feedback.
- Watch timeline scrub to last step and rewind to first were checked. Roving arrow-key navigation, Enter-to-mark and accessible removal passed.
- Real mouse palette pickup, snap, fast re-grab, safe invalid drop, Escape cancellation and red remove-zone drop passed at both widths. No stranded drag was left after removal.
- The 14 saved screenshots comprise four modes and three lesson presets at each target viewport.

## Unverified / pending owner review
- Not manually exercised on a physical touchscreen, iPad, Android or Safari.
- No cross-browser acceptance or full 104-configuration family audit was performed.
- Not GOLD-approved; the owner must stress-test and decide whether to accept.
- The review archive is standalone; nothing has been committed or pushed to GitHub.

**Artifact SHA-256:** `8709f04826b54babfb6b877c26e365957b0a059a03b5ff7dad170d19d3468e1c`
