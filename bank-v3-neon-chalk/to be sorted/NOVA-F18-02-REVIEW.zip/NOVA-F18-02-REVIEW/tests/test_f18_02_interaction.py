from playwright.sync_api import sync_playwright
from pathlib import Path
import json,math
s=Path('/mnt/data/F18-02-unit-conversion-bridges.html').read_text();out=Path('/mnt/data/f18_02_qa');rows=[]
def note(width,test,passed,detail):
 rows.append(dict(width=width,test=test,passed=bool(passed),detail=detail));print('PASS' if passed else 'FAIL',width,test,str(detail)[:140])
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in (380,1280):
  pg=b.new_page(viewport={'width':width,'height':980})
  errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  pg.set_content(s,wait_until='domcontentloaded');pg.locator('#F18-02 .nova-tab[data-m="explore"]').click();pg.wait_for_timeout(200)
  exp=lambda:pg.evaluate('NOVA_F18_02_CONFIG._explore.state()')
  for k,target in [('time',2.5),('length',320),('area',750),('volume',1750),('euro',100),('speed',20),('density',1500),('dollar',78)]:
   pg.evaluate('(k)=>{NOVA_F18_02_CONFIG._explore.select(k);const p=NOVA_F18_02_CONFIG.presets[k];NOVA_F18_02_CONFIG._explore.place(p.correct)}',k)
   t=exp();note(width,'preset '+k,abs(t['result']-target)<1e-7,t)
   if k in ('density','time','dollar'):
    pg.screenshot(path=str(out/f'F18-02_{width}_preset_{k}.png'),full_page=True)
  pg.evaluate('NOVA_F18_02_CONFIG._explore.select("length");NOVA_F18_02_CONFIG._explore.clear()')
  # real pointer drag source factor to centre gate
  tok=pg.locator('[data-factor-index="1"]');tok.scroll_into_view_if_needed();pg.wait_for_timeout(230)
  a=tok.bounding_box();gate=pg.locator('[data-maths="factor-target"]').bounding_box();
  sx=a['x']+a['width']/2;sy=a['y']+a['height']/2;ex=gate['x']+gate['width']/2;ey=gate['y']+gate['height']/2
  pg.mouse.move(sx,sy);pg.mouse.down();pg.wait_for_timeout(60);pg.mouse.move(ex,ey,steps=2);pg.wait_for_timeout(80);pg.mouse.up();pg.wait_for_timeout(200)
  t=exp();note(width,'actual fast mouse drag into gate',t['selected']==1,t)
  # regrab token at gate and move to tray target
  tok=pg.locator('[data-factor-index="1"]');tok.scroll_into_view_if_needed();pg.wait_for_timeout(160)
  a=tok.bounding_box();source=pg.locator('[data-factor-index="0"]').bounding_box();
  sx=a['x']+a['width']/2;sy=a['y']+a['height']/2;ex=source['x']+source['width']/2;ey=source['y']+source['height']/2
  pg.mouse.move(sx,sy);pg.mouse.down();pg.wait_for_timeout(55);pg.mouse.move(ex,ey,steps=3);pg.wait_for_timeout(75);pg.mouse.up();pg.wait_for_timeout(550)
  t=exp();note(width,'actual regrab and red-tray remove',t['selected'] is None,t)
  # keyboard Enter and delete
  tok=pg.locator('[data-factor-index="1"]');tok.focus();pg.keyboard.press('Enter');pg.wait_for_timeout(100)
  t=exp();note(width,'keyboard Enter places factor',t['selected']==1,t)
  tok=pg.locator('[data-factor-index="1"]');tok.focus();pg.keyboard.press('Delete');pg.wait_for_timeout(100)
  t=exp();note(width,'keyboard Delete removes factor',t['selected'] is None,t)
  # wrong factor shows guidance; invalid drop doesn't change selected
  pg.evaluate('NOVA_F18_02_CONFIG._explore.place(0)');note(width,'wrong factor rejected from answer',exp()['result'] is None,exp())
  pg.evaluate('NOVA_F18_02_CONFIG._explore.clear()')
  tok=pg.locator('[data-factor-index="1"]');tok.scroll_into_view_if_needed();pg.wait_for_timeout(190)
  a=tok.bounding_box();sx=a['x']+a['width']/2;sy=a['y']+a['height']/2
  pg.mouse.move(sx,sy);pg.mouse.down();pg.wait_for_timeout(55);pg.mouse.move(sx,sy+220,steps=8);pg.wait_for_timeout(70);pg.mouse.up();pg.wait_for_timeout(450)
  note(width,'invalid drop springs back',exp()['selected'] is None,exp())
  # cancellation/escape
  tok=pg.locator('[data-factor-index="1"]');tok.scroll_into_view_if_needed();pg.wait_for_timeout(120);a=tok.bounding_box();sx=a['x']+a['width']/2;sy=a['y']+a['height']/2
  pg.mouse.move(sx,sy);pg.mouse.down();pg.mouse.move(sx,sy-80,steps=4);pg.keyboard.press('Escape');pg.mouse.up();pg.wait_for_timeout(480)
  note(width,'Escape drag cancel',exp()['selected'] is None,exp())
  # all 8 challenge answers include unit check and wrong factor check
  pg.locator('#F18-02 .nova-tab[data-m="challenge"]').click();pg.wait_for_timeout(180)
  for k in range(8):
   key=pg.evaluate('NOVA_F18_02_CONFIG._challenge.state().key')
   p=pg.evaluate('(key)=>NOVA_F18_02_CONFIG.presets[key]',key)
   wrong=pg.evaluate('([v])=>NOVA_F18_02_CONFIG._challenge.check(v,0)',[str(p['amount']*p['factor'])+' '+p['to']]);note(width,'wrong factor challenge '+key,wrong[0] is False,wrong)
   # wrong output unit tests
   wrongUnit='cm' if p['to']!='cm' else 'm'
   wrong=pg.evaluate('([v])=>NOVA_F18_02_CONFIG._challenge.check(v)',[str(p['amount']*p['factor'])+' '+wrongUnit]);note(width,'wrong unit '+key,wrong[0] is False,wrong)
   pg.evaluate('NOVA_F18_02_CONFIG._challenge.solve()');pg.get_by_role('button',name='Check conversion').click();pg.wait_for_timeout(1100)
   cur=pg.evaluate('NOVA_F18_02_CONFIG._challenge.task()');note(width,'valid challenge '+key,cur==min(k+1,7),cur)
  # watch all steps plus reduced motion
  pg.locator('#F18-02 .nova-tab[data-m="watch"]').click()
  for i in range(6):
   pg.evaluate('(i)=>{NOVA.engines["F18-02"].timeline.pause(); NOVA.engines["F18-02"].timeline.go(i);}',i);pg.wait_for_timeout(95)
   note(width,'watch step '+str(i+1),pg.locator('#F18-02 .f1802-drawing').count()==1 and pg.locator('#F18-02 .nv-dock').count()==1,'plot + one mascot')
  pg.evaluate('NOVA.setReducedMotion(true);NOVA.engines["F18-02"].timeline.go(4)')
  note(width,'reduced-motion result',pg.get_by_text('320 cm',exact=False).count()>0,'has answer')
  pg.evaluate('NOVA.setReducedMotion(false)')
  note(width,'no page script errors',len(errs)==0,errs)
  pg.close()
 b.close()
(out/'interaction.json').write_text(json.dumps(rows,indent=2))
print('PASS TOTAL',sum(x['passed'] for x in rows),'/',len(rows))
