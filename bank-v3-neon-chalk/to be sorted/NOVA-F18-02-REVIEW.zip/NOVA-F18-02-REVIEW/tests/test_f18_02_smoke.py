from playwright.sync_api import sync_playwright
from pathlib import Path
import json
s=Path('/mnt/data/F18-02-unit-conversion-bridges.html').read_text();out=Path('/mnt/data/f18_02_qa');out.mkdir(exist_ok=True);rows=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [380,1280]:
  pg=b.new_page(viewport={'width':width,'height':980})
  errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  pg.set_content(s,wait_until='domcontentloaded');pg.wait_for_timeout(350)
  for mode in ['watch','guided','explore','challenge']:
   pg.locator('#F18-02 .nova-tab[data-m="'+mode+'"]').click();pg.wait_for_timeout(250)
   d={'width':width,'mode':mode,'plot':pg.locator('#F18-02 .f1802-drawing').count(),'dock':pg.locator('#F18-02 .nova-stage .nv-dock').count(),'errors':list(errs)}
   d['passed']=d['plot']==1 and d['dock']==1 and not d['errors'];rows.append(d)
   pg.screenshot(path=str(out/f'F18-02_{width}_{mode}.png'),full_page=True)
   print(d)
  pg.close()
 b.close()
(out/'smoke.json').write_text(json.dumps(rows,indent=2))
print('SMOKE',sum(x['passed'] for x in rows),'/',len(rows))
