// NOVA F18-02 reproducible browser tests. Requires: npm install playwright
// Run: node tests/stress_f18_02.js ./F18-02-unit-conversion-bridges.html
const fs=require('fs'),assert=require('assert');
const {chromium}=require('playwright');
const {pathToFileURL}=require('url');
(async()=>{
 const filename=process.argv[2]||'./F18-02-unit-conversion-bridges.html';
 const browser=await chromium.launch({headless:true});let checks=0;
 try{
  for(const width of [380,1280]){
   const page=await browser.newPage({viewport:{width,height:900}}),errors=[];page.on('pageerror',e=>errors.push(String(e)));
   await page.goto(pathToFileURL(require('path').resolve(filename)).href);
   for(const mode of ['watch','guided','explore','challenge']){
    await page.locator(`#F18-02 .nova-tab[data-m="${mode}"]`).click();
    assert.strictEqual(await page.locator('#F18-02 .f1802-drawing').count(),1);
    assert.strictEqual(await page.locator('#F18-02 .nova-stage .nv-dock').count(),1);checks+=2;
   }
   await page.locator('#F18-02 .nova-tab[data-m="explore"]').click();
   for(const [key,expected] of Object.entries({time:2.5,length:320,area:750,volume:1750,euro:100,speed:20,density:1500,dollar:78})){
    const v=await page.evaluate(k=>{NOVA_F18_02_CONFIG._explore.select(k);NOVA_F18_02_CONFIG._explore.place(NOVA_F18_02_CONFIG.presets[k].correct);return NOVA_F18_02_CONFIG._explore.state()},key);
    assert(Math.abs(v.result-expected)<1e-9);checks++;
   }
   await page.evaluate(()=>{NOVA_F18_02_CONFIG._explore.select('length');NOVA_F18_02_CONFIG._explore.clear()});
   const token=page.locator('[data-factor-index="1"]'),target=page.locator('[data-maths="factor-target"]');
   await token.scrollIntoViewIfNeeded();const a=await token.boundingBox(),b=await target.boundingBox();
   await page.mouse.move(a.x+a.width/2,a.y+a.height/2);await page.mouse.down();
   await page.mouse.move(b.x+b.width/2,b.y+b.height/2,{steps:3});await page.mouse.up();
   assert.strictEqual((await page.evaluate(()=>NOVA_F18_02_CONFIG._explore.state())).selected,1);checks++;
   await page.locator('[data-factor-index="1"]').focus();await page.keyboard.press('Delete');
   assert.strictEqual((await page.evaluate(()=>NOVA_F18_02_CONFIG._explore.state())).selected,null);checks++;
   assert.deepStrictEqual(errors,[]);checks++;
   await page.close();
  }
 }finally{await browser.close()}
 console.log(`F18-02 JS regression: ${checks}/${checks} assertions passed`);
})().catch(e=>{console.error(e);process.exitCode=1});
