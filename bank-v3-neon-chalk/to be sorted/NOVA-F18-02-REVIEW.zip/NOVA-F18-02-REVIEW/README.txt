NOVA MATHS V2 — F18-02 · UNIT-CONVERSION BRIDGES
STATUS: COMPLETE FOR OWNER REVIEW — NOT GOLD APPROVED

Open F18-02-unit-conversion-bridges.html locally in a modern browser.
All code, fonts and original NOVA mascot artwork are inlined.

Four modes: WATCH, GUIDED, EXPLORE, CHALLENGE.
Eight presets: time, length, area, volume, two currency examples,
compound speed and density. Currency example rates are NOT LIVE.

QA/F18-02-QA-REPORT.html is the visual/interaction review.
QA/screenshots: final 380/1280 × four modes, plus six preset captures.
QA/smoke.json & QA/interaction.json: actual Chromium results, 102/102 passed.
tests/test_f18_02_smoke.py, tests/test_f18_02_interaction.py: executed Python scripts.
tests/stress_f18_02.js: optional JS parity script; syntax checked, not executed.

NOT TESTED: physical touchscreen, physical printing, owner acceptance.
GitHub was NOT changed.
