"""F16-09 browser QA: maths, modes, presets, real mouse drag, keyboard, cancellation, challenge."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json, math
R=Path(__file__).resolve().parents[1]
HTML=(R/'F16/F16-09-grouped-frequency.html').read_text()
checks=[]
def check(title, value, details=''):
 passed=bool(value);checks.append({'name':title,'pass':passed,'detail':str(details)[:250]});print('PASS' if passed else 'FAIL',title, str(details)[:60],flush=True)
def xy(page,x,y):
 return page.evaluate('''p=>{let s=document.querySelector('.f169-svg'),q=s.createSVGPoint();q.x=p[0];q.y=p[1];let t=q.matrixTransform(s.getScreenCTM());return {x:t.x,y:t.y}}''',[x,y])
def drag(page,query,target,steps=1):
 el=page.locator(query).first;el.scroll_into_view_if_needed();page.wait_for_timeout(40)
 bb=el.bounding_box();assert bb is not None,query
 px=bb['x']+bb['width']/2;py=bb['y']+bb['height']/2;t=xy(page,*target)
 page.mouse.move(px,py);page.mouse.down();page.mouse.move(t['x'],t['y'],steps=steps);page.mouse.up();page.wait_for_timeout(130)
def click_mode(page,m):
 page.locator(f'.nova-tab[data-m="{m}"]').click();page.wait_for_timeout(75)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  page=browser.new_page(viewport={'width':width,'height':980},reduced_motion='reduce');errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(HTML,wait_until='load');page.wait_for_timeout(95)
  for mode in ['watch','guided','explore','challenge']:
   click_mode(page,mode)
   check(f'{width} {mode} SVG',page.locator('.f169-svg').count()==1)
   check(f'{width} {mode} one mascot dock',page.locator('.nova-stage .nv-dock').count()==1)
   check(f'{width} {mode} no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'))
   check(f'{width} {mode} diagram coverage',page.evaluate('''()=>{let a=document.querySelector('.f169-svg').getBoundingClientRect(),b=document.querySelector('.nova-stage').getBoundingClientRect();return a.height/b.height >= .6}'''))
  check(f'{width} canonical core primitives',page.evaluate('!!(NOVA.neonPlot&&NOVA.neonBox&&NOVA.chalkText&&NOVA.ui.svgDrag&&NOVA.motion&&NOVA.scene.helperStrip)'))
  click_mode(page,'watch')
  for i in range(9):
   page.evaluate('i=>{F16_09.timeline.pause();F16_09.timeline.go(i,"test")}',i)
   check(f'{width} Watch step {i} SVG available',page.locator('.f169-svg').count()==1)
  click_mode(page,'explore')
  expected={'y8-tables':([3,5,4,2],14,260,260/14), 'y8-mean':([2,5,4,1],12,220,220/12), 'y9-repr':([2,3,6,4,1],16,390,390/16)}
  for preset,(f,n,w,avg) in expected.items():
   page.locator('select[aria-label="Lesson preset"]').select_option(preset);page.wait_for_timeout(80)
   d=page.evaluate('NOVA_F16_09_CONFIG._explore.get()')
   check(f'{width} {preset} frequency counts',d['frequencies']==f,d)
   check(f'{width} {preset} total sample size',d['total']==n,d)
   check(f'{width} {preset} correct midpoint-weighted sum',d['weighted']==w,d)
   check(f'{width} {preset} estimated mean',abs(d['estimate']-avg)<1e-8,d)
   check(f'{width} {preset} all plotted bars',page.locator('.f169-svg [data-bar]').count()==len(f))
   check(f'{width} {preset} source tally',page.evaluate('''()=>{let p=NOVA_F16_09_CONFIG.presets[NOVA_F16_09_CONFIG.preset];return p.raw.length===p.frequencies.reduce((a,b)=>a+b,0)&&p.frequencies.every((v,i)=>p.raw.filter(x=>x>=p.bounds[i]&&x<p.bounds[i+1]).length===v)}'''))
  page.locator('select[aria-label="Lesson preset"]').select_option('y8-tables');page.wait_for_timeout(60)
  l={'mobile':width==380};T={'x':24 if width==380 else 34,'y':117 if width==380 else 178,'w':402 if width==380 else 356,'head':52 if width==380 else 54,'row':50 if width==380 else 61}
  # Drag table frequency from second row into third row, which must transfer one count.
  target=(T['x']+T['w']*.52,T['y']+T['head']+2.5*T['row'])
  drag(page,'[data-token="1"]',target,steps=1)
  check(f'{width} FAST native table transfer',page.evaluate('NOVA_F16_09_CONFIG._explore.get().frequencies.join(",")')=='3,4,5,2',page.evaluate('NOVA_F16_09_CONFIG._explore.get()'))
  check(f'{width} no stranded drag after transfer',page.evaluate('NOVA.ui._drag===null'))
  # Re-grab destination tile and return the count by dragging from third back to second.
  targetback=(T['x']+T['w']*.52,T['y']+T['head']+1.5*T['row'])
  drag(page,'[data-token="2"]',targetback,steps=4)
  check(f'{width} re-grab and reverse transfer',page.evaluate('NOVA_F16_09_CONFIG._explore.get().frequencies.join(",")')=='3,5,4,2')
  before=page.evaluate('NOVA_F16_09_CONFIG._explore.get().frequencies')
  drag(page,'[data-token="1"]',(T['x']+T['w']*.52,43),steps=4)
  check(f'{width} invalid drop unchanged',page.evaluate('NOVA_F16_09_CONFIG._explore.get().frequencies')==before)
  # Escape while holding table token.
  bb=page.locator('[data-token="1"]').bounding_box();dst=xy(page,*target)
  page.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);page.mouse.down();page.mouse.move(dst['x'],dst['y'],steps=4);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(140)
  check(f'{width} escape preserves values',page.evaluate('NOVA_F16_09_CONFIG._explore.get().frequencies')==before)
  check(f'{width} escape clears drag state',page.evaluate('NOVA.ui._drag===null'))
  page.locator('[data-token="1"]').focus();page.keyboard.press('ArrowRight');page.wait_for_timeout(80)
  check(f'{width} keyboard table transfer',page.evaluate('NOVA_F16_09_CONFIG._explore.get().frequencies.join(",")')=='3,4,5,2')
  page.locator('[data-bar="0"]').focus();page.keyboard.press('ArrowUp');page.wait_for_timeout(60)
  check(f'{width} keyboard height increment',page.evaluate('NOVA_F16_09_CONFIG._explore.get().frequencies[0]')==4)
  # Re-initialize before graphical bar-height native drag.
  page.get_by_role('button',name='Reset table').click();page.wait_for_timeout(65)
  g={'x':52 if width==380 else 442,'w':348 if width==380 else 295,'y':548 if width==380 else 218,'h':240 if width==380 else 360}
  unit=g['h']/9;barX=g['x']+(g['w']/4)*.5
  # Desired f=5, target 5 segment centre
  targetbar=(barX,(788 if width==380 else 578)-5*unit)
  drag(page,'[data-bar="0"]',targetbar,steps=1)
  check(f'{width} FAST native bar height drag',page.evaluate('NOVA_F16_09_CONFIG._explore.get().frequencies[0]')==5,page.evaluate('NOVA_F16_09_CONFIG._explore.get()'))
  check(f'{width} bar drag releases pointer',page.evaluate('NOVA.ui._drag===null'))
  page.get_by_role('button',name='Reset table').click();page.wait_for_timeout(60)
  # Remove table token via red zone.
  rem=(361 if width==380 else 675,910 if width==380 else 712)
  drag(page,'[data-token="1"]',rem,steps=5);page.wait_for_timeout(400)
  check(f'{width} native red removal reduces frequency',page.evaluate('NOVA_F16_09_CONFIG._explore.get().total')==13,page.evaluate('NOVA_F16_09_CONFIG._explore.get()'))
  check(f'{width} no stranded objects after removal',page.evaluate('NOVA.ui._drag===null'))
  # Challenge: verify actual pointer transfer, arithmetic and wrong-answer feedback.
  click_mode(page,'challenge');q=lambda:page.evaluate('NOVA_F16_09_CONFIG._challengeState()')
  check(f'{width} challenge intentionally starts wrong',q()['frequencies']==[3,6,3,2])
  page.get_by_role('button',name='Check').click();page.wait_for_timeout(130)
  check(f'{width} wrong frequencies rejected',q()['task']==0)
  drag(page,'[data-token="1"]',target,steps=1)
  check(f'{width} mouse repairs Challenge table',q()['frequencies']==[3,5,4,2],q())
  page.get_by_role('button',name='Check').click();page.wait_for_timeout(1000)
  check(f'{width} Challenge task 0 advances',q()['task']==1,q())
  def fill(value):
   inp=page.locator('.nova-panel input').last
   if not inp.count():inp=page.locator('input').last
   inp.fill(str(value))
  fill(30);page.get_by_role('button',name='Check').click();page.wait_for_timeout(100)
  check(f'{width} upper boundary rejected as midpoint',q()['task']==1)
  fill(25);page.get_by_role('button',name='Check').click();page.wait_for_timeout(950)
  check(f'{width} midpoint correct advances',q()['task']==2)
  fill(260);page.get_by_role('button',name='Check').click();page.wait_for_timeout(100)
  check(f'{width} weighted sum rejected as mean',q()['task']==2)
  fill(round(260/14,2));page.get_by_role('button',name='Check').click();page.wait_for_timeout(130)
  check(f'{width} correct estimated mean accepted',page.get_by_text('Correct',exact=False).count()>0)
  check(f'{width} no browser exceptions',not errors,errors)
  page.close()
 browser.close()
res={'passed':sum(t['pass'] for t in checks),'total':len(checks),'failed':[t for t in checks if not t['pass']],'checks':checks}
(R/'tests/STRESS-RESULTS.json').write_text(json.dumps(res,indent=2));print('RESULT',res['passed'],'/',res['total'],'FAILED',len(res['failed']))
