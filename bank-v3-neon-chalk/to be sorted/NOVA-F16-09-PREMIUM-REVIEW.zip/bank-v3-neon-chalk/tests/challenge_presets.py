from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1];html=(R/'F16/F16-09-grouped-frequency.html').read_text();tests=[]
def ok(n,c):tests.append({'test':n,'pass':bool(c)});print(('PASS' if c else 'FAIL'),n,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  p=b.new_page(viewport={'width':width,'height':960},reduced_motion='reduce');err=[];p.on('pageerror',lambda e:err.append(str(e)));p.set_content(html)
  for preset,expected,estimate in [('y8-mean',[2,5,4,1],220/12),('y9-repr',[2,3,6,4,1],390/16)]:
   p.locator('.nova-tab[data-m="explore"]').click();p.locator('select[aria-label="Lesson preset"]').select_option(preset)
   p.locator('.nova-tab[data-m="challenge"]').click();q=lambda:p.evaluate('NOVA_F16_09_CONFIG._challengeState()')
   ok(f'{width} {preset} wrong initial arrangement',q()['frequencies'][1]==expected[1]+1 and q()['frequencies'][2]==expected[2]-1)
   p.get_by_role('button',name='Move one observation').click();p.get_by_role('button',name='Check').click();p.wait_for_timeout(800)
   ok(f'{width} {preset} transfer solves first task',q()['task']==1)
   inp=p.locator('.nova-panel input').last;inp.fill('25');p.get_by_role('button',name='Check').click();p.wait_for_timeout(800)
   ok(f'{width} {preset} midpoint solves second task',q()['task']==2)
   inp=p.locator('.nova-panel input').last;inp.fill(str(round(estimate,2)));p.get_by_role('button',name='Check').click();p.wait_for_timeout(100)
   ok(f'{width} {preset} mean accepted',p.get_by_text('Correct',exact=False).count()>0)
  ok(f'{width} no page exceptions',not err)
  p.close()
 b.close()
(R/'tests/CHALLENGE-PRESETS.json').write_text(json.dumps({'passed':sum(x['pass'] for x in tests),'total':len(tests),'failed':[x for x in tests if not x['pass']],'checks':tests},indent=2))
print('FINAL',sum(x['pass'] for x in tests),'/',len(tests))
