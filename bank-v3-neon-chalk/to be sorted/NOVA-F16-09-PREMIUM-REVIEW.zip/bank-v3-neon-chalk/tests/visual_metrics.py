from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1];html=(R/'F16/F16-09-grouped-frequency.html').read_text();rows=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  pg=b.new_page(viewport={'width':width,'height':975},reduced_motion='reduce');err=[];pg.on('pageerror',lambda e:err.append(str(e)));pg.set_content(html)
  for key in ['y8-tables','y8-mean','y9-repr']:
   pg.locator('.nova-tab[data-m="explore"]').click();pg.locator('select[aria-label="Lesson preset"]').select_option(key)
   for mode in ['watch','guided','explore','challenge']:
    pg.locator(f'.nova-tab[data-m="{mode}"]').click();pg.wait_for_timeout(35)
    m=pg.evaluate('''()=>{let s=document.querySelector('.nova-stage .f169-svg'),st=document.querySelector('.nova-stage');return {pct:+(s.getBoundingClientRect().height/st.getBoundingClientRect().height*100).toFixed(1),overflow:document.documentElement.scrollWidth-innerWidth,mascots:st.querySelectorAll('.nv-dock').length,svg:s?1:0};}''')
    rows.append({'width':width,'preset':key,'mode':mode,**m,'errors':err[:]})
  pg.close()
 b.close()
shots=sorted(x.name for x in (R/'shots').glob('F16-09-*.png'))
result={'viewChecks':rows,'screenshots':shots,'counts':{'views':len(rows),'screenshots':len(shots),'browserErrors':sum(len(x['errors']) for x in rows),'minMobileCoverage':min(x['pct'] for x in rows if x['width']==380),'noOverflow':all(x['overflow']<=2 for x in rows),'singleMascot':all(x['mascots']==1 for x in rows)}}
(R/'tests/VISUAL-RESULTS.json').write_text(json.dumps(result,indent=2));print(result['counts'])
