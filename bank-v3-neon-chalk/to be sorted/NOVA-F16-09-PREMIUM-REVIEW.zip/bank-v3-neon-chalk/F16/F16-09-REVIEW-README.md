# NOVA Maths V2 — F16-09 Grouped Frequency

**PREMIUM REVIEW · NOT GOLD**

Open `F16/F16-09-grouped-frequency.html` in your browser without a server or any external dependencies.

**Purpose:** Construct grouped frequency tables and matching frequency diagrams; estimate a mean using frequency-weighted class midpoints, explicitly distinguishing an estimate from the exact mean of original observations.

**Presets:** Y8-064 Grouped frequency tables; Y8-065 Estimating the mean from grouped data; Y9-047 Grouped data representations. All use non-overlapping half-open class intervals (lower inclusive, upper exclusive).

**Modes:** Watch (9 named steps with playback, pause, rewind, scrub and narration slots); Guided (9 scaffolds); Explore (mouse/touch drag transfer between table frequency rows, bar-height manipulation, red removal, arrow key/selector equivalents); Challenge (repair a grouped table, identify midpoint, calculate approximate weighted mean, with misconception-specific feedback).

**Maths key:** for each class [a,b), frequency f, midpoint m=(a+b)/2. Total sample count N=Σf. Grouped mean estimate =Σ(fm)/N. With individual scores unavailable, the estimate is not exact. The Year 9 preset estimates 390/16 = 24.375, displayed 24.38.

**Related engines:** F16-02 bar chart, F16-07 Mean Explorer, F16-12 histogram, F0/F2 shared foundations.

**Offline reproduction:** Run `python3 build/build-f16-09.py`. The build script verifies the two exact pinned shared-core SHA-256 hashes and regenerates the standalone. No GitHub access or modification.

**QA:** `F16/F16-09-QA.md`, test scripts/results in `tests/`, and 42 actual review screenshots in `shots/`. This pack does not include or update unrelated component families.
