# F16-02 — Bar Chart Builder (Premium Review)

Open `F16-02-bar-chart-builder.html` directly in a browser, offline. It is a self-contained HTML.

Use the Watch, Guided, Explore and Challenge tabs. In Explore, switch lessons between Y7-066 and Y7-071, drag bars by their glowing top grips, try the numeric keyboard controls, and compare 0 versus 4 frequency baselines. In Challenge, complete all three questions.

The ZIP contains only this component, its editable source and build files, 14 browser screenshots, and QA evidence. It has no third-party libraries and makes no GitHub changes. No GOLD approval is claimed.

Build note: `build/build-f16-02.py` expects the existing locked F2-03 file in your local checkout and verifies its shared-runtime hashes. Do not bypass the hash guard; if F2-03 does not match, inspect with the owner before updating the build source.
