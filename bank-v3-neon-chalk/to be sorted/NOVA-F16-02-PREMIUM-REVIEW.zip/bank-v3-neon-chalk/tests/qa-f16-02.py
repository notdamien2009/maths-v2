from playwright.sync_api import sync_playwright
from pathlib import Path
import json,traceback,time
ROOT=Path(__file__).resolve().parent;HTML=(ROOT.parent/'F16'/'F16-02-bar-chart-builder.html').read_text();checks=[]
def test(name,condition,extras=''):
 ok=bool(condition);checks.append({'name':name,'pass':ok,'extra':extras});print(('PASS' if ok else 'FAIL'),name,extras,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  pg=b.new_page(viewport={'width':width,'height':1000},device_scale_factor=1,reduced_motion='reduce')
  errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(HTML,wait_until='load',timeout=90000);pg.wait_for_timeout(200)
  tabs=['watch','guided','explore','challenge']
  for mode in tabs:
   pg.locator('.nova-tab[data-m="'+mode+'"]').click();pg.wait_for_timeout(100)
   svg=pg.locator('.f16b-plot');meta=pg.evaluate('''()=>({overflow:document.documentElement.scrollWidth>innerWidth,stageMascots:document.querySelectorAll('.nova-stage .nv-dock').length,chart:document.querySelectorAll('.f16b-plot').length,font:getComputedStyle(document.documentElement).getPropertyValue('--nova-font-chalk-draw')})''')
   test(f'{width} {mode} one chart',meta['chart']==1)
   test(f'{width} {mode} one mascot inside stage',meta['stageMascots']==1)
   test(f'{width} {mode} horizontal overflow absent',not meta['overflow'])
   pg.screenshot(path=str(ROOT.parent/'shots'/'F16-02'/f'F16-02-{width}-{mode}.png'),full_page=True)
  # teaching Watch step rendering
  pg.locator('.nova-tab[data-m="watch"]').click();pg.wait_for_timeout(80)
  for i in range(8):
   pg.evaluate(f'window.F16_02.timeline.pause();window.F16_02.timeline.go({i},"test")');pg.wait_for_timeout(30)
   count=pg.locator('.f16b-plot [data-bar]').count()
   test(f'{width} watch step {i} bar count',count==max(0,min(4,i-1)),f'actual {count}')
  pg.locator('.nova-tab[data-m="explore"]').click();pg.wait_for_timeout(120)
  for name in ['books','mislead']:
   pg.locator('select[aria-label="Statistics preset"]').select_option(name)
   vals=pg.evaluate('window.NOVA_F16_02_CONFIG._explore.values()');expected=pg.evaluate(f'NOVA_F16_02_CONFIG.presets.{name}.values')
   test(f'{width} {name} original values',vals==expected)
   test(f'{width} {name} four glass bars',pg.locator('.f16b-plot [data-bar]').count()==4)
   test(f'{width} {name} four mouse handles',pg.locator('.f16b-plot [data-bar-handle]').count()==4)
  pg.locator('select[aria-label="Statistics preset"]').select_option('books')
  pg.locator('select[aria-label="Bar-chart baseline"]').select_option('4')
  test(f'{width} cropped baseline 4',pg.evaluate('NOVA_F16_02_CONFIG._explore.baseline()')==4)
  pg.locator('select[aria-label="Bar-chart baseline"]').select_option('0')
  test(f'{width} honest baseline 0',pg.evaluate('NOVA_F16_02_CONFIG._explore.baseline()')==0)
  pg.locator('select[aria-label="Choose bar"]').select_option('0')
  pg.locator('input[aria-label="Set exact frequency"]').fill('8')
  pg.get_by_role('button',name='Set height').click()
  test(f'{width} numeric frequency edit',pg.evaluate('NOVA_F16_02_CONFIG._explore.values()')[0]==8)
  pg.get_by_role('button',name='Increase +1').click()
  test(f'{width} increase frequency button',pg.evaluate('NOVA_F16_02_CONFIG._explore.values()')[0]==9)
  pg.get_by_role('button',name='Decrease −1').click()
  test(f'{width} decrease frequency button',pg.evaluate('NOVA_F16_02_CONFIG._explore.values()')[0]==8)
  pg.get_by_role('button',name='Reset chart').click()
  test(f'{width} reset frequency edit',pg.evaluate('NOVA_F16_02_CONFIG._explore.values()')[0]==6)
  # actual mouse grip drag; convert SVG viewBox to screen coords
  def drag(bar_index, value, step_count=12):
   pg.evaluate('''()=>window.scrollTo(0,document.querySelector('.f16b-plot').getBoundingClientRect().top+window.scrollY-115)''')
   handle=pg.locator(f'.f16b-plot [data-bar-handle="{bar_index}"]');bd=handle.bounding_box();sr=pg.locator('.f16b-plot').bounding_box();assert bd and sr
   mobile=width==380;W=450 if mobile else 770;H=740 if mobile else 650;T=156 if mobile else 122;PH=395 if mobile else 390
   xmin=0;xmax=12;current=pg.evaluate('NOVA_F16_02_CONFIG._explore.values()')[bar_index]
   cx=bd['x']+bd['width']/2;cy=bd['y']+bd['height']/2
   y=T+PH-(value/12)*PH
   px=sr['x']+(66+(bar_index+.5)/4*354 if mobile else 112+(bar_index+.5)/4*565)/W*sr['width'];py=sr['y']+(y/H)*sr['height']
   pg.mouse.move(cx,cy);pg.mouse.down();pg.mouse.move(px,py,steps=step_count);pg.mouse.up();pg.wait_for_timeout(460)
  drag(0,10)
  test(f'{width} native pointer drag 6 to 10',pg.evaluate('NOVA_F16_02_CONFIG._explore.values()')[0]==10)
  drag(0,5,1)
  test(f'{width} fast native pointer drag 10 to 5',pg.evaluate('NOVA_F16_02_CONFIG._explore.values()')[0]==5)
  test(f'{width} no active drag after mouseup',pg.evaluate('NOVA.ui._drag===null'))
  # Escape cancels drag
  pg.evaluate("window.scrollTo(0,document.querySelector('.f16b-plot').getBoundingClientRect().top+window.scrollY-115)")
  bd=pg.locator('[data-bar-handle="1"]').bounding_box();pg.mouse.move(bd['x']+bd['width']/2,bd['y']+bd['height']/2);pg.mouse.down();pg.mouse.move(bd['x']+20,bd['y']-55,steps=4);pg.keyboard.press('Escape');pg.mouse.up();pg.wait_for_timeout(350)
  test(f'{width} Escape clears active pointer',pg.evaluate('NOVA.ui._drag===null'))
  test(f'{width} Escape preserves frequency',pg.evaluate('NOVA_F16_02_CONFIG._explore.values()')[1]==9)
  # Keyboard arrows on bar handle
  pg.locator('[data-bar-handle="2"]').focus();pg.keyboard.press('ArrowUp');pg.wait_for_timeout(60)
  test(f'{width} keyboard arrow increases frequency',pg.evaluate('NOVA_F16_02_CONFIG._explore.values()')[2]==5)
  # Challenge path
  pg.locator('.nova-tab[data-m="challenge"]').click();pg.wait_for_timeout(120)
  pg.locator('input[aria-label="Set challenge bar frequency"]').fill('1');pg.get_by_role('button',name='Apply value').click();pg.get_by_role('button',name='Check').click();pg.wait_for_timeout(100)
  feedback=pg.locator('.nova-fb.bad').first.text_content() or ''
  test(f'{width} wrong challenge feedback',bool(feedback) and ('bar' in feedback.lower() or 'interval' in feedback.lower()))
  pg.locator('input[aria-label="Set challenge bar frequency"]').fill('6');pg.get_by_role('button',name='Apply value').click();pg.get_by_role('button',name='Check').click();pg.wait_for_timeout(1000)
  test(f'{width} correct challenge advances',pg.locator('.pr-task').inner_text().startswith('In the shown graph'))
  pg.locator('.rs-opts button').first.click();pg.get_by_role('button',name='Check').click();pg.wait_for_timeout(1000)
  test(f'{width} cropped-axis critique advances','difference between' in pg.locator('.pr-task').inner_text())
  inp=pg.locator('.pr-task').locator('xpath=..').locator('input').first
  # Generic find numeric field within challenge ctl and avoid entering control input
  fields=pg.locator('.nova-panel input'); print('input list',[x.get_attribute('aria-label') for x in fields.all()],flush=True)
  answer=pg.locator('.nova-panel input').last;answer.fill('5');pg.get_by_role('button',name='Check').click();pg.wait_for_timeout(160)
  test(f'{width} correct greatest-minus-least accepted',pg.locator('.nova-fb.ok').count()>=1)
  test(f'{width} zero page errors',len(errors)==0,str(errors[-3:]))
  pg.close()
 b.close()
ROOT.joinpath('test-results.json').write_text(json.dumps({'total':len(checks),'passed':sum(x['pass'] for x in checks),'failed':[x for x in checks if not x['pass']],'checks':checks},indent=2))
print('TOTAL',sum(x['pass'] for x in checks),'/',len(checks),flush=True)
