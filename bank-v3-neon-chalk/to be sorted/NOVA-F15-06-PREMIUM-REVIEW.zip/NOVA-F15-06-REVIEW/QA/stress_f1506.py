from playwright.sync_api import sync_playwright
from pathlib import Path
import math,json
HTML=Path('/mnt/data/NOVA-F15-06-Trig-Ratio-Builder.html').read_text()
results=[]
def ck(w,name,cond,detail=''):
 results.append({'width':w,'name':name,'pass':bool(cond),'detail':str(detail)[:180]});print(('PASS' if cond else 'FAIL'),w,name,str(detail)[:90],flush=True)
with sync_playwright() as p:
 br=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  page=br.new_page(viewport={'width':width,'height':900},reduced_motion='reduce',device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(HTML,wait_until='load')
  root=page.locator('#F15-06')
  def mode(name):root.locator('.nova-tabs button').filter(has_text=name).first.click();page.wait_for_timeout(70)
  def state():return page.evaluate('NOVA_F15_06_CONFIG._explore.state()')
  def svgpt(x,y):return page.evaluate('''([x,y])=>{let s=document.querySelector('#F15-06 svg.f156-svg');let p=s.createSVGPoint();p.x=x;p.y=y;let q=p.matrixTransform(s.getScreenCTM());return {x:q.x,y:q.y}}''',[x,y])
  # Mathematical independent truth checks, all named presets.
  for name in page.evaluate('Object.keys(NOVA_F15_06_CONFIG.presets)'):
   m=page.evaluate('''name => {const st=NOVA_F15_06_CONFIG.presets[name];return {st:st, v:NOVA_F15_06_MATH.values(st), sol:NOVA_F15_06_MATH.calculate(st)}}''',name)
   st=m['st'];v=m['v'];a=st['a'];o=st['o'];h=math.hypot(a,o)
   ok=abs(v['h']-h)<1e-8 and abs(v['sin']-o/h)<1e-8 and abs(v['cos']-a/h)<1e-8 and abs(v['tan']-o/a)<1e-8 and abs(v['theta']-math.degrees(math.atan2(o,a)))<1e-8
   ck(width,'preset '+name+' independent trigonometry',ok)
  mode('Explore')
  ck(width,'explore 3 draggable roles',root.locator('[data-label]').count()==3)
  ck(width,'explore 2 constrained vertices',root.locator('[data-handle]').count()==2)
  st=state()
  angle0=math.degrees(math.atan2(st['o'],st['a']))
  ck(width,'initial θ exact',abs(page.evaluate('NOVA_F15_06_MATH.values(NOVA_F15_06_CONFIG._explore.state()).theta')-angle0)<1e-9)
  # key equivalent + constrained geometry
  handle=root.locator('[data-handle="a"]');handle.focus();page.keyboard.press('ArrowRight');page.wait_for_timeout(60)
  st=state();ck(width,'keyboard right increases adjacent by .5',abs(st['a']-4.5)<.001,st['a'])
  page.keyboard.press('ArrowLeft');page.wait_for_timeout(60)
  ck(width,'keyboard left returns side',abs(state()['a']-4)<.001,state()['a'])
  # Real pointer drag one .5 increment; a constant scale across all snap values.
  handle=root.locator('[data-handle="a"]');handle.scroll_into_view_if_needed();page.wait_for_timeout(60)
  rect=handle.bounding_box();pos={'x':rect['x']+rect['width']/2,'y':rect['y']+rect['height']/2}
  sc=min((245 if width==380 else 328)/6,(240 if width==380 else 286)/5)
  start=svgpt(105+4*sc,363 if width==380 else 354)
  end=svgpt(105+4.5*sc,363) if width==380 else svgpt(150+4.5*sc,354)
  # Use target based on genuine rendered handle centre rather than hard coded scaling.
  stepPx=abs(svgpt((105 if width==380 else 150)+4.5*sc,363 if width==380 else 354)['x']-svgpt((105 if width==380 else 150)+4*sc,363 if width==380 else 354)['x'])
  page.mouse.move(pos['x'],pos['y']);page.mouse.down();page.mouse.move(pos['x']+stepPx,pos['y'],steps=1);page.mouse.up();page.wait_for_timeout(150)
  ck(width,'actual fast pointer drag adjacent +.5',abs(state()['a']-4.5)<.001,state()['a'])
  ck(width,'no pointer drag stranded',page.evaluate('NOVA.ui._drag===null'))
  # invalid outside drop resets safely
  handle=root.locator('[data-handle="a"]');handle.scroll_into_view_if_needed();rect=handle.bounding_box();pos={'x':rect['x']+rect['width']/2,'y':rect['y']+rect['height']/2};old=state()['a']
  page.mouse.move(pos['x'],pos['y']);page.mouse.down();page.mouse.move(pos['x']+140,pos['y']-90,steps=1);page.mouse.up();page.wait_for_timeout(90)
  ck(width,'off-axis drop springs back',abs(state()['a']-old)<.0001,state()['a'])
  ck(width,'invalid drop no detached object',page.evaluate('NOVA.ui._drag===null') and root.locator('[data-handle="a"]').count()==1)
  # real mouse role card -> correct side
  initial=state()
  sc=min((245 if width==380 else 328)/6,(240 if width==380 else 286)/5)
  x0=105 if width==380 else 150;y0=363 if width==380 else 354
  oppTarget=svgpt(x0,y0-initial['o']*sc/2)
  label=root.locator('[data-label="opp"]');label.scroll_into_view_if_needed();rect=label.bounding_box();start={'x':rect['x']+rect['width']/2,'y':rect['y']+rect['height']/2}
  page.mouse.move(start['x'],start['y']);page.mouse.down();page.mouse.move(oppTarget['x'],oppTarget['y'],steps=1);page.mouse.up();page.wait_for_timeout(125)
  ck(width,'real mouse places opposite label',state()['placed'].get('opp')==True,state()['placed'])
  ck(width,'placed card can be regrabbed',root.locator('[data-label="opp"]').count()==1)
  # Wrong-side invalid drop should not place other label
  label=root.locator('[data-label="adj"]');label.scroll_into_view_if_needed();rect=label.bounding_box();start={'x':rect['x']+rect['width']/2,'y':rect['y']+rect['height']/2}
  hyp=svgpt((x0+(x0+initial['a']*sc))/2,(y0+y0-initial['o']*sc)/2)
  page.mouse.move(start['x'],start['y']);page.mouse.down();page.mouse.move(hyp['x'],hyp['y'],steps=1);page.mouse.up();page.wait_for_timeout(110)
  ck(width,'wrong side not accepted',not state()['placed'].get('adj',False),state()['placed'])
  # Escape cancellation, and keyboard correct placement
  label=root.locator('[data-label="hyp"]');label.scroll_into_view_if_needed();rect=label.bounding_box();start={'x':rect['x']+rect['width']/2,'y':rect['y']+rect['height']/2}
  page.mouse.move(start['x'],start['y']);page.mouse.down();page.mouse.move(start['x']-35,start['y']-50,steps=2);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(90)
  ck(width,'Escape returns card',not state()['placed'].get('hyp',False) and page.evaluate('NOVA.ui._drag===null'))
  root.locator('[data-label="hyp"]').focus();page.keyboard.press('Enter');page.wait_for_timeout(80)
  ck(width,'keyboard side card places target',state()['placed'].get('hyp')==True)
  root.locator('[data-label="hyp"]').focus();page.keyboard.press('Enter');page.wait_for_timeout(80)
  ck(width,'keyboard side card unplaces target',state()['placed'].get('hyp')==False)
  # preset selection and all ratio selectors
  allP=page.evaluate('Object.keys(NOVA_F15_06_CONFIG.presets)')
  for k in allP:
   page.evaluate('''k=>NOVA_F15_06_CONFIG._explore.select(k)''',k);page.wait_for_timeout(20)
   st=state();ck(width,'selector '+k+' changes exact preset',abs(st['a']-page.evaluate('k=>NOVA_F15_06_CONFIG.presets[k].a',k))<1e-8)
  for ratio in ['sin','cos','tan']:
   page.evaluate('''k=>NOVA_F15_06_CONFIG._explore.ratio(k)''',ratio)
   ck(width,'ratio selector '+ratio,state()['target']==ratio)
  mode('Challenge')
  for i in range(8):
   q=page.evaluate('i=>NOVA_F15_06_CONFIG._challengeQuestions[i]',i)
   ck(width,'challenge '+str(i+1)+' correct',page.evaluate('''i=>{let q=NOVA_F15_06_CONFIG._challengeQuestions[i];return NOVA_F15_06_CONFIG._check(q,q.ans)[0]}''',i))
  ck(width,'challenge misconception ratio swap',page.evaluate('''()=>{let q=NOVA_F15_06_CONFIG._challengeQuestions[0];let r=NOVA_F15_06_CONFIG._check(q,.8);return !r[0] && r[1].includes('cosine')}'''))
  ck(width,'challenge wrong hypotenuse operator',page.evaluate('''()=>{let q=NOVA_F15_06_CONFIG._challengeQuestions[7];let r=NOVA_F15_06_CONFIG._check(q,3);return !r[0] && r[1].includes('multiplied')}'''))
  ck(width,'no JS errors',len(errors)==0,errors[:2]);page.close()
 br.close()
summary={'passed':sum(x['pass'] for x in results),'failed':sum(not x['pass'] for x in results),'results':results}
Path('/mnt/data/f15-reference/stress_f1506_results.json').write_text(json.dumps(summary,indent=2))
print('TOTAL',summary['passed'],summary['failed'],flush=True)
