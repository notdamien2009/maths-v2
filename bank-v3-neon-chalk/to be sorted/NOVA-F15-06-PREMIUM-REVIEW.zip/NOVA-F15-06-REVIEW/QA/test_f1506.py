from playwright.sync_api import sync_playwright
from pathlib import Path
import json,math
p='http://127.0.0.1:8765/NOVA-F15-06-Trig-Ratio-Builder.html'
results=[]
with sync_playwright() as pl:
 b=pl.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':850},device_scale_factor=1, reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(Path('/mnt/data/NOVA-F15-06-Trig-Ratio-Builder.html').read_text(),wait_until='load');page.wait_for_timeout(250)
  def test(label,ok):results.append({'width':width,'test':label,'ok':bool(ok)})
  test('loads',bool(page.locator('#F15-06').count()))
  test('correct original mascot dock',page.locator('#F15-06 .nv-dock').count()==1)
  test('math core accessible',page.evaluate('typeof NOVA.ui.svgDrag')=='function')
  test('trig identities and 3 4 5',page.evaluate('NOVA_F15_06_MATH.verify(4,3) && Math.abs(NOVA_F15_06_MATH.values({a:4,o:3}).sin-.6)<1e-9'))
  for m in ['Guided','Explore','Challenge','Watch']:
   loc=page.locator('#F15-06 .nova-tabs button')
   # buttons may have odd icons
   print(width,'tabs',loc.all_text_contents()) if m=='Guided' else None
   loc.filter(has_text=m).first.click(force=True)
   page.wait_for_timeout(250)
   test('mode '+m,page.locator('#F15-06 .nova-stage svg.f156-svg').count()==1)
   test('mascot '+m,page.locator('#F15-06 .nv-dock').count()==1)
   page.screenshot(path=f'/mnt/data/f15-reference/F15-06-{width}-{m.lower()}.png',full_page=True,animations='disabled',timeout=15000)
   if m=='Explore':
    test('explore labels',page.locator('[data-label]').count()==3)
    test('explore handles',page.locator('[data-handle]').count()==2)
    test('explore values',page.evaluate('NOVA_F15_06_CONFIG._explore.state().a')==4)
   if m=='Challenge':
    test('challenge 8 tasks',page.evaluate('NOVA_F15_06_CONFIG._challengeQuestions.length')==8)
    test('challenge checks',page.evaluate('NOVA_F15_06_CONFIG._challengeQuestions.every(q => NOVA_F15_06_CONFIG._check(q,q.ans)[0])'))
  test('no browser JS errors',not errors)
  print(width,'errors',errors[:8]);page.close()
 b.close()
Path('/mnt/data/f15-reference/test_f1506_results.json').write_text(json.dumps({'passed':sum(x['ok'] for x in results),'failed':sum(not x['ok'] for x in results),'results':results},indent=2))
print('RESULT',sum(x['ok'] for x in results),sum(not x['ok'] for x in results))
