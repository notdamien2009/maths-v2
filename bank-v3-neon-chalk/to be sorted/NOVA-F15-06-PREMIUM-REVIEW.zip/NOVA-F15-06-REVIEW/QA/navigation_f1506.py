from playwright.sync_api import sync_playwright
from pathlib import Path
import json,time
S=Path('/mnt/data/NOVA-F15-06-Trig-Ratio-Builder.html').read_text()
log=[]
def note(w,t,ok,detail=''):
 log.append({'width':w,'task':t,'pass':bool(ok),'detail':str(detail)[:240]}); print(w,('PASS' if ok else 'FAIL'),t,str(detail)[:100],flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  pg=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce')
  errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));pg.set_content(S)
  root=pg.locator('#F15-06');root.locator('.nova-tabs button').filter(has_text='Guided').click();pg.wait_for_timeout(65)
  for i in range(12):
   pg.evaluate('i=>window.F15_06.timeline.go(i,"qa")',i);pg.wait_for_timeout(20)
   svg=root.locator('.nova-stage svg.f156-svg')
   note(width,'guided state '+str(i+1),svg.count()==1 and root.locator('.nv-dock').count()==1 and pg.evaluate('F15_06.timeline.i')==i)
  note(width,'12-step named narration and prompts',pg.evaluate('NOVA_F15_06_CONFIG.startMode==="watch" && window.F15_06.timeline.steps.every(s=>s.name && s.narration && s.prompt)'))
  # challenge real answer form submission
  root.locator('.nova-tabs button').filter(has_text='Challenge').click();pg.wait_for_timeout(75)
  for i in range(8):
   q=pg.evaluate('i=>NOVA_F15_06_CONFIG._challengeQuestions[i]',i)
   inputs=root.locator('input')
   note(width,'question '+str(i+1)+' has input',inputs.count()>=1)
   inp=inputs.last
   inp.fill(str(q['ans']));
   # Feedback and automatic progression are checked after real DOM submission.
   btn=root.locator('button').filter(has_text='Check').first
   btn.click();pg.wait_for_timeout(860 if i<7 else 115)
   k=pg.evaluate('NOVA_F15_06_CONFIG._challenge.task()')
   note(width,'actual DOM submit '+str(i+1),k==min(i+1,7),k)
  root.locator('.nova-tabs button').filter(has_text='Watch').click();pg.wait_for_timeout(70)
  note(width,'Watch exposes scrub control',root.locator('input[type=range]').count()>=1)
  note(width,'Watch timeline has play/pause/reset',hasattr(None,'nonexistent') or pg.evaluate('''()=>{let t=F15_06.timeline;return typeof t.play==='function'&&typeof t.pause==='function'&&typeof t.reset==='function'&&typeof t.scrubTo==='function'}'''))
  # cancellation by browser pointercancel under direct actual event.
  root.locator('.nova-tabs button').filter(has_text='Explore').click();pg.wait_for_timeout(70)
  ell=root.locator('[data-label=adj]');ell.scroll_into_view_if_needed();r=ell.bounding_box();pg.mouse.move(r['x']+r['width']/2,r['y']+r['height']/2);pg.mouse.down();pg.mouse.move(r['x']+r['width']/2+28,r['y']+r['height']/2-25,steps=1)
  pg.evaluate('''()=>{document.dispatchEvent(new PointerEvent('pointercancel',{pointerId:1,bubbles:true}))}''');pg.mouse.up()
  pg.wait_for_timeout(80)
  note(width,'pointercancel returns object',pg.evaluate('NOVA.ui._drag===null') and ell.count()==1)
  note(width,'page errors',not errors,errors[:2]);pg.close()
 b.close()
Path('/mnt/data/f15-reference/navigation_f1506_results.json').write_text(json.dumps({'passed':sum(x['pass'] for x in log),'failed':sum(not x['pass'] for x in log),'results':log},indent=2))
print('TOTAL',sum(x['pass'] for x in log),sum(not x['pass'] for x in log))
