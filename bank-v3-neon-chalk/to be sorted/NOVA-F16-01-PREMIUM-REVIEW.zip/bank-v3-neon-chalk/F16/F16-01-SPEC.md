# NOVA Maths V2 · F16-01 — Exact component specification

**Family:** F16 Data and Statistics. **Component:** Tally, frequency table and pictogram.

**Maths purpose:** Collect one response at a time; group tally marks in fives; read a numeric frequency table; create pictograms from a scale/key; compare category frequencies and totals.

**Parameters:** Four category labels, whole-number observation frequencies, picture key = two observations, pictogram glyph type and narrative context. Half-symbols represent one observation with the key 2.

**Lesson presets:** Y7-065 collection and organisation (fruit); Y7-066 pictograms (books); Y7-068 stem-and-leaf data preparation (times grouped by tens); Y8-064 grouped frequency (reading minutes).

**Watch / Guided sequence:** Meet observations → Organise categories → Build tally groups → Write frequencies → Make the pictogram → Read and check. Narration and prompts are distinct per step.

**Explore interaction:** Drag four labelled observation cards from the tray into frequency-table rows. The shared F2 SVG drag kit controls pointer movement, target highlighting, snapping, removal and cancellation. The component reasserts capture after SVG reparenting, and provides keyboard row-select and return controls. An observation card increases a row count by exactly one. Each category row can hold one additional card; drops onto an occupied row are rejected safely.

**Challenge:** Place one response in its correct row; interpret 5+2 tally marks; calculate three-and-a-half symbols for frequency seven with key two. Errors explain the specific misconception.

**Extension:** Grouped-frequency preparation for KS3/GCSE; linked components F0-02, F0-03, F0-04, F0-15, F16-02, F16-05, F16-09.

**Authority:** Repository master `00-master/NOVA-MASTER-FOR-OTHER-AI.md`, Family F16, F16-01. Shared runtime extracted unmodified from the F14-01 review standalone, independently identified in the F14 family audit as byte-identical to F2-03's JS core. No GitHub changes.
