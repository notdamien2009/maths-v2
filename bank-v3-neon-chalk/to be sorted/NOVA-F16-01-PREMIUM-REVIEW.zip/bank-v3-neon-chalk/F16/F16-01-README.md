# F16-01 Premium Review Pack

Open `F16/F16-01-tally-frequency-pictogram.html` in the browser. It is a self-contained review build using the established F0/F2 shared NOVA engine; no internet required.

Use the four tabs Watch, Guided, Explore and Challenge. Explore supplies four lesson presets. Drag labelled observations to rows; once placed, drag the same card to another row or to the red Remove tray; keyboard alternatives sit below the stage. Check the odd-frequency preset's half pictogram symbols.

`F16/F16-01-SPEC.md` maps the master specification to the implementation. `F16/F16-01-QA.md` records tests, result files and screenshots. `src/F16-01.js` and `src/F16-01.css` are the component-specific additions; the standalone itself contains the full unchanged shared runtime, Chalk font definitions and helper assets.

**Owner review is required. NOT GOLD APPROVED.** No GitHub files have been changed.
