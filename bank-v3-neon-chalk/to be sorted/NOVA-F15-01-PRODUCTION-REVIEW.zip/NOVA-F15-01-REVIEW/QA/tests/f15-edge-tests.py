from pathlib import Path
from playwright.sync_api import sync_playwright
import json,os
html=Path('/mnt/data/F15-01-pythagoras-squares-on-sides-PREMIUM-REVIEW.html').read_text();r=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium')
 for w in (380,1280):
  page=b.new_page(viewport={'width':w,'height':950},reduced_motion='reduce');page.set_default_timeout(3500);page.set_content(html);page.get_by_role('tab',name='Explore').click()
  def start():
   page.locator('.nova-panel button',has_text='Reset').click()
   g=page.locator('[data-handle="a"] .nv-hit');g.scroll_into_view_if_needed();bb=g.bounding_box();x=bb['x']+bb['width']/2;y=bb['y']+bb['height']/2
   page.mouse.move(x,y);page.mouse.down();assert page.evaluate('!!NOVA.ui._drag');return x,y
  x,y=start();page.mouse.move(x+144,y+82,steps=1);page.mouse.up();page.wait_for_timeout(100)
  z=page.evaluate('({a:NOVA_F15_01_CONFIG._explore.state().a,drag:!!NOVA.ui._drag,lifts:document.querySelectorAll(".nv-drag-lift").length})');r.append({'width':w,'test':'invalid drop resets','PASS':z['a']==3 and not z['drag'] and z['lifts']==0,'state':z})
  x,y=start();page.mouse.move(x+28,y,steps=1);page.evaluate("document.dispatchEvent(new PointerEvent('pointercancel',{bubbles:true,pointerId:1,clientX:0,clientY:0}))");page.mouse.up();page.wait_for_timeout(100)
  z=page.evaluate('({a:NOVA_F15_01_CONFIG._explore.state().a,drag:!!NOVA.ui._drag,lifts:document.querySelectorAll(".nv-drag-lift").length})');r.append({'width':w,'test':'pointercancel resets','PASS':z['a']==3 and not z['drag'] and z['lifts']==0,'state':z})
  x,y=start();page.mouse.move(x+50,y+50,steps=1);page.evaluate('window.dispatchEvent(new Event("blur"))');page.mouse.up();page.wait_for_timeout(150)
  z=page.evaluate('({a:NOVA_F15_01_CONFIG._explore.state().a,drag:!!NOVA.ui._drag,lifts:document.querySelectorAll(".nv-drag-lift").length})');r.append({'width':w,'test':'window blur resets','PASS':z['a']==3 and not z['drag'] and z['lifts']==0,'state':z})
  page.close()
 b.close()
Path('/mnt/data/f15-reference/edge-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
os._exit(0)
