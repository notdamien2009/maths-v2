from pathlib import Path
from playwright.sync_api import sync_playwright
import json, traceback, time
HTML=Path('/mnt/data/F15-01-pythagoras-squares-on-sides-PREMIUM-REVIEW.html').read_text()
results=[]

def t(name,fun):
 print("RUN",name,flush=True)
 try:
  v=fun();print('PASS',name,flush=True);results.append({'test':name,'status':'PASS','detail':v})
 except Exception as ex:
  results.append({'test':name,'status':'FAIL','detail':str(ex)[:350]})
  print('FAIL',name,str(ex)[:500])

def init(ctx):
 pg=ctx.new_page();pg.set_default_timeout(5000);pg.set_content(HTML,wait_until='load',timeout=20000);pg.wait_for_timeout(120);return pg
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in (380,1280):
  ctx=b.new_context(viewport={'width':width,'height':940},reduced_motion='reduce')
  pg=init(ctx);errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  def viewport_tests():
   for mode in ['Watch','Guided','Explore','Challenge']:
    pg.get_by_role('tab',name=mode).click();pg.wait_for_timeout(90)
    assert pg.locator('.nova-stage .f15-svg').count()==1,mode
    assert pg.locator('.nova-stage .nv-dock').count()==1,mode
    assert pg.locator('.nova-stage .nv-dockfig').count()==1,mode
    assert pg.locator('.nova-stage').locator('text').count()>0,mode
   assert not errs,errs
   return '4 modes, core helper dock exactly once, no page errors'
  t(f'{width}px · four modes',viewport_tests)
  def step_test():
   pg.get_by_role('tab',name='Guided').click()
   for k in range(10):
    pg.evaluate('(i)=>NOVA.engines["F15-01"].timeline.go(i,"qa")',k)
    assert pg.locator('.nova-stage .f15-svg').count()==1
    text=pg.locator('.nova-stage').inner_text()
    if k==8:assert 'a² + b² = c²' in text
    if k==7:assert 'Arrangement 2' in text
   assert not errs,errs
   return 'all 10 states; exact dissection two panels and identity visible'
  t(f'{width}px · all teaching states',step_test)
  def math_test():
   nums=[(3,4),(5,12),(8,15),(6,8),(2,3),(7,9)]
   for a,b in nums:
    z=pg.evaluate('([a,b])=>NOVA_F15_01_MATH.check(a,b)',[a,b]);assert z['correct'] and all(abs(z['areas'][i]-z['sideSquares'][i])<1e-8 for i in range(3)),[a,b,z]
   return f'{len(nums)} geometrically verified square constructions'
  t(f'{width}px · exact geometry',math_test)
  pg.get_by_role('tab',name='Explore').click()
  def presets():
   vals=[('y8areas',3,4),('y8lengths',5,12),('y9mastery',8,15)]
   for key,a,b in vals:
    pg.locator('.nova-panel select').select_option(key)
    st=pg.evaluate('NOVA_F15_01_CONFIG._explore.state()')
    assert st['a']==a and st['b']==b
    assert pg.locator('.nova-stage .f15-svg').count()==1
   pg.locator('.nova-panel select').select_option('y8areas')
   return '3 presets updated geometry and controls'
  t(f'{width}px · presets',presets)
  def keyboard():
   g=pg.locator('[data-handle="a"]');g.focus();g.press('ArrowRight')
   assert pg.evaluate('NOVA_F15_01_CONFIG._explore.state().a')==4
   pg.locator('[data-handle="b"]').focus();pg.keyboard.press('ArrowDown')
   assert pg.evaluate('NOVA_F15_01_CONFIG._explore.state().b')==3
   pg.locator('.nova-panel button',has_text='Reset').click()
   return 'both vertex handles with arrow keys; reset'
  t(f'{width}px · keyboard vertex controls',keyboard)
  def pointer_actual():
   pg.locator('.nova-panel button',has_text='Reset').click()
   target=pg.locator('[data-handle="a"] .nv-hit');target.scroll_into_view_if_needed();bb=target.bounding_box();assert bb, 'no draggable hit rect'
   x,y=bb['x']+bb['width']/2,bb['y']+bb['height']/2
   dy=0;dx=pg.evaluate('''()=>{let sv=document.querySelector('.nova-stage .f15-svg');let p=sv.createSVGPoint();p.x=0;p.y=0;let m=sv.getScreenCTM();return 30*m.a;}''')
   pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+dx,y+dy,steps=1);pg.mouse.up();pg.wait_for_timeout(300)
   st=pg.evaluate('NOVA_F15_01_CONFIG._explore.state()');assert st['a']==4,st
   assert pg.locator('.nv-drag-lift').count()==0
   return {'moved':st['a'],'mouse_pixels':round(dx,1),'stranded':0}
  t(f'{width}px · fast real mouse drag',pointer_actual)
  def cancel():
   pg.locator('.nova-panel button',has_text='Reset').click();g=pg.locator('[data-handle="a"] .nv-hit');g.scroll_into_view_if_needed();bb=g.bounding_box();x=bb['x']+bb['width']/2;y=bb['y']+bb['height']/2
   pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+80,y+15,steps=1);pg.keyboard.press('Escape');pg.mouse.up();pg.wait_for_timeout(300)
   assert pg.evaluate('NOVA_F15_01_CONFIG._explore.state().a')==3
   assert pg.locator('.nv-drag-lift').count()==0
   return 'Escape cancels drag; original value restored; 0 stranded'
  t(f'{width}px · Escape cancellation',cancel)
  def label_keyboard():
   pg.locator('.nova-panel button',has_text='Reset').click();g=pg.locator('[data-maths="label-card"]');g.focus();g.press('Enter')
   assert pg.evaluate('NOVA_F15_01_CONFIG._explore.state().placed')
   return 'label card Enter activates correct placement'
  t(f'{width}px · label placement keyboard',label_keyboard)
  def label_drag():
   pg.locator('.nova-panel button',has_text='Reset').click()
   pg.locator('[data-maths="label-card"] .nv-hit').scroll_into_view_if_needed();src=pg.locator('[data-maths="label-card"] .nv-hit').bounding_box();assert src
   dest=pg.locator('.nova-stage .f15-svg text').filter(has_text='c² = 25').first.bounding_box();assert dest
   x,y=src['x']+src['width']/2,src['y']+src['height']/2;tx,ty=dest['x']+dest['width']/2,dest['y']+dest['height']/2
   pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(tx,ty,steps=6);pg.mouse.up();pg.wait_for_timeout(280)
   assert pg.evaluate('NOVA_F15_01_CONFIG._explore.state().placed'),'label not accepted'
   assert pg.locator('.nv-drag-lift').count()==0
   return 'gold label dragged onto green square; snap; 0 stranded'
  t(f'{width}px · real mouse label drag',label_drag)
  def challenge():
   pg.get_by_role('tab',name='Challenge').click()
   inputs=['25','13','5',None,'100']
   for j,ans in enumerate(inputs):
    assert pg.locator('.nova-panel .pr-task').inner_text().strip()
    if ans is None:pg.locator('.nova-panel .rs-opts button').first.click()
    else:
     field=pg.locator('.nova-panel input').first;field.fill(ans)
    pg.locator('.nova-panel button',has_text='Check').first.click();pg.wait_for_timeout(1000 if j<4 else 200)
    assert 'bad' not in pg.locator('.nova-panel .nova-fb').last.get_attribute('class')
    assert not errs,errs
   return '5/5 official task answers checked via UI'
  t(f'{width}px · all five challenge checks',challenge)
  ctx.close()
 b.close()
print(json.dumps(results,indent=2))
Path('/mnt/data/f15-reference/stress-results.json').write_text(json.dumps(results,indent=2))
print('COUNTS',sum(z['status']=='PASS' for z in results),'PASS',sum(z['status']=='FAIL' for z in results),'FAIL')
