# NOVA Maths V2 — F15-01 Pythagoras Squares-on-Sides
## Review build QA · 13 October 2026

**Status: PRODUCTION REVIEW — NOT GOLD APPROVED.** All work was performed locally; no GitHub changes were made.

## Provenance and core integrity
- Read `bank-v3-neon-chalk/HANDOVER-v3.md` and the exact **F15-01 Pythagoras squares-on-sides** section of `00-master/NOVA-MASTER-FOR-OTHER-AI.md` through the private GitHub connector.
- The stylesheet and core script were extracted from the actual F14-01 review engine saved in the user's Library. The resulting F15 engine uses **the original F0/F2 inline NOVA shared core without changing the core script**.
- Independent cross-check: the embedded F15 shared core is byte-identical to the core embedded in Library `F2-03-base-ten-blocks.html`, SHA-256 `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc`.
- New component behaviour is contained in its second script; extra CSS only extends the established visual system. The F15-specific pointer bridge forwards trusted mouse pointer updates/releases to the original drag helper on browsers that lose pointer capture when the SVG group is reparented. No original core functions were overwritten.

## Mathematics & teaching
- Exact vertices: A=(0,0), B=(a,0), C=(0,b). Three external square polygons are constructed algorithmically and face outwards from their respective sides. The right-angle marker is at A.
- Square area construction compared against independent shoelace-formula polygon area across (3,4), (5,12), (8,15), (6,8), (2,3), (7,9): **all six confirmed** within numerical tolerance.
- The dissection proof uses two equally sized enclosing squares, both with sides a+b; each contains four congruent right triangles. One leaves a central c² square; the other leaves the a² and b² squares. Subtracting equal triangle areas proves a²+b²=c².
- Ten distinct teaching states, with narration slots, scaffolding and step-specific mascot messages. No artificial four-step limit.
- Three named curriculum presets: Y8-044 (3,4,5), Y8-045 (5,12,13), Y9-030 (8,15,17).
- Five tasks cover finding square area, computing hypotenuse, finding a shorter leg by subtraction, identifying the hypotenuse, and distinguishing length from square area. Specific feedback addresses the most relevant common mistakes.

## Browser checks performed
The automated scripts in `QA/tests` ran headless Chromium using Playwright at **380px** and **1280px**. The complete results and screenshots are in this review archive.

| Test at each width | 380px | 1280px |
|---|---|---|
| Four modes load and stage helper appears exactly once; no page errors | PASS | PASS |
| All 10 teaching states render and area proof is visible | PASS | PASS |
| Six exact geometry cases agree with independent area formula | PASS | PASS |
| All three lesson presets update their dimensions | PASS | PASS |
| Both vertex handles support keyboard movement and reset | PASS | PASS |
| Physical high-speed one-step mouse drag snaps a leg vertex | PASS | PASS |
| Escape during an active drag restores position (no orphan) | PASS | PASS |
| Keyboard Enter places c² label | PASS | PASS |
| Physical mouse drag places c² label on correct square | PASS | PASS |
| All five Challenge answers checked through actual UI | PASS | PASS |
| Invalid physical drop resets object cleanly | PASS | PASS |
| Browser-dispatched pointercancel restores object cleanly | PASS | PASS |
| Window blur dispatch restores object cleanly | PASS | PASS |

**Evidence totals:** 20/20 baseline checks; 6/6 additional cancellation and invalid-drop checks; **26/26 passing** across the two viewports. `pointercancel` and `blur` were dispatched programmatically; mouse drag and drop were conducted using Playwright's native mouse events. No untested device/browser support is claimed.

## Review screenshots
`380-{watch,guided,explore,challenge}.png`, `1280-{watch,guided,explore,challenge}.png`, `proof-380.png`, `proof-1280.png` are full-page captures. Proof screenshots show Guided state 9/10.

## Owner review / remaining checks
- Review the composition, glow balance, handwriting sizes and docked mascot on actual hardware against F2-03 and F14-01.
- Test fast finger dragging on a physical touch device (mouse drag was stress-tested, touch hardware not available in this environment).
- Test manual narration pacing, any final sound/voice selection, and lesson integration in NOVA.
- The component remains **for review** until explicitly approved by the user; do not call it GOLD.
