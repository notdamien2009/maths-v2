# NOVA Maths V2 — F14-08 Rotational Symmetry (Premium Review)

**Status:** Standalone review build, NOT GOLD-approved. GitHub was NOT touched.

## Canonical design and dependencies
Derived directly from the supplied F14-07 premium HTML, which embeds the F0/F2 NOVA shared core, fonts and mascot artwork. The current file is self-contained and uses `NOVA.svg.grid`, `NOVA.svg.axes`, `NOVA.neonPath`, `NOVA.neonRing`, `NOVA.chalkText`, `NOVA.ui.svgDrag`, `NOVA.motion`, `NOVA.scene.helperStrip` and `NOVA.bankMount`.

## Mathematics and lesson context
The target is **Y7-055 Symmetry**. Rotational symmetry order is the number of times a shape matches itself in a complete 360° turn; every shape has order at least one. The smallest positive matching angle is 360° divided by the order. The original shape stays fixed in blue under the movable green image. Validity is computed by rotating each vertex about the nominated centre and testing correspondence against the source vertices. This ensures the centre also matters.

## Components and modes
- **Watch:** 6 teaching steps: starting position, centre, predict a quarter-turn, animate 90°, count matching turns, generalise order.
- **Guided:** Named steps and individual Sir Bob teaching prompts, with stage controls.
- **Explore:** 10 geometries (square 4, non-square rectangle 2, equilateral triangle 3, pentagon 5, regular hexagon 6, parallelogram 2, kite 1, irregular L 1, 3-bladed spinner 3, shifted rectangle 2). Rotate by grabbing the green shape or gold dial; move the pivot; use slider (supports 72° pentagon), buttons, keyboard alternatives, reveal matching positions and reset.
- **Challenge:** 8 tasks covering order, smallest matching angle, order-one misconception, positioning a square by a precise quarter-turn and finding an off-origin centre.
- **GCSE extension:** symmetry order of regular polygons, rotation about off-origin centres and vertex-coordinate proof.

## Test evidence
- Browser regression at 380px and 1280px: **186 passed; 0 failed.** Includes all four modes, premium frame, one in-stage mascot, Chalk font, no horizontal overflow, exact order for all ten presets, 72° pentagon, slider/button/keyboard interactions, eight tasks and no browser script errors.
- Real mouse/pointer stress: **18 passed; 0 failed.** Includes dragging the rotation dial by 90°, dragging the centre by a grid square, dragging the green shape by a quarter-turn, Escape cancellation, release of pointer capture and no stranded drag.
- **Overall: 204 passed, 0 failed.**
- Visual evidence: `screenshots/F14-08-380-*.png` and `screenshots/F14-08-1280-*.png`, one screenshot per mode and width.
- Final HTML SHA256: `f76097e3d4873e2e8c0e7997c375e2179d331f0cc6446fcc30045be2479275a5`.

Automated results do not constitute owner approval. This component remains a review build until its visuals and interaction are approved by the owner.
