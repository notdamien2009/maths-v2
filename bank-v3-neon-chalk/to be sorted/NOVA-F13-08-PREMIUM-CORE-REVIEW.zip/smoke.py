from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent
src=(p/'F13-08-Cylinder-Unroll-PREMIUM-CORE.html').read_text()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for w in (1280,380):
  x=b.new_page(viewport={'width':w,'height':960});errs=[];x.on('pageerror',lambda e:errs.append(str(e)));x.set_content(src,wait_until='domcontentloaded',timeout=85000);x.wait_for_timeout(300)
  print('LOAD',w,'errs',errs,'tabs',x.locator('[role=tab]').all_inner_texts(),'stage',x.locator('.nova-stage').count(), 'paths',x.locator('[data-maths="true-cylinder-curved-surface"] path').count(),'NOVA',x.evaluate('!!NOVA.engines["F13-08"]'))
  x.evaluate('NOVA.engines["F13-08"].timeline.pause()')
  x.locator('.nova-stage').screenshot(path=str(p/'screenshots'/f'{w}-watch.png'),animations='disabled')
  x.get_by_role('tab',name='Explore').click();x.wait_for_timeout(170);x.get_by_role('button',name='Unroll net').click();x.wait_for_timeout(250)
  x.locator('.nova-stage').screenshot(path=str(p/'screenshots'/f'{w}-net.png'),animations='disabled')
  print('EXPL',w,'errs',errs,'unroll',x.evaluate('NOVA_F13_08_CONFIG._explore.state.unroll'),'overflow',x.evaluate('document.documentElement.scrollWidth-innerWidth'))
  x.close()
 b.close()
