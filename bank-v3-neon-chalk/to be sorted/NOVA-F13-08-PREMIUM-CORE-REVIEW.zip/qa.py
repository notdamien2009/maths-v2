from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,math
root=Path(__file__).resolve().parent
snap=root/'screenshots';snap.mkdir(exist_ok=True)
html=(root/'F13-08-Cylinder-Unroll-PREMIUM-CORE.html').read_text('utf-8')
base=(root/'source/approved-F13-07-base.html').read_text('utf-8')
R=[]
def check(label,passed):
 passed=bool(passed);R.append(dict(check=label,passed=passed))
 if not passed: print('FAIL:',label,flush=True)
 return passed
core=lambda x:x.split('<script>',1)[1].split('</script>',1)[0]
check('Original NOVA JS runtime is preserved exactly',core(html)==core(base))
check('Original NOVA CSS begins byte-identically',html.split('<style>',1)[1].startswith(base.split('<style>',1)[1].split('/* F13-07 local additions only;',1)[0]))
check('Rejected F13-07 component code removed',"var NOVA_F13_07_CONFIG=" not in html)
check('Only one F13-08 component',html.count('var NOVA_F13_08_CONFIG=')==1)
check('Original offline Chalk embedded', 'data:font/woff2;base64' in html)
check('Original offline mascot embedded', 'data:image/webp;base64' in html)
check('Source build output reproducible',html==__import__('subprocess').run(['python',str(root/'source/build.py')],capture_output=True,check=True).returncode*''+(root/'F13-08-Cylinder-Unroll-PREMIUM-CORE.html').read_text('utf-8'))
PRE={'classic':(2,3),'slender':(1,5),'wide':(3,2),'balanced':(2,2),'column':(2,5)}
CH=[(2,3,12,20),(3,2,12,30),(1,5,10,12)]
with sync_playwright() as pw:
 br=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  p=br.new_page(viewport={'width':width,'height':980});errors=[]
  p.on('pageerror',lambda e:errors.append(str(e)))
  p.set_content(html,wait_until='domcontentloaded',timeout=90000)
  p.evaluate('NOVA.engines["F13-08"].timeline.pause()')
  tag=f'{width}px'
  check(tag+' no startup JS errors',not errors)
  check(tag+' official NOVA runtime functions',p.evaluate('!!(NOVA.bankMount&&NOVA.chalkText&&NOVA.neonPath&&NOVA.f12&&NOVA.scene.helperStrip)'))
  check(tag+' official mascot asset data URL',p.evaluate('NOVA.helperImg("explain").src.startsWith("data:image/webp")'))
  check(tag+' chalk font available',p.evaluate('document.fonts.check("16px NOVA Chalk")'))
  check(tag+' official stage background',p.evaluate('getComputedStyle(document.querySelector(".nova-stage")).backgroundImage !== "none"'))
  check(tag+' mascot inside stage once',p.locator('.nova-stage .nv-dockfig').count()==1)
  check(tag+' speech bubble inside stage once',p.locator('.nova-stage .nv-dockbub').count()==1)
  check(tag+' no horizontal overflow',p.evaluate('document.documentElement.scrollWidth <= innerWidth'))
  check(tag+' cylinder curved surface exists',p.locator('.nova-stage [data-maths="true-cylinder-curved-surface"]').count()==1)
  check(tag+' TWO correct circular end entities',p.locator('[data-circle]').count()==2)
  # Watch steps are each a fully functional, unique state.
  for i in range(12):
   p.evaluate('(i)=>NOVA.engines["F13-08"].timeline.go(i,"QA")',i)
   check(tag+f' Watch {i+1} side surface present',p.locator('.nova-stage [data-maths="true-cylinder-curved-surface"]').count()==1)
   check(tag+f' Watch {i+1} two end caps present',p.locator('[data-circle]').count()==2)
   check(tag+f' Watch {i+1} dock stays singular',p.locator('.nova-stage .nv-dockfig').count()==1)
   check(tag+f' Watch {i+1} calculation stays present','TOTAL AREA' in p.locator('.f13c-svg').text_content())
   if i in (0,4,5,7,9,11) and width==1280:p.locator('.nova-stage').screenshot(path=str(snap/f'{width}-watch-{i+1}.png'),animations='disabled')
  p.get_by_role('tab',name='Guided').click()
  check(tag+' Guided mode remains mounted',p.locator('.nova-stage .f13c-svg').count()==1)
  p.get_by_role('tab',name='Explore').click()
  check(tag+' Explore exposes test state',p.evaluate('!!NOVA_F13_08_CONFIG._explore.state'))
  for name,(r,h) in PRE.items():
   p.locator('select[aria-label="Cylinder preset"]').select_option(name);p.wait_for_timeout(70)
   got=p.evaluate('(()=>{let s=NOVA_F13_08_CONFIG._explore.state;return [s.r,s.ht]})()')
   check(tag+' '+name+' preset exact dimensions',got==[r,h])
   cards=p.locator('.f12-strip .nv-ntile .mt').all_inner_texts()
   check(tag+' '+name+' three exact π area coefficients',cards==[str(2*r*h)+'π',str(2*r*r)+'π',str(2*r*(h+r))+'π'])
   attr=p.locator('[data-development-length]').first.get_attribute('data-development-length')
   check(tag+' '+name+' exact developed circumference',math.isclose(float(attr),2*math.pi*r,rel_tol=1e-12))
   if name in ('wide','slender') and width==1280:p.locator('.nova-stage').screenshot(path=str(snap/f'{width}-{name}-closed.png'),animations='disabled')
  p.locator('select[aria-label="Cylinder preset"]').select_option('classic');p.wait_for_timeout(60)
  p.get_by_role('button',name='Unroll net').click();p.wait_for_timeout(95)
  check(tag+' net opens to 100%',p.evaluate('NOVA_F13_08_CONFIG._explore.state.unroll')==100)
  check(tag+' flat rectangle uses ONE surface polygon',p.locator('[data-maths="true-cylinder-curved-surface"]>path').count()==1+2) # body + 2 edge paths
  check(tag+' both end caps are genuine circles',p.evaluate('(()=>[...document.querySelectorAll("[data-circle] ellipse")].every(e=>Math.abs(+e.getAttribute("rx")-+e.getAttribute("ry"))<.001))()'))
  # Exact closed-form measurements, from the rendered polygon and circles.
  measure=p.evaluate(r'''(()=>{let s=NOVA_F13_08_CONFIG._explore.state,body=document.querySelector('[data-maths="true-cylinder-curved-surface"] > path'),str=body.getAttribute('d');let a=[...str.matchAll(/(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/g)].map(x=>[+x[1],+x[2]]);let circles=[...document.querySelectorAll('[data-circle]')].map(g=>({name:g.dataset.circle,ellipse:g.querySelectorAll('ellipse')[1]}));return {r:s.r,h:s.ht,v:a,circles:circles.map(c=>({name:c.name,cx:+c.ellipse.getAttribute('cx'),cy:+c.ellipse.getAttribute('cy'),ry:+c.ellipse.getAttribute('ry')}))};})()''')
  v=measure['v']
  check(tag+' net rectangle contains four exact corners',len(v)>=4)
  if len(v)>=4:
   wpx=math.dist(v[0],v[1]);hpx=math.dist(v[1],v[2])
   check(tag+' flattened rectangle ratio equals 2πr/h',abs(wpx/hpx-2*math.pi*2/3)<.0002)
   check(tag+' top edge horizontal',abs(v[2][1]-v[3][1])<.001)
   check(tag+' bottom edge horizontal',abs(v[0][1]-v[1][1])<.001)
   caps={c['name']:c for c in measure['circles']}
   check(tag+' top circle tangent to rectangle',abs(caps['top']['cy']+caps['top']['ry']-v[2][1])<.02)
   check(tag+' bottom circle tangent to rectangle',abs(caps['bottom']['cy']-caps['bottom']['ry']-v[0][1])<.02)
  check(tag+' no mascot overlap on open net',p.locator('.nova-stage .nv-dockfig').count()==1)
  p.locator('.nova-stage').screenshot(path=str(snap/f'{width}-net.png'),animations='disabled')
  # Continuous shape: must never substitute a flat decorative image; all states keep the same SVG surface.
  slide=p.locator('input[aria-label="UNROLL (%)"]')
  for val in (15,35,55,75,90):
   slide.fill(str(val));slide.dispatch_event('input');p.wait_for_timeout(65)
   theta=float(p.locator('[data-retained-angle]').first.get_attribute('data-retained-angle'))
   ln=float(p.locator('[data-development-length]').first.get_attribute('data-development-length'))
   check(tag+f' {val}% cylinder arc retains exact material circumference',abs(ln-4*math.pi)<1e-9 and math.isclose(theta,2*math.pi*(1-val/100),abs_tol=1e-9))
   check(tag+f' {val}% both caps still present',p.locator('[data-circle]').count()==2)
  slide.fill('100');slide.dispatch_event('input');p.wait_for_timeout(70)
  p.locator('select[aria-label="Highlight cylinder surfaces"]').select_option('curved');p.wait_for_timeout(70)
  check(tag+' curved-only highlight fades caps',p.locator('[data-maths="two-congruent-end-circles"]').get_attribute('opacity')=='.19')
  p.locator('select[aria-label="Highlight cylinder surfaces"]').select_option('ends');p.wait_for_timeout(70)
  check(tag+' caps-only highlight fades shell',abs(float(p.locator('[data-maths="true-cylinder-curved-surface"]').get_attribute('opacity'))-.17)<1e-6)
  p.locator('select[aria-label="Highlight cylinder surfaces"]').select_option('all')
  grid=p.locator('input[aria-label="Show curved material grid"]')
  grid.uncheck();p.wait_for_timeout(75)
  check(tag+' grid checkbox hides material guides',p.evaluate('NOVA_F13_08_CONFIG._explore.state.seams')==False)
  grid.check();p.wait_for_timeout(75)
  check(tag+' grid checkbox restores material guides',p.evaluate('NOVA_F13_08_CONFIG._explore.state.seams')==True)
  p.locator('input[aria-label="RADIUS"]').fill('4');p.locator('input[aria-label="HEIGHT"]').fill('6');p.wait_for_timeout(80)
  check(tag+' radius height sliders update exact geometry',p.evaluate('(()=>{let s=NOVA_F13_08_CONFIG._explore.state;return [s.r,s.ht]})()')==[4,6])
  check(tag+' 4×6 exact total area coefficient 80', '80π' in p.locator('.nova-stage').inner_text())
  p.get_by_role('button',name='Reset',exact=True).click();p.wait_for_timeout(70)
  check(tag+' reset dimensions and fold',p.evaluate('(()=>{let s=NOVA_F13_08_CONFIG._explore.state;return [s.r,s.ht,s.unroll]})()')==[2,3,0])
  svg=p.locator('.f13c-svg');svg.scroll_into_view_if_needed();svg.focus();p.keyboard.press('ArrowRight');p.wait_for_timeout(75)
  check(tag+' keyboard Right opens cylinder 5%',p.evaluate('NOVA_F13_08_CONFIG._explore.state.unroll')==5)
  p.keyboard.press('End');p.wait_for_timeout(75)
  check(tag+' keyboard End fully unrolls',p.evaluate('NOVA_F13_08_CONFIG._explore.state.unroll')==100)
  p.keyboard.press('Home');p.wait_for_timeout(75)
  check(tag+' keyboard Home recloses',p.evaluate('NOVA_F13_08_CONFIG._explore.state.unroll')==0)
  svg.scroll_into_view_if_needed();bb=svg.bounding_box();x=bb['x']+bb['width']*.2;y=bb['y']+bb['height']*.25
  p.mouse.move(x,y);p.mouse.down()
  for i in range(35):p.mouse.move(x+bb['width']*.62*i/34,y)
  p.mouse.up();p.wait_for_timeout(90)
  check(tag+' high speed drag opens unroll',p.evaluate('NOVA_F13_08_CONFIG._explore.state.unroll')>50)
  check(tag+' fast drag terminates without stuck pointer','f13c-grab' not in (svg.get_attribute('class') or ''))
  p.get_by_role('tab',name='Challenge').click()
  check(tag+' Challenge asks two independent area coefficients',p.locator('.nova-panel input[type=number]').count()==2)
  inp=p.locator('.nova-panel input[type=number]')
  p.get_by_role('button',name='Check answers').click()
  check(tag+' incomplete answer rejected',p.locator('.nova-fb.bad').count()==1)
  for k,(r,h,a,sa) in enumerate(CH):
   check(tag+f' challenge {k+1} correct task loaded',p.evaluate('NOVA_F13_08_CONFIG._challenge.task()')==k)
   if k==0:
    inp.nth(0).fill('11');inp.nth(1).fill('20');p.get_by_role('button',name='Check answers').click()
    check(tag+' wrong curved area diagnostic',p.locator('.nova-fb.bad').count()==1)
    inp.nth(0).fill('12');inp.nth(1).fill('16');p.get_by_role('button',name='Check answers').click()
    check(tag+' one circle omitted diagnostic','BOTH' in p.locator('.nova-panel').inner_text())
   inp.nth(0).fill(str(a));inp.nth(1).fill(str(sa));p.get_by_role('button',name='Check answers').click()
   check(tag+f' challenge {k+1} exact curved/total values accepted',p.locator('.nova-fb.ok').count()==1)
   if k<2:p.wait_for_timeout(1300)
  p.locator('.nova-stage').screenshot(path=str(snap/f'{width}-challenge.png'),animations='disabled')
  p.get_by_role('tab',name='Watch').click();p.evaluate('NOVA.engines["F13-08"].timeline.pause()')
  check(tag+' navigation leaves one official mascot',p.locator('.nova-stage .nv-dockfig').count()==1)
  check(tag+' no runtime JS exceptions',not errors)
  check(tag+' no full page horizontal overflow at exit',p.evaluate('document.documentElement.scrollWidth<=innerWidth'))
  if width==380:
   check(tag+' strip remains on one mobile row',p.evaluate('(()=>{let n=[...document.querySelectorAll(".f12-strip .nv-ntile")];return n.length===3&&Math.max(...n.map(x=>x.getBoundingClientRect().top))-Math.min(...n.map(x=>x.getBoundingClientRect().top))<10;})()'))
  p.close()
 br.close()
(root/'QA-RESULTS.json').write_text(json.dumps(R,indent=2))
passes=sum(x['passed'] for x in R)
print('RESULT',passes,'/',len(R),'passed',flush=True)
if passes<len(R):raise SystemExit(1)
