# F13-08 — Cylinder Unroll · NOVA Premium Core Review

Open `F13-08-Cylinder-Unroll-PREMIUM-CORE.html` in your browser (works offline). This is the review build for Family F13 engine 08, not a GitHub commit.

The core and official NOVA assets are embedded. The unroll runs through an SVG material mesh and ends as a flat rectangular side face plus two circles. Use Watch, Guided, Explore or Challenge tabs. Drag across the cylinder or use the Unroll slider. Keyboard arrows open/close in 5% steps; Home closes and End fully opens.

Explore includes five size presets, radius and height controls, curved/end highlights, and full 3D/net actions. Challenge asks for the coefficient of π in curved and total external surface area on three examples.

## Files
- `F13-08-Cylinder-Unroll-PREMIUM-CORE.html` — complete offline standalone
- `source/approved-F13-07-base.html` — last approved premium core base
- `source/F13-08.engine.js` — editable new engine
- `source/F13-08.component.css` — additive component styles
- `source/build.py` — reproducible assembly (run with `python source/build.py`)
- `qa.py`, `QA-RESULTS.json`, `QA-REPORT.md` — browser QA and test evidence
- `screenshots/` — real Chromium captures at desktop and mobile sizes, including midway and fully unrolled views

No GitHub changes. Keep this as a review build until approved visually.
