NOVA MATHS V2 — F18-01 RULER AND MEASURING TOOLS
=================================================
STATUS: BUILT FOR REVIEW — NOT GOLD APPROVED

Open F18-01-ruler-and-measuring-tools.html in a modern browser.
It is fully standalone: embedded NOVA core, helper artwork and chalk fonts.

QA/F18-01-QA-REPORT.html contains the visual/interaction review.
QA/screenshots: all four modes at 380px and 1280px.
QA/*.json: recorded automated smoke, interaction and stress-test results.

NOT TESTED: real physical touch device; owner visual acceptance.
GitHub was not changed.

ORIGINAL REFERENCE BASE: NOVA F14-01-REVIEW original inlined core, with
F0-02 and F2-03 premium visual references, and F18-01 master specification.
