from pathlib import Path
import json,sys,traceback
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];FILE=R/'F16/F16-14-misleading-graph-spotter.html'
DATA=FILE.read_text(); results=[]
PRESETS=['y7-pictogram','y7-bar','y9-distribution','y9-correlation','y9-sampling']
if len(sys.argv)>2:PRESETS=[sys.argv[2]]
def chk(name,condition,detail=None):
  result={'test':name,'pass':bool(condition)}
  if not condition:result['detail']=detail
  results.append(result)
  print(('PASS' if condition else 'FAIL'),name, str(detail)[:160] if not condition else '',flush=True)
def status(page):return page.evaluate('NOVA_F16_14_CONFIG._explore.get()')
def ptr(page,locator,target=None,cancel=False):
 locator.scroll_into_view_if_needed(timeout=10000);box=locator.bounding_box();assert box
 sx,sy=box['x']+box['width']/2,box['y']+box['height']/2
 if target:
  h=target.bounding_box();assert h
  x,y=h['x']+h['width']/2,h['y']+h['height']/2
 else:x,y=sx+55,sy-20
 page.mouse.move(sx,sy);page.mouse.down();page.mouse.move(x,y,steps=1);page.wait_for_timeout(80)
 if cancel:page.keyboard.press('Escape')
 page.mouse.up();page.wait_for_timeout(500)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in ([int(sys.argv[1])] if len(sys.argv)>1 else [380,1280]):
  page=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(DATA,wait_until='domcontentloaded',timeout=60000)
  for mode in ['Watch','Guided','Explore','Challenge']:
   page.get_by_role('tab',name=mode,exact=True).click();page.wait_for_timeout(140)
   q=page.evaluate('''()=>{let s=document.querySelector('.nova-stage')?.getBoundingClientRect(),v=document.querySelector('.f1614-svg')?.getBoundingClientRect();return {ratio:v.height/s.height,dock:document.querySelectorAll('.nova-stage .nv-dock').length,overflow:document.documentElement.scrollWidth>innerWidth}}''')
   chk(f'{width} {mode} visual stage',q['ratio']>=.60 and q['dock']==1 and not q['overflow'] and not errors,q)
  page.get_by_role('tab',name='Explore',exact=True).click();page.wait_for_timeout(130)
  for key in PRESETS:
   page.locator('.f1614-controls select').select_option(key);page.wait_for_timeout(130)
   start=status(page)
   chk(f'{width} {key} preset loaded',start['preset']==key and start['repaired']==False,start)
   # real mouse cursor across the screen to the fault hotspot
   try:
    ptr(page,page.locator('[data-repair-card]'),page.locator('[data-hotspot="fault"]'))
    after=status(page)
    chk(f'{width} {key} native repair drag',after['repaired']==True,after)
   except Exception as ex:chk(f'{width} {key} native repair drag',False,str(ex))
   # Red removal zone, mouse
   if status(page)['repaired']:
    try:
     ptr(page,page.locator('[data-repair-card]'),page.locator('.f1614-svg [data-maths-nonexistent]') if False else page.locator('.f1614-svg').locator('text').filter(has_text='Remove').first)
     chk(f'{width} {key} red removal',status(page)['repaired']==False,status(page))
    except Exception as ex:chk(f'{width} {key} red removal',False,str(ex))
   page.get_by_role('button',name='Restore misleading view').click();page.wait_for_timeout(150)
   before=status(page)
   try:ptr(page,page.locator('[data-repair-card]'),cancel=True)
   except Exception as ex:chk(f'{width} {key} Escape cancel',False,str(ex))
   else:chk(f'{width} {key} Escape cancel',status(page)==before and not page.evaluate('!!NOVA.ui._drag'),status(page))
   page.locator('[data-repair-card]').focus();page.keyboard.press('Space');page.wait_for_timeout(130)
   chk(f'{width} {key} keyboard repair',status(page)['repaired'] is True,status(page))
   page.get_by_role('button',name='Restore misleading view').click();page.wait_for_timeout(110)
   chk(f'{width} {key} reset repaired state',status(page)['repaired'] is False)
   # actual computed maths in source
   q=page.evaluate('''()=>{let x=NOVA_F16_14_CONFIG.presets[NOVA_F16_14_CONFIG.preset];switch(x.kind){case 'bar':return Math.max(...x.counts)-Math.min(...x.counts);case 'pictogram':return x.counts[1];case 'spread':return Math.max(...x.sets[0])-Math.min(...x.sets[0]);case 'scatter':return x.points.length;case 'sample':return x.counts[0]/(x.counts[0]+x.counts[1])*100;}}''')
   chk(f'{width} {key} math truth',q==page.evaluate('NOVA_F16_14_CONFIG.presets[NOVA_F16_14_CONFIG.preset].expected'),q)
   # Challenge exact: no answer should advance, then solve 3 parts with data answer
   page.get_by_role('tab',name='Challenge',exact=True).click();page.wait_for_timeout(140)
   chk(f'{width} {key} Challenge opens 0',page.evaluate('NOVA_F16_14_CONFIG._challenge.task()')==0)
   page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(120)
   chk(f'{width} {key} incorrect repair rejected',page.evaluate('NOVA_F16_14_CONFIG._challenge.task()')==0)
   page.locator('[data-repair-card]').focus();page.keyboard.press('Space');page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(970)
   chk(f'{width} {key} repair accepted',page.evaluate('NOVA_F16_14_CONFIG._challenge.task()')==1)
   loc=page.locator('.nova-panel input[type="number"],.nova-panel input[type="text"]').last
   if not loc.count():loc=page.locator('.nova-panel input').last
   loc.fill(str(q));page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(970)
   chk(f'{width} {key} numerical answer accepted',page.evaluate('NOVA_F16_14_CONFIG._challenge.task()')==2)
   s=page.locator('.f1614-choice select');s.select_option(str(page.evaluate('NOVA_F16_14_CONFIG.presets[NOVA_F16_14_CONFIG.preset].correct')))
   page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(210)
   # final task remains 2; inspect feedback text at panel
   feedback=page.locator('.nova-panel').inner_text().lower()
   chk(f'{width} {key} justified conclusion accepted','correct' in feedback or 'supported' in feedback,feedback[-220:])
   page.get_by_role('tab',name='Explore',exact=True).click();page.wait_for_timeout(140)
  chk(f'{width} no page errors',not errors,errors)
  page.close()
 b.close()
output=R/('tests/F16-14-RESULTS'+('-'+sys.argv[1]+('-'+sys.argv[2] if len(sys.argv)>2 else '') if len(sys.argv)>1 else '')+'.json');output.write_text(json.dumps({'total':len(results),'passed':sum(q['pass'] for q in results),'failed':[q for q in results if not q['pass']],'results':results},indent=2));print('SUMMARY',sum(q['pass'] for q in results),'/',len(results))
sys.exit(0 if all(q['pass'] for q in results) else 1)
