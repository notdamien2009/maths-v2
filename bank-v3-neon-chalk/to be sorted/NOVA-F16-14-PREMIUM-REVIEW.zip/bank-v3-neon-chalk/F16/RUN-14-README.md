F16-14 Misleading Graph Spotter: open `F16-14-misleading-graph-spotter.html`. Four modes. Premium review pending owner sign-off. GitHub unchanged.
