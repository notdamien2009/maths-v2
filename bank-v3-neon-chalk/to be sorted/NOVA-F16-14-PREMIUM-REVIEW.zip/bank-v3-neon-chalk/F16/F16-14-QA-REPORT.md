# NOVA F16-14 · Premium Review (not GOLD)

**Engine:** Misleading Graph Spotter. Five KS3 lesson presets: Y7-066 pictogram key; Y7-071 truncated bar axis; Y9-049 spread vs mean; Y9-050 correlation vs causation; Y9-052 sampling bias.

## Functional scope
- Four NOVA modes; Watch has nine named steps with narration slots; Guided scaffolds each representation; Explore uses genuine NOVA SVG dragging and a reversible repair lens; Challenge checks repair, a numerical reading and a reasoned interpretation.
- Core runtime and CSS are pinned verbatim from the F16-13 review package, with SHA-256 checks in `build/build-f16-14.py`.
- The repair target glows; mouse and keyboard operation supported. Invalid drops, Escape and red remove zone use the NOVA shared SVG drag handler.

## Evidence and limitations
- **130 distinct checks passed, 0 recorded failures**: 65 mobile (380px) and 65 desktop (1280px) completed across separate runs. See `tests/F16-14-COMBINED-RESULTS.json`.
- Two monolithic long test runs were interrupted by the execution timeout during desktop checks. The final desktop sampling case was re-run and completed separately with 17/17 checks. Check logs for exact sequence; no claim of an uninterrupted 130-check run.
- 20 actual browser screenshots: Watch/Guided/Explore/Challenge at both widths, all five presets at both widths, plus two corrected views.
- Screenshots show exactly one original NOVA mascot dock inside the stage, no external/duplicated helper, and no horizontal page overflow.
- Drawings occupy at least 80% of stage height in the tested modes. The stage is tall to keep fault rationale, repair tray and mascot clear.
- **Physical touch hardware and owner visual review have not been performed.** No GOLD approval is assumed.
- **No GitHub writes.** A fresh byte-level comparison with GitHub current core is outstanding; the pinned runtime matches earlier F13 release and the F2-derived shared-core hash.

## Building
Extract top folder `bank-v3-neon-chalk/`, then run `python build/build-f16-14.py` from anywhere. The script verifies pinned-core hashes and generates the same standalone file at `F16/F16-14-misleading-graph-spotter.html`.

**Standalone HTML SHA-256:** `806dec8518bdc2447b14dabfee0ed606dfd7e7cf5f396c5b0ee365fa1f139100`.
