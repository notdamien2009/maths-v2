# NOVA Maths F11-08 — Compass Constructions · Premium Review

**Status:** owner review candidate only; not GOLD-approved. GitHub untouched.

## Open now
`F11/F11-08-compass-constructions.html` — fully self-contained HTML with the same verified F0/F1 core snapshot inherited from the F11-07 base.

## Mathematical scenes
- Perpendicular bisector — two arcs with identical radii, exact intersection pair, middle perpendicular and midpoint.
- Angle bisector — vertex-centred arc marks and second pair of equal-radius arcs, exact angle halving.
- Equilateral triangle — two arcs of radius AB, sides and equal angles.
- SSS triangle — intersection of two circles with independently measured side radii.
- Distance loci — exact crossings of two equal-distance circles.

Seven lesson presets: Y7-056, Y7-057, Y8-050, Y8-051, Y8-056, Y9-027, Y9-028. Twenty Watch/Guided stages, all four modes, eight answer+reason challenges. Mouse/touch draggable handles, arrow keys, pointer-capture, Escape rollback, and draggable reason cards.

## Install after approval
Extract `bank-v3-neon-chalk/` into the maths-v2 bank root, without replacing the existing `core/` directory. These component-specific files are additive. The builder reads the **current** `core/nova-core.js` and `core/nova-core.css` in the repository at build time:

`python3 build/build-F11-08.py`

Run tests with Python Playwright and Chromium installed:
`python3 tests/test_f118.py`

QA: **176/176 browser and mathematical checks passed** at 380px and 1280px. Included screenshots and `tests/F11-08-QA.json` provide review evidence. The builder does not overwrite the shared core, and this ZIP deliberately does not contain duplicate core files.

## Known boundaries
The precision compass is illustrated by its true arcs, intersection points, and radius controls rather than a detailed physical tool. Reason cards drop into the reason panel, not directly onto SVG sectors. Final owner visual/functional sign-off is still required.
