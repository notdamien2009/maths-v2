#!/usr/bin/env python3
"""F11-08 Premium QA: computed Euclidean geometry, exact constructions, real browser modes, responsive layouts, direct pointer input."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,sys,math,hashlib
root=Path(__file__).resolve().parents[1]
source=(root/'F11/F11-08-compass-constructions.html').read_text()
shots=root/'shots/F11-08'; shots.mkdir(parents=True,exist_ok=True)
passed=[];failed=[]
def ck(name,result):
 try:
  assert result, 'assertion false';passed.append(name)
 except Exception as e:failed.append({'check':name,'error':str(e)[:300]})
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=browser.new_page(viewport={'width':width,'height':1000},reduced_motion='reduce');errs=[];page.on('pageerror',lambda err:errs.append(str(err)))
  page.set_content(source,wait_until='load');page.wait_for_timeout(120)
  ck(f'{width} engine mounts',page.locator('#F11-08').count()==1)
  ck(f'{width} exact 4 modes',page.get_by_role('tab').count()==4)
  ck(f'{width} original NOVA Chalk embedded',page.evaluate('document.fonts.check("20px NOVA Chalk")'))
  ck(f'{width} theme stage',page.locator('[data-testid=f118-stage]').count()==1)
  ck(f'{width} helper inside stage',page.evaluate('''()=>{let a=document.querySelector('#F11-08 .f118-theatre').getBoundingClientRect(),b=document.querySelector('#F11-08 .nv-dockfig').getBoundingClientRect();return b.left>=a.left-2&&b.right<=a.right+2&&b.top>=a.top-2&&b.bottom<=a.bottom+2;}'''))
  ck(f'{width} no exceptions on initial mount',len(errs)==0)
  page.screenshot(path=str(shots/f'F11-08-{width}-watch.png'),full_page=True,animations='disabled')
  for name in ['Guided','Explore','Challenge']:
   page.get_by_role('tab',name=name,exact=True).click();page.wait_for_timeout(65)
   ck(f'{width} {name} diagram displayed',page.locator('[data-testid=f118-svg]').count()==1)
   ck(f'{width} {name} runtime clean',len(errs)==0)
   page.screenshot(path=str(shots/f'F11-08-{width}-{name.lower()}.png'),full_page=True,animations='disabled')
  # Challenge answer hidden, including side cards and on SVG label.
  ck(f'{width} Challenge metric secrecy',page.locator('[data-testid=f118-aside] .f118-main').all_inner_texts()[1:]==['?','?','?'])
  for i,(val,reason) in enumerate([(90,'perpendicular'),(155,'midpoint'),(35,'bisect'),(60,'equilateral'),(784,'perimeter'),(180,'locus'),(55,'bisect'),(180,'sum')],1):
   page.locator('[data-testid=f118-answer]').fill(str(val));page.locator(f'button[data-reason="{reason}"]').click();page.get_by_role('button',name='Check answer + reason').click();page.wait_for_timeout(60)
   if i!=8:
    ck(f'{width} Challenge {i} correct answer & reason',page.get_by_role('button',name='Next challenge →').count()==1)
    page.get_by_role('button',name='Next challenge →').click()
   else:ck(f'{width} mastery final',page.get_by_text('8 / 8 · CONSTRUCTION MASTERY').count()==1)
  ck(f'{width} all challenges runtime clean',len(errs)==0)
  # Explore is separate active mode so previous Challenge cannot leak internal state.
  page.get_by_role('tab',name='Explore',exact=True).click()
  for preset,kind in [('y7_056','perpendicular'),('y7_057','equilateral'),('y8_050','angle'),('y8_051','locus'),('y8_056','sss'),('y9_027','locus'),('y9_028','sss')]:
   page.locator('[data-testid=f118-preset]').select_option(preset)
   ck(f'{width} preset {preset} maps to {kind}',page.locator('[data-testid=f118-kind]').input_value()==kind)
   ck(f'{width} preset {preset} SVG',page.locator('[data-testid=f118-geometry]').count()==1)
  # Unit test circle intersection identity on dynamic geometry; hundreds of real values.
  for radius in range(170,250,10):
   result=page.evaluate('''r=>{let m=__F118_MATH__.models('perpendicular',{radius:r}),d=__F118_MATH__.dist;return [d(m.A,m.P),d(m.B,m.P),d(m.A,m.Q),d(m.B,m.Q),d(m.A,m.M),d(m.B,m.M)]}''',radius)
   ck(f'{width} perpendicular r{radius} circle intersections',all(abs(x-radius)<1e-6 for x in result[:4]))
   ck(f'{width} perpendicular r{radius} midpoint halves equal',abs(result[4]-result[5])<1e-8)
  for angle in [30,45,50,65,70,90,110,130]:
   result=page.evaluate('''a=>{let m=__F118_MATH__.models('angle',{angle:a}),d=__F118_MATH__.dist;return{ap:d(m.O,m.P),aq:d(m.O,m.Q),ip:d(m.I,m.P),iq:d(m.I,m.Q),calculatedAngle:Math.abs(Math.atan2(m.I.y-m.O.y,m.I.x-m.O.x)*180/Math.PI)}}''',angle)
   ck(f'{width} angle {angle} matching equal arcs',abs(result['ip']-result['iq'])<1e-8 and abs(result['ap']-result['aq'])<1e-8)
   ck(f'{width} angle {angle} bisector exactly half',abs(result['calculatedAngle']-angle/2)<1e-8)
  for sideA,sideB in [(190,200),(220,260),(280,280),(260,180),(180,275)]:
   result=page.evaluate('''s=>{let m=__F118_MATH__.models('sss',{sideA:s[0],sideB:s[1]}),d=__F118_MATH__.dist;return [d(m.A,m.C),d(m.B,m.C),d(m.A,m.B)]}''',[sideA,sideB])
   ck(f'{width} SSS {sideA}/{sideB} exact lengths',abs(result[0]-sideA)<1e-8 and abs(result[1]-sideB)<1e-8 and abs(result[2]-304)<1e-8)
  for radius in [125,150,180,205,240]:
   result=page.evaluate('''r=>{let m=__F118_MATH__.models('locus',{radius:r}),d=__F118_MATH__.dist;return[d(m.A,m.P),d(m.B,m.P),d(m.A,m.Q),d(m.B,m.Q)]}''',radius)
   ck(f'{width} equal-distance locus r{radius} intersections',all(abs(q-radius)<1e-7 for q in result))
  page.locator('[data-testid=f118-preset]').select_option('y8_050')
  h=page.locator('[data-testid=f118-angle-handle]');h.scroll_into_view_if_needed();before=float(h.get_attribute('aria-valuenow'))
  h.focus();page.keyboard.press('ArrowRight');page.wait_for_timeout(50)
  ck(f'{width} keyboard ray rotation',float(h.get_attribute('aria-valuenow'))==before+5)
  # Fast pointer rotation, direct visual updates, then Escape must rollback.
  hb=h.bounding_box();page.mouse.move(hb['x']+hb['width']/2,hb['y']+hb['height']/2);page.mouse.down()
  page.mouse.move(hb['x']+50,hb['y']+95,steps=1);page.wait_for_timeout(105)
  ck(f'{width} live pointer angle',float(h.get_attribute('aria-valuenow'))!=before+5)
  page.keyboard.press('Escape');page.wait_for_timeout(65)
  ck(f'{width} angle Escape rollback',float(h.get_attribute('aria-valuenow'))==before+5)
  page.mouse.up()
  page.locator('[data-testid=f118-preset]').select_option('y7_056');h=page.locator('[data-testid=f118-radius-handle]');h.scroll_into_view_if_needed();rb=h.bounding_box();initial=float(h.get_attribute('aria-valuenow'))
  page.mouse.move(rb['x']+rb['width']/2,rb['y']+rb['height']/2);page.mouse.down();page.mouse.move(rb['x']-30,rb['y'],steps=1);page.wait_for_timeout(105)
  ck(f'{width} live compass radius drag',float(h.get_attribute('aria-valuenow'))<initial)
  page.mouse.up();page.wait_for_timeout(65);h.focus();old=float(h.get_attribute('aria-valuenow'));page.keyboard.press('ArrowRight');page.wait_for_timeout(45)
  ck(f'{width} keyboard compass adjustment',float(h.get_attribute('aria-valuenow'))==old+5)
  ck(f'{width} no stranded drag',page.evaluate('window.NOVA.ui._drag==null'))
  ck(f'{width} no page errors after drags',len(errs)==0)
  page.screenshot(path=str(shots/f'F11-08-{width}-bisector-explore.png'),full_page=True,animations='disabled')
  for kind in ['angle','equilateral','sss','locus']:
   page.locator('[data-testid=f118-kind]').select_option(kind)
   page.screenshot(path=str(shots/f'F11-08-{width}-{kind}-explore.png'),full_page=True,animations='disabled')
  # Drop-card actual pointer gesture on first challenge.
  page.get_by_role('tab',name='Challenge').click();btn=page.locator('button[data-reason=perpendicular]');drop=page.locator('[data-testid=f118-reason-drop]');btn.scroll_into_view_if_needed();bb=btn.bounding_box();dd=drop.bounding_box();page.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);page.mouse.down();page.mouse.move(dd['x']+dd['width']/2,dd['y']+dd['height']/2,steps=4);page.mouse.up();page.wait_for_timeout(65)
  ck(f'{width} real reason card drag-drop',drop.get_attribute('data-set')=='true')
  ck(f'{width} reason drag no stranded',page.evaluate('window.NOVA.ui._drag==null'))
  ck(f'{width} challenge runtime clean after drag',len(errs)==0)
  page.close()
 browser.close()
result={'component':'F11-08','core':'F0/F1 inherited unchanged','checks':len(passed)+len(failed),'passed':len(passed),'failed':failed,'viewports':[380,1280]}
(root/'tests/F11-08-QA.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2));sys.exit(1 if failed else 0)
