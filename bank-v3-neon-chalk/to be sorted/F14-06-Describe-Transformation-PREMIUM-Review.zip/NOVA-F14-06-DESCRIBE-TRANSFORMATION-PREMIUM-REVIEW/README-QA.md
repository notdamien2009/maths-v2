# NOVA F14-06 · Describe the Transformation Challenge — Premium Review

**Status:** REVIEW build; not GOLD approved. GitHub unchanged.

## Source baseline
- Uses the embedded NOVA F0/F2 CSS, JS, premium stage and original mascot artwork copied from F14-05, itself based on the user's supplied canonical F0/F2 files.
- The inherited shell, stage background, neon/chalk tokens and the NOVA.ui.svgDrag pointer kit are preserved.
- One helper dock inside the stage; the secondary NOVA side panel helper is hidden by the same F14 family styling.

## Purpose and lesson targets
- Y7-053 Rotation; Y8-054 Rotation; six named comparison presets including translation, reflection and enlargement.
- Pupils identify original and transformed vertices and supply a complete description: type, direction, angle and centre; translation vector; mirror-line equation; enlargement centre/scale factor.
- Teaching uses six named steps with the guide revealed; Challenge hides the construction guide and correct description.

## Interaction and misconception coverage
- Watch, Guided, Explore, Challenge (six tasks).
- Explore: change presets; reveal construction/description after prediction; drag final image, centre, vector or mirror-line handle; snapped grid, red reset zone, keyboard arrows.
- Challenge: identify clockwise vs anticlockwise; off-origin centre; two-component translation vector; reflection line; scale/centre; place a rotated image by drag or arrows.
- Wrong answers get cause-specific feedback. The score and events are handled by the existing NOVA challenge/engine core.

## Verified QA evidence
- Main Playwright regression at 380 and 1280: **130/130 passed**, 0 failed.
- Supplemental mouse/keyboard/cancel stress at 380 and 1280: **12/12 passed**, 0 failed.
- Total **142/142 passed**. Evidence in `test-results.json`.
- Screenshots: 8 images across all four modes at each viewport width. See `screenshots/`.
- Main test covers original core presence, premium tokens, Chalk fonts, stage/mascot, overflow, all six challenges, all six presets, guide/description reveal, keyboard handle movement, real mouse image drag and reset.
- Supplemental stress covers real mouse centre/vector/line drag, Escape, `pointercancel`, and errors.
- Some drawing-value checks remain human-review items: check subtle label overlap and overall premium match side by side with the actual F2 components.

## Components inside this ZIP
- `F14-06-describe-transformation-PREMIUM.html` — self-contained HTML (~1.2 MB)
- `screenshots/` — 8 annotated-by-filename browser captures (380, 1280)
- `test-results.json` — per-assertion main and stress results
- `README-QA.md` — this report

## Manual acceptance gate
Owner reviews visual details in all four modes, verifies fluid dragging on target hardware and explicitly approves before F14-06 is considered GOLD. Do not push to GitHub without permission.

SHA-256 HTML: 59d64048651da485db0b54069785e6a5a14fef5ffcfa46805a6e5d869fd0d4d8
