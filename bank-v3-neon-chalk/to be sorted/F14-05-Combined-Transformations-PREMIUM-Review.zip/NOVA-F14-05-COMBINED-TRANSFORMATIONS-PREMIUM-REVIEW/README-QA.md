# NOVA Maths V2 — F14-05 Combined Transformations · Premium review

**Status:** Review build, not GOLD approved. **Repository:** `notdamien2009/maths-v2` READ-ONLY. No commits, modifications or pushes to GitHub.

## Basis and visual shell
- Adapted from previous corrected F14-04 premium build and user-supplied F0/F2 HTML references. The fully embedded existing NOVA F0/F2 core, fonts, tokens, SVG/neon/chalk primitives, premium background, interaction/timeline engine and companion image art remain in place.
- **One mascot docked inside the premium stage**, with stage-local prompt bubble; the older external mascot strip is hidden.
- Uses `NOVA.svg.root/grid/axes`, `NOVA.neonPath/neonRing/neonBox/neonTile/chalkText`, `NOVA.motion`, `NOVA.ui.svgDrag`, `NOVA.scene.helperStrip`, `NOVA.challengeRun`.

## Master requirement
- Source F14-05 master: combined transformations with ghost stages, transformations in sequence, grid and guides. Linked lesson: **Y8-054 Rotation**. Visual: original blue ABC → purple A′B′C′ → green A″B″C″.
- Four modes: **Watch, Guided, Explore and Challenge**. Six narrated storyboard steps; independent intermediate and final positions; premium Neon + Chalk mathematical artwork. Step timeline uses inherited NOVA controls.
- `rotate 90° clockwise` about (0,0) followed by `translate (4,−1)`: **A(−4,−3) → A′(−3,4) → A″(1,3)**.
- Reversing the order: **A(−4,−3) → (0,−4) → (−4,0)**; shows why order matters.
- Four presets: rotate → translate; translate → rotate; reflect in x=−1 → translate; translate → reflect in x=−1.
- Explore: change sequence, reverse order, use the real NOVA `svgDrag` to move purple and green shapes independently; move gold rotation centre, translation vector or reflection-line handle; snap to coordinate grid; red reset tray; keyboard arrow movement; Escape/pointercancel leave no pieces stranded.
- Challenge (four tasks): drag the intermediate rotation image, identify the two-stage coordinate, reverse the order, and drag the final combined image. Maths checking and misconception-specific feedback.

## QA evidence
- **116 checks passed and 0 checks failed** in headless Chromium, at **380×900 and 1280×900**, including reduced-motion rendering.
- Screenshots: 8 full-page images, four modes at both sizes in `screenshots/`.
- Checks: canonical original core and font, one interior mascot, non-overflow layout, Watch/Guided/Explore/Challenge, all four challenge tasks, four presets, actual mouse dragging of both images/centre/vector/reflection line, arrow-key alternatives, reversal, Escape recovery and no JS errors.
- Detailed itemised results in `QA-results.json`.
- Source HTML SHA256 `983fa840737b813e2207c8dfbd1bf4d2b414b1e0e0418d3cc23f0ba5a7b777f3`.

**Important:** Automated QA and captured visuals do not imply owner approval. Review visual hierarchy, interactive feel and pedagogy against F0/F2 premium benchmarks before accepting this component.
