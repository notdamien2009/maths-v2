from playwright.sync_api import sync_playwright
from pathlib import Path
import json, traceback
R=Path(__file__).resolve().parents[1];html=(R/'F16/F16-11-two-way-tables.html').read_text()
results=[]
def check(title,passed,extra=None):
 results.append({'check':title,'pass':bool(passed),'detail':extra});print(('PASS' if passed else 'FAIL'),title,extra or '')
def state(page):return page.evaluate('NOVA_F16_11_CONFIG._explore.get()')
def drag(page,loc,target,steps=2):
 loc.scroll_into_view_if_needed(timeout=5000)
 a=loc.bounding_box();b=target.bounding_box()
 if not a or not b:raise Exception('no boxes')
 sx=a['x']+a['width']/2;sy=a['y']+a['height']/2;dx=b['x']+b['width']/2;dy=b['y']+b['height']/2
 page.mouse.move(sx,sy);page.mouse.down();page.mouse.move(dx,dy,steps=steps);page.mouse.up();page.wait_for_timeout(520)
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in (380,1280):
  page=browser.new_page(viewport={'width':w,'height':900},device_scale_factor=1,reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda ex:errors.append(str(ex)))
  page.set_content(html,wait_until='domcontentloaded',timeout=60000)
  for mode in ('Watch','Guided','Explore','Challenge'):
   page.get_by_role('tab',name=mode,exact=True).click();page.wait_for_timeout(90)
   m=page.evaluate('''()=>({svg:document.querySelector('.f1611-svg')?.getBoundingClientRect().height,stage:document.querySelector('.nova-stage')?.getBoundingClientRect().height,dock:document.querySelectorAll('.nova-stage .nv-dock').length,overflow:document.documentElement.scrollWidth>innerWidth})''')
   check(f'{w} {mode} stage/mode/render',bool(m['svg'] and m['stage'] and m['dock']==1 and not m['overflow'] and m['svg']/m['stage']>=.6),m)
  page.get_by_role('tab',name='Explore',exact=True).click()
  for preset in ('y7-probability','y8-table'):
   page.locator('.f1611-controls select').first.select_option(preset)
   page.wait_for_timeout(80)
   x=state(page);m=x['counts'];rr=list(map(sum,m));cc=list(map(sum,zip(*m)));grand=sum(rr)
   check(f'{w} {preset} row/column totals',x['rows']==rr and x['columns']==cc and x['total']==grand)
   source=page.locator('[data-count="0-0"]').first;target=page.locator('[data-count="0-1"]').first
   before=x['total'];drag(page,source,target,steps=1);n=state(page)
   check(f'{w} {preset} fast native drag',n['counts'][0][0]==m[0][0]-1 and n['counts'][0][1]==m[0][1]+1 and n['total']==before,n['counts'])
   # re-grab and reverse (the DOM is rebuilt after every good drop)
   drag(page,page.locator('[data-count="0-1"]').first,page.locator('[data-count="0-0"]').first,steps=3);n=state(page)
   check(f'{w} {preset} regrab',n['counts']==m,n['counts'])
   # drop outside zones to spring home
   loc=page.locator('[data-count="0-0"]').first;loc.scroll_into_view_if_needed();a=loc.bounding_box();page.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);page.mouse.down();page.mouse.move(a['x']+a['width']/2+65,a['y']-52,steps=1);page.mouse.up();page.wait_for_timeout(550)
   check(f'{w} {preset} invalid drop stays',state(page)['counts']==m)
   # escape mid-drag
   loc=page.locator('[data-count="0-0"]').first;loc.scroll_into_view_if_needed();a=loc.bounding_box();page.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);page.mouse.down();page.mouse.move(a['x']+a['width']/2+44,a['y']-22,steps=2);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(570)
   check(f'{w} {preset} Escape recovery',state(page)['counts']==m and page.evaluate('!NOVA.ui._drag'))
   loc=page.locator('[data-count="0-0"]').first;loc.focus();page.keyboard.press('ArrowRight');page.wait_for_timeout(80);n=state(page)
   check(f'{w} {preset} keyboard transfer',n['counts'][0][0]==m[0][0]-1 and n['counts'][0][1]==m[0][1]+1)
   page.get_by_role('button',name='Reset table').click();n=state(page);check(f'{w} {preset} reset',n['counts']==m)
   # real removal drop
   drag(page,page.locator('[data-count="0-0"]').first,page.locator('.f1611-svg .nv-neon-box').last,steps=3) if False else None
   rm=page.locator('.f1611-svg').first
   start=page.locator('[data-count="0-0"]').first;start.scroll_into_view_if_needed();a=start.bounding_box()
   rem=page.locator('.f1611-svg').evaluate('''e=>{let p=e.createSVGPoint();p.x=360;p.y=750;let q=p.matrixTransform(e.getScreenCTM());return {x:q.x,y:q.y}}''') if w==380 else page.locator('.f1611-svg').evaluate('''e=>{let p=e.createSVGPoint();p.x=660;p.y=680;let q=p.matrixTransform(e.getScreenCTM());return {x:q.x,y:q.y}}''')
   page.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);page.mouse.down();page.mouse.move(rem['x'],rem['y'],steps=4);page.mouse.up();page.wait_for_timeout(650)
   check(f'{w} {preset} remove target',state(page)['total']==before-1,state(page)['counts'])
   page.get_by_role('button',name='Reset table').click()
  page.get_by_role('tab',name='Challenge',exact=True).click()
  for preset in ('y7-probability','y8-table'):
   # challenge always follows currently selected Explore preset
   page.get_by_role('tab',name='Explore',exact=True).click();page.locator('.f1611-controls select').first.select_option(preset)
   page.get_by_role('tab',name='Challenge',exact=True).click()
   c=page.evaluate('NOVA_F16_11_CONFIG._challengeState()')
   check(f'{w} {preset} target maths', (c['correctMissing']==(8 if preset=='y7-probability' else 6)) and c['grand']==(40 if preset=='y7-probability' else 55) and c['columnTotal']==(18 if preset=='y7-probability' else 15),c)
   # native drag of target card to missing intersection
   src=page.locator('[data-option]').first;dest=page.locator('.f1611-svg').first
   src.scroll_into_view_if_needed();a=src.bounding_box();m=dest.evaluate('''e=>{let p=e.createSVGPoint();p.x=window.innerWidth<=540?24+112+1.5*((402-112)/4):44+154+1.5*((702-154)/4);p.y=window.innerWidth<=540?157+65+112*.55:151+76+112*.55;let q=p.matrixTransform(e.getScreenCTM());return {x:q.x,y:q.y}}''') if preset=='y8-table' else dest.evaluate('''e=>{let p=e.createSVGPoint();p.x=window.innerWidth<=540?24+112+1.5*((402-112)/3):44+154+1.5*((702-154)/3);p.y=window.innerWidth<=540?157+65+112*.55:151+76+112*.55;let q=p.matrixTransform(e.getScreenCTM());return {x:q.x,y:q.y}}''')
   page.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);page.mouse.down();page.mouse.move(m['x'],m['y'],steps=3);page.mouse.up();page.wait_for_timeout(200)
   placed=page.evaluate('NOVA_F16_11_CONFIG._challengeState().placed');check(f'{w} {preset} native missing card',placed==c['correctMissing'],placed)
   page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(1100)
   check(f'{w} {preset} advance to column task',page.evaluate('NOVA_F16_11_CONFIG._challengeState().task')==1)
   inp=page.locator('.pr-task').locator('..').locator('input') if False else page.locator('input.nova-input')
   # choose entry by label
   entries=page.locator('.nova-stage').count()
   inputs=page.locator('input[type=text],input[type=number]')
   if inputs.count():
    inputs.last.fill(str(c['columnTotal']));page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(1100)
    check(f'{w} {preset} advance to fraction',page.evaluate('NOVA_F16_11_CONFIG._challengeState().task')==2)
    frac=page.locator('.f1611-stacked input');prob=c['probability'];frac.nth(0).fill(str(prob['numerator']));frac.nth(1).fill(str(prob['denominator']));page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(120)
    check(f'{w} {preset} fraction correctness',page.locator('text=Correct. The numerator').count()>0)
   else:check(f'{w} {preset} numeric entry found',False)
  check(f'{w} all browser errors',not errors,errors)
  page.close()
 browser.close()
R.joinpath('tests/STRESS-RESULTS.json').write_text(json.dumps({'checks':len(results),'passed':sum(v['pass'] for v in results),'failed':[x for x in results if not x['pass']],'results':results},indent=2))
print('RESULT',sum(x['pass'] for x in results),'/',len(results));raise SystemExit(0 if all(x['pass'] for x in results) else 2)
