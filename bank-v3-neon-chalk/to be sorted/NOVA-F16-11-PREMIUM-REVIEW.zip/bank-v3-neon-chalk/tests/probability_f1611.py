from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1];html=(R/'F16/F16-11-two-way-tables.html').read_text();out=[]
def ck(k,v):out.append({'case':k,'passed':bool(v)});print('PASS' if v else 'FAIL',k)
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in (380,1280):
  for preset in ('y7-probability','y8-table'):
   pg=browser.new_page(viewport={'width':w,'height':900},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
   pg.set_content(html,wait_until='domcontentloaded');pg.get_by_role('tab',name='Explore').click();pg.locator('.f1611-controls select').first.select_option(preset);pg.get_by_role('tab',name='Challenge').click()
   state=pg.evaluate('NOVA_F16_11_CONFIG._challengeState()');pg.get_by_role('button',name='Place selected card').click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(900)
   ck(f'{w}/{preset} keyboard missing card',pg.evaluate('NOVA_F16_11_CONFIG._challengeState().task')==1)
   pg.locator('input[type=text],input[type=number]').last.fill(str(state['columnTotal']));pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(900)
   ck(f'{w}/{preset} column total',pg.evaluate('NOVA_F16_11_CONFIG._challengeState().task')==2)
   f=pg.locator('.f1611-stacked input');n=state['probability']['numerator'];d=state['probability']['denominator']
   wrongDen=20 if d==40 else 55
   f.nth(0).fill(str(n));f.nth(1).fill(str(wrongDen));pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(100)
   ck(f'{w}/{preset} wrong denominator rejected',pg.evaluate('NOVA_F16_11_CONFIG._challengeState().task')==2 and ('denominator' in pg.locator('.nova-engine').inner_text().lower()))
   numerator,denominator=(3,10) if d==40 else (1,3)
   f.nth(0).fill(str(numerator));f.nth(1).fill(str(denominator));pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(130)
   ck(f'{w}/{preset} equivalent fraction accepted','Correct. The numerator' in pg.locator('.nova-engine').inner_text())
   ck(f'{w}/{preset} no exceptions',not errors)
   pg.close()
 browser.close()
R.joinpath('tests/PROBABILITY-RESULTS.json').write_text(json.dumps({'total':len(out),'passed':sum(x['passed'] for x in out),'cases':out},indent=2))
print('RESULT',sum(x['passed'] for x in out),'/',len(out));raise SystemExit(0 if all(x['passed'] for x in out) else 2)
