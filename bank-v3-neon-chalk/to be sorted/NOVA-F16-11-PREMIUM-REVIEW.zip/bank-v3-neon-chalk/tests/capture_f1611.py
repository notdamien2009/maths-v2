from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1];html=(R/'F16/F16-11-two-way-tables.html').read_text();cases=[]
with sync_playwright() as pw:
 br=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in (380,1280):
  for preset in ('y7-probability','y8-table'):
   page=br.new_page(viewport={'width':w,'height':900},device_scale_factor=1,reduced_motion='reduce');errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
   page.set_content(html,wait_until='domcontentloaded',timeout=60000)
   page.get_by_role('tab',name='Explore').click();page.locator('.f1611-controls select').first.select_option(preset)
   for mode in ('watch','guided','explore','challenge'):
    page.get_by_role('tab',name=mode.capitalize()).click();page.wait_for_timeout(70)
    out=R/'shots'/f'F16-11-{w}-{preset}-{mode}.png';page.locator('.nova-engine').screenshot(path=str(out),animations='disabled',timeout=60000)
    res=page.evaluate('''()=>({dock:document.querySelectorAll('.nova-stage .nv-dock').length,svg:!!document.querySelector('.nova-stage .f1611-svg'),overflow:document.documentElement.scrollWidth>window.innerWidth})''')
    cases.append({'path':out.name,'width':w,'preset':preset,'mode':mode,'ok':not errs and res['dock']==1 and res['svg'] and not res['overflow'],'errors':errs,'metrics':res});print(out.name,'ok' if cases[-1]['ok'] else 'FAIL',flush=True)
   page.close()
 br.close()
R.joinpath('tests/VISUAL-RESULTS.json').write_text(json.dumps({'total':len(cases),'passed':sum(q['ok'] for q in cases),'cases':cases},indent=2))
