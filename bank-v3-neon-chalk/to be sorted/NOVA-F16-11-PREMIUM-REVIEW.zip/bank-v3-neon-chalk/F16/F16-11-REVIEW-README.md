# F16-11 Two-Way Tables — Premium Review

Open `F16/F16-11-two-way-tables.html` as a standalone offline page. The two lesson presets are **Y7-077** and **Y8-067**. It includes Watch, Guided, Explore and Challenge.

Source: `src/F16-11.js`, `src/F16-11.css`, `build/F16-11.src.html` and `build/build-f16-11.py`. The build script uses SHA-pinned `tests/pinned-core.js` and `.css` and writes the same standalone HTML.

Test evidence: `tests/STRESS-RESULTS.json` (62/62), `tests/PROBABILITY-RESULTS.json` (20/20), `tests/VISUAL-RESULTS.json` (16/16), and `tests/BUILD-HASHES.json` for bit-for-bit output verification. Screenshots are in `shots/F16/`.

**No GitHub changes. Not GOLD-approved.** Review visually and on a real touchscreen before merge.
