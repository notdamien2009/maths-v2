# NOVA F17-08 · Venn Diagram

Run: **F17-08**, one engine only; standalone NOVA Neon + Chalk. Not GOLD-approved.

Open `F17-08-Venn-Diagram-PREMIUM-REVIEW.html` directly in a browser; it contains the CSS, mathematical core, fonts, mascot and interactions. There is no external library to install.

Review the files in `screenshots/` and the recorded results in `tests/`.

Presets: Y8-067 survey, Y8-072 even/multiples of 3, Y9-044 prime/even.

Tests were run with Python Playwright and Chromium using the final standalone HTML; paths in the included scripts refer to the production working environment and can be adjusted locally. Physical touchscreen QA has not been run.

GitHub was not modified.
