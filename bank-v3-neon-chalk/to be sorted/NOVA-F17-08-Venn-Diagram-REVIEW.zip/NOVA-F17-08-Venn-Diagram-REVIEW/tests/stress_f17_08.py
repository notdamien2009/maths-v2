import asyncio,pathlib,json,math
from playwright.async_api import async_playwright
HTML=pathlib.Path('/mnt/data/F17-08-Venn-Diagram-PREMIUM-REVIEW.html').read_text()
OUT=pathlib.Path('/mnt/data/f17_08_work');OUT.mkdir(exist_ok=True)
results=[]
def check(label, condition, detail=None):
 results.append({'name':label,'pass':bool(condition),'detail':detail})
 if not condition: print('FAIL',label,detail)
async def fromsvg(page,x,y):
 return await page.evaluate('([x,y])=>{const svg=document.querySelector("svg.f178-plot"),p=svg.createSVGPoint();p.x=x;p.y=y;const z=p.matrixTransform(svg.getScreenCTM());return {x:z.x,y:z.y}}',[x,y])
async def drag(page,item,x,y,steps=3,escape=False):
 e=page.locator(f'[data-venn-item="{item}"]');await e.scroll_into_view_if_needed();await page.locator('svg.f178-plot').evaluate('(e)=>e.scrollIntoView({block:"center"})');await page.wait_for_timeout(60)
 box=await e.bounding_box(); assert box, f'item {item} missing'
 src={'x':box['x']+box['width']/2,'y':box['y']+box['height']/2};dest=await fromsvg(page,x,y)
 await page.mouse.move(src['x'],src['y']);await page.mouse.down();await page.mouse.move(dest['x'],dest['y'],steps=steps)
 if escape:await page.keyboard.press('Escape')
 await page.mouse.up();await page.wait_for_timeout(190)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for width in [380,1280]:
   page=await browser.new_page(viewport={'width':width,'height':1000},reduced_motion='reduce')
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',HTML)
   await page.wait_for_timeout(90)
   for mode in ['Watch','Guided','Explore','Challenge']:
    await page.get_by_role('tab',name=mode).click();await page.wait_for_timeout(100)
    check(f'{width}/{mode}/svg',await page.locator('svg.f178-plot').count()==1)
    check(f'{width}/{mode}/one-mascot',await page.locator('.nv-dock').count()==1)
    check(f'{width}/{mode}/no-js-error',not errors,errors[-2:])
    await page.screenshot(path=str(OUT/f'F17-08-{width}-{mode.lower()}.png'),full_page=True)
    if mode=='Explore':
     for preset,expected,prob in [('survey',[3,2,4,3],[3,4]),('notation',[4,2,2,4],[1,6]),('prime',[4,1,5,2],[5,6])]:
      v=await page.evaluate('(preset)=>{NOVA_F17_08_CONFIG._explore.setPreset(preset);return NOVA_F17_08_CONFIG._explore.get()}',preset)
      check(f'{width}/{preset}/total',v['total']==12,v)
      check(f'{width}/{preset}/counts',[v['regionCounts'][k] for k in ['a','both','b','none']]==expected,v['regionCounts'])
      check(f'{width}/{preset}/prob',v['prob']==prob,v['prob'])
      await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.reveal()');r=await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.get()')
      check(f'{width}/{preset}/reveal',r['allCorrect'] and r['placed']==12 and r['correct']==12,r)
      await page.screenshot(path=str(OUT/f'F17-08-{width}-{preset}-revealed.png'),full_page=True)
     await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.setPreset("survey")')
     pos=await page.evaluate('()=>({layout:document.querySelector("svg.f178-plot").viewBox.baseVal.width})')
     # Real high-speed drag to region A-only (outcome 1), then regrab and move to both (incorrect)
     await drag(page,1,110 if width==380 else 270,335 if width==380 else 350,steps=1)
     v=await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.get()');check(f'{width}/mouse-fast-place',v['assignments'].get('1')=='a',v['assignments'])
     await drag(page,1,210 if width==380 else 429,335 if width==380 else 350,steps=2)
     v=await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.get()');check(f'{width}/regrab-to-overlap',v['assignments'].get('1')=='both',v['assignments'])
     await drag(page,1,22 if width==380 else 54,96 if width==380 else 93,steps=4)
     v=await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.get()');check(f'{width}/invalid-springs-back',v['assignments'].get('1')=='both',v['assignments'])
     await drag(page,1,300 if width==380 else 610,335 if width==380 else 350,steps=3,escape=True)
     v=await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.get()');check(f'{width}/escape-cancel',v['assignments'].get('1')=='both',v['assignments'])
     await drag(page,1,312 if width==380 else 682,846 if width==380 else 864,steps=3)
     v=await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.get()');check(f'{width}/red-remove',not v['assignments'].get('1'),v['assignments'])
     # Keyboard non-pointer equivalent including controls and delete.
     await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.place(6,"both")')
     v=await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.get()');check(f'{width}/keyboard-placement',v['assignments'].get('6')=='both')
     e=page.locator('[data-venn-item="6"]');await e.focus();await e.press('Delete');await page.wait_for_timeout(90)
     v=await page.evaluate('()=>NOVA_F17_08_CONFIG._explore.get()');check(f'{width}/keyboard-remove',not v['assignments'].get('6'))
     # Roving tabindex, and select-based keyboard alternative.
     check(f'{width}/one-roving-tabstop',await page.locator('svg.f178-plot [data-venn-item][tabindex="0"]').count()==1)
   # Challenge answer leak and mark feedback, first task.
   await page.get_by_role('tab',name='Challenge').click();await page.wait_for_timeout(80)
   check(f'{width}/challenge-hidden-probability',bool(await page.locator('svg.f178-plot').text_content()) and '?' in await page.locator('svg.f178-plot').text_content())
   inputs=await page.locator('input').evaluate_all('(els)=>els.map(e=>({type:e.type,placeholder:e.placeholder,visible:!!e.offsetWidth}))')
   print('Challenge inputs',width,inputs[:8])
   check(f'{width}/no-page-errors-end',not errors,errors[-3:])
   await page.close()
  await browser.close()
 (OUT/'QA-STRESS-RESULTS.json').write_text(json.dumps({'total':len(results),'passed':sum(t['pass'] for t in results),'failed':[r for r in results if not r['pass']],'checks':results},indent=2))
 print('TOTAL',len(results),'PASS',sum(t['pass'] for t in results),'FAIL',len([r for r in results if not r['pass']]))
asyncio.run(main())
