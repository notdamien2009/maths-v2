import asyncio,pathlib,json
from playwright.async_api import async_playwright
HTML=pathlib.Path('/mnt/data/F17-08-Venn-Diagram-PREMIUM-REVIEW.html').read_text();OUT=pathlib.Path('/mnt/data/f17_08_work');OUT.mkdir(exist_ok=True)
checks=[]
def check(k,x,detail=None):
 checks.append({'check':k,'passed':bool(x),'detail':detail});
 if not x:print('FAIL',k,detail)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for width in (380,1280):
   page=await b.new_page(viewport={'width':width,'height':1000},reduced_motion='no-preference')
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',HTML);await page.wait_for_timeout(110)
   # Watch animation controls are supplied by the canonical core, not new code.
   await page.get_by_role('tab',name='Watch').click();await page.wait_for_timeout(100)
   controls=await page.locator('button[aria-label]').evaluate_all('(els)=>els.map(e=>e.getAttribute("aria-label"))')
   check(f'{width}/watch-six-steps',len(await page.locator('body').inner_text())>0)
   for term in ['Reset','Step back','Step forward']:
    check(f'{width}/watch-'+term.lower().replace(' ','-')+'-control',term in controls,controls)
   check(f'{width}/watch-play-pause-control','Pause' in controls or 'Play' in controls,controls)
   # Stop autoplay before testing manual step controls.
   if 'Pause' in controls:await page.get_by_role('button',name='Pause',exact=True).click()
   await page.get_by_role('button',name='Reset',exact=True).click();await page.get_by_role('button',name='Step forward',exact=True).click();await page.wait_for_timeout(100)
   check(f'{width}/watch-forward-advances','STEP 2/6' in await page.locator('body').inner_text())
   await page.get_by_role('button',name='Step back',exact=True).click();await page.wait_for_timeout(100)
   check(f'{width}/watch-back-rewinds','STEP 1/6' in await page.locator('body').inner_text())
   check(f'{width}/watch-scrub-control',await page.locator('input[type=range]').count()>=1)
   # When auto-play is active the Watch step indicator should change over time.
   meta=await page.evaluate('()=>({step:NOVA.events.history().filter(e=>e.type==="step"&&e.detail.engine==="F17-08").slice(-1),anim:!matchMedia("(prefers-reduced-motion: reduce)").matches})');check(f'{width}/normal-motion',meta['anim'] is True,meta)
   await page.get_by_role('tab',name='Challenge').click();await page.wait_for_timeout(110)
   for i,(value,wrong,trap) in enumerate([('3','9','union count'),('2/3','5/6','overlap'),('1/12','5/12','every prime'),('1/6','5/6','at least one circle')]):
    question=await page.locator('.pr-task').inner_text()
    check(f'{width}/challenge-{i+1}-question',bool(question),question)
    inp=page.locator('input[type="text"]');await inp.fill(wrong);await page.get_by_role('button',name='Check',exact=True).click();await page.wait_for_timeout(90)
    alltext=(await page.locator('body').inner_text()).lower()
    check(f'{width}/challenge-{i+1}-wrong-feedback',trap.lower() in alltext,alltext[-400:])
    await inp.fill(value);await page.get_by_role('button',name='Check',exact=True).click();await page.wait_for_timeout(950 if i<3 else 120)
    alltext=(await page.locator('body').inner_text())
    check(f'{width}/challenge-{i+1}-correct-feedback','Correct.' in alltext or 'Correct' in alltext,alltext[-350:])
    if i<3:check(f'{width}/challenge-{i+1}-advances',await page.locator('.pr-task').inner_text()!=question)
   check(f'{width}/no-js-errors',not errors,errors)
   await page.close()
  await b.close()
 (OUT/'QA-EXTRA-RESULTS.json').write_text(json.dumps({'total':len(checks),'passed':sum(v['passed'] for v in checks),'failed':[x for x in checks if not x['passed']],'checks':checks},indent=2))
 print('EXTRA',len(checks),'PASSED',sum(v['passed'] for v in checks),'FAILED',len([x for x in checks if not x['passed']]))
asyncio.run(main())
