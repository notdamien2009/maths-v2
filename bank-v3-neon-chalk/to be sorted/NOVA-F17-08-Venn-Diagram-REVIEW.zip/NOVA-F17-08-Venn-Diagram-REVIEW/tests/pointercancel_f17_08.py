import asyncio,pathlib,json
from playwright.async_api import async_playwright
HTML=pathlib.Path('/mnt/data/F17-08-Venn-Diagram-PREMIUM-REVIEW.html').read_text()
R=[]
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for w in [380,1280]:
   page=await b.new_page(viewport={'width':w,'height':950},reduced_motion='reduce');await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',HTML);await page.get_by_role('tab',name='Explore').click()
   e=page.locator('[data-venn-item="3"]');await e.scroll_into_view_if_needed();box=await e.bounding_box();x=box['x']+box['width']/2;y=box['y']+box['height']/2
   await page.mouse.move(x,y);await page.mouse.down();await page.mouse.move(x+60,y-70,steps=3)
   before=await page.evaluate('()=>!!NOVA.ui._drag');print('active',w,before)
   await e.evaluate('(el)=>el.dispatchEvent(new PointerEvent("pointercancel",{bubbles:true,pointerId:1,pointerType:"mouse",isPrimary:true}))')
   await page.wait_for_timeout(120);await page.mouse.up()
   after=await page.evaluate('()=>({drag:!!NOVA.ui._drag,pos:NOVA_F17_08_CONFIG._explore.get().assignments[3],transform:document.querySelector(`[data-venn-item="3"]`).getAttribute("transform")})')
   print('cancel',w,after);R.append({'width':w,'pass':before and not after['drag'] and not after['pos'],'detail':after});await page.close()
  await b.close()
 path=pathlib.Path('/mnt/data/f17_08_work/QA-POINTERCANCEL.json');path.write_text(json.dumps(R,indent=2));print('CANCEL',sum(x['pass'] for x in R),'/',len(R))
asyncio.run(main())
