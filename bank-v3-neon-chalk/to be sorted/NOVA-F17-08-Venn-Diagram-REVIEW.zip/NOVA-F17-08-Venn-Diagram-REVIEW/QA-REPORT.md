# NOVA F17-08 Venn Diagram — Production QA / Review

Status: **BUILT FOR OWNER REVIEW — NOT GOLD APPROVED**. GitHub was read only. Physical touchscreen use not tested.

## Evidence summary

- **120/120 recorded automated assertions passed**: viewport and interactive stress 68/68, four-mode Watch/Challenge and normal-motion 50/50, pointercancel 2/2. Original failed attempts from test setup/syntax fixes are not included in passing totals; their causes were corrected and the final files re-tested.
- **16 full-page screenshots**: Watch, Guided, Explore, Challenge at **380px and 1280px**; each of the three presets revealed at both widths; final Watch step at both widths.
- **Original NOVA core script unchanged** between F17-07 reference and F17-08 build. SHA256: `bc8b287a321aff1b3aeda8383879c68a6e7abf7542a6a9b72576a1c027bc4c6e`. The F17-08 engine itself is appended separately in `source/F17-08-engine-only.js` and the original component-local styles are appended without altering core definitions.
- Premium SVG uses embedded NOVA Chalk and `NOVA.neonPath`, `NOVA.neonBox`, `NOVA.chalkText`, `NOVA.neonLine`, `NOVA.ui.svgDrag`, `NOVA.motion`, `NOVA.bankMount`, `NOVA.challengeRun`, and `NOVA.scene.helperStrip`. The file is entirely self-contained, without CDN dependencies.

## Exact preset mathematics

| Preset | A only | A and B | B only | Neither | P(focus) |
|---|---:|---:|---:|---:|---|
| Y8-067 sports survey | 3 | 2 | 4 | 3 | P(A ∪ B) = 9/12 = 3/4 |
| Y8-072 even/multiples of 3, 1..12 | 4 | 2 | 2 | 4 | P(A ∩ B) = 2/12 = 1/6 |
| Y9-044 prime/even, 1..12 | 4 | 1 | 5 | 2 | P(A ∪ B) = 10/12 = 5/6 |

`source/F17-08-engine-only.js` lines 4–23 store immutable preset domains and perform exact set/region calculations; lines 36–85 generate the diagram and draggable objects. `tests/QA-STRESS-RESULTS.json` records the expected counts and fractions and complete sorted models for both viewport widths.

## Interaction / modes

- **WATCH / GUIDED**: six named steps teaching universe → A only → intersection → B only/neither → union → probability; Watch timeline has reset/back/forward/play-pause/scrub. Watch step-six screenshots show final correct model.
- **EXPLORE**: 12 separately draggable outcomes in a two-row tray; four snap zones, red REMOVE zone, re-grab placed objects, invalid drop recovery, Escape and pointercancel recovery. Test scripts move the real Chromium mouse at both viewport widths, then verify engine state and no stranded pieces. Outcome/region selector and remove keys give a keyboard alternative.
- **CHALLENGE**: four genuine questions, results **3**, **2/3**, **1/12**, **1/6**. Wrong-answer misconceptions and correct answers were submitted in Chromium at both widths, verifying specific feedback, automatic advancing and answer hiding.
- **Events**: `NOVA.events` value keys declared in config include preset, outcome, region, placedCount, correctCount, eventProbability, focusRegion, complete, reset; note `NOVA.bankMount` supplies step/correct/mode/hint events through the core.

## QA and evidence locations

| Guard | Evidence |
|---|---|
| Core reused verbatim / no replacement fonts, styles, mascots or primitives | Core SHA above; `source/F17-08-engine-only.js` lines 1–3, 20–22, 36–56, and 127–130; screenshot in `screenshots/` |
| Original single mascot inside stage | `tests/QA-STRESS-RESULTS.json`, `one-mascot` checks, all eight mode screenshots |
| Four operational modes at 380 and 1280 | `tests/QA-STRESS-RESULTS.json`, screenshots for each mode |
| Presets and mathematical exactness | `tests/QA-STRESS-RESULTS.json`, `source/F17-08-engine-only.js` lines 4–19 and 117–125 |
| Real mouse fast drag / re-grab / wrong region / invalid / Escape / removal | `tests/QA-STRESS-RESULTS.json` keys `mouse-fast-place`, `regrab-to-overlap`, `invalid-springs-back`, `escape-cancel`, `red-remove` |
| Pointer cancellation and no stranded items | `tests/QA-POINTERCANCEL.json`, 2/2 |
| Keyboard placement, Delete and roving tabindex | `tests/QA-STRESS-RESULTS.json`, per-viewport keyboard/roving keys |
| Watch control/navigation, real normal motion and scrub | `tests/QA-EXTRA-RESULTS.json`, per-viewport watch checks; final Watch screenshots |
| Four Challenge answers and misconception feedback | `tests/QA-EXTRA-RESULTS.json`; per-viewport task 1–4 checks |
| No page errors in tested modes | `tests/QA-STRESS-RESULTS.json` and `tests/QA-EXTRA-RESULTS.json` |

## Outstanding before GOLD approval

Owner acceptance at both widths; physical touchscreen/Apple Safari checks; independent cross-browser stress beyond Chromium; learner pedagogical review of whether two-way tables are supported in the desired lesson context. F17-08 has **no GOLD approval**.
