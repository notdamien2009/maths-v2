# NOVA F11-09 · Locus Builder · Premium Review

**Status:** Browser-tested review candidate; awaiting owner's visual and functional approval. Not GOLD approved. No GitHub write.

## Source of truth and provenance

- F11-08 repository-review shell is inherited unchanged in layout and controls.
- Existing approved F0/F1 source is copied directly from F11-08's actual working core for *local build* and embedded by `build/build-F11-09.py`.
- Deliverable ZIP deliberately does **not** include or overwrite `core/`.
- Component code is confined to `src/F11-09.js`, `src/F11-09.css`, `build/F11-09.src.html` and its builder.
- No external runtime dependencies; opening the standalone HTML works offline.

## Mathematical scenes

1. Fixed distance from a point → circumference of a circle (not the entire disk).
2. Fixed perpendicular distance from a line → two parallel loci, one on each side.
3. Equal distances from points A and B → their perpendicular bisector.
4. Equal perpendicular distances from two intersecting rays, inside the angle → internal angle bisector.
5. Two specified point distances → intersection of two circles, with exact analytic coordinates.
6. Two bounded-distance inequalities → intersection (lens) of two filled disks; points on both valid boundaries included.

**30 named Watch/Guided states**, 7 curriculum-oriented named presets, and **8 Challenge tasks** requiring an exact answer and its mathematical justification. The core controls provide Watch, Guided, Explore and Challenge modes, Sir Bob narration slots, reduced-motion support and print fallback.

## Interactive controls

- Fast, direct pointer capture (no laggy trailing tween) for draggable radius, angle, circle and endpoint controls.
- Live repaint from one mathematical model; pointer handle stays mounted during redraw.
- Escape, cancellation or focus loss restores starting value; keyboard arrow equivalents available.
- Reason cards can be clicked or dragged onto the reason target, with pointer cancellation cleanup.
- Value events expose only enumerated keys from `F119_CONFIG`.

## QA

Automated Chromium tests at **380px and 1280px**: **148 of 148 passed**. Evidence: `tests/F11-09-QA.json`, `tests/test_f119.py`, captured screenshots in `shots/F11-09/`.

This includes 8 challenge/reason tasks, every preset, circle-point intersection invariants (including disjoint circles), equal perpendicular distances in angle bisectors, keyboard controls, live fast drag and Escape rollback, reason card drop, mascot in-container bounding-box assertion, and runtime page errors.

## Rebuild after owner approval

Unzip into your local `bank-v3-neon-chalk/` working directory **alongside your existing** `core/nova-core.css` and `core/nova-core.js`, then run:

```bash
python build/build-F11-09.py
```

This writes `F11/F11-09-locus-builder.html`. The script only reads shared core and never edits core or GitHub.

## Known scope boundary

The F11-09 engine models circular, parallel-line, bisector and two-condition loci. It is not a general-purpose region solver for arbitrary polygons; that is beyond this component's master prompt. The shaded overlap is a mathematical representation, not a separate physical drag-and-drop token.
