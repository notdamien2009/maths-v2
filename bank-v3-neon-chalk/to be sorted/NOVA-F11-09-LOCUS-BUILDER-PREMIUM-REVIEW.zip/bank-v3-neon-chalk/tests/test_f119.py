#!/usr/bin/env python3
"""F11-09: real-browser mathematical checks, presentation, keyboard, pointer, Challenge and source provenance."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,sys,math
root=Path(__file__).resolve().parents[1];s=(root/'F11/F11-09-locus-builder.html').read_text();shots=root/'shots/F11-09';shots.mkdir(parents=True,exist_ok=True)
passed=[];failed=[]
def ck(label,condition):
 try:
  if not condition:raise AssertionError('false')
  passed.append(label)
 except Exception as e: failed.append({'test':label,'error':str(e)})
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':1000},reduced_motion='reduce');errs=[];page.on('pageerror',lambda e:errs.append(str(e)));page.set_content(s,wait_until='load');page.wait_for_timeout(120)
  ck(f'{width} shell mounted',page.locator('#F11-09').count()==1)
  ck(f'{width} exactly four modes',page.get_by_role('tab').count()==4)
  ck(f'{width} inherited NOVA Chalk font',page.evaluate('document.fonts.check("20px NOVA Chalk")'))
  ck(f'{width} learning theatre visible',page.locator('[data-testid=f119-stage]').count()==1)
  ck(f'{width} mascot fully contained',page.evaluate('''()=>{let a=document.querySelector('#F11-09 .f119-theatre').getBoundingClientRect(),b=document.querySelector('#F11-09 .nv-dockfig').getBoundingClientRect();return b.left>=a.left-2&&b.right<=a.right+2&&b.top>=a.top-2&&b.bottom<=a.bottom+2}'''))
  ck(f'{width} no errors on load',not errs)
  for mode in ('Watch','Guided','Explore','Challenge'):
   page.get_by_role('tab',name=mode,exact=True).click();page.wait_for_timeout(90)
   ck(f'{width} {mode} shows SVG',page.locator('[data-testid=f119-svg]').count()==1)
   ck(f'{width} {mode} no runtime errors',not errs)
   page.screenshot(path=str(shots/f'F11-09-{width}-{mode.lower()}.png'),full_page=True,animations='disabled')
  ck(f'{width} Challenge hides result',page.locator('[data-testid=f119-aside] .f119-main').all_inner_texts()[-1]=='?')
  tasks=[(165,'radius'),(105,'perpendicular'),(0,'bisector'),(120,'midpoint'),(40,'angle'),(165,'intersection'),(2,'intersection'),(2,'inside')]
  for i,(answer,reason) in enumerate(tasks):
   page.locator('[data-testid=f119-answer]').fill(str(answer));page.locator(f'button[data-reason="{reason}"]').click();page.get_by_role('button',name='Check answer + reason').click();page.wait_for_timeout(60)
   if i<7:
    ck(f'{width} task {i+1} exact value + reason',page.get_by_role('button',name='Next challenge →').count()==1)
    page.get_by_role('button',name='Next challenge →').click()
   else:ck(f'{width} final mastery',page.get_by_text('8 / 8 · LOCI MASTERY').count()==1)
  ck(f'{width} Challenge runtime clean',not errs)
  page.get_by_role('tab',name='Explore',exact=True).click()
  for preset,kind in [('y8_050','perp'),('y8_051','point'),('y9_027','circles'),('y9_028','perp'),('y9_041','angle'),('y8_line','line'),('y9_region','region')]:
   page.locator('[data-testid=f119-preset]').select_option(preset);page.wait_for_timeout(40)
   ck(f'{width} preset {preset}',page.locator('[data-testid=f119-kind]').input_value()==kind)
   ck(f'{width} scene {kind} rendered',page.locator('[data-testid=f119-geometry]').count()==1)
   page.screenshot(path=str(shots/f'F11-09-{width}-{kind}-explore.png'),full_page=True,animations='disabled')
  for d in (100,120,150,200,240):
   m=page.evaluate('''x=>{let t=__F119_MATH__.model('perp',{distance:x,radius:165}),dist=__F119_MATH__.model;return [t.M.x,t.A.x,t.B.x,t.r,t.P.y,t.Q.y]}''',d)
   ck(f'{width} perpendicular midpoint at {d}',abs(m[1]+d/2-365)<1e-8 and abs(m[2]-d/2-365)<1e-8 and abs(m[0]-365)<1e-8)
   ck(f'{width} bisector crossing inside stage at {d}',m[4]>=60 and m[5]<=500)
  for d,ra,rb in ((180,165,145),(110,160,180),(240,165,145),(225,90,90),(100,215,210)):
   out=page.evaluate('''p=>{let m=__F119_MATH__.model('circles',{distance:p[0],radius:p[1],radiusB:p[2]}),f=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);return{n:m.int.length,d:m.distance,ra:m.ra,rb:m.rb,v:m.int.map(x=>[f(x,m.A),f(x,m.B)])}}''',[d,ra,rb]);
   ck(f'{width} circle exact crossings {d}/{ra}/{rb}',all(abs(x-ra)<1e-7 and abs(y-rb)<1e-7 for x,y in out['v']))
   ck(f'{width} circle intersection count {d}/{ra}/{rb}',out['n']==(2 if abs(ra-rb)<d<ra+rb else 0))
  for angle in (35,40,60,80,90,110,115):
   out=page.evaluate('''a=>{let m=__F119_MATH__.model('angle',{angle:a}),P=m.bis,u={x:Math.cos(-m.alpha),y:Math.sin(-m.alpha)},d1=Math.abs(P.y-m.O.y),d2=Math.abs((P.x-m.O.x)*u.y-(P.y-m.O.y)*u.x);return[d1,d2]}''',angle)
   ck(f'{width} angle {angle} exactly equal perpendicular distance',abs(out[0]-out[1])<1e-7)
  # Real live pointer capture and cancellation (no stale drag state)
  page.locator('[data-testid=f119-kind]').select_option('point');h=page.locator('[data-testid=f119-radius-handle]');h.scroll_into_view_if_needed();h.focus();initial=float(h.get_attribute('aria-valuenow'));page.keyboard.press('ArrowRight');page.wait_for_timeout(40)
  ck(f'{width} keyboard radius changes',float(h.get_attribute('aria-valuenow'))==initial+5)
  h.scroll_into_view_if_needed();box=h.bounding_box();bx=box['x']+box['width']/2;by=box['y']+box['height']/2
  page.mouse.move(bx,by);page.mouse.down();page.mouse.move(bx-43,by-36,steps=1);page.wait_for_timeout(125)
  ck(f'{width} live fast radius updates',float(h.get_attribute('aria-valuenow'))!=initial+5)
  page.keyboard.press('Escape');page.wait_for_timeout(70)
  ck(f'{width} Escape reverts radius',float(h.get_attribute('aria-valuenow'))==initial+5)
  page.mouse.up();ck(f'{width} no stranded pointer after cancellation',page.evaluate('window.NOVA.ui._drag===null'))
  page.locator('[data-testid=f119-kind]').select_option('angle');h=page.locator('[data-testid=f119-angle-handle]');h.scroll_into_view_if_needed();h.focus();before=int(h.get_attribute('aria-valuenow'));page.keyboard.press('ArrowRight');page.wait_for_timeout(40)
  ck(f'{width} keyboard angle changes',int(h.get_attribute('aria-valuenow'))==before+5)
  page.locator('[data-testid=f119-kind]').select_option('circles');h=page.locator('[data-testid=f119-radiusB-handle]');h.focus();before=int(h.get_attribute('aria-valuenow'));page.keyboard.press('ArrowLeft');page.wait_for_timeout(40)
  ck(f'{width} second radius keyboard adjustment',int(h.get_attribute('aria-valuenow'))==before-5)
  page.get_by_role('tab',name='Challenge',exact=True).click();btn=page.locator('button[data-reason=radius]');drop=page.locator('[data-testid=f119-reason-drop]');btn.scroll_into_view_if_needed();bb=btn.bounding_box();dd=drop.bounding_box();page.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);page.mouse.down();page.mouse.move(dd['x']+dd['width']/2,dd['y']+dd['height']/2,steps=5);page.mouse.up();page.wait_for_timeout(60)
  ck(f'{width} real reason drag and drop',drop.get_attribute('data-set')=='true')
  ck(f'{width} no stranded reason drag',page.evaluate('window.NOVA.ui._drag===null'))
  ck(f'{width} zero console runtime errors',not errs)
  if errs:print('RUNTIME ERRORS',width,errs)
  page.close()
 b.close()
report={'engine':'F11-09','status':'premium-review','passed':len(passed),'failed':failed,'count':len(passed)+len(failed),'viewports':[380,1280]};(root/'tests/F11-09-QA.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));sys.exit(1 if failed else 0)
