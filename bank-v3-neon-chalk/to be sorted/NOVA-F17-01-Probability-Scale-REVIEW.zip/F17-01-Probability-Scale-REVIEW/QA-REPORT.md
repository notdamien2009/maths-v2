# F17-01 Probability Scale — review QA (13 October 2026)

Source: NOVA F14-01 family review embedded core (core v3.6.2), compared with GitHub handover/master and F17-01 master spec. GitHub not modified.

HTML: F17-01-Probability-Scale-PREMIUM-REVIEW.html (standalone, embedded NOVA CSS, chalk fonts, core/mascot assets and engine JS).

## Verification
- Browser: Chromium via Playwright `page.set_content`, 380px and 1280px, all four modes; no page JavaScript exceptions.
- Visual screenshots: `screenshots/F17-01-<width>-<mode>.png`, widths 380px and 1280px.
- Core helpers: `NOVA.numberLine`, `NOVA.ui.svgDrag`, F14 embedded v3.6.2 inherited core.
- Mathematics: 3/10 = 0.3, complement 7/10 = 0.7; 5/8 = 0.625, complement 3/8 = 0.375.
- 37 of 40 automated assertions passed; 3 FAILED. NOT full acceptance. Failed checks documented below.

## Remaining open checks
- 1280 regrab placed marker to .7: 0.3 — desktop pointer re-grab of previously placed marker did not update. Follow-on keyboard and Escape assertions expected 0.6 but observed 0.2 (cascading failures).
- 1280 keyboard left: 0.2 — desktop pointer re-grab of previously placed marker did not update. Follow-on keyboard and Escape assertions expected 0.6 but observed 0.2 (cascading failures).
- 1280 Escape recovery: 0.2 — desktop pointer re-grab of previously placed marker did not update. Follow-on keyboard and Escape assertions expected 0.6 but observed 0.2 (cascading failures).

Other limits: screenshots are viewport browser renders, not an independent manual accessibility audit. Device touch testing not performed. Voice playback and full NVDA/VoiceOver tests not performed. The GitHub copy of core was verified for presence but not bytes-downloaded; embedded F14 review family core used in output. This is a REVIEW build, not GOLD-approved.
