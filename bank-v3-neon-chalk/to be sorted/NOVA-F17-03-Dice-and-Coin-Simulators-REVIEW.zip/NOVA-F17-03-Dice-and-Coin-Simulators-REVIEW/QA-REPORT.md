# NOVA Maths V2 — F17-03 Dice and Coin Simulators — Review QA

**Date:** 13 October 2026  
**Status:** BUILT FOR OWNER REVIEW · NOT GOLD-APPROVED  
**GitHub:** Read only; no modifications, commits, pushes or uploads.  
**Standalone HTML SHA-256:** `c50ae9902a55c6359e7f0d16c773fa4a6eda83abbc4ea58da5e103d7b3301844`  
**Evidence:** `tests/F17-03-STRESS-RESULTS.json` (108/108); `tests/F17-03-ADDITIONAL-RESULTS.json` (20/20); `tests/F17-03-smoke.json` (8 of 8 viewports/modes). 

## Canonical references and design compliance
- Source specification: private `notdamien2009/maths-v2`, `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, section `F17-03 Dice and coin simulators`.
- Master handover: `bank-v3-neon-chalk/HANDOVER-v3.md`. Previous F17-01 and F17-02 standalone review files remain *review*, not GOLD-approved. F14 family review archive supplied exact core reference and screenshot assets.
- Engine is a standalone HTML: shared NOVA v3.x core, fonts and family visuals are embedded; no external CSS, JS or fonts. Evidence HTML line 16, `src` self-contained script data.
- NOVA neon depth, large 3D glass dice, concentric neon coin, familiar original stage and chalk fonts: F17-03 code starts at HTML line 1712; CSS at line 574.
- Mathematical SVGs use canonical NOVA.neonPath/neonRing/neonBox/chalkText and root. See HTML lines 1742, 1751, 1764.
- Exactly one mascot in the stage in every mode and viewport (not outside); measured in `tests/F17-03-smoke.json`; original `NOVA.scene.helperStrip` at HTML line 1821.
- Stacked NOVA Chalk fractions on stage (reduced to lowest terms) implemented near HTML line 1739. Decimal theory and empirical metrics are labelled separately.
- Stage screenshots: `screenshots/F17-03-380-watch.png`, `-guided`, `-explore`, `-challenge`, and corresponding 1280 names. Six more images show other preset/apparatus layouts.

## Mathematical accuracy and presets
| Canonical lesson | Apparatus | Theoretical event | Favourable / total | Decimal |
|---|---|---|---:|---:|
| Y7-074 Systematic listing and sample spaces | Die + coin | EVEN die **AND** HEADS coin | 3/12 = 1/4 | 0.25 |
| Y7-076 Experimental probability and relative frequency | Fair coin | HEADS | 1/2 | 0.5 |
| Y8-073 Experimental and theoretical probability | Six-sided die | die is 5 or 6 | 2/6 = 1/3 | 0.3333… |
| Y9-046 Experimental probability and relative frequency | Two independent dice | sum exactly 7 | 6/36 = 1/6 | 0.1666… |

- Independent sample spaces built as exact enumerations of (2, 6, 12, 36) equally likely outcomes. See line 1726.
- `favourable()` counts the Cartesian enumeration using active event criteria (not a hard-coded answer); see line 1731.
- Trial sampling uses original `NOVA.rng.create`, samples coin and dice equitably, calculates win per sampled outcome, and records the observed relative frequency. See lines 1725, 1859, 1860.
- Editing an event after collecting results clears previous trial history, preventing stale experimental data from being attributed to the new event. See line 1852.
- Additional Y9 mathematical test: SUM = 7 AND DOUBLES has **zero** outcomes (sum seven is odd); verified in `tests/F17-03-ADDITIONAL-RESULTS.json`.

## Four engine modes and key learning behaviours
- **WATCH:** Six named tutor-narration steps: meet apparatus → possible outcomes → favourable event → animate trial → collect results → compare and predict. See lines 1824, 1831.
- **GUIDED:** Canonical shared NOVA guided stepper, prompts and targeted narration; visual states rendered at 380 and 1280.
- **EXPLORE:** Choose one of four lesson presets; assign, drag, re-grab or remove a rule token using the original F2 SVG drag system; validated geometry-based slots; keyboard equivalent; run 1, 20 or 100 trials; clear/reset. See lines 1845, 1802.
- **CHALLENGE:** Four checked tasks: complete die × coin sample space (12), experimental heads 14/40 = 0.35, number of die faces equal to 5 or 6 (2), two-dice sum-seven ordered pairs (6). Misconception-specific responses cover additive counting, theoretical vs empirical and reversed pairs. See line 1879.

## Browser and interaction evidence (actually executed)
- **108/108** Playwright headless Chromium stress assertions at 380px and 1280px, reported individually in `tests/F17-03-STRESS-RESULTS.json`.
- **20/20** additional Chromium assertions for non-reduced rolling animation, full trial completion, impossible compound event, stale-history reset, page overflow, and true `pointercancel` cleanup.
- **8/8** independent full viewport/mode render snapshots have exactly one SVG and one stage mascot, with no JavaScript page error.
- Actual mouse tests include: drag WIN/rule event into snap target, re-grab and remove to red tray, one-step fast mouse drag, out-of-zone spring-back, incompatible token rejection, Escape cancellation, and keyboard-control equivalents. All pass. No stranded active drag state.
- Normal motion test captured the apparatus with a nonidentity transform **during** the animation, then verified its record was added only at the end.
- Automated Chromium checks are not proof of compatibility with every browser or a physical touchscreen. Physical touch QA remains outstanding.

## Two local robustness fixes to existing shared SVG drag (not GitHub)
1. Preserves the F17-02 review-build v3.6.2 pointer-capture repair after lifted SVG element reparenting; confirm at HTML line 1688.
2. **New local F17-03 precision guard:** an SVG coordinate such as 175.999984 must count as the exact left edge at x=176. A ±0.08 SVG-unit rounding guard is added to the `inZ` drag-zone hit test, without changing snap target sizes or maths, HTML line 1682. Fast desktop mouse re-drop now succeeds in an actually executed test.

These are local standalone changes only; the repository has not been touched. A shared-core change requires owner approval.

## Owner acceptance checklist
- Inspect the supplied screenshots and open the standalone HTML at 380 and 1280 in all four modes.
- Assess scene quality, clarity of the 3D dice/coin, text and mascot size side-by-side with F0-02 / F2-03 and your recent F14 family review.
- Check a real mouse or touchscreen, including fast multi-piece manipulations and mode switching.
- Approve or request targeted changes. **Do not call this GOLD without explicit approval.**
