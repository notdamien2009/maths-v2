from playwright.sync_api import sync_playwright
from pathlib import Path
import json
html=(Path(__file__).resolve().parents[1] / 'F17-03-Dice-and-Coin-Simulators-PREMIUM-REVIEW.html').read_text();results=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':960},device_scale_factor=1,reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded',timeout=60000);page.wait_for_timeout(300)
  for mode in ['watch','guided','explore','challenge']:
   page.locator('.nova-tab[data-m="'+mode+'"]').click();page.wait_for_timeout(160)
   f=str(Path(__file__).resolve().parents[1] / 'screenshots' / f'F17-03-{width}-{mode}.png');page.locator('#F17-03 .nova-stage').screenshot(path=f,timeout=60000)
   results.append(dict(width=width,mode=mode,svg=page.locator('svg.f173-plot').count(),mascot=page.locator('#F17-03 .nova-stage .nv-dock').count(),errors=errors.copy(),height=page.locator('#F17-03 .nova-stage').evaluate('(e)=>Math.ceil(e.getBoundingClientRect().height)')))
  page.close()
 b.close()
(Path(__file__).resolve().parent / 'F17-03-smoke.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
