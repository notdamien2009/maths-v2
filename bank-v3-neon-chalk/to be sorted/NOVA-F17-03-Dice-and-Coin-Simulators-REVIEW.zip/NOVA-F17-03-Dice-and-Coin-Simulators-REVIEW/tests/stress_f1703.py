from playwright.sync_api import sync_playwright
from pathlib import Path
import json,traceback
html=(Path(__file__).resolve().parents[1] / 'F17-03-Dice-and-Coin-Simulators-PREMIUM-REVIEW.html').read_text()
res=[]
def ck(name,ok,details=None):
 res.append(dict(test=name,passed=bool(ok),details=details));print(('PASS' if ok else 'FAIL'),name,(str(details)[:250] if details is not None else ''),flush=True)
def coord(page,x,y):
 return page.evaluate('''([x,y])=>{let s=document.querySelector('svg.f173-plot'),p=s.createSVGPoint();p.x=x;p.y=y;let a=p.matrixTransform(s.getScreenCTM());return {x:a.x,y:a.y}}''',[x,y]);
def drag(page,x,y,x2,y2,steps=15):
 page.locator('svg.f173-plot').scroll_into_view_if_needed();a=coord(page,x,y);b=coord(page,x2,y2)
 page.mouse.move(a['x'],a['y']);page.mouse.down();page.mouse.move(b['x'],b['y'],steps=steps);page.mouse.up();page.wait_for_timeout(520)
def get(page):return page.evaluate('NOVA_F17_03_CONFIG._explore.get()')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  page=browser.new_page(viewport={'width':width,'height':970},reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  try:
   page.set_content(html,wait_until='domcontentloaded',timeout=50000)
   for mode in ['watch','guided','explore','challenge']:
    page.locator('.nova-tab[data-m="'+mode+'"]').click()
    ck(f'{width}/{mode} SVG',page.locator('svg.f173-plot').count()==1)
    ck(f'{width}/{mode} one in-stage helper',page.locator('#F17-03 .nova-stage .nv-dock').count()==1)
    ck(f'{width}/{mode} no page error',not errors,errors[-1] if errors else None)
   page.locator('.nova-tab[data-m="explore"]').click();page.wait_for_timeout(80)
   L={'x':101,'y':600,'tx':97,'ty':492,'ux':287,'uy':492,'rx':282,'ry':600} if width==380 else {'x':345,'y':482,'tx':176,'ty':482,'ux':552,'uy':482,'rx':690,'ry':482}
   state=get(page);ck(f'{width}/Year7 preset model',state['model']['kind']=='diecoin' and state['model']['events']==['EVEN','HEADS'])
   ck(f'{width}/Y7 fair paired outcomes',state['space']==12 and state['favourable']==3 and abs(state['theoretical']-.25)<1e-10,state)
   ck(f'{width}/original 3D artwork rendered',page.locator('svg.f173-plot [data-device]').count()==2)
   # true mouse re-grab of event A into red REMOVE
   drag(page,L['tx'],L['ty'],L['rx'],L['ry'])
   st=get(page);ck(f'{width}/actual mouse re-grab removal',st['model']['events']==[None,'HEADS'],st['model']['events'])
   # palette EVEN -> EVENT A
   page.locator('svg.f173-plot').scroll_into_view_if_needed()
   ck(f'{width}/palette hitbox',page.evaluate('''([x,y])=>{let s=document.querySelector('svg.f173-plot'),p=s.createSVGPoint();p.x=x;p.y=y;p=p.matrixTransform(s.getScreenCTM());return !!document.elementFromPoint(p.x,p.y)?.closest('[data-palette]')}''',[L['x'],L['y']]))
   drag(page,L['x'],L['y'],L['tx'],L['ty'],steps=1)
   st=get(page);ck(f'{width}/fast pointer snap restores even',st['model']['events']==['EVEN','HEADS'],st['model']['events'])
   # drag to invalid location and ensure it springs back
   drag(page,L['tx'],L['ty'],width==380 and 195 or 380,width==380 and 392 or 360,steps=2)
   ck(f'{width}/invalid drag unchanged',get(page)['model']['events']==['EVEN','HEADS'])
   # Escape cancels a running drag
   page.locator('svg.f173-plot').scroll_into_view_if_needed();a=coord(page,L['tx'],L['ty']);b=coord(page,L['rx'],L['ry'])
   page.mouse.move(a['x'],a['y']);page.mouse.down();page.mouse.move(b['x'],b['y'],steps=4);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(430)
   ck(f'{width}/escape leaves model stable',get(page)['model']['events']==['EVEN','HEADS'])
   ck(f'{width}/no stranded drag',page.evaluate('NOVA.ui._drag===null'))
   # invalid slot: choose HEADS, drag palette to slot A: should fail, not modify
   page.locator('select[aria-label="Event token"]').select_option('HEADS')
   drag(page,L['x'],L['y'],L['tx'],L['ty'])
   ck(f'{width}/invalid kind-specific event rejected',get(page)['model']['events']==['EVEN','HEADS'])
   # valid coin slot assignment via controls
   page.locator('select[aria-label="Event target"]').select_option('1');page.get_by_role('button',name='Remove event').click()
   ck(f'{width}/keyboard remove second event',get(page)['model']['events']==['EVEN',None])
   page.get_by_role('button',name='Place event').click()
   ck(f'{width}/keyboard restore heads event',get(page)['model']['events']==['EVEN','HEADS'])
   # clear, then 20 trials (empirical tally validates exact counts)
   page.get_by_role('button',name='Run 20 trials').click();page.wait_for_timeout(100)
   st=get(page);ck(f'{width}/20 run trials',len(st['model']['history'])==20)
   ck(f'{width}/outcomes in valid sample space',all(1<=i['out']['a']<=6 and i['out']['c'] in ['H','T'] for i in st['model']['history']))
   ck(f'{width}/trial win checking matches event',all(i['win']==(i['out']['a']%2==0 and i['out']['c']=='H') for i in st['model']['history']))
   ck(f'{width}/experimental exact wins fraction',abs(st['relativeFrequency']-sum(i['win'] for i in st['model']['history'])/20)<1e-10)
   ck(f'{width}/theoretical unchanged by run',abs(st['theoretical']-.25)<1e-10)
   page.get_by_role('button',name='Run 100 trials').click();page.wait_for_timeout(100)
   ck(f'{width}/100 more trials',len(get(page)['model']['history'])==120)
   page.get_by_role('button',name='Clear trials').click();ck(f'{width}/clear trials',len(get(page)['model']['history'])==0)
   presets={'y7experiment':('coin',2,1,.5),'y8compare':('die',6,2,1/3),'y9relative':('twodice',36,6,1/6)}
   for key,(kind,size,fav,theory) in presets.items():
    page.locator('select[aria-label="Lesson preset"]').select_option(key);st=get(page)
    ck(f'{width}/{key} valid preset',st['model']['kind']==kind)
    ck(f'{width}/{key} theory',st['space']==size and st['favourable']==fav and abs(st['theoretical']-theory)<1e-10,st['favourable'])
    page.get_by_role('button',name='Run 20 trials').click();page.wait_for_timeout(120)
    st=get(page);ck(f'{width}/{key} 20 valid experiments',len(st['model']['history'])==20)
    if key=='y9relative':ck(f'{width}/two dice count only sum seven',all(i['win']==(i['out']['a']+i['out']['b']==7) for i in st['model']['history']))
   # test keyboard attempt with incompatible HEADS on second die
   page.locator('select[aria-label="Event token"]').select_option('DOUBLES');page.locator('select[aria-label="Event target"]').select_option('1');page.get_by_role('button',name='Remove event').click()
   ck(f'{width}/Y9 no second slot changes primary',get(page)['model']['events'][0]=='SUM7')
   ck(f'{width}/no drag pending on preset switches',page.evaluate('NOVA.ui._drag===null'))
   # Challenge wrong/correct through progression
   page.locator('.nova-tab[data-m="challenge"]').click();page.wait_for_timeout(100)
   inp=page.locator('.nova-panel input').first
   inp.fill('8');page.get_by_role('button',name='Check',exact=True).click()
   ck(f'{width}/challenge 1 rejects addition',page.locator('.nova-fb.bad').count()>0)
   inp.fill('12');page.get_by_role('button',name='Check',exact=True).click()
   ck(f'{width}/challenge 1 correct',page.locator('.nova-fb.ok').count()>0)
   page.wait_for_timeout(840);ck(f'{width}/challenge 2 advance',page.evaluate('NOVA_F17_03_CONFIG._challenge.task()')==1)
   inp=page.locator('.nova-panel input').first;inp.fill('0.5');page.get_by_role('button',name='Check',exact=True).click()
   ck(f'{width}/challenge 2 rejects theoretical',page.locator('.nova-fb.bad').count()>0)
   inp.fill('0.35');page.get_by_role('button',name='Check',exact=True).click()
   ck(f'{width}/challenge 2 correct',page.locator('.nova-fb.ok').count()>0)
   page.wait_for_timeout(840);ck(f'{width}/challenge 3 advance',page.evaluate('NOVA_F17_03_CONFIG._challenge.task()')==2)
   page.get_by_role('button',name='2 faces').click();page.get_by_role('button',name='Check',exact=True).click()
   ck(f'{width}/challenge 3 correct',page.locator('.nova-fb.ok').count()>0)
   page.wait_for_timeout(840);ck(f'{width}/challenge 4 advance',page.evaluate('NOVA_F17_03_CONFIG._challenge.task()')==3)
   inp=page.locator('.nova-panel input').first;inp.fill('3');page.get_by_role('button',name='Check',exact=True).click()
   ck(f'{width}/challenge 4 rejects missing reverse pairs',page.locator('.nova-fb.bad').count()>0)
   inp.fill('6');page.get_by_role('button',name='Check',exact=True).click()
   ck(f'{width}/challenge 4 correct',page.locator('.nova-fb.ok').count()>0)
   ck(f'{width}/final no JS errors',not errors,errors[-1] if errors else None)
  except Exception as e:
   ck(f'{width}/uncaught test exception',False,str(e));traceback.print_exc()
  finally:page.close()
 browser.close()
(Path(__file__).resolve().parent / 'F17-03-STRESS-RESULTS.json').write_text(json.dumps({'total':len(res),'pass':sum(x['passed'] for x in res),'fail':[x for x in res if not x['passed']],'tests':res},indent=2))
print('TOTAL',len(res),'PASS',sum(x['passed'] for x in res),'FAIL',sum(not x['passed'] for x in res))
