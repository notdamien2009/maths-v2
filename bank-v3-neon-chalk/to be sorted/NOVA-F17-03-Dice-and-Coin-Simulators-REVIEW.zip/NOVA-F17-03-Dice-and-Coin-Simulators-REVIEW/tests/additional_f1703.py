from playwright.sync_api import sync_playwright
from pathlib import Path
import json
html=(Path(__file__).resolve().parents[1] / 'F17-03-Dice-and-Coin-Simulators-PREMIUM-REVIEW.html').read_text();data=[]
def chk(label,c,detail=None):
 data.append(dict(test=label,passed=bool(c),details=detail));print(('PASS' if c else 'FAIL'),label,detail or '',flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':970},reduced_motion='no-preference');err=[];page.on('pageerror',lambda e:err.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded',timeout=60000)
  page.locator('.nova-tab[data-m="explore"]').click()
  sel=page.locator('select[aria-label="Lesson preset"]')
  for key in ['y7experiment','y8compare','y9relative']:
   sel.select_option(key);page.locator('.nova-stage').screenshot(path=str(Path(__file__).resolve().parents[1] / 'screenshots' / f'F17-03-{width}-{key}.png'))
   chk(f'{width}/{key} no image overflow',page.evaluate('''()=>{let s=document.querySelector('.nova-stage .f173-plot');let z=s.getBoundingClientRect(),t=s.parentElement.getBoundingClientRect();return z.left>=t.left-3&&z.right<=t.right+3}'''))
  # Y9 second event changes the conjunction and clears previous trial history
  page.locator('select[aria-label="Event token"]').select_option('DOUBLES');page.locator('select[aria-label="Event target"]').select_option('1');page.get_by_role('button',name='Place event').click()
  st=page.evaluate('NOVA_F17_03_CONFIG._explore.get()')
  chk(f'{width}/Y9 two-dice compound impossible conjunction',st['model']['events']==['SUM7','DOUBLES'] and st['theoretical']==0,st['model']['events'])
  page.get_by_role('button',name='Run 20 trials').click();page.wait_for_timeout(1150)
  st=page.evaluate('NOVA_F17_03_CONFIG._explore.get()');chk(f'{width}/no erroneous favourable in incompatible 2-event model',len(st['model']['history'])==20 and not any(a['win'] for a in st['model']['history']))
  page.locator('select[aria-label="Event target"]').select_option('1');page.get_by_role('button',name='Remove event').click()
  st=page.evaluate('NOVA_F17_03_CONFIG._explore.get()');chk(f'{width}/editing event clears history',len(st['model']['history'])==0 and abs(st['theoretical']-1/6)<1e-10)
  # Single-trial animation evidence in no-preference motion setting
  sel.select_option('y7experiment');page.get_by_role('button',name='Run 1 trial').click()
  page.wait_for_timeout(250)
  mid=page.evaluate('''()=>({transform:document.querySelector('[data-device]')?.getAttribute('transform'),length:NOVA_F17_03_CONFIG._explore.get().model.history.length})''')
  chk(f'{width}/device actually animates in normal motion',bool(mid['transform']) and mid['length']==0,mid)
  page.wait_for_timeout(1100)
  after=page.evaluate('NOVA_F17_03_CONFIG._explore.get()');chk(f'{width}/single trial completes after animation',len(after['model']['history'])==1 and after['model']['tumble']==False)
  # pointercancel explicit via dispatched PointerEvent to live drag element
  page.locator('svg.f173-plot').scroll_into_view_if_needed()
  probe=page.evaluate('''()=>{let g=document.querySelector('[data-slot-token]'),s=document.querySelector('svg.f173-plot');if(!g)return {ok:false};let r=g.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;g.dispatchEvent(new PointerEvent('pointerdown',{pointerId:55,button:0,bubbles:true,clientX:x,clientY:y}));let on=!!NOVA.ui._drag;g.dispatchEvent(new PointerEvent('pointercancel',{pointerId:55,button:0,bubbles:true,clientX:x+100,clientY:y+100}));return {on,after:!!NOVA.ui._drag}}''')
  page.wait_for_timeout(390)
  chk(f'{width}/pointercancel clears active drag',probe.get('on') and not page.evaluate('!!NOVA.ui._drag'),probe)
  chk(f'{width}/no JavaScript errors',not err,err[-1] if err else None)
  page.close()
 b.close()
(Path(__file__).resolve().parent / 'F17-03-ADDITIONAL-RESULTS.json').write_text(json.dumps({'total':len(data),'pass':sum(x['passed'] for x in data),'fail':[x for x in data if not x['passed']],'tests':data},indent=2))
print('TOTAL',len(data),'PASS',sum(x['passed'] for x in data))
