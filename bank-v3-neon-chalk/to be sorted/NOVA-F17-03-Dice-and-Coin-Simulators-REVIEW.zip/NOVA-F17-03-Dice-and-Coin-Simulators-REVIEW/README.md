NOVA MATHS V2 — F17-03 DICE AND COIN SIMULATORS

Open F17-03-Dice-and-Coin-Simulators-PREMIUM-REVIEW.html in a browser. All assets are embedded.
Review QA-REPORT.md and the screenshots/tests before approval. No GitHub changes.
