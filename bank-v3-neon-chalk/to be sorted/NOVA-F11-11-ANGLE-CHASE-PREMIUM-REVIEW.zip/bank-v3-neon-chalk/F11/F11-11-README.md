# F11-11 · Angle Chase / F11-13 Geometry Proof Stepper — Premium Review

Standalone HTML: `F11/F11-11-angle-chase.html`.

## Teaching engine
- The original NOVA F0/F1 neon and chalk core is embedded in the standalone HTML; no upstream core changes.
- Watch, Guided, Explore and Challenge.
- Six mathematically distinct geometry constructions: straight line, around a point, vertically opposite, parallel lines, triangles (including isosceles), and polygons.
- Twenty-nine guided storyboard states and eleven named curriculum presets.
- Ten answer-and-reason Challenge tasks, including Y9 deductive reasoning.
- F11-13 formal geometric proof is a preset of F11-11, **not** a separate engine. Choose the F11-13 preset in Explore to reveal Given → Rule → Calculation → Conclusion cumulatively.
- Live drag handles and accessible keyboard alternatives; Escape cancels and restores. Reason cards drag into the reason box and can also be selected by click/keyboard. **Reason cards are not dropped directly onto individual SVG angle sectors.**

## Install into the repository after owner approval
Extract the top folder `bank-v3-neon-chalk/` into the bank. Review before replacing paths. It installs only the F11-11 component, its editable sources, builder, tests and screenshots. The protected existing `core/nova-core.js` and `.css` are **not included or overwritten**. Run from bank root:

`python3 build/build-F11-11.py`

Builder reads the repository's own `core/` and the F11-11 source. Recheck appearance if that core has changed since this review, as the self-contained HTML was built with the F11-10 review's protected core snapshot.

## Source and QA
- `build/F11-11.src.html`, `build/build-F11-11.py`, `src/F11-11.js`, `src/F11-11.css`
- `tests/test_f111.py`, `tests/F11-11-QA.json`, `tests/F11-11-MANIFEST.json`
- `shots/F11-11/` contains screenshots at 380px and 1280px, four modes and each curriculum preset.
- Stress testing includes fast pointer movement, pointer cancellation via Escape, keyboard adjustment, live geometry refresh, proof reveal, reason drops, ten challenges and algebraic geometry checks.
- Test environment: Chromium via Playwright, reduced-motion emulation; this is not physical touchscreen validation.

## Known boundaries
- F11-12 is a preset of F18-03 and is outside this F11-11 build.
- Owner GOLD approval is still pending. No GitHub modification was made.
