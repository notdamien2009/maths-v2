#!/usr/bin/env python3
"""F11-11 review tests: geometry, proof preset, actual pointer dragging, mobile/desktop and all ten challenges."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json,hashlib,sys,math
root=Path(__file__).resolve().parents[1]
s=(root/'F11/F11-11-angle-chase.html').read_text()
shots=root/'shots/F11-11'; shots.mkdir(parents=True,exist_ok=True)
passed=[];fail=[]
def ck(name,predicate):
 try:
  if not predicate:raise AssertionError('condition was false')
  passed.append(name)
 except Exception as e:fail.append({'test':name,'error':str(e)})
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  page=browser.new_page(viewport={'width':width,'height':1000},reduced_motion='reduce');errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content(s,wait_until='load');page.wait_for_timeout(110)
  ck(f'{width} shell',page.locator('#F11-11').count()==1)
  ck(f'{width} tabs',page.get_by_role('tab').count()==4)
  ck(f'{width} genuine embedded NOVA Chalk',page.evaluate('document.fonts.check("20px NOVA Chalk")'))
  ck(f'{width} SVG',page.locator('[data-testid=f111-svg]').count()==1)
  ck(f'{width} contained mascot',page.evaluate('''()=>{let a=document.querySelector('.f111-theatre').getBoundingClientRect(),b=document.querySelector('.f111-theatre .nv-dockfig').getBoundingClientRect();return b.left>=a.left-2&&b.right<=a.right+2&&b.top>=a.top-2&&b.bottom<=a.bottom+2}'''))
  for mode in ('Watch','Guided','Explore','Challenge'):
   page.get_by_role('tab',name=mode,exact=True).click();page.wait_for_timeout(35)
   ck(f'{width} {mode} visible',page.locator('[data-testid=f111-svg]').count()==1)
   page.screenshot(path=str(shots/f'F11-11-{width}-{mode.lower()}.png'),full_page=True,animations='disabled')
  ck(f'{width} challenge result concealed',page.locator('[data-testid=f111-aside] .f111-main').all_inner_texts()[-1]=='?')
  ck(f'{width} challenge proof concealed',page.locator('[data-testid=f111-proofline]').is_hidden())
  tasks=[(115,'straight'),(105,'point'),(73,'opposite'),(62,'alternate'),(122,'cointerior'),(60,'triangle'),(84,'isosceles'),(120,'exterior'),(1080,'polygon'),(60,'triangle')]
  for i,(answer,reason) in enumerate(tasks):
   page.locator('[data-testid=f111-answer]').fill(str(answer))
   page.locator(f'button[data-reason="{reason}"]').click()
   page.get_by_role('button',name='Check answer + reason').click();page.wait_for_timeout(30)
   if i<len(tasks)-1:
    ck(f'{width} task {i+1} correct',page.get_by_role('button',name='Next challenge →').count()==1)
    page.get_by_role('button',name='Next challenge →').click();page.wait_for_timeout(30)
    ck(f'{width} task {i+2} concealed',page.locator('[data-testid=f111-aside] .f111-main').all_inner_texts()[-1]=='?')
   else:ck(f'{width} mastery',page.get_by_text('10 / 10 · ANGLE CHASE MASTERY').count()==1)
  ck(f'{width} challenge runtime',not errs)
  page.get_by_role('tab',name='Explore',exact=True).click()
  presets=['y7_line','y7_point','y7_opposite','y7_parallel','y7_triangle','y8_polygon','y8_congruence','y9_parallel','y9_polygon','y9_proof','y9_congruence']
  for k in presets:
   page.locator('[data-testid=f111-preset]').select_option(k);page.wait_for_timeout(30)
   ck(f'{width} {k} stage',page.locator('[data-testid=f111-geometry]').count()==1)
   page.locator('[data-testid=f111-stage]').screenshot(path=str(shots/f'F11-11-{width}-{k}.png'),animations='disabled')
  page.locator('[data-testid=f111-preset]').select_option('y9_proof');ck(f'{width} proof card populated',page.locator('[data-testid=f111-proofline]').is_visible())
  page.locator('[data-testid=f111-phase]').fill('3');ck(f'{width} proof staged to first named rule', '2/4' in page.locator('[data-testid=f111-proofline]').inner_text())
  page.locator('[data-testid=f111-preset]').select_option('y7_line')
  h=page.locator('[data-testid=f111-angle-handle]');h.scroll_into_view_if_needed();h.focus();initial=int(h.get_attribute('aria-valuenow'))
  page.keyboard.press('ArrowRight');page.wait_for_timeout(50);ck(f'{width} keyboard angle step',int(h.get_attribute('aria-valuenow'))==initial+5)
  h.scroll_into_view_if_needed();r=h.bounding_box();px=r['x']+r['width']/2;py=r['y']+r['height']/2
  page.mouse.move(px,py);page.mouse.down();page.mouse.move(px-80,py+16,steps=1);page.wait_for_timeout(100)
  changed=int(h.get_attribute('aria-valuenow'));ck(f'{width} live fast drag',changed!=initial+5)
  page.keyboard.press('Escape');page.wait_for_timeout(70);ck(f'{width} Escape reset',int(h.get_attribute('aria-valuenow'))==initial+5);page.mouse.up()
  ck(f'{width} nothing stranded',page.evaluate('window.NOVA.ui._drag===null'))
  # Verify actual reason-card drag rather than only click.
  page.get_by_role('tab',name='Challenge',exact=True).click();source=page.locator('button[data-reason=straight]');target=page.locator('[data-testid=f111-reason-drop]');source.scroll_into_view_if_needed();a=source.bounding_box();b=target.bounding_box()
  page.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2);page.mouse.down();page.mouse.move(b['x']+b['width']/2,b['y']+b['height']/2,steps=7);page.mouse.up();page.wait_for_timeout(55)
  ck(f'{width} reason drag accepted',target.get_attribute('data-set')=='true')
  ck(f'{width} reason ghost cleared',page.evaluate('window.NOVA.ui._drag===null'))
  page.locator('[data-testid=f111-answer]').fill('65');page.get_by_role('button',name='Check answer + reason').click()
  ck(f'{width} wrong result rejected',page.get_by_role('button',name='Next challenge →').count()==0)
  page.locator('[data-testid=f111-answer]').fill('115');page.locator('button[data-reason=point]').click();page.get_by_role('button',name='Check answer + reason').click()
  ck(f'{width} wrong reason rejected',page.get_by_role('button',name='Next challenge →').count()==0)
  page.locator('button[data-reason=straight]').click();page.get_by_role('button',name='Check answer + reason').click()
  ck(f'{width} can recover from mistakes',page.get_by_role('button',name='Next challenge →').count()==1)
  for n in range(3,13):
   v=page.evaluate('''n=>{let m=__F111_MATH__.model({kind:'polygon',sides:n});return [m.central,m.interior,m.sum]}''',n)
   ck(f'{width} polygon {n} algebraic accuracy',abs(v[0]-360/n)<1e-8 and abs(v[1]-(180-360/n))<1e-8 and v[2]==(n-2)*180)
  for a in range(35,76,5):
   v=page.evaluate('''a=>{let m=__F111_MATH__.model({kind:'triangle',angle:a});return [m.a,m.b,m.c]}''',a)
   ck(f'{width} triangle sum {a}',abs(sum(v)-180)<1e-8 and abs(v[0]-a)<1e-8 and abs(v[1]-65)<1e-8)
  # Regular polygon handle changes rotation, never the number of sides.
  page.get_by_role('tab',name='Explore',exact=True).click()
  page.locator('[data-testid=f111-preset]').select_option('y8_polygon')
  n_before=int(page.locator('[data-testid=f111-sides]').input_value())
  h=page.locator('[data-testid=f111-angle-handle]');h.focus();page.keyboard.press('ArrowRight');page.wait_for_timeout(50)
  ck(f'{width} polygon rotates by keyboard',int(page.locator('[data-testid=f111-rotation]').input_value())==5)
  ck(f'{width} polygon side count stays fixed',int(page.locator('[data-testid=f111-sides]').input_value())==n_before)
  page.locator('[data-testid=f111-rotation]').fill('45');page.wait_for_timeout(40)
  m=page.evaluate('''()=>{let x=__F111_MATH__.model({kind:'polygon',sides:6,rotation:45});return {rotation:x.rotation,lengths:x.pts.map((p,i)=>Math.hypot(p.x-x.pts[(i+1)%6].x,p.y-x.pts[(i+1)%6].y))}}''')
  ck(f'{width} rotation exact geometry',m['rotation']==45 and max(m['lengths'])-min(m['lengths'])<1e-7)
  ck(f'{width} polygon no runtime errors',not errs)
  ck(f'{width} no JS exceptions',not errs)
  if errs:print(width,'errors',errs)
  page.close()
 browser.close()
report={'engine':'F11-11','status':'premium review','passed':len(passed),'failed':fail,'total':len(passed)+len(fail),'viewports':[380,1280],'sha256':hashlib.sha256(s.encode()).hexdigest()}
(root/'tests/F11-11-QA.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2));sys.exit(1 if fail else 0)
