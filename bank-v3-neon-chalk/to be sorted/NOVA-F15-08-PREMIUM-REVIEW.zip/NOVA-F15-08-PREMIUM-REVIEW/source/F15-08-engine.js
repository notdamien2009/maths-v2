/* F15-08 Unit Circle Explorer — existing NOVA F0/F2 neon/chalk engine, not a replacement design system */
(function(){'use strict';
var H=NOVA.h,S=NOVA.svg,E=S.el,M=NOVA.motion,ID='F15-08',RAD=Math.PI/180;
var CONFIG=window.NOVA_F15_08_CONFIG={startMode:'watch',preset:'quadrants',events:['value','step','mode','hintUsed','correct','theta','label','preset'],presets:{
 quadrants:{label:'All four quadrants',theta:45,min:0,max:360,kind:'explorer'},
 y9first:{label:'Link to Year 9 trig · 30°',theta:30,min:0,max:360,kind:'trig'},
 axes:{label:'Axis landmarks · 90°',theta:90,min:0,max:360,kind:'axes'},
 second:{label:'Quadrant II · 120°',theta:120,min:0,max:360,kind:'signs'},
 third:{label:'Quadrant III · 225°',theta:225,min:0,max:360,kind:'signs'},
 fourth:{label:'Quadrant IV · 315°',theta:315,min:0,max:360,kind:'signs'},
 gcse:{label:'GCSE extension · 210°',theta:210,min:0,max:360,kind:'extension'}
 }};
var STEPS=[
 {name:'A circle of radius one',pose:'explain',theta:30,say:'This is a circle centred at the origin. Every point on the circumference is exactly one unit from the centre.'},
 {name:'Angles start on positive x',pose:'point-right',theta:0,say:'Zero degrees starts on the positive horizontal axis. We measure positive angles anticlockwise.'},
 {name:'Turn through thirty degrees',pose:'ruler',theta:30,say:'Rotate the radius anticlockwise by thirty degrees. Its length stays exactly one.'},
 {name:'Drop the vertical projection',pose:'point-down',theta:30,say:'Drop a perpendicular from the point to the horizontal axis. The foot completes a right angled triangle.'},
 {name:'Horizontal coordinate is cosine',pose:'show-one',theta:30,say:'Cosine is the signed horizontal coordinate. In quadrant one it is positive.'},
 {name:'Vertical coordinate is sine',pose:'show-two',theta:30,say:'Sine is the signed vertical coordinate. Here it is also positive.'},
 {name:'Read the ordered pair',pose:'count',theta:30,say:'The point has coordinates cosine theta, then sine theta. Horizontal comes first, vertical second.'},
 {name:'Pythagoras still holds',pose:'idea',theta:30,say:'The legs form a right triangle with hypotenuse one. Cosine squared plus sine squared equals one.'},
 {name:'Ninety-degree landmark',pose:'point-left',theta:90,say:'At ninety degrees cosine is zero and sine is one. The point sits at the very top.'},
 {name:'Quadrant two: negative x',pose:'compare',theta:135,say:'Beyond ninety degrees the horizontal coordinate turns negative while the vertical coordinate stays positive.'},
 {name:'One hundred eighty degrees',pose:'show-one',theta:180,say:'At one hundred eighty degrees, the point is negative one, zero.'},
 {name:'Quadrant three: both negative',pose:'think',theta:225,say:'In quadrant three both coordinates are negative. Cosine and sine keep their signed meanings.'},
 {name:'Two hundred seventy degrees',pose:'point-down',theta:270,say:'At two hundred seventy degrees cosine is zero and sine is negative one.'},
 {name:'Quadrant four: positive x',pose:'magnify',theta:315,say:'In quadrant four cosine is positive and sine negative. The horizontal and vertical projections tell the signs.'},
 {name:'Full turn to three sixty',pose:'celebrate',theta:360,say:'After three hundred sixty degrees the point returns to one, zero. One full revolution is complete.'},
 {name:'Tangent and undefined points',pose:'explain',theta:90,say:'Tangent equals sine divided by cosine. At ninety and two hundred seventy degrees cosine is zero, so tangent is undefined.'},
 {name:'Move and predict',pose:'question',theta:210,say:'Try moving the point. Before looking at the values, predict the signs from the quadrant.'}
];
function fmt(v,dp){if(!Number.isFinite(v))return 'undefined';if(Math.abs(v)<1e-9)v=0;return dp==null?String(Number(v.toFixed(2))):Number(v).toFixed(dp);}
function clamp(x,a,b){return Math.max(a,Math.min(b,x));}
function vals(theta){theta=Number(theta);var r=theta*RAD,x=Math.cos(r),y=Math.sin(r);if(Math.abs(x)<1e-12)x=0;if(Math.abs(y)<1e-12)y=0;var tan=x===0?null:y/x;var q=theta===0||theta===360||theta===90||theta===180||theta===270?'axis':Math.floor(theta/90)+1;var ref=q==='axis'?0:Math.min(theta%180,180-theta%180);return {theta:theta,x:x,y:y,tan:tan,quadrant:q,ref:ref,id:fmt(x,3)+', '+fmt(y,3),sq:x*x+y*y};}
window.NOVA_F15_08_MATH={values:vals,presets:CONFIG.presets,steps:STEPS};
function emit(k,v){NOVA.events.emit('value',{engine:ID,key:k,control:k,value:v});}
function ch(g,x,y,text,role,size,anchor){return NOVA.chalkText(g,x,y,String(text),{role:role||'unknown',size:size||20,anchor:anchor||'middle'});}
function path(g,d,role,w,opt){return NOVA.neonPath(g,d,Object.assign({role:role||'op',width:w||3},opt||{}));}
function ln(g,x1,y1,x2,y2,role,w){return path(g,'M'+fmt(x1,3)+' '+fmt(y1,3)+' L'+fmt(x2,3)+' '+fmt(y2,3),role,w);}
function rect(g,x,y,w,h,role){return NOVA.neonBox(g,x,y,w,h,{role:role||'support'});}
function btn(text,fn){return H('button',{class:'nova-btn',text:text,onclick:fn});}
function rw(p,els){p.appendChild(H('div',{class:'f158-controls'},els));}
function layout(mob){return mob?{W:420,H:796,cx:210,cy:227,r:145,cardX:14,cardY:458,cardW:392,cardH:64,trayY:744}:{W:820,H:565,cx:238,cy:252,r:182,cardX:479,cardY:84,cardW:320,cardH:84,trayY:505};}
function proj(theta,L){var v=vals(theta);return {px:L.cx+v.x*L.r,py:L.cy-v.y*L.r,fx:L.cx+v.x*L.r,fy:L.cy,v:v};}
function polarArc(cx,cy,r,theta){if(theta>=360)return 'M'+(cx+r)+' '+cy+' A'+r+' '+r+' 0 1 0 '+(cx-r)+' '+cy+' A'+r+' '+r+' 0 1 0 '+(cx+r)+' '+cy;var t=theta*RAD;return 'M'+(cx+r)+' '+cy+' A'+r+' '+r+' 0 '+(theta>180?1:0)+' 0 '+fmt(cx+r*Math.cos(t),3)+' '+fmt(cy-r*Math.sin(t),3);}
function scene(stage,st,o){o=o||{};stage.textContent='';var mob=innerWidth<=540,L=layout(mob),v=vals(st.theta),g=S.root(L.W,L.H,'Unit circle at '+v.theta+' degrees. P equals cosine '+fmt(v.x,3)+' and sine '+fmt(v.y,3)+'. Quadrant '+v.quadrant+'. Tangent '+(v.tan===null?'undefined':fmt(v.tan,3))+'.');g.classList.add('f158-board');var step=o.step==null?16:o.step;
 // Atmospheric mathematical construction, intentionally subordinate to the neon circle.
 var guides=E('g',{style:'opacity:.12;pointer-events:none'},g);for(var k=-4;k<=4;k++){var dx=k*(L.r/4);ln(guides,L.cx+dx,L.cy-L.r-18,L.cx+dx,L.cy+L.r+18,'support',.7);ln(guides,L.cx-L.r-18,L.cy+dx,L.cx+L.r+18,L.cy+dx,'support',.7);}
 // Canonical neon paths with glass fill, real circle and two coordinate axes.
 var circle='M'+(L.cx-L.r)+' '+L.cy+' A'+L.r+' '+L.r+' 0 1 0 '+(L.cx+L.r)+' '+L.cy+' A'+L.r+' '+L.r+' 0 1 0 '+(L.cx-L.r)+' '+L.cy;
 path(g,circle,'result',5.6);ln(g,L.cx-L.r-24,L.cy,L.cx+L.r+24,L.cy,'given',3.2);ln(g,L.cx,L.cy-L.r-22,L.cx,L.cy+L.r+22,'support',3.2);
 for(var a=0;a<360;a+=90){var xx=L.cx+L.r*Math.cos(a*RAD),yy=L.cy-L.r*Math.sin(a*RAD);NOVA.neonRing(g,xx,yy,{r:4.7,role:'unknown'});}
 ch(g,L.cx+L.r+13,L.cy-13,'x','given',mob?19:20,'start');ch(g,L.cx+11,L.cy-L.r-16,'y','support',mob?19:20,'start');
 ch(g,L.cx-12,L.cy+26,'O','unknown',mob?18:19,'end');
 var quad=(s)=>ch(g,L.cx+(s[0])*L.r*.55,L.cy+(s[1])*L.r*.62,s[2],'unknown',mob?17:18);
 quad([1,-1,'I']);quad([-1,-1,'II']);quad([-1,1,'III']);quad([1,1,'IV']);
 if(step>=2||o.interactive){path(g,'M'+L.cx+' '+L.cy+' L'+fmt(v.px??(L.cx+v.x*L.r),3)+' '+fmt(L.cy-v.y*L.r,3),'result',4.7);}
 var P=proj(st.theta,L),px=P.px,py=P.py,fx=P.fx,fy=P.fy;
 if(step>=3||o.interactive){ln(g,px,py,fx,fy,'support',4.1);ln(g,L.cx,L.cy,fx,fy,'given',4.1);if(Math.abs(px-L.cx)>18&&Math.abs(py-L.cy)>18){var xx=px+(px>L.cx?-10:10),yy=fy+(py<fy?-10:10);path(g,'M'+fmt(xx,2)+' '+fy+' L'+fmt(xx,2)+' '+fmt(yy,2)+' L'+fmt(px,2)+' '+fmt(yy,2),'focus',2.8);}}
 // Angle construction uses mathematically correct SVG arcs for the full 360° sweep.
 if(step>=1||o.interactive){path(g,polarArc(L.cx,L.cy,mob?37:46,st.theta),'focus',3.4);var at=st.theta>320?320:Math.max(18,st.theta/2),ar=mob?59:72;ch(g,L.cx+ar*Math.cos(at*RAD),L.cy-ar*Math.sin(at*RAD),fmt(st.theta)+'°','focus',mob?18:20);}
 if(step>=2||o.interactive){NOVA.neonRing(g,px,py,{r:12,role:'focus'});var lx=clamp(px+(v.x>=0?-20:18),28,L.W-35),ly=clamp(py+(v.y>=0?-21:30),28,L.cy+L.r+25);ch(g,lx,ly,'P','focus',mob?20:23);}
 // Readouts are mathematical glass cards and keep the model at full scale.
 var items=[{name:'cos θ',val:fmt(v.x,3),role:'given',comment:'signed horizontal coordinate x'},{name:'sin θ',val:fmt(v.y,3),role:'support',comment:'signed vertical coordinate y'},{name:'tan θ',val:v.tan===null?'undefined':fmt(v.tan,3),role:'result',comment:v.tan===null?'cos θ = 0: no division by zero':'sin θ ÷ cos θ'}];
 items.forEach(function(it,i){var x=L.cardX,y=L.cardY+i*(L.cardH+(mob?9:12)),h=L.cardH;rect(g,x,y,L.cardW,h,it.role);ch(g,x+18,y+(mob?24:32),it.name,it.role,mob?21:22,'start');ch(g,x+L.cardW-17,y+(mob?24:32),(i===0&&step<4&&!o.interactive)||(i===1&&step<5&&!o.interactive)||(i===2&&step<15&&!o.interactive)?'·':it.val,it.role,mob?22:25,'end');ch(g,x+17,y+(mob?49:63),it.comment,'unknown',mob?15.5:17,'start');});
 if(step>=6||o.interactive){if(mob){ch(g,25,436,'P = ( cos θ, sin θ )','unknown',21,'start');}else{ch(g,L.cardX+12,54,'P = ( cos θ, sin θ )','unknown',23,'start');}}
 var eqy=mob?703:459;if(step>=7||o.interactive)ch(g,mob?210:641,eqy,'cos² θ + sin² θ = 1','result',mob?22:23);
 if(o.interactive){
  // Point constrained on true circle. One F2-style SVG drag for smooth actual pointer capture.
  var point=E('g',{tabindex:'0',role:'slider','data-handle':'circle-point','aria-label':'Move the point on the unit circle. Left and right arrow keys adjust the angle.','aria-valuemin':'0','aria-valuemax':'360','aria-valuenow':String(st.theta)},g);NOVA.neonRing(point,px,py,{r:14,role:'focus'});
  var zones=[];for(var angle=0;angle<=355;angle+=5){var pt=proj(angle,L);zones.push({x:pt.px-11,y:pt.py-11,w:22,h:22,id:String(angle),kind:'drop'});}zones.push({x:L.cx+L.r-11,y:L.cy-11,w:22,h:22,id:'360',kind:'drop'});
  NOVA.ui.svgDrag(g,point,{box:{x:px-17,y:py-17,w:34,h:34},zones:function(){return zones;},onDrop:function(id){st.theta=+id;st.feedback='The point moved to '+id+' degrees. Horizontal means cosine; vertical means sine.';emit('theta',st.theta);o.update();return true;}});
  point.addEventListener('keydown',function(e){if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(e.key))return;e.preventDefault();st.theta=e.key==='Home'?0:e.key==='End'?360:clamp(st.theta+(e.key==='ArrowLeft'||e.key==='ArrowDown'?-5:5),0,360);emit('theta',st.theta);o.update('circle-point');});
  // Label cards may be moved from tray to projected coordinate roles, with removal by tray.
  var nearZeroX=Math.abs(px-L.cx)<28,nearZeroY=Math.abs(py-L.cy)<28;
  var targets={cos:{name:'cosine x',role:'given',loc:[nearZeroX?L.cx-64:(L.cx+px)/2,L.cy+(py<L.cy?23:-23)]},
   sin:{name:'sine y',role:'support',loc:[px+(px>L.cx?30:-30),nearZeroY?L.cy-58:(L.cy+py)/2]},
   radius:{name:'radius 1',role:'result',loc:[(L.cx+px)/2+(py>L.cy?23:-23),(L.cy+py)/2+(px>L.cx?-23:23)]}};
  var bx=mob?6:27,bw=mob?130:128,by=L.trayY;
  Object.keys(targets).forEach(function(key,i){var t=targets[key],placed=!!st.placed[key],x=placed?clamp(t.loc[0]-bw/2,4,L.W-bw-4):bx+i*(bw+7),y=placed?clamp(t.loc[1]-20,10,L.H-44):by;
   var grp=E('g',{tabindex:'0',role:'button','data-label':key,'aria-label':'Drag '+t.name+' card to the correct feature, or press Enter to place and remove it'},g);rect(grp,x,y,bw,37,t.role);ch(grp,x+bw/2,y+26,t.name,t.role,mob?17.5:18);
   var zz=Object.keys(targets).map(function(k){return {x:targets[k].loc[0]-21,y:targets[k].loc[1]-21,w:42,h:42,id:k,kind:'drop'};});
   if(placed)zz.push({x:bx-3,y:by-3,w:bw*3+20,h:46,id:'remove',kind:'remove'});
   NOVA.ui.svgDrag(g,grp,{box:{x:x,y:y,w:bw,h:37},zones:function(){return zz;},onDrop:function(id){if(id!==key){st.feedback='Incorrect target: check what '+t.name+' measures.';o.update();return false;}st.placed[key]=true;st.feedback=t.name+' correctly matched.';emit('label',key);o.update();return true;},onRemove:function(){st.placed[key]=false;st.feedback=t.name+' returned to the tray.';o.update();}});
   grp.addEventListener('keydown',function(e){if(!['Enter',' '].includes(e.key))return;e.preventDefault();st.placed[key]=!st.placed[key];st.feedback=t.name+(st.placed[key]?' placed.':' returned to tray.');emit('label',key);o.update(key);});
  });
 }
 stage.appendChild(g);
 if(!o.interactive&&step>=7)stage.appendChild(H('div',{class:'f158-proof',text:step===15?'Undefined tangent at 90° or 270°: the denominator cos θ is zero.':'The unit radius gives cos² θ + sin² θ = 1 in every quadrant.'}));
 NOVA.scene.helperStrip(stage,o.pose||'explain',o.say||'Follow the horizontal and vertical projections to read sine and cosine.');
 if(o.animate&&!NOVA.reducedMotion()){var elem=g.querySelector('.nv-neon-tube');if(elem){elem.style.opacity='.27';M.tween(360,function(t){if(elem.isConnected)elem.style.opacity=String(.27+.73*t);},M.ease.out,function(){if(elem.isConnected)elem.style.opacity='1';});}}
 return g;
}
function stepRender(i,stage){var step=STEPS[i],st={theta:step.theta,placed:{}};scene(stage,st,{step:i,pose:step.pose,say:step.say,animate:true});}
var DEF={id:ID,title:'Unit Circle Explorer',config:CONFIG,steps:STEPS,render:stepRender,
 alt:'Interactive unit circle with anticlockwise angle, point P, x cosine and y sine projections and quadrant signs.',
 staticAlt:'On the unit circle P = (cos θ, sin θ), cos squared θ plus sin squared θ equals one. Quadrant I (+,+), II (−,+), III (−,−), IV (+,−). Tangent undefined at 90 or 270 degrees.',
 exploreIntro:'Drag the neon ring around the exact unit circle. Watch the signed x and y projections, quadrant and trig readouts. Place the labels by dragging them to the matching features.',
 explore:function(panel,stage,api){var base=CONFIG.presets[CONFIG.preset],st={theta:base.theta,placed:{},feedback:'Drag the point. The radius remains one, so P always has coordinates (cos θ, sin θ).'};
  var preset=H('select',{class:'nova-input','aria-label':'Unit circle exploration preset'});Object.keys(CONFIG.presets).forEach(function(k){preset.appendChild(H('option',{value:k,text:CONFIG.presets[k].label}));});preset.value=CONFIG.preset;
  var angle=H('input',{type:'range',min:0,max:360,step:1,value:st.theta,'aria-label':'Angle theta from zero to 360 degrees'});var output=H('div',{class:'f158-report','aria-live':'polite'});
  function paint(focus){angle.value=st.theta;var v=vals(st.theta);scene(stage,st,{interactive:true,pose:Object.values(st.placed).filter(Boolean).length===3?'celebrate':'magnify',say:st.feedback,update:paint});output.textContent='θ '+fmt(st.theta)+'°. P = ('+fmt(v.x,3)+', '+fmt(v.y,3)+'). '+(v.quadrant==='axis'?'On an axis.':'Quadrant '+v.quadrant+'.')+' cos θ '+fmt(v.x,3)+', sin θ '+fmt(v.y,3)+', tangent '+(v.tan===null?'undefined':fmt(v.tan,3))+'. '+st.feedback;if(focus){var n=stage.querySelector('[data-handle="'+focus+'"], [data-label="'+focus+'"]');if(n)n.focus({preventScroll:true});}}
  preset.onchange=function(){CONFIG.preset=preset.value;base=CONFIG.presets[CONFIG.preset];st={theta:base.theta,placed:{},feedback:'Preset loaded. Predict the signs from the quadrant.'};emit('preset',CONFIG.preset);paint();};
  angle.oninput=function(){st.theta=+angle.value;st.feedback='The radius is still exactly one.';emit('theta',st.theta);paint();};
  rw(panel,[H('label',{text:'Preset'}),preset]);rw(panel,[H('label',{text:'Angle θ'}),angle,H('strong',{text:'0°–360°'})]);
  rw(panel,[btn('−15°',function(){st.theta=clamp(st.theta-15,0,360);emit('theta',st.theta);paint();}),btn('+15°',function(){st.theta=clamp(st.theta+15,0,360);emit('theta',st.theta);paint();}),btn('90°',function(){st.theta=90;paint();}),btn('180°',function(){st.theta=180;paint();}),btn('270°',function(){st.theta=270;paint();}),btn('Reset',function(){st={theta:base.theta,placed:{},feedback:'Return to the starting angle.'};paint();})]);panel.appendChild(output);paint();CONFIG._explore={state:function(){return st;},paint:paint,select:function(k){preset.value=k;preset.onchange();}};
 },
 challenge:function(panel,api,stage){var Q=[
  {q:'At 30°, what is the y-coordinate of the unit-circle point? Give 2 decimal places.',theta:30,ans:.5,dp:2,hint:'The y-coordinate is sine of the angle.',wrong:[{v:.866,msg:'That is cosine: the x-coordinate, not y.'}]},
  {q:'At 120°, what is cos θ to 2 decimal places?',theta:120,ans:-.5,dp:2,hint:'Quadrant II has negative x. cos 120° = −cos 60°.',wrong:[{v:.5,msg:'Quadrant II x-values are negative: the sign is missing.'},{v:.866,msg:'That is the size of sine, not cosine.'}]},
  {q:'At 270°, what is sin θ?',theta:270,ans:-1,dp:0,hint:'The bottom of the circle has y = −1.',wrong:[{v:1,msg:'Sine is negative at the bottom of the unit circle.'},{v:0,msg:'Zero is cosine at 270°, not sine.'}]},
  {q:'At 300°, give cos θ to 2 decimal places.',theta:300,ans:.5,dp:2,hint:'Quadrant IV has positive x. Its reference angle is 60°.',wrong:[{v:-.5,msg:'Cosine is positive in quadrant IV.'},{v:-.866,msg:'That is sine, not cosine.'}]},
  {q:'At 135°, calculate tan θ.',theta:135,ans:-1,dp:0,hint:'Sine is positive and cosine is negative in quadrant II, so tangent is negative.',wrong:[{v:1,msg:'Opposite signs make tangent negative.'},{v:0,msg:'Tangent = sine divided by cosine, not the horizontal projection.'}]},
  {q:'At 210°, give the x-coordinate to 3 decimal places.',theta:210,ans:-Math.sqrt(3)/2,dp:3,hint:'210° has reference angle 30°. x = −cos 30°.',wrong:[{v:Math.sqrt(3)/2,msg:'Quadrant III x-values are negative.'},{v:-.5,msg:'That is the y-coordinate (sine), not x.'}]},
  {q:'The point is (0, −1). What angle from 0° to 360° is it?',theta:270,ans:270,dp:0,hint:'Find the bottom axis of the unit circle.',wrong:[{v:90,msg:'90° is the top, not the bottom.'},{v:180,msg:'180° is the left end of the horizontal axis.'}]},
  {q:'cos θ = −0.5 and sin θ > 0. Which angle is θ, in degrees?',theta:120,ans:120,dp:0,hint:'Negative cosine, positive sine gives quadrant II. Reference angle is 60°.',wrong:[{v:60,msg:'At 60° cosine is positive.'},{v:240,msg:'At 240° sine is negative: quadrant III.'}]},
  {q:'At 225°, what is the reference angle in degrees?',theta:225,ans:45,dp:0,hint:'A quadrant-III reference angle is θ − 180°.',wrong:[{v:135,msg:'Reference angle is the acute angle to the closest x-axis.'}]}
 ];
 function check(t,v){if(!Number.isFinite(v))return [false,'Enter a finite number, without units.'];var tolerance=Math.pow(10,-t.dp)*.501;if(Math.abs(v-t.ans)<=tolerance)return [true,'Correct. '+fmt(t.ans,t.dp)+(t.ans>2?'°':'')+'.'];for(var w of t.wrong)if(Math.abs(v-w.v)<=Math.max(.015,tolerance))return [false,w.msg];if(t.ans<0&&v>0)return [false,'Check quadrant signs. The horizontal and vertical coordinates can be negative.'];if(t.ans>2&&v>=-1&&v<=1)return [false,'You supplied a ratio or coordinate; this question asks for an angle in degrees.'];return [false,'Trace the horizontal cosine and vertical sine projections, then use the correct quadrant.'];}
 function show(i){var q=Q[i];scene(stage,{theta:q.theta,placed:{}},{step:16,pose:'think',say:'Read the signed coordinates. Check the quadrant before you answer.'});}
 var tasks=Q.map(function(q){return {q:q.q,build:NOVA.entryTask('Number without units',ID),check:function(v){return check(q,v);},hint:q.hint,solve:function(ctl){var input=ctl.querySelector('input');if(input){input.value=fmt(q.ans,q.dp);input.dispatchEvent(new Event('input',{bubbles:true}));}}};});
 NOVA.challengeRun(panel,api,tasks,show,CONFIG);CONFIG._challengeQuestions=Q;CONFIG._check=check;
 }
};
/* Preserve F15-06/F15-07 pointer continuity safeguard; no shared-core modifications. */
(function(){function drag(){var d=NOVA.ui._drag;return d&&d.el&&d.el.closest&&d.el.closest('#'+ID)?d:null;}
 document.addEventListener('pointermove',function(e){if(!e.isTrusted)return;var d=drag();if(d)d.el.dispatchEvent(new PointerEvent('pointermove',{pointerId:e.pointerId,pointerType:e.pointerType,clientX:e.clientX,clientY:e.clientY,buttons:e.buttons,bubbles:false,cancelable:true}));},true);
 document.addEventListener('pointerup',function(e){var d=drag();if(d)d.up(e);},true);
 document.addEventListener('pointercancel',function(e){var d=drag();if(d)d.cancel(e);},true);
 window.addEventListener('blur',function(){var d=drag();if(d)d.cancel();});})();
NOVA.bankMount({id:ID,num:'F15·08',title:'Unit Circle Explorer',def:DEF,years:'Year 9 trigonometric ratios and GCSE extension: unit circle, quadrants, exact values and signed sine/cosine.',linked:['F0-02','F0-03','F14-11','F15-06','F15-07','F15-09'],spec:{purpose:'Model (cos θ, sin θ) as the coordinates of a point on the unit circle, demonstrate projection geometry, signs and the Pythagorean identity.',params:'Angle 0°–360°; quadrant; signed x/y; reference angle; selected preset; tangent and undefined cases.',presets:'Y9 trig link at 30°; axis landmarks; four quadrants; GCSE signed ratios extension.',steps:'17 teaching states from unit radius, anticlockwise sweep, perpendicular projections to quadrant signs, identity and tangent.',interactions:'Mouse/touch/keyboard constrained circle drag; 0°–360° slider; role-label drag/drop and re-grabbing; nine challenge problems.',traps:'Treating sine and cosine as always positive; swapped axes; confusing 90° and 270°; tan where cosine is zero; reference angle sign.',gcse:'Quadrant signs, reference angles and exact special-angle values; unit-circle identity.'}});
var lg=document.getElementById('log');if(lg){function f(e){lg.textContent=new Date(e.time).toLocaleTimeString()+' '+e.type+' '+JSON.stringify(e.detail)+'\n'+lg.textContent.slice(0,5000);}NOVA.events.history().forEach(f);NOVA.events.on('*',f);document.getElementById('clearlog').onclick=function(){lg.textContent='';};}
})();
