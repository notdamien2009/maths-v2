import json
from pathlib import Path
from playwright.sync_api import sync_playwright
s=Path('/mnt/data/NOVA-F15-08-Unit-Circle-Explorer.html').read_text()
results=[];shots=Path('/mnt/data/f15-reference/F15-08-QA')
def check(n,ok,detail=''):
 results.append({'check':n,'pass':bool(ok),'detail':detail});print('PASS' if ok else 'FAIL',n,detail,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errs=[];page.on('pageerror',lambda e:errs.append(str(e)));page.set_content(s,wait_until='domcontentloaded');page.get_by_text('Explore',exact=True).first.click();
  for key,theta in [('quadrants',45),('y9first',30),('axes',90),('second',120),('third',225),('fourth',315),('gcse',210)]:
   page.locator('[aria-label="Unit circle exploration preset"]').select_option(key)
   state=page.evaluate('NOVA_F15_08_CONFIG._explore.state()');check(f'{width} {key} theta',state['theta']==theta,str(state['theta']))
   card_text=page.locator('.f158-board').text_content(); math=page.evaluate('NOVA_F15_08_MATH.values(NOVA_F15_08_CONFIG._explore.state().theta)');check(f'{width} {key} correct rendered coordinate', f'{math["x"]:.3f}' in card_text or f'{math["x"]:.3f}' in page.locator('.f158-report').inner_text(),str(math['id']))
   if key in ['axes','third','fourth']:page.screenshot(path=str(shots/f'{width}-{key}-preset.png'),full_page=True)
  # check watch mode buttons, range and first step
  page.get_by_text('Watch',exact=True).first.click();page.wait_for_timeout(120)
  timeline=page.locator('#F15-08 .nova-tl')
  check(f'{width} watch timeline',timeline.count()==1)
  inputs=timeline.locator('input[type=range]');check(f'{width} timeline scrub control',inputs.count()>0)
  if inputs.count():
   inputs.first.evaluate("(e)=>{e.value=e.min;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}))}");page.wait_for_timeout(60)
   txt=timeline.inner_text();check(f'{width} scrub to first frame','Step 1 of 17' in txt,txt[-150:])
  check(f'{width} no JS exceptions',not errs,str(errs[:3]));page.close()
 b.close()
Path('/mnt/data/f15-reference/F15-08-QA/preset-results.json').write_text(json.dumps(results,indent=2))
print('TOTAL',sum(x['pass'] for x in results),'/',len(results))
