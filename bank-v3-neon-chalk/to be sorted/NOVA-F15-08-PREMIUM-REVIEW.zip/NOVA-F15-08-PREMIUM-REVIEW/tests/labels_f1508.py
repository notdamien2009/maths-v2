import json,math
from pathlib import Path
from playwright.sync_api import sync_playwright
src=Path('/mnt/data/NOVA-F15-08-Unit-Circle-Explorer.html').read_text();results=[]
def ck(w,label,passed,extra=''):
 results.append({'width':w,'check':label,'pass':bool(passed),'detail':str(extra)});print('PASS' if passed else 'FAIL',w,label,extra,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':950});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(src);page.get_by_text('Explore',exact=True).first.click();page.wait_for_timeout(400)
  mob=width==380;L={'W':420,'H':796,'cx':210,'cy':227,'r':145,'bx':6,'bw':130,'by':744} if mob else {'W':820,'H':565,'cx':238,'cy':252,'r':182,'bx':27,'bw':128,'by':505}
  x=L['cx']+L['r']*math.cos(math.pi/4);y=L['cy']-L['r']*math.sin(math.pi/4)
  targets={'cos':((L['cx']+x)/2,L['cy']+23),'sin':(x+30,(L['cy']+y)/2),'radius':((L['cx']+x)/2-23,(L['cy']+y)/2-23)}
  page.locator('.f158-board').evaluate('(x)=>x.scrollIntoView({block:"start"})');page.wait_for_timeout(150)
  def screen(pos):
   bb=page.locator('.f158-board').bounding_box();return (bb['x']+pos[0]/L['W']*bb['width'],bb['y']+pos[1]/L['H']*bb['height'])
  def d(src,dst,steps=10):
   page.mouse.move(*screen(src));page.mouse.down();page.mouse.move(*screen(dst),steps=steps);page.mouse.up();page.wait_for_timeout(400)
  for i,key in enumerate(['cos','sin','radius']):
   start=(L['bx']+i*(L['bw']+7)+L['bw']/2,L['by']+18)
   d(start,targets[key])
   state=page.evaluate('NOVA_F15_08_CONFIG._explore.state()');ck(width,key+' mouse drop on mathematical side',bool(state['placed'].get(key)),state['placed'])
  # Drag cos placed back to red removal tray
  if page.evaluate('Boolean(NOVA_F15_08_CONFIG._explore.state().placed.cos)'):
   pos=targets['cos']; d((max(4,min(L['W']-L['bw']-4,pos[0]-L['bw']/2))+L['bw']/2,max(10,min(L['H']-44,pos[1]-20))+18),(L['bx']+65,L['by']+17))
   ck(width,'regrab mouse removal',not bool(page.evaluate('NOVA_F15_08_CONFIG._explore.state().placed.cos')))
  # Cancel Escape should restore rather than strand; use separate fresh state
  point=(x,y);page.mouse.move(*screen(point));page.mouse.down();page.mouse.move(*screen((L['cx'],L['cy'])),steps=5);page.keyboard.press('Escape');page.mouse.up()
  ck(width,'Escape restores angle',page.evaluate('NOVA_F15_08_CONFIG._explore.state().theta')==45)
  ck(width,'pointer cancellation leaves no active drag',page.evaluate('!NOVA.ui._drag || !NOVA.ui._drag.el'))
  ck(width,'no Javascript errors',not errors,errors[:2]);page.close()
 b.close()
Path('/mnt/data/f15-reference/F15-08-QA/label-results.json').write_text(json.dumps(results,indent=2))
print('total',sum(k['pass'] for k in results),'/',len(results))
