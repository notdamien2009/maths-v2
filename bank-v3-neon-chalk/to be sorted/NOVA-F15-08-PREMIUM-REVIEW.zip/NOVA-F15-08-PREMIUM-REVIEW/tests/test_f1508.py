import json, time, math, sys, traceback
from pathlib import Path
from playwright.sync_api import sync_playwright
url='http://127.0.0.1:8899/NOVA-F15-08-Unit-Circle-Explorer.html'
folder=Path('/mnt/data/f15-reference/F15-08-QA');folder.mkdir(exist_ok=True)
checks=[]
def record(ok,description,extra=''):
 checks.append({'pass':bool(ok),'description':description,'detail':extra});print(('PASS' if ok else 'FAIL'),description,extra,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--disable-features=site-per-process'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[]
  page.on('pageerror', lambda e:errors.append(str(e)))
  page.set_content(Path('/mnt/data/NOVA-F15-08-Unit-Circle-Explorer.html').read_text(),wait_until='domcontentloaded',timeout=35000);page.wait_for_timeout(400)
  record(bool(page.locator('#F15-08').count()),str(width)+' engine mounted')
  print('TABS',page.locator('button').all_text_contents()[:35])
  for mode in ['Watch','Guided','Explore','Challenge']:
   # Find tabs by text + inspect selector.
   loc=page.get_by_text(mode,exact=True).first
   if loc.count():loc.first.click();page.wait_for_timeout(200)
   else:record(False,str(width)+' '+mode+' tab found');continue
   record(page.locator('#F15-08 svg').count()>0,str(width)+' '+mode+' draws SVG')
   record(page.locator('#F15-08 .nv-dock').count()==1,str(width)+' '+mode+' one helper dock')
   page.screenshot(path=str(folder/f'{width}-{mode.lower()}.png'),full_page=True)
  record(not errors,str(width)+' no page errors',str(errors[:3]))
  page.close()
 b.close()
Path('/mnt/data/f15-reference/F15-08-QA/test-initial.json').write_text(json.dumps(checks,indent=2))
print('RESULT:',sum(c['pass'] for c in checks),'/',len(checks))
