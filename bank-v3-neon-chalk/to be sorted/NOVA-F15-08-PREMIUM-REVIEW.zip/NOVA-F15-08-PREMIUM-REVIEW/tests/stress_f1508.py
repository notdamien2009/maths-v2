import json,math
from pathlib import Path
from playwright.sync_api import sync_playwright
src=Path('/mnt/data/NOVA-F15-08-Unit-Circle-Explorer.html').read_text()
results=[]
def ok(name,cond,detail=''):
 results.append({'check':name,'pass':bool(cond),'detail':str(detail)}); print(('PASS' if cond else 'FAIL'),name,detail,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(src,wait_until='domcontentloaded');
  def angle(): return page.evaluate('window.NOVA_F15_08_CONFIG._explore.state().theta')
  def point(x,y):
   svg=page.locator('.f158-board').first; bb=svg.bounding_box();vw=420 if width==380 else 820; vh=796 if width==380 else 565
   return (bb['x']+bb['width']*x/vw,bb['y']+bb['height']*y/vh)
  def drag(source,target,steps=8):
   a=point(*source);z=point(*target);page.mouse.move(*a);page.mouse.down();page.mouse.move(*z,steps=steps);page.mouse.up();page.wait_for_timeout(100)
  # actual maths across 361 points
  vals=page.evaluate('''()=>Array.from({length:361},(_,theta)=>window.NOVA_F15_08_MATH.values(theta))''')
  ok(f'{width} 361 unit-radius identities',all(abs(t['sq']-1)<1e-10 for t in vals))
  ok(f'{width} periodic closed endpoints',vals[0]['x']==vals[360]['x'] and vals[0]['y']==vals[360]['y'])
  ok(f'{width} tangent undefined at 90/270',vals[90]['tan'] is None and vals[270]['tan'] is None)
  ok(f'{width} quadrant signs correct',vals[45]['x']>0 and vals[45]['y']>0 and vals[135]['x']<0 and vals[135]['y']>0 and vals[225]['x']<0 and vals[225]['y']<0 and vals[315]['x']>0 and vals[315]['y']<0)
  ok(f'{width} seven named presets',len(page.evaluate('Object.keys(window.NOVA_F15_08_CONFIG.presets)'))==7)
  ok(f'{width} 17 teaching beats',len(page.evaluate('window.NOVA_F15_08_MATH.steps'))==17)
  page.get_by_text('Explore',exact=True).first.click();page.wait_for_timeout(100)
  ok(f'{width} explore starts at 45',angle()==45)
  page.locator('[aria-label="Angle theta from zero to 360 degrees"]').evaluate("(x)=>{x.value='210'; x.dispatchEvent(new Event('input',{bubbles:true}))}")
  ok(f'{width} numeric slider updates circle',angle()==210)
  page.locator('[data-handle="circle-point"]').focus();page.keyboard.press('ArrowRight')
  ok(f'{width} keyboard increments circle',angle()==215)
  page.keyboard.press('Home');ok(f'{width} home goes 0',angle()==0)
  page.keyboard.press('End');ok(f'{width} end goes 360',angle()==360)
  # reset to 45
  page.locator('[aria-label="Angle theta from zero to 360 degrees"]').evaluate("(x)=>{x.value='45'; x.dispatchEvent(new Event('input',{bubbles:true}))}")
  L={'W':420,'H':796,'cx':210,'cy':227,'r':145} if width==380 else {'W':820,'H':565,'cx':238,'cy':252,'r':182}
  def where(a):return (L['cx']+L['r']*math.cos(math.radians(a)), L['cy']-L['r']*math.sin(math.radians(a)))
  # scroll SVG into view for true mouse pointer
  page.locator('[data-handle="circle-point"]').scroll_into_view_if_needed()
  drag(where(45),where(135),12)
  ok(f'{width} real pointer moves circle 45 to 135',angle() in (130,135,140),angle())
  current=angle()
  drag(where(current),where(315),1)
  ok(f'{width} fast one-step pointer move 135 to 315',angle() in (310,315,320),angle())
  # invalid drop should leave no floating drag
  current=angle()
  drag(where(current),(L['cx'],L['cy']),5)
  ok(f'{width} invalid drop restores angle',angle()==current,angle())
  ok(f'{width} no stranded dragging',page.evaluate('!NOVA.ui._drag || !NOVA.ui._drag.el'))
  # keyboard label placement; also regrab toggles
  label=page.locator('[data-label="cos"]');label.focus();page.keyboard.press('Enter')
  ok(f'{width} keyboard place card',bool(page.evaluate('window.NOVA_F15_08_CONFIG._explore.state().placed.cos')))
  page.locator('[data-label="cos"]').focus();page.keyboard.press('Enter')
  ok(f'{width} keyboard remove card',not bool(page.evaluate('window.NOVA_F15_08_CONFIG._explore.state().placed.cos')))
  # challenge checker all questions, miscons feedback
  page.get_by_text('Challenge',exact=True).first.click();qs=page.evaluate('window.NOVA_F15_08_CONFIG._challengeQuestions');
  ok(f'{width} nine challenge items',len(qs)==9)
  checked=page.evaluate('''()=>window.NOVA_F15_08_CONFIG._challengeQuestions.map(t=>window.NOVA_F15_08_CONFIG._check(t,t.ans)[0])''')
  ok(f'{width} correct challenge answers',all(checked),checked)
  wrong=page.evaluate('''()=>window.NOVA_F15_08_CONFIG._challengeQuestions.map(t=>window.NOVA_F15_08_CONFIG._check(t,t.ans+2)[0])''')
  ok(f'{width} obvious wrong answers rejected',not any(wrong),wrong)
  # Actual question input/check (playwright)
  inp=page.locator('#F15-08 .nova-panel input').first
  print('INPUTS',width,page.locator('#F15-08 input').count(),page.locator('#F15-08 button').all_text_contents()[:18])
  if inp.count():
   inp.fill('0.5'); check=page.get_by_role('button',name='Check',exact=True)
   if check.count(): check.first.click();page.wait_for_timeout(150);ok(f'{width} actual correct submission',('Correct' in page.locator('#F15-08').inner_text()))
  ok(f'{width} no javascript errors',not errors,errors[:2])
  page.close()
 b.close()
Path('/mnt/data/f15-reference/F15-08-QA/stress-results.json').write_text(json.dumps(results,indent=2))
print('TOTAL',sum(x['pass'] for x in results),'/',len(results))
