# NOVA F15-08 — Unit Circle Explorer · Production QA Evidence

**Status:** Built for owner review; NOT GOLD-approved. No changes made to GitHub.  
**Source:** private repo `notdamien2009/maths-v2`, `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, F15-08 exact spec; `HANDOVER-v3.md`; canonical F0/F2 references; previous F15-07 standalone.  
**Delivery:** One self-contained HTML engine with embedded CSS, JavaScript, font subsets, vector artwork and original NOVA mascot art. No external downloads.  

## Exact implementation

- Core JavaScript: copied without mutation from F15-07. SHA-256 = `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc` (compare the first `<script>` element of the two HTML pages).
- Main app source `source/F15-08-engine.js`: `CONFIG.presets`, `STEPS`, `vals`, `scene`, `DEF.explore`, `DEF.challenge`, `NOVA.bankMount`.
- Render and maths: 0–360 degrees, exact radius 1; P=(cos theta,sin theta); signed coordinate projections; four quadrants; axis landmarks; tangent undefined when cos theta=0; cos² theta + sin² theta = 1. The arc path handles a true full 360° sweep rather than a zero-length arc.
- Watch: 17 named teaching stages and narration lines with step-specific poses; playback via the unmodified NOVA engine timeline, including play, pause, back, scrub and reset. Identity and coordinate text revealed in their teaching stages. Guided uses the same core's stepped scaffolding.
- Explore: one captured mouse/touch draggable point constrained to the true circle, a live 0–360 degree slider, three draggable label cards snapping to the horizontal leg, vertical projection and radius; invalid drop returns; placed cards can be dragged back to tray; Escape recovers; keyboard arrow/Home/End and Enter equivalents.
- Challenge: nine numerically verified questions with tolerance appropriate to requested rounding, misconceptions around quadrants and the wrong trig coordinate, actual Check and feedback.
- Drawing: `NOVA.neonPath`, `NOVA.neonRing`, `NOVA.neonBox`, `NOVA.chalkText`, and `NOVA.ui.svgDrag`; no custom rendering library or second mascot. Additional CSS only governs local layout and hides the external duplicate narrator portrait while leaving narration content in the stage helper bubble.
- Responsive: portrait 420×796 SVG viewBox on narrow screens; 820×565 with side readout cards on desktop. One docked mascot within the stage. Use `screenshots/` to review both.

## Automated results — 114 / 114

| Test script / result JSON | Passing | Scope |
|---|---:|---|
| test_f1508.py / test-initial.json | 20 / 20 | 380px/1280px, four modes, SVG rendering, one stage dock, no JS errors |
| stress_f1508.py / stress-results.json | 44 / 44 | 361-angle identity, signed quadrants, undefined tangent, presets, number slider, Home/End, real fast pointer drag, invalid drop, keyboard cards, 9 correct and wrong answers, actual Check submission |
| labels_f1508.py / label-results.json | 14 / 14 | Three mouse card drops to the mathematical segments, re-grab/remove animation, Escape cancellation and zero stranded, at both viewports |
| presets_f1508.py / preset-results.json | 36 / 36 | Seven named presets, signs and numerical coordinate readouts, Watch timeline step-one scrub, no console/page errors, at both widths |

## Screenshot evidence

- 380-watch.png, 380-guided.png, 380-explore.png, 380-challenge.png
- 1280-watch.png, 1280-guided.png, 1280-explore.png, 1280-challenge.png
- 380-axes-preset.png, 380-third-preset.png, 380-fourth-preset.png
- 1280-axes-preset.png, 1280-third-preset.png, 1280-fourth-preset.png

## Scope, qualifications and acceptance

- Automated tests ran headless Chromium using `page.set_content` because direct `file://` and localhost navigation is blocked in this runtime. The delivery HTML is a standalone file and may be opened normally in a browser.
- Both reduced-motion render checks and authentic Playwright mouse down/move/up interactions were executed. Synthetic keyboard input is separate from pointer QA. The one-step fast drag was tested at mobile and desktop widths.
- Browser captures and source verification do not substitute for the owner's manual stress testing on their machine and touchscreen. This is **review-ready**, not owner-approved GOLD.
- F15-08 has no explicitly named curriculum lessons in the master entry; the presets therefore provide Y9/GCSE extension coverage without falsely assigning new lesson numbers.
