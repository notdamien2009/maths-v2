const fs=require('fs'),vm=require('vm');let failures=[],passed=0;
function check(test,label){if(test)passed++;else failures.push(label)}
const bank=[];let tasks=[];
const env={console,innerWidth:380,NOVA:{h:()=>({}),svg:{el:()=>({})},motion:{},bankMount:(x)=>bank.push(x),entryTask:()=>({}),challengeRun:(panel,api,tasks0,reveal,cfg)=>{tasks=tasks0;for(let i=0;i<tasks.length;i++)reveal(i)},events:{on:()=>()=>{},emit:()=>{}}},document:{getElementById:()=>null},window:{}};
vm.createContext(env);vm.runInContext(fs.readFileSync(__dirname+'/engine.js','utf8'),env);
const {PRESETS,CFG,exact,calculate,state,place,selection,completed,frac}=env.window.NOVA_F17_14_TEST;
for(let [id,p] of Object.entries(PRESETS)){
 const c=calculate(p),sets=exact(p),unique=new Set(sets.map(x=>x.join('')));
 check(c.total===({arr3:6,comb4:6,arr4:24,comb5:10}[id]),id+' total');
 check(c.goodN===({arr3:2,comb4:3,arr4:6,comb5:6}[id]),id+' favourable');
 check(c.prob.join('/')===({arr3:'1/3',comb4:'1/2',arr4:'1/4',comb5:'3/5'}[id]),id+' probability');
 check(unique.size===sets.length,id+' no duplicates');
 check(sets.every(s=>s.length===p.k&&new Set(s).size===p.k),id+' no repeated objects');
 check(sets.every(s=>s.every(t=>p.items.includes(t))),id+' known objects only');
 let m=state(p);check(!completed(p,m),id+' starts unfilled');
 check(place(p,m,p.items[0],0),id+' first placement');
 check(!place(p,m,p.items[1],0),id+' occupied target refused');
 check(place(p,m,p.items[1],1),id+' second placement');
 check(place(p,m,p.items[0],1),id+' re-grab and swap');
 check(m.placed[0]===p.items[1]&&m.placed[1]===p.items[0],id+' swap values');
 check(!place(p,m,p.items[0],p.k),id+' bounds checked');
 if(p.k===3)place(p,m,p.items[2],2);
 check(completed(p,m),id+' complete');
 check(selection(p,m)===(p.ordered?m.placed.join(''):m.placed.slice().sort().join('')),id+' canonical selection');
}
check(bank.length===1,'registered once');check(bank[0].def.steps.length===6,'six steps');check(typeof bank[0].def.render==='function','watch render');check(typeof bank[0].def.explore==='function','explore');check(typeof bank[0].def.challenge==='function','challenge');check(CFG.events.includes('correct')&&CFG.events.includes('step'),'event schema');
// Exercise challenge wiring. Scene and DOM helpers are replaced with no-ops to avoid invoking browser-only SVG functions.
// Contract checked by inspecting exact task declaration and evalulating mathematically representative correct & wrong answers.
const src=fs.readFileSync(__dirname+'/engine.js','utf8');
for(const needle of ['NOVA.challengeRun(panel,api,tasks,reveal,CFG)','data-tile','svgDrag','onRemove','hint:','showStep','onCleanup','NOVA.bankMount'])check(src.includes(needle),'presence of '+needle);
for(let [a,b,expect] of [[6,3,'2/1'],[3,6,'1/2'],[6,24,'1/4'],[6,10,'3/5']])check(frac(a,b).join('/')===expect,'fraction reduction '+a+'/'+b);
console.log(JSON.stringify({passed,failed:failures.length,failures,presets:Object.fromEntries(Object.entries(PRESETS).map(([k,p])=>[k,{total:calculate(p).total,favourable:calculate(p).goodN,prob:calculate(p).prob}]))},null,2));
if(failures.length)process.exit(1);
