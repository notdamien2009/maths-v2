from pathlib import Path
from bs4 import BeautifulSoup
import hashlib,json,re,sys
work=Path('/mnt/data/f17_14_work');file=Path('/mnt/data/F17-14-Combinations-and-Arrangements-PREMIUM-REVIEW.html');src=file.read_text();base=BeautifulSoup(Path('/mnt/data/F17-12-Expected-Outcomes-PREMIUM-REVIEW.html').read_text(),'html.parser');doc=BeautifulSoup(src,'html.parser')
checks={
 'Single standalone HTML':src.lstrip().lower().startswith('<!doctype html>') and bool(doc.html),
 'No external scripts/styles':all(not x.get('src') for x in doc.find_all('script')) and all(not x.get('href') for x in doc.find_all('link')),
 'Exactly original shared core':hashlib.sha256(doc.find_all('script')[0].text.encode()).digest()==hashlib.sha256(base.find_all('script')[0].text.encode()).digest(),
 'NOVA Chalk fonts embedded':('@font-face' in doc.style.text and 'nova-font-chalk' in doc.style.text),
 'Premium dark stage CSS':('nova-stage' in doc.style.text and 'neon' in doc.style.text),
 'Original scene helper, no custom mascot':('NOVA.scene.helperStrip' in doc.find_all('script')[-1].text and 'new Image' not in doc.find_all('script')[-1].text),
 'NOVA core drawing helpers reused':all(x in doc.find_all('script')[-1].text for x in ['NOVA.neonBox','NOVA.neonRing','NOVA.chalkText','NOVA.neonLine']),
 'F2-style SVG dragging':('NOVA.ui.svgDrag' in doc.find_all('script')[-1].text and 'onRemove' in doc.find_all('script')[-1].text),
 'Keyboard equivalents':all(x in doc.find_all('script')[-1].text for x in ['ArrowRight','ArrowLeft','Delete','Place selected tile']),
 'Four modes wired to bank':all(x in doc.find_all('script')[-1].text for x in ['render:showStep','explore,challenge','steps,']),
 'Watch narration and prompts':('narration:' in doc.find_all('script')[-1].text and 'prompt:' in doc.find_all('script')[-1].text),
 'Question answers concealed':('hideAnswer:true' in doc.find_all('script')[-1].text and '!o.hideAnswer' in doc.find_all('script')[-1].text),
 'Reduced motion via original core':('NOVA.reducedMotion' in doc.find_all('script')[0].text),
 'Static print fallback':('@media print' in doc.style.text and 'staticAlt:' in doc.find_all('script')[-1].text),
 'No family GOLD approval claim':('GOLD-approved' not in doc.find_all('script')[-1].text),
 'Event key allowlist':('CFG.valueKeys.includes(key)' in doc.find_all('script')[-1].text),
 'NOVA style/mascot inside stage':('NOVA.scene.helperStrip(stage' in doc.find_all('script')[-1].text),
}
(work/'test-static.json').write_text(json.dumps({'checks':checks,'passed':sum(checks.values()),'failed':len(checks)-sum(checks.values())},indent=2))
print(json.dumps({'passed':sum(checks.values()),'failed':len(checks)-sum(checks.values()),'failed_names':[k for k,v in checks.items() if not v]}))
if not all(checks.values()):sys.exit(1)
