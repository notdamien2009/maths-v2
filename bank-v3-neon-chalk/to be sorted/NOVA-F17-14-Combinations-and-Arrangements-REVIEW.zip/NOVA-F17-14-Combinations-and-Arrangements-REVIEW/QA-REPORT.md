# F17-14 QA report · 13 October 2026

**Release status:** Review candidate; **NOT GOLD-approved**.

## Tests executed successfully

| Suite | Assertions passed | Evidence | What was actually verified |
|---|---:|---|---|
| Pure maths and model | 78 / 78 | `test-maths.json`, `test_math.js` | All four preset counts, non-repetition, unique unordered groups, favourable event counts, reduced rational probabilities, placement, swap, occupancy refusal and bounds, four-mode registration |
| Simulated document/runtime paths | 63 / 63 | `test-runtime.json`, `test_runtime.js` | Six Watch callbacks and all four Explore callbacks at 380/1280-width states execute without exceptions in a mock DOM; Challenge answer functions accept correct inputs and reject sampled wrong inputs; event schema; placement wiring present |
| Static/integrity checks | 17 / 17 | `test-static.json`, `test_static.py` | Single-file bundle, unchanged original NOVA shared JS core, embedded fonts, NOVA primitives, SVG drag hooks, keyboard controls, developer-log collapsible, print fallback, no external links |
| JS parser | PASS | `node --check engine.js` | No JavaScript syntax errors |

**Total automated assertions actually completed: 158 / 158** (141 isolated runtime/model + 17 static checks). These numbers are NOT a browser-pass claim. The mock document can only exercise control paths; it cannot establish CSS layout, pointer coordinates or rendering.

## Browser QA: blocked, not passed

Chromium from `/usr/bin/chromium` was attempted using Playwright. Attempts to navigate both `file://` and local `http://127.0.0.1` URLs returned `net::ERR_BLOCKED_BY_ADMINISTRATOR`. A minimal blank-page browser test then stalled before the browser launch completed. Therefore all of the following are **UNVERIFIED**:

- Actual visual quality, responsive clipping, label separation and screenshot comparison at 380 and 1280 px.
- Physical pointer dragging and high-speed movement, snap highlighting and release, re-grab, red-zone removal, invalid-drop spring-back, Escape and pointercancel inside the live DOM.
- Full Watch/Guided motion timeline, play/pause/rewind/scrub, original mascot animations and speech bubble display.
- Physical touchscreen, accessibility screen reader and cross-browser behaviour.

No review screenshots were generated or claimed for F17-14.

## Mathematical spot checks

The exact list constructor generates nPk ordered selections with distinct members then deduplicates by the sorted item set for unordered selections. It produces 6 ordered choices from A,B,C; 6 unordered two-from-four groups; 24 three-position podium orders from four; and 10 unordered three-from-five groups. For uniformly sampled outcomes, the probability of the named favourable event equals respectively **1/3, 1/2, 1/4, 3/5**.

## Source evidence and design locks

- `engine.js:4-19` — presets, deterministic enumeration, exact probabilities, duplicate-refusal and re-grab/swap model.
- `engine.js:33-94` — NOVA geometric components and `NOVA.ui.svgDrag` including green slot targets, red REMOVE zone and keyboard controls.
- `engine.js:95-110` — six named teaching steps and contextual mascot speeches.
- `engine.js:111-123` — Explore and keyboard accessibility controls.
- `engine.js:124-135` — challenge questions, mathematical checking, misconception feedback and concealed probability counts.
- `engine.js:136-137` — `NOVA.bankMount` registration and separate stage-only helper use.

The original embedded NOVA core JS was retained byte-for-byte from the F17-12 review source (SHA-256: `bc8b287a321aff1b3aeda8383879c68a6e7abf7542a6a9b72576a1c027bc4c6e`). No mascot artwork, filter library or mathematical drawing system was replaced.

## Required release follow-up

Run a live viewport-and-drag QA suite and inspect visually against F0-02/F2 before owner approval. These checks are a release blocker, not optional polish. GitHub has not been modified.
