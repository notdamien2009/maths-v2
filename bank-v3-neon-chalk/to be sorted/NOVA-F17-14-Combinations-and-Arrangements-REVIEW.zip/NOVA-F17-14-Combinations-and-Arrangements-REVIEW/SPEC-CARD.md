# F17-14 · Canonical spec card

**Family:** F17 Probability and Sets. **Component:** Combinations and Arrangements. **Specification:** `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, section `F17-14`. The master provides no specific lesson identifiers; none are invented.

- **Mathematical purpose:** Generate distinct arrangements and unordered selections without repetition, derive counts and event probabilities by complete enumeration.
- **Age range:** Reusable KS3 probability demonstrations with GCSE extension to nPr/nCr.
- **Parameters:** A–E distinct choices; 2–3 numbered slots; selection mode ordered/unordered; named target event; all outcomes and favourable outcomes; reduced rational chance.
- **Presets:** Arrange three of three; choose two of four; podium three of four; choose three of five.
- **Watch/Guided teaching:** Identify distinct elements → fill first slot → complete product of choices → compare reversing order → remove duplicates for combinations → count and calculate probability.
- **Explore:** Core NOVA SVG drag with green slots and red REMOVE zone, re-grab and swap, invalid-drop rejection and auto-return, roving keyboard focus, select/place/remove form, reset, check and reveal.
- **Challenge:** Four different checks: 3! = 6, 4 choose 2 = 6, 4 permute 3 = 24, probability of a named member in 3 of 5 = 3/5.
- **Misconceptions:** AB and BA counted twice in an unordered pair; reusing an object; counting only the first choice; dividing favourable outcomes by the wrong total.
- **Linked components:** F0-02, F0-03, F0-04, F17-05, F17-06, F17-07.
- **Acceptance gate:** Owner visual sign-off and real browser/physical touch testing. Code-level checks alone do not establish visual or pointer-stress acceptance.
