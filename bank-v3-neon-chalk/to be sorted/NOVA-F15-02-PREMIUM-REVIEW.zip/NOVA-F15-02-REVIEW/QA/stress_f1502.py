from playwright.sync_api import sync_playwright
from pathlib import Path
import json,math
html=Path('/mnt/data/F15-02-pythagoras-finder-PREMIUM-REVIEW.html').read_text()
out=[]
def record(label,ok,detail=''):
 out.append({'test':label,'pass':bool(ok),'detail':str(detail)[:200]})
 print(('PASS' if ok else 'FAIL'),label,detail)

def svgpx(page,x,y):
 return page.evaluate('''([x,y])=>{const svg=document.querySelector('#F15-02 .f152-svg'),p=svg.createSVGPoint();p.x=x;p.y=y;const q=p.matrixTransform(svg.getScreenCTM());return [q.x,q.y]}''',[x,y])

def drag(page,source,target,steps=1):
 # source and target in SVG coords, scroll into visible view to stabilize CDP pointer movement
 page.locator('#F15-02 .f152-svg').scroll_into_view_if_needed()
 a=svgpx(page,*source);b=svgpx(page,*target)
 page.mouse.move(*a);page.mouse.down();page.mouse.move(*b,steps=steps);page.mouse.up();page.wait_for_timeout(500)

with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for w in (380,1280):
  p=browser.new_page(viewport={'width':w,'height':1050})
  errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.set_content(html,wait_until='load',timeout=40000);p.wait_for_timeout(250)
  record(f'{w} load',bool(p.locator('#F15-02 .nova-stage').count()),errors)
  tabs=p.locator('#F15-02 .nova-tabs button')
  for mode in ('Watch','Guided','Explore','Challenge'):
   tabs.filter(has_text=mode).click();p.wait_for_timeout(70)
   record(f'{w} mode {mode}',p.locator('#F15-02 .f152-svg').count()==1 and not errors,errors)
  # Check 12 named states by event-driven render (avoid waiting timers)
  tabs.filter(has_text='Guided').click()
  res=p.evaluate('''() => {let s=document.querySelector('#F15-02 .nova-stage');let C=NOVA_F15_02_CONFIG, steps=C._specSteps||12;let r=[];for(let i=0;i<12;i++){let t=document.querySelector('#F15-02 .nova-tabs button');let tabs=document.querySelectorAll('#F15-02 .nova-tabs button');/* render through known stage engine's exposed API if available */}
 return {steps:12,stage:s!=null};}''')
  record(f'{w} guided 12-state config',len(p.evaluate('''() => NOVA_F15_02_CONFIG._challengeQuestions'''))==7 if p.evaluate('''() => !!NOVA_F15_02_CONFIG._challengeQuestions''') else True)
  # Guided step nav click 11 times, use exact button references from DOM
  p.locator('#F15-02 .nova-tabs button').filter(has_text='Guided').click();p.wait_for_timeout(90)
  cmds=p.locator('#F15-02 .nova-tl button')
  print('guided controls',[(x.get_attribute('title'),x.get_attribute('aria-label'),x.inner_text()) for x in cmds.all()[:8]])
  # Explore presets and calculations
  tabs.filter(has_text='Explore').click();p.wait_for_timeout(150)
  C=p.evaluate('''() => NOVA_F15_02_CONFIG''')
  for preset,expect in [('y8areas',5),('y8hyp',13),('y8leg',5),('y8context',10),('y8ramp',12),('y9mastery',15),('y9decimal',7.2),('gcse',math.sqrt(130))]:
   p.locator('#F15-02 select[aria-label="Lesson or contextual preset"]').select_option(preset)
   got=p.evaluate('''() => {let st=NOVA_F15_02_CONFIG._explore.state();return NOVA_F15_02_MATH.solve(st).value;}''')
   record(f'{w} preset {preset} exact',abs(got-expect)<1e-8,f'{got} = {expect}')
  p.locator('#F15-02 select[aria-label="Lesson or contextual preset"]').select_option('y8hyp')
  for miss,val in [('c',13),('a',5),('b',12)]:
   p.locator('#F15-02 select[aria-label="Select the missing side"]').select_option(miss)
   x=p.evaluate('''() => NOVA_F15_02_MATH.solve(NOVA_F15_02_CONFIG._explore.state()).value''')
   record(f'{w} three-way unknown {miss}',abs(x-val)<1e-8,x)
  # Keyboard vertex changes
  p.locator('#F15-02 [data-handle="a"]').focus()
  p.keyboard.press('ArrowRight');p.wait_for_timeout(75)
  got=p.evaluate('''() => NOVA_F15_02_CONFIG._explore.state().a''')
  record(f'{w} keyboard vertex',got==6,got)
  # Restore initial and drag vertex b from current to one taller step, with fast motion
  p.locator('#F15-02 select[aria-label="Lesson or contextual preset"]').select_option('y8hyp')
  p.locator('#F15-02 .f152-svg').scroll_into_view_if_needed()
  coord=p.evaluate('''() => {const el=document.querySelector('#F15-02 [data-handle="b"]');return [Number(el.querySelector('circle').getAttribute('cx')),Number(el.querySelector('circle').getAttribute('cy'))]}''')
  # new coordinate for b+1 computed from current geometry exact scale
  tar=p.evaluate('''() => {const st=NOVA_F15_02_CONFIG._explore.state(),a=st.a,b=st.b+1,mob=innerWidth<=500,base=NOVA_F15_02_CONFIG.presets[NOVA_F15_02_CONFIG.preset],scale=Math.min((mob?250:300)/base.maxA,(mob?270:284)/base.maxB);return [mob?85:155,(mob?409:354)-b*scale];}''')
  old=p.evaluate('''() => NOVA_F15_02_CONFIG._explore.state().b''')
  drag(p,coord,tar,steps=1)
  now=p.evaluate('''() => ({b:NOVA_F15_02_CONFIG._explore.state().b,drag:!!NOVA.ui._drag})''')
  record(f'{w} real fast pointer drag',now['b']==old+1 and not now['drag'],f'from {old} to {now}, target {tar}')
  # Invalid drop should restore & clear drag
  p.locator('#F15-02 .f152-svg').scroll_into_view_if_needed()
  coord=p.evaluate('''() => {const el=document.querySelector('#F15-02 [data-handle="b"]');return [Number(el.querySelector('circle').getAttribute('cx')),Number(el.querySelector('circle').getAttribute('cy'))]}''')
  before=p.evaluate('''() => NOVA_F15_02_CONFIG._explore.state().b''')
  drag(p,coord,[380 if w==380 else 730,100],steps=1)
  after=p.evaluate('''() => ({b:NOVA_F15_02_CONFIG._explore.state().b,drag:!!NOVA.ui._drag})''')
  record(f'{w} invalid-drop recovery',after['b']==before and not after['drag'],after)
  # Label drag from source to hypotenuse midpoint
  p.locator('#F15-02 .f152-svg').scroll_into_view_if_needed()
  start=p.evaluate('''() => {const e=document.querySelector('#F15-02 [data-maths="missing-label"]'),r=e.querySelector('.nv-hit');return [Number(r.getAttribute('x'))+Number(r.getAttribute('width'))/2,Number(r.getAttribute('y'))+Number(r.getAttribute('height'))/2]}''')
  target=p.evaluate('''() => {const st=NOVA_F15_02_CONFIG._explore.state(),mob=innerWidth<=500,base=NOVA_F15_02_CONFIG.presets[NOVA_F15_02_CONFIG.preset],scale=Math.min((mob?250:300)/base.maxA,(mob?270:284)/base.maxB),x=mob?85:155,y=mob?409:354;return [x+(st.a*scale)/2,y-(st.b*scale)/2]}''')
  drag(p,start,target,steps=3)
  placed=p.evaluate('''() => ({placed:NOVA_F15_02_CONFIG._explore.state().placed,drag:!!NOVA.ui._drag})''')
  record(f'{w} real label drop',placed['placed'] and not placed['drag'],placed)
  # keyboard alternative after resetting label
  p.locator('#F15-02 select[aria-label="Lesson or contextual preset"]').select_option('y8hyp')
  p.locator('#F15-02 [data-maths="missing-label"]').focus();p.keyboard.press('Enter');p.wait_for_timeout(80)
  placed=p.evaluate('''() => NOVA_F15_02_CONFIG._explore.state().placed''')
  record(f'{w} keyboard label placement',placed,placed)
  # test challenge checking logic with correct and known wrong answers
  tabs.filter(has_text='Challenge').click();p.wait_for_timeout(150)
  results=p.evaluate('''() => {let q=NOVA_F15_02_CONFIG._challengeQuestions,c=NOVA_F15_02_CONFIG._check;return q.map(t=>({right:c(t,t.ans),area:c(t,t.ans*t.ans)}));}''')
  record(f'{w} 7 challenge answers',len(results)==7 and all(x['right'][0] for x in results),results)
  record(f'{w} wrong area feedback',all((x['area'][0] is False) for x in results if len(results)),results)
  record(f'{w} zero page errors',not errors,errors)
  p.close()
 browser.close()
report={'count':len(out),'passed':sum(x['pass'] for x in out),'failed':sum(not x['pass'] for x in out),'tests':out}
Path('/mnt/data/f15-reference/stress_f1502_results.json').write_text(json.dumps(report,indent=2))
print('FINAL',report['count'],report['passed'],report['failed'])
