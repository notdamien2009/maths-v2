# F16-15 · Sampling Visual — Premium Review

Open `F16/F16-15-sampling-visual.html` directly offline. It is a self-contained HTML.

Rebuild: `python3 build/build-f16-15.py` from the top `bank-v3-neon-chalk` folder. The builder embeds and verifies the pinned original NOVA shared runtime. Editable component code is `src/F16-15.js` + `.css`.

Browser QA: `python3 tests/stress_f1615.py 380` and `python3 tests/stress_f1615.py 1280` (requires Playwright and Chromium). Evidence in `tests/F16-15-RESULTS-{380,1280}.json`; screenshots under `shots/F16-15/`.

Owner must test and sign off. **No GitHub writes, no GOLD claim.**
