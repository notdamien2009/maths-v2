# F16-15 — Sampling Visual · Premium Review QA

**Status:** BUILT, AUTOMATED REVIEW CHECKS PASSED, OWNER GOLD APPROVAL PENDING. Not a GOLD approval.

## Specification and pedagogical contract
- Master: `00-master/NOVA-MASTER-FOR-OTHER-AI.md`, section F16-15; lesson presets **Y7-065** and **Y9-052**.
- A population of 60 people is modelled explicitly as 60 neon pupil rings, split 30 / 18 / 12. The sample size is capped at 12.
- Random sampling picks 12 distinct population indices by a seeded shuffling method; it may not match population proportions by chance. Proportional allocation uses largest remainders (6 / 4 / 2); the percentages shown are **rounded**, not exact matches (50/33/17 compared with 50/30/20). Convenience sampling deliberately takes only the last category: 0/0/12. These are contrasting examples, not promises of perfect statistical representativeness.
- Challenge tasks verify sample membership totals, population percentage (18 of 60 = 30%), and the limitation of a convenient subgroup survey. Incorrect frequency-as-percentage answers and overgeneralised inferences are rejected.

## Runtime inheritance
- The supplied core `tests/pinned-core.js` and `.css` are copied without modification from the earlier F16 review runtime that was benchmarked against F2-03 and used in F14 production. The builder verifies exact SHA-256 digests before embedding them. This report does **not** claim a new independent comparison to the current remote GitHub core.
- Drawing code uses `NOVA.neonRing`, `NOVA.neonBox`, `NOVA.neonLine`, `NOVA.chalkText`, `NOVA.neonTile` and `NOVA.ui.svgDrag`. It does not replace the core artwork, mascot, font or drag system.
- Exactly one original docked mascot inside the stage is checked in all four modes. No external mascot, horizontal split row or alternative drawing library.

## Executed QA, evidence
| Acceptance point | Measured evidence | Outcome |
|---|---|---|
| Browser four modes | `tests/F16-15-RESULTS-380.json` and `-1280.json`: Watch, Guided, Explore, Challenge loaded, 60 data points, single dock, no horizontal document overflow | Pass |
| Desktop/mobile art fill | Initial stage measurements: 380px stage 1089px / SVG 920px (84.5%); desktop display also exceeded 80%; precise values can vary with final viewport/font metrics | Pass |
| Real mouse movement | `tests/stress_f1615.py` drives native browser mouse from pupil into tray in 1 step, invalid drop, placed-card drag to red Remove zone | Pass at both widths and both presets |
| Pointer cancellation | Escape while holding mouse restores pre-drag sample; `NOVA.ui._drag` reset; no detached objects | Pass at both widths and both presets |
| Keyboard parity | Individual dot Space toggles selection; sample-card Space removes; arrow moves roving focused pupil | Pass at both widths and both presets |
| Sampling mathematics | `30+18+12=60`; balanced 6/4/2; convenience 0/0/12; random draw has 12 unique indices; population totals unchanged after edits | Pass |
| Challenge correctness | An incomplete sample, wrong percentage 18, and overclaim are all rejected; correct proportional selection, 30%, and justified limitation advance / complete | Pass at both widths and both presets |
| Page errors | Playwright captured no exceptions in completed suites and all 20 screenshots | Pass |
| Motion accessibility | Test contexts use `reduced_motion='reduce'`; original motion library honors that mode | Browser exercised; regular animation timing not a full timing audit |
| Visual comparisons | 20 original viewport captures in `shots/F16-15/`: four modes, random/stratified/convenience and later Watch slides | Review evidence; owner visual sign-off pending |
| Reproducible builder | `build/build-f16-15.py` run again; produced identical HTML SHA-256 | Pass |

## Summary
**94 / 94 automated interaction, maths and responsive assertions passed.** 20 browser screenshots. No GitHub commits, pushes or modified upstream files.

## Known acceptance limits
- Actual physical touchscreen use was not tested (browser-pointer and keyboard tests were run).
- Owner visual approval remains outstanding; no GOLD sign-off.
- A fresh independent byte-for-byte check of the current GitHub core was not performed.
- Deterministic pseudorandom selection is used to make samples reproducible in teaching; statistical randomness in production-scale surveys is not claimed.
