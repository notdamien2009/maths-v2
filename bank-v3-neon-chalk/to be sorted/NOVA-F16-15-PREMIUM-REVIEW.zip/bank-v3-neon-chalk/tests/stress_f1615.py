#!/usr/bin/env python3
from pathlib import Path
import json,sys,time
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];raw=(R/'F16/F16-15-sampling-visual.html').read_text();width=int(sys.argv[1]) if len(sys.argv)>1 else 380
alltests=[]
def check(label,ok,detail=None):
 entry={'test':f'{width} {label}','pass':bool(ok)}
 if not ok:entry['detail']=str(detail)[:500]
 alltests.append(entry);print('PASS' if ok else 'FAIL',entry['test'],('' if ok else detail),flush=True)
def state(page):return page.evaluate('NOVA_F16_15_CONFIG._explore.get()')
def toSvg(page,x,y):return page.evaluate('''p=>{let s=document.querySelector('.f1615-svg');let q=s.createSVGPoint();q.x=p[0];q.y=p[1];let a=q.matrixTransform(s.getScreenCTM());return {x:a.x,y:a.y}}''',[x,y])
def drag(page,source,coords):
 source.scroll_into_view_if_needed();b=source.bounding_box();assert b,b
 sx,sy=b['x']+b['width']/2,b['y']+b['height']/2
 dst=toSvg(page,*coords);page.mouse.move(sx,sy);page.mouse.down();page.mouse.move(dst['x'],dst['y'],steps=1);page.mouse.up();page.wait_for_timeout(430)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':width,'height':950},reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(raw,wait_until='domcontentloaded',timeout=90000)
 for mode in ['Watch','Guided','Explore','Challenge']:
  page.get_by_role('tab',name=mode,exact=True).click();page.wait_for_timeout(160)
  v=page.evaluate('''()=>{let s=document.querySelector('.nova-stage')?.getBoundingClientRect(),v=document.querySelector('.f1615-svg')?.getBoundingClientRect();return {ratio:v.height/s.height,people:document.querySelectorAll('[data-person-id]').length,dock:document.querySelectorAll('.nova-stage .nv-dock').length,overflow:document.documentElement.scrollWidth>innerWidth}}''')
  check(f'{mode} visual and accessibility shell',v['people']==60 and v['dock']==1 and not v['overflow'] and v['ratio']>=.6,v)
 page.get_by_role('tab',name='Explore',exact=True).click();page.wait_for_timeout(180)
 for key in ['y7-065','y9-052']:
  page.locator('.f1615-controls select').select_option(key);page.wait_for_timeout(130)
  initial=state(page);check(f'{key} source population exact',initial['size']==0 and page.evaluate('NOVA_F16_15_CONFIG.presets[NOVA_F16_15_CONFIG.preset].counts.reduce((a,b)=>a+b,0)')==60,initial)
  page.get_by_role('button',name='Proportional 12').click();s=state(page);check(f'{key} proportional sample',s['size']==12 and s['counts']==[6,4,2],s)
  page.get_by_role('button',name='Convenience 12').click();s=state(page);check(f'{key} convenience biased',s['size']==12 and s['counts']==[0,0,12],s)
  page.get_by_role('button',name='Random 12').click();s=state(page);check(f'{key} random without replacement',s['size']==12 and len(set(s['selected']))==12 and all(0<=i<60 for i in s['selected']),s)
  page.get_by_role('button',name='Clear sample').click();check(f'{key} clear resets',state(page)['size']==0,state(page))
  # native single-step pointer; from a person to the sample panel
  dest=(145 if width<=540 else 350,752)
  drag(page,page.locator('[data-person-id="0"]'),dest);check(f'{key} fast mouse adds correct pupil',state(page)['selected']==[0],state(page))
  drag(page,page.locator('[data-person-id="1"]'),(width==380 and 430 or 695,640));check(f'{key} invalid drop springs back',state(page)['selected']==[0] and not page.evaluate('!!NOVA.ui._drag'),state(page))
  # red removal from an already placed sample tile
  drag(page,page.locator('[data-sample-id="0"]'),(365 if width<=540 else 710,889));check(f'{key} regrab and remove',state(page)['size']==0 and not page.evaluate('!!NOVA.ui._drag'),state(page))
  # sample from the population, then drag again with Escape
  drag(page,page.locator('[data-person-id="0"]'),dest)
  src=page.locator('[data-person-id="2"]');src.scroll_into_view_if_needed();r=src.bounding_box();cx=r['x']+r['width']/2;cy=r['y']+r['height']/2;t=toSvg(page,*dest)
  page.mouse.move(cx,cy);page.mouse.down();page.mouse.move(t['x'],t['y'],steps=1);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(520)
  check(f'{key} Escape cancel and no stranded',state(page)['selected']==[0] and not page.evaluate('!!NOVA.ui._drag'),state(page))
  # keyboard add/remove
  page.locator('[data-person-id="30"]').focus();page.keyboard.press('Space');page.wait_for_timeout(120)
  check(f'{key} keyboard add',state(page)['counts']==[1,1,0],state(page))
  page.locator('[data-sample-id="30"]').focus();page.keyboard.press('Space');page.wait_for_timeout(140)
  check(f'{key} keyboard remove',state(page)['selected']==[0],state(page))
  page.locator('[data-person-id="0"]').focus();page.keyboard.press('ArrowRight');check(f'{key} roving arrow key',page.evaluate('document.activeElement.dataset.personId')=='1',page.evaluate('document.activeElement.outerHTML.slice(0,160)'))
  # mathematical state responds to live intervention
  page.locator('[data-person-id="0"]').focus();page.keyboard.press('Space');check(f'{key} population unchanged after removal',state(page)['size']==0 and sum(page.evaluate('NOVA_F16_15_CONFIG.presets[NOVA_F16_15_CONFIG.preset].counts'))==60,state(page))
  # Challenge: 6 from first group, 4 from second and 2 from third
  page.get_by_role('tab',name='Challenge',exact=True).click();page.wait_for_timeout(220)
  check(f'{key} challenge opens',page.evaluate('NOVA_F16_15_CONFIG._challenge.task()')==0)
  page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(180)
  check(f'{key} incomplete sample rejected',page.evaluate('NOVA_F16_15_CONFIG._challenge.task()')==0)
  for i in [0,1,2,3,4,5,30,31,32,33,48,49]:
   v=page.locator(f'[data-person-id="{i}"]');v.focus();page.keyboard.press('Space');page.wait_for_timeout(40)
  v=page.evaluate('NOVA_F16_15_CONFIG._challengeState()');check(f'{key} built proportional challenge sample',v['counts']==[6,4,2] and len(v['selected'])==12,v)
  page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(1080)
  check(f'{key} challenge sample accepted',page.evaluate('NOVA_F16_15_CONFIG._challenge.task()')==1)
  num=page.locator('.nova-panel input[type="text"],.nova-panel input[type="number"]').last;num.fill('18');page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(160)
  check(f'{key} frequency is not percentage',page.evaluate('NOVA_F16_15_CONFIG._challenge.task()')==1)
  num.fill('30');page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(1070)
  check(f'{key} correct population percentage',page.evaluate('NOVA_F16_15_CONFIG._challenge.task()')==2)
  page.locator('[data-bias-choice]').select_option('0');page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(190)
  check(f'{key} biased inference rejected','correct' not in page.locator('.pr-row').inner_text().lower())
  page.locator('[data-bias-choice]').select_option('1');page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(190)
  txt=page.locator('.nova-panel').inner_text().lower();check(f'{key} bias conclusion accepted','correct' in txt or 'one convenient subgroup' in txt,txt[-200:])
  page.get_by_role('tab',name='Explore',exact=True).click();page.wait_for_timeout(130)
 check('No browser exceptions',not errors,errors)
 page.close();b.close()
output=R/f'tests/F16-15-RESULTS-{width}.json';output.write_text(json.dumps({'width':width,'total':len(alltests),'passed':sum(x['pass'] for x in alltests),'failed':[x for x in alltests if not x['pass']],'tests':alltests},indent=2));print('SUMMARY',width,sum(x['pass'] for x in alltests),'/',len(alltests),flush=True)
sys.exit(0 if all(x['pass'] for x in alltests) else 1)
