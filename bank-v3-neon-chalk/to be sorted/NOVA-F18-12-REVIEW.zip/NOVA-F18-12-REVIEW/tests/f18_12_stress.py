from playwright.sync_api import sync_playwright
import json,math
from pathlib import Path
R=Path('/mnt/data');Q=R/'f18_12_qa';Q.mkdir(exist_ok=True)
html=(R/'F18-12-standard-unit-stories.html').read_text();checks=[]
def ck(n,ok,d=''):
 checks.append({'name':n,'ok':bool(ok),'detail':str(d)[:300]})
 if not ok: print('FAIL',n,str(d)[:300],flush=True)
def ev(p,s):return p.evaluate(s)
def mode(p,m):p.locator('#F18-12 .nova-tabs button').filter(has_text=m).click();p.wait_for_timeout(70)
def locate(p,x,y):
 r=ev(p,'() => {var e=document.querySelector("#F18-12 .f1812-svg"),r=e.getBoundingClientRect(),b=e.viewBox.baseVal;return {x:r.x,y:r.y,w:r.width,h:r.height,bw:b.width,bh:b.height}}')
 return (r['x']+x*r['w']/r['bw'],r['y']+y*r['h']/r['bh'])
def dr(p,f,remove=False,invalid=False,fast=False):
 target=p.locator(f'#F18-12 .f1812-tile[data-factor="{f}"]');target.scroll_into_view_if_needed();r=target.bounding_box();src=(r['x']+r['width']/2,r['y']+r['height']/2)
 dst=locate(p,220,764 if remove else 354 if invalid else 484)
 p.mouse.move(*src);p.mouse.down();p.mouse.move(*dst,steps=2 if fast else 14);p.mouse.up();p.wait_for_timeout(100)
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in (380,1280):
  p=browser.new_page(viewport={'width':w,'height':960},reduced_motion='reduce');errors=[];p.on('pageerror',lambda e:errors.append(str(e)));p.set_content(html);p.wait_for_timeout(100)
  ck(f'{w} canonical core',ev(p,'NOVA.version') is not None)
  ck(f'{w} exact original mascot in stage',p.locator('#F18-12 .nova-stage .nv-dock').count()==1)
  ck(f'{w} 6 presets',len(ev(p,'Object.keys(NOVA_F18_12_CONFIG.presets)'))==6)
  ck(f'{w} no external libraries',ev(p,'document.querySelectorAll("script[src],link[rel=stylesheet]").length')==0)
  for m in ('Watch','Guided','Explore','Challenge'):
   mode(p,m)
   ck(f'{w} {m} mounted',p.locator('#F18-12 .f1812-svg').count()==1)
   ck(f'{w} {m} mascot inside',p.locator('#F18-12 .nova-stage .nv-dock').count()==1)
   ck(f'{w} {m} no overflow',ev(p,'document.documentElement.scrollWidth<=innerWidth+1'))
   p.locator('#F18-12 .nova-stage').screenshot(path=str(Q/f'F18-12_{w}_{m.lower()}.png'),animations='disabled')
  mode(p,'Explore')
  cases={'desk':(260,'cm',100),'trail':(1750,'m',1000),'floor':(24000,'cm²',10000),'poster':(.65,'m²',10000),'crate':(35000,'cm³',1000000),'water':(1800,'mL',1000)}
  for key,(ans,u,f) in cases.items():
   ev(p,f'NOVA_F18_12_CONFIG._explore.select("{key}")');v=ev(p,'NOVA_F18_12_CONFIG._explore.state()')
   ck(f'{w} {key} result',math.isclose(v['answer'],ans,rel_tol=1e-10),v)
   ck(f'{w} {key} factor',v['factor']==f,v)
   ck(f'{w} {key} unit',v['unit']==u,v)
   tiles=ev(p,'[...document.querySelectorAll("#F18-12 .f1812-tile")].map(e=>e.getAttribute("data-factor"))')
   ck(f'{w} {key} distinct distractors',len(set(tiles))==3,tiles)
   p.locator('#F18-12 .nova-stage').screenshot(path=str(Q/f'F18-12_{w}_preset-{key}.png'),animations='disabled')
  ev(p,'NOVA_F18_12_CONFIG._explore.select("desk")')
  dr(p,100);ck(f'{w} real mouse factor drop',ev(p,'NOVA_F18_12_CONFIG._explore.state().tile')==100,ev(p,'NOVA_F18_12_CONFIG._explore.state()'))
  dr(p,100,remove=True,fast=True);ck(f'{w} actual red removal drop',ev(p,'NOVA_F18_12_CONFIG._explore.state().tile') is None,ev(p,'NOVA_F18_12_CONFIG._explore.state()'))
  dr(p,100,fast=True);ck(f'{w} fast regrab',ev(p,'NOVA_F18_12_CONFIG._explore.state().tile')==100)
  dr(p,100,invalid=True);ck(f'{w} invalid drop return',ev(p,'NOVA_F18_12_CONFIG._explore.state().tile')==100)
  drag=p.locator('#F18-12 .f1812-tile[data-factor="100"]');drag.scroll_into_view_if_needed();r=drag.bounding_box();x=r['x']+r['width']/2;y=r['y']+r['height']/2
  p.mouse.move(x,y);p.mouse.down();p.mouse.move(x+50,y-25,steps=3);p.keyboard.press('Escape');p.mouse.up();p.wait_for_timeout(90)
  ck(f'{w} Escape safe',ev(p,'NOVA_F18_12_CONFIG._explore.state().tile')==100)
  ck(f'{w} nothing floats',p.locator('#F18-12 .nv-drag-lift').count()==0)
  drag=p.locator('#F18-12 .f1812-tile[data-factor="100"]');drag.focus();p.keyboard.press('Delete');ck(f'{w} keyboard removal',ev(p,'NOVA_F18_12_CONFIG._explore.state().tile') is None)
  drag=p.locator('#F18-12 .f1812-tile[data-factor="100"]');drag.focus();p.keyboard.press('Enter');ck(f'{w} keyboard placement',ev(p,'NOVA_F18_12_CONFIG._explore.state().tile')==100)
  mode(p,'Challenge')
  tasks=[(370,'cm',100),(2450,'m',1000),(18000,'cm²',10000),(4.5,'m²',10000),(24000,'cm³',1000000),(2750,'mL',1000)]
  for idx,(ans,u,f) in enumerate(tasks):
   ev(p,f'NOVA_F18_12_CONFIG._challenge.task({idx})');v=ev(p,'NOVA_F18_12_CONFIG._challenge.state()')
   ck(f'{w} Challenge {idx} math',math.isclose(v['expected'],ans,rel_tol=1e-9),v)
   ck(f'{w} Challenge {idx} factor',v['factor']==f,v)
   ck(f'{w} Challenge {idx} hidden value',p.locator('#F18-12 .f1812-card[data-converted]').count()==0)
   ck(f'{w} Challenge {idx} unit required',not ev(p,f'NOVA_F18_12_CONFIG._challenge.check("{ans}")')[0])
   ck(f'{w} Challenge {idx} missing tile rejected',not ev(p,f'NOVA_F18_12_CONFIG._challenge.check("{ans} {u}")')[0])
   ck(f'{w} Challenge {idx} wrong amount rejected',not ev(p,f'NOVA_F18_12_CONFIG._challenge.check("{ans*10} {u}")')[0])
   ev(p,f'NOVA_F18_12_CONFIG._challenge.place({f})')
   ck(f'{w} Challenge {idx} correct',ev(p,f'NOVA_F18_12_CONFIG._challenge.check("{ans} {u}")')[0])
  ev(p,'NOVA_F18_12_CONFIG._challenge.task(0)');ev(p,'NOVA_F18_12_CONFIG._challenge.place(100)')
  p.locator('#F18-12 input[aria-label="Converted measurement and unit"]').fill('370 cm')
  p.locator('#F18-12 button').filter(has_text='Check conversion').click();p.wait_for_timeout(90)
  ck(f'{w} real button works',p.locator('#F18-12 .f1812-status[data-good]').count()==1)
  ck(f'{w} no JS errors',not errors,errors)
  p.close()
 browser.close()
results={'passed':sum(x['ok'] for x in checks),'total':len(checks),'failed':[x for x in checks if not x['ok']],'checks':checks}
(Q/'stress-results.json').write_text(json.dumps(results,indent=2));print('STRESS',results['passed'],'/',results['total'],'FAILED:',results['failed'][:20])
