import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
P='file:///mnt/data/F18-12-standard-unit-stories.html'
async def main():
 out=[];qa=Path('/mnt/data/f18_12_qa');qa.mkdir(exist_ok=True)
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for w in (380,1280):
   page=await browser.new_page(viewport={'width':w,'height':900},reduced_motion='reduce')
   errors=[];page.on('pageerror',lambda ex: errors.append(str(ex)))
   await page.set_content(Path('/mnt/data/F18-12-standard-unit-stories.html').read_text(),wait_until='domcontentloaded');await page.wait_for_timeout(500)
   for mode in ['Watch','Guided','Explore','Challenge']:
    await page.locator('#F18-12 .nova-tabs button').filter(has_text=mode).first.click()
    await page.wait_for_timeout(250)
    vals=await page.evaluate('''() => ({svg:!!document.querySelector('.f1812-svg'),width:document.documentElement.scrollWidth,screen:window.innerWidth,stage:document.querySelector('#F18-12 .nova-stage')?.getBoundingClientRect().height,pips:document.querySelectorAll('#F18-12 .nova-stage .nova-helperbar').length, cards:document.querySelectorAll('#F18-12 .f1812-card').length})''')
    await page.screenshot(path=str(qa/f'F18-12_{w}_{mode.lower()}.png'),full_page=False)
    out.append({'width':w,'mode':mode,'errors':errors[:],'values':vals,'pass':bool(vals['svg'] and vals['width']<=w+1 and not errors)})
   await page.close()
  await browser.close()
 (qa/'smoke.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
asyncio.run(main())
