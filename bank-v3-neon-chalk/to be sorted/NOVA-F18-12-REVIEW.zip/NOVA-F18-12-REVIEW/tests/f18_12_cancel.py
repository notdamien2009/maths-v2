import json
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path('/mnt/data');Q=R/'f18_12_qa';r=[]
def ck(label,ok,ev=''):
 r.append({'name':label,'ok':bool(ok),'detail':str(ev)[:270]});print('PASS' if ok else 'FAIL',label,ev)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for w in [380,1280]:
  p=b.new_page(viewport={'width':w,'height':950},reduced_motion='reduce');p.set_content((R/'F18-12-standard-unit-stories.html').read_text());p.locator('#F18-12 .nova-tabs button').filter(has_text='Explore').click()
  el=p.locator('#F18-12 .f1812-tile[data-factor="100"]');el.scroll_into_view_if_needed();rct=el.bounding_box();x=rct['x']+rct['width']/2;y=rct['y']+rct['height']/2
  p.mouse.move(x,y);p.mouse.down();p.mouse.move(x+60,y-30,steps=3)
  ck(f'{w} actual drag in progress',p.evaluate('!!NOVA.ui._drag'))
  p.locator('#F18-12 .f1812-tile[data-factor="100"]').dispatch_event('pointercancel',{'pointerId':1})
  p.mouse.up();p.wait_for_timeout(60)
  ck(f'{w} pointercancel cleared shared drag',not p.evaluate('!!NOVA.ui._drag'))
  ck(f'{w} pointercancel did not place factor',p.evaluate('NOVA_F18_12_CONFIG._explore.state().tile') is None)
  ck(f'{w} pointercancel removed floating class',p.locator('#F18-12 .nv-drag-lift').count()==0)
  p.close()
 b.close()
out={'passed':sum(x['ok'] for x in r),'total':len(r),'checks':r,'failed':[x for x in r if not x['ok']]};(Q/'cancel-results.json').write_text(json.dumps(out,indent=2));print(out['passed'],'/',out['total'])
