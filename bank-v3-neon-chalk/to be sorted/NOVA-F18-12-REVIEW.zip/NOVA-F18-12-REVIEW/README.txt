NOVA F18-12 — STANDARD-UNIT STORIES — REVIEW BUILD
Standalone HTML: F18-12-standard-unit-stories.html
NOVA Neon + Chalk core and original helper art embedded unchanged.
One component. Six story presets. Six Challenge tasks.
Four modes: WATCH, GUIDED, EXPLORE, CHALLENGE.
Automated evidence: 249/249 browser checks passed at 380px and 1280px.
Screenshots: 22; separate QA evidence report and test scripts.
This is for owner review, NOT GOLD-approved.
Physical touchscreen and owner visual QA outstanding.
GitHub unchanged.
