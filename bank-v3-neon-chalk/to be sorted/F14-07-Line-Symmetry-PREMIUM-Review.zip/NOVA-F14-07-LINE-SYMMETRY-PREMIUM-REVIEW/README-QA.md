# NOVA Maths V2 · F14-07 Line Symmetry — Review QA

**Status:** Premium review build for owner review (NOT GOLD-approved). GitHub was not changed.

**Basis:** F14-07 master prompt for KS3 Y7-055 Symmetry, derived from exact bundled F0/F2 core used in the F14-06 premium reference. The file is self-contained HTML with embedded CSS, JavaScript, Chalk font and mascot art. Uses NOVA.svg.grid/axes, NOVA.neonPath, NOVA.ui.svgDrag, NOVA.motion, NOVA.scene.helperStrip, NOVA.bankMount.

**Deliverables:** Standalone HTML + eight full-page Chromium screenshots + detailed JSON QA logs.

## Maths purpose
Line symmetry means a fold maps the entire figure exactly onto itself. Kite 1, non-square rectangle 2, square 4, isosceles triangle 1, equilateral triangle 3, regular hexagon 6, irregular L-shape 0, shifted kite 1 (x=1). All axes are checked against vertex reflection coordinates, not inferred from preset count alone. Non-symmetric L geometry corrected after mathematical QA.

## Functions
Watch: six-stage half-shape reflection sequence. Guided: same staged prompts with replay/step. Explore: eight presets, freely rotate and drag test line, reveal genuine axes, complete mirrored green half. Challenge: seven graduated tasks; counting axes, relocating x=1 symmetry line and dragging a missing half into position.

## Verified test results
- Browser suite: **138 passed / 0 failed** across 380px + 1280px in Watch, Guided, Explore and Challenge. Checks include frame and premium tokens, embedded font, single mascot in stage, absent duplicate outside helper, drawing primitives, eight presets, seven challenges, keyboard control, answer feedback, no horizontal overflow and no JavaScript errors.
- Real-pointer suite: **12 passed / 0 failed** across 380px + 1280px. Includes real mouse movement of axis and green piece, reset, Escape cancellation and no stranded drag.
- **Total: 150 checks passed, 0 failed.**
- Visual evidence in `screenshots/F14-07-<width>-<mode>.png`.
- Source HTML SHA256: `986aeca0f97dcd6c79c091e80b14746f5e6ae86ec026474bb2c4c1106c17ad10`.

## Notes
- Code intentionally remains at review status pending owner visual approval. Automated tests are not a substitute for pupil/teacher acceptance.
- Fraction notation not required for this component.
- Animated teaching uses the NOVA motion helper; reduced-motion modes are supported by the core.
- No additional font files or external assets are distributed; the self-contained HTML includes inline resources.
