# NOVA F14-09 — Tessellation Maker — Premium Review

Review only. No GitHub changes. Built on the NOVA F0/F2 premium HTML shell with its embedded shared JS/CSS core and Chalk fonts.

## What this engine teaches

Exact polygons tessellating without gaps or overlapping interiors. Watch / Guided demonstrate translations of equal-sized squares and a vertex-angle justification. Explore includes a gold tray with draggable copies, re-grab and rearrange, a red remove zone, snap targets, keyboard placement, Fill pattern, Remove last, Reset, and vertex-angle annotation. Challenge contains seven questions, including two hands-on tile placement tasks with misconception-specific feedback.

Presets: **squares (16 tiles), equilateral triangles (24), regular hexagons (12), rhombi (15), parallelograms (15)**. These tessellate exactly. **Regular pentagons (9 preview tiles)** are a comparison, not a tessellation. Some irregular pentagons *can* tessellate; the non-tiling claim concerns the regular pentagon only.

## QA evidence

- 108/108 standard browser / layout / interaction / maths checks, zero failures, at 380 and 1280 pixels.
- 24/24 real-pointer stress checks: tile drop, regrab, move, red removal zone, Escape cancellation, and the two interactive Challenge placements at both widths.
- 5/5 mathematically independent polygon geometry checks: valid, edge-matching shapes with zero positive-area overlap (Shapely union-area verification).
- **137 checks passed, 0 failed** (itemised in QA-RESULTS.json).
- Screenshots in `screenshots/`: all four modes at both 380px and 1280px, plus two filled mobile pattern examples.
- No external assets or network dependencies. Standalone file includes CSS, JS and inline mascot/font assets from provided NOVA reference.

## Build and review cautions

Owner sign-off is still required. This is a review build; it is not a GOLD-approved component. When importing into NOVA, preserve the tested premium shell and do not replace it with a new generic layout. The source is self-contained HTML and can be opened directly in a modern browser.

Standalone file SHA-256: `7acbf2a3d5f23dd882fb1a43b9c2cf3a325a52ec33187c4e0c5e73e4ca74e43e`.
