# NOVA Maths V2 — F18-04 Timetable reader · Review build

Standalone interactive HTML with embedded existing NOVA shared core.

Contents:
- F18-04-timetable-reader.html (open locally in Chrome or Edge)
- F18-04-QA-REPORT.html (scope, audit evidence, outstanding review tasks)
- screenshots/ (4 modes and 5 presets at 380px and 1280px)
- tests/ (browser regression and raw JSON results)

Status: BUILT FOR REVIEW. Not GOLD-approved. GitHub unchanged.

Features: Watch / Guided / Explore / Challenge; five authentic teaching scenarios (fictional service examples); 6 Challenge tasks; pointer + keyboard drag service cards; 24-hour notation, midnight, connection and deadline reasoning.

To re-run tests: Install Python Playwright and Chromium. Scripts use a self-contained HTML path under /mnt/data; change ROOT if running elsewhere.

Recorded browser QA: 108/108 checks passed. Physical touch hardware not tested.
