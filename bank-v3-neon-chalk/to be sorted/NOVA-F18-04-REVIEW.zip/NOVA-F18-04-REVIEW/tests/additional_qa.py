import asyncio,json,pathlib
from playwright.async_api import async_playwright
ROOT=pathlib.Path('/mnt/data'); QA=ROOT/'f18_04_qa';HTML=(ROOT/'F18-04-timetable-reader.html').read_text(); checks=[]
def ck(name,ok,note=''):checks.append({'name':name,'ok':bool(ok),'note':note})
async def main():
 async with async_playwright() as p:
  br=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w in (380,1280):
   ctx=await br.new_context(viewport={'width':w,'height':900},reduced_motion='reduce')
   pg=await ctx.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
   await pg.set_content(HTML,wait_until='load')
   await pg.locator('#F18-04 .nova-tabs button').filter(has_text='Watch').click()
   # Built-in timeline has six named teaching beats, buttons and range scrub.
   events=await pg.evaluate('NOVA.events.history().filter(x=>x.type==="step"&&x.detail.engine==="F18-04").map(x=>x.detail.name)')
   ck(f'{w} WATCH events have named teaching steps',len(events)>0 and all(bool(n) for n in events),str(events[-6:]))
   scrub=await pg.locator('#F18-04 input[type="range"]').count()
   ck(f'{w} WATCH has timeline/scrub control',scrub>=1,str(scrub))
   await pg.locator('#F18-04 .nova-tabs button').filter(has_text='Guided').click()
   ck(f'{w} GUIDED supplies question prompt',('?' in (await pg.locator('#F18-04').inner_text())))
   # Different presets must be mathematically self-consistent from their exact minute-of-day data.
   rows=await pg.evaluate('''()=>{let p=NOVA_F18_04_CONFIG.presets;return {bus:p.bus.trips[0][3]-p.bus.trips[0][0],schoolA:p.school.trips[0][3],schoolB:p.school.trips[1][3],schoolC:p.school.trips[2][3],rail:p.rail.trips[1][2]-p.rail.trips[0][1],railLater:p.rail.trips[2][2]-p.rail.trips[0][1],night:p.night.trips[1][3]-p.night.trips[1][0],midday:p.midday.trips[0][3]-p.midday.trips[0][0],station:p.bus.trips[2][2]-p.bus.trips[2][0]}}''')
   ck(f'{w} timetable values independently recompute',rows=={'bus':43,'schoolA':480,'schoolB':510,'schoolC':540,'rail':8,'railLater':28,'night':58,'midday':47,'station':27},str(rows))
   await pg.locator('#F18-04 .nova-tabs button').filter(has_text='Explore').click()
   # No horizontal overflow from the engine shell.
   overflow=await pg.evaluate('''()=>({page:document.documentElement.scrollWidth,viewport:innerWidth,body:document.body.scrollWidth,stage:document.querySelector('#F18-04 .f1804-drawing').getBoundingClientRect().width})''')
   ck(f'{w} no horizontal scroll overflow',overflow['page']<=w+1,str(overflow))
   # Check presets around midnight mark every next-day time (including +1 glyph).
   await pg.evaluate('NOVA_F18_04_CONFIG._explore.select("night")')
   svgtext=await pg.locator('#F18-04 svg.f1804-drawing').evaluate('(e)=>e.textContent')
   ck(f'{w} next-day times visibly marked',svgtext.count('+1')>=5,str(svgtext.count('+1')))
   await pg.locator('#F18-04 .nova-tabs button').filter(has_text='Challenge').click()
   chk=pg.locator('#F18-04 .nova-panel .nova-btn').filter(has_text='Check timetable')
   ck(f'{w} visible Challenge check button exists',(await chk.count())==1)
   await chk.click()
   text=await pg.locator('#F18-04').inner_text()
   ck(f'{w} missing-answer feedback explains unit',('Include the duration unit' in text),text[-280:])
   # Non-leaking task 6 route must be visible when that question loads.
   await pg.evaluate('NOVA_F18_04_CONFIG._challenge.task(5)')
   side=await pg.locator('#F18-04 .f1804-side').inner_text()
   ck(f'{w} final task route displays Station not Leisure','Station' in side and 'Leisure Ctr' not in side,str(side[:160]))
   ck(f'{w} no browser errors in extended QA',not errors,str(errors))
   await ctx.close()
  await br.close()
 (QA/'additional-results.json').write_text(json.dumps({'passed':sum(x['ok'] for x in checks),'total':len(checks),'checks':checks},indent=2));print(json.dumps({'passed':sum(x['ok'] for x in checks),'total':len(checks),'failed':[x for x in checks if not x['ok']]},indent=2))
asyncio.run(main())
