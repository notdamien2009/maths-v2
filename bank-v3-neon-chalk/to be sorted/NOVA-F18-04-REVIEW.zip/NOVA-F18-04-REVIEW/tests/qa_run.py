import asyncio,json,pathlib,traceback
from playwright.async_api import async_playwright
ROOT=pathlib.Path('/mnt/data');OUT=ROOT/'f18_04_qa';HTML=(ROOT/'F18-04-timetable-reader.html').read_text()
checks=[]; problems=[]
def record(name,condition,detail=''):
 checks.append({'name':name,'ok':bool(condition),'detail':detail})
 if not condition:problems.append(name+(' : '+str(detail) if detail else ''))
async def snapshot(page,width,mode):
 await page.screenshot(path=str(OUT/f'F18-04_{width}_{mode}.png'),full_page=True,animations='disabled')
async def select_mode(page,label):
 await page.locator('#F18-04 .nova-tabs button').filter(has_text=label).click()
 await page.wait_for_timeout(90)
async def drag(page,frm,to,steps=12):
 await page.mouse.move(*frm)
 await page.mouse.down()
 await page.mouse.move(*to,steps=steps)
 await page.mouse.up()
 await page.wait_for_timeout(130)
async def xy(page, selector):
 return await page.locator(selector).first.evaluate('(e)=>{const r=e.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]}')
async def gate_xy(page):
 return await page.locator('#F18-04 svg.f1804-drawing').evaluate('(e)=>{const b=e.getBoundingClientRect(),v=e.viewBox.baseVal;return [b.x+b.width*0.5,b.y+b.height*(v.width===400?515:503)/v.height]}')
async def tray_xy(page):
 return await page.locator('#F18-04 svg.f1804-drawing').evaluate('(e)=>{const b=e.getBoundingClientRect(),v=e.viewBox.baseVal;return [b.x+b.width*.8,b.y+b.height*(v.width===400?590:575)/v.height]}')
async def get_state(page):
 return await page.evaluate('window.NOVA_F18_04_CONFIG._explore.state()')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  for w in (380,1280):
   ctx=await browser.new_context(viewport={'width':w,'height':850},device_scale_factor=1,reduced_motion='reduce')
   page=await ctx.new_page(); errors=[]
   page.on('pageerror',lambda x:errors.append(str(x)))
   await page.set_content(HTML,wait_until='load');await page.wait_for_timeout(90)
   record(f'{w} core initialized',await page.evaluate('typeof NOVA.bankMount==="function" && typeof NOVA.ui.svgDrag==="function" && typeof NOVA.neonBox==="function"'))
   for mode in ('Watch','Guided','Explore','Challenge'):
    await select_mode(page,mode)
    visible=await page.locator('#F18-04 svg.f1804-drawing').count()
    record(f'{w} {mode} renders SVG',visible==1,f'count {visible}')
    await snapshot(page,w,mode.lower())
   await select_mode(page,'Explore')
   config=await page.evaluate('Object.keys(window.NOVA_F18_04_CONFIG.presets)')
   record(f'{w} all five presets',set(config)=={'bus','school','rail','night','midday'},str(config))
   expected={'bus':None,'school':None,'rail':None,'night':None,'midday':None}
   for k in expected:
    await page.evaluate('(k)=>window.NOVA_F18_04_CONFIG._explore.select(k)',k)
    record(f'{w} preset {k} renders 12 readings',await page.locator('#F18-04 .f1804-drawing').count()==1)
    await page.screenshot(path=str(OUT/f'F18-04_{w}_preset_{k}.png'),full_page=True,animations='disabled')
   await page.evaluate('window.NOVA_F18_04_CONFIG._explore.select("bus")')
   # Test real mouse pointer on a token (not merely keyboard or state injection).
   await page.locator('#F18-04 [data-service="2"]').scroll_into_view_if_needed();pos=await xy(page,'#F18-04 [data-service="2"]');dest=await gate_xy(page)
   await drag(page,pos,dest,25)
   st=await get_state(page)
   record(f'{w} rapid pointer drag C into dock',st['selected']==2,str(st))
   record(f'{w} expected C route is 43 min',st['duration']==43,str(st))
   record(f'{w} mouse released and no detached object',await page.evaluate('!NOVA.ui._drag'))
   # Re-grab from the selected dock and drop in the red removal tray.
   pos=await xy(page,'#F18-04 [data-service="2"]');dest=await tray_xy(page)
   await drag(page,pos,dest,9)
   st=await get_state(page)
   record(f'{w} regrab C and remove in tray',st['selected'] is None,str(st))
   record(f'{w} released after removal',await page.evaluate('!NOVA.ui._drag'))
   # Invalid drop must recover.
   await page.locator('#F18-04 [data-service="0"]').scroll_into_view_if_needed();pos=await xy(page,'#F18-04 [data-service="0"]');svg=page.locator('#F18-04 svg.f1804-drawing')
   bad=await svg.evaluate('(e)=>{let r=e.getBoundingClientRect();return [r.x+r.width*.94,r.y+r.height*.16]}')
   await drag(page,pos,bad,18)
   record(f'{w} invalid drop springs home', (await get_state(page))['selected'] is None)
   record(f'{w} no stranded drag after invalid drop',await page.evaluate('!NOVA.ui._drag'))
   # Test cancel during mouse drag.
   await page.locator('#F18-04 [data-service="1"]').scroll_into_view_if_needed();pos=await xy(page,'#F18-04 [data-service="1"]');dest=await gate_xy(page)
   await page.mouse.move(*pos);await page.mouse.down();await page.mouse.move(*dest,steps=7)
   await page.keyboard.press('Escape');await page.mouse.up();await page.wait_for_timeout(90)
   record(f'{w} Escape cancels pointer drag',await page.evaluate('!NOVA.ui._drag'))
   record(f'{w} Escape preserves prior selection', (await get_state(page))['selected'] is None)
   # Keyboard Enter then Enter to deselect, roving focus navigation.
   k=page.locator('#F18-04 [data-service="1"]');await k.focus();await page.keyboard.press('Enter');await page.wait_for_timeout(70)
   record(f'{w} keyboard selects B', (await get_state(page))['selected']==1)
   await page.locator('#F18-04 [data-service="1"]').focus();await page.keyboard.press('Enter');await page.wait_for_timeout(70)
   record(f'{w} keyboard toggles B off',(await get_state(page))['selected'] is None)
   await page.locator('#F18-04 [data-service="0"]').focus();await page.keyboard.press('ArrowRight')
   record(f'{w} roving arrows focus next service',await page.evaluate('document.activeElement?.getAttribute("data-service")==="1"'))
   # Maths for all task cases via independently calculated definitions.
   await select_mode(page,'Challenge')
   tasks=await page.evaluate('window.NOVA_F18_04_CONFIG._challenge.tasks.map(t=>({preset:t.preset,expected:t.expected,service:t.service,unit:t.unit}))')
   independent=[('bus',43,0,'min'),('school',475,1,'time'),('rail',8,1,'min'),('night',58,1,'min'),('midday',47,0,'min'),('bus',27,2,'min')]
   record(f'{w} six independent mathematical values',[(t['preset'],t['expected'],t['service'],t['unit']) for t in tasks]==independent,str(tasks))
   for i,t in enumerate(tasks):
    await page.evaluate('(j)=>window.NOVA_F18_04_CONFIG._challenge.task(j)',i)
    await page.evaluate('window.NOVA_F18_04_CONFIG._challenge.solve()')
    state=await page.evaluate('window.NOVA_F18_04_CONFIG._challenge.state()')
    outcome=await page.evaluate('window.NOVA_F18_04_CONFIG._challenge.check(window.NOVA_F18_04_CONFIG._challenge.state().entry)')
    record(f'{w} challenge task {i+1} accepts exact value with service',outcome[0] is True,str(outcome))
    value=state['entry'].replace(' min','') if t['unit']=='min' else (state['entry']+' min')
    wrong=await page.evaluate('(v)=>window.NOVA_F18_04_CONFIG._challenge.check(v)',value)
    record(f'{w} challenge task {i+1} rejects absent or incorrect unit',wrong[0] is False,str(wrong))
    wrongsrv=await page.evaluate('(v)=>window.NOVA_F18_04_CONFIG._challenge.check(v,(window.NOVA_F18_04_CONFIG._challenge.state().service+1)%3)',state['entry'])
    record(f'{w} challenge task {i+1} rejects wrong service',wrongsrv[0] is False,str(wrongsrv))
    if i==0:
     # Challenge cannot reveal result through side card even after service placed.
     tx=await page.locator('#F18-04 .f1804-side').inner_text()
     record(f"{w} challenge does not expose answer in side panel",'43 min' not in tx,str(tx[:150]))
   record(f'{w} no uncaught browser errors',not errors,str(errors))
   await ctx.close()
  await browser.close()
 out={'total':len(checks),'passed':sum(x['ok'] for x in checks),'failed':len(problems),'issues':problems,'checks':checks};(OUT/'stress-results.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='checks'},indent=2))
asyncio.run(main())
