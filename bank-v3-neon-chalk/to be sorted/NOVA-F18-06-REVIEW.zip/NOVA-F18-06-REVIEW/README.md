# NOVA Maths V2 — F18-06 Budget and Payslip

Built and tested for owner review. NOT GOLD-approved.

Open `F18-06-budget-and-payslip.html` in a modern browser. It is a self-contained HTML file with embedded original F0/F2 core, mathematical fonts, neon SVG drawing helpers, original in-stage mascot and no network requirement.

Family: F18 Measures / Units / Time / Money. Curriculum: Year 8 wages, deductions and budgeting. Six lesson presets: first job, overtime, payslip, weekly budget, savings plan and percentage deduction GCSE bridge.

WATCH: six teaching beats, voice narration slots, play/rewind/scrub, reduced-motion support.
GUIDED: paced mathematical prompts.
EXPLORE: drag deductible payroll slips and household spending slips to separate docks; re-grab and return; Enter/Space to allocate; Delete or Enter to remove; Escape to cancel; Left/Right between tokens.
CHALLENGE: six cash sums, unit-specific checks and misconception feedback; requires corresponding allocated slips for net and remaining-money tasks.

Important: payroll and percentage deductions are fictional teaching examples, not actual tax, NI or pension rules.

Automated browser validation: 242 / 242 checks across 380px and 1280px. See QA report and test scripts/results. Physical touchscreen stress test, owner sign-off and GOLD approval outstanding.

GitHub has not been modified.
