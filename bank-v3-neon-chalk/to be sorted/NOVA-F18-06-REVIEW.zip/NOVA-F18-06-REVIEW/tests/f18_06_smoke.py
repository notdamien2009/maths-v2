from pathlib import Path
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
 b=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(Path('/mnt/data/F18-06-budget-and-payslip.html').read_text(),wait_until='domcontentloaded');page.wait_for_timeout(160)
  print('WIDTH',width,'stage',page.locator('#F18-06 .nova-stage').count(),'svg',page.locator('.f1806-svg').count(),'core',page.evaluate('typeof NOVA.ui.svgDrag'),'error',errors,'over',page.evaluate('document.documentElement.scrollWidth-innerWidth'))
  for mode in ['watch','guided','explore','challenge']:
   page.locator('#F18-06 .nova-tabs button').filter(has_text=mode.title()).click();page.wait_for_timeout(65)
   print(mode,'svg',page.locator('#F18-06 .f1806-svg').count(),'mascot',page.locator('#F18-06 .nova-stage .nv-dock').count(),'error',errors[-1:] )
   page.screenshot(path=f'/mnt/data/f18_06_{width}_{mode}.png',full_page=True,animations='disabled')
  page.close()
 b.close()
