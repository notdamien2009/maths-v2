import json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data');QA=ROOT/'f18_06_qa';QA.mkdir(exist_ok=True)
HTML=(ROOT/'F18-06-budget-and-payslip.html').read_text()
checks=[]
def ck(name,ok,detail=''):
 checks.append({'name':name,'ok':bool(ok),'detail':str(detail)[:400]})
 if not ok:print('FAIL',name,detail,flush=True)
def go(page,mode):
 page.locator('#F18-06 .nova-tabs button').filter(has_text=mode.title()).click();page.wait_for_timeout(45)
def val(page,js):return page.evaluate(js)
def ex(page):return val(page,'NOVA_F18_06_CONFIG._explore.state()')
def drag(page,id,where='ded',placed=False,steps=22):
 tk=page.locator('#F18-06 .f1806-svg .f1806-token[data-kind="'+('placed' if placed else 'source')+'"][data-id="'+id+'"]')
 tk.scroll_into_view_if_needed(timeout=4000)
 bb=tk.bounding_box();src=(bb['x']+bb['width']/2,bb['y']+bb['height']/2)
 data=page.locator('#F18-06 .f1806-svg').evaluate('(e)=>({r:e.getBoundingClientRect().toJSON(),vb:{w:e.viewBox.baseVal.width,h:e.viewBox.baseVal.height}})')
 r=data['r'];v=data['vb'];scale=r['width']/v['w']; cx=r['x']+v['w']*.5*scale; cy=r['y']+{'ded':575,'cost':702,'remove':391,'invalid':60}[where]*scale
 page.mouse.move(*src);page.mouse.down();page.mouse.move(cx,cy,steps=steps);page.mouse.up();page.wait_for_timeout(440 if where=='remove' else 80)
 return {'src':src,'dst':[cx,cy]}
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  page=browser.new_page(viewport={'width':width,'height':900},reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(HTML,wait_until='domcontentloaded')
  ck(f'{width} single shared core',val(page,'typeof NOVA.ui.svgDrag')=='function')
  ck(f'{width} only one core copy',val(page,'document.querySelectorAll("#F18-06").length')==1)
  ck(f'{width} no horizontal overflow',val(page,'document.documentElement.scrollWidth<=innerWidth+1'))
  ck(f'{width} six proper presets',len(val(page,'Object.keys(NOVA_F18_06_CONFIG.presets)'))==6)
  for mode in ('watch','guided','explore','challenge'):
   go(page,mode)
   ck(f'{width} {mode} has SVG',page.locator('#F18-06 .f1806-svg').count()==1)
   ck(f'{width} {mode} exactly one in-stage mascot',page.locator('#F18-06 .nova-stage .nv-dock').count()==1)
   ck(f'{width} {mode} stage construction',page.locator('#F18-06 .f1806-svg .nv-neon-box').count()>=2)
   ck(f'{width} {mode} no outside mascot',page.locator('#F18-06 .nova-bob').first.evaluate('(e)=>getComputedStyle(e).display')=='none')
   page.screenshot(path=str(QA/f'F18-06_{width}_{mode}.png'),full_page=True,animations='disabled')
  pp=val(page,'NOVA_F18_06_CONFIG.presets')
  expected={
   'shift':(11400,800,10600,2600,8000),
   'overtime':(24200,2420,21780,6175,15605),
   'payslip':(42000,5460,36540,11340,25200),
   'weekly':(31500,2250,29250,16830,12420),
   'savings':(31000,0,31000,23500,7500),
   'percent':(26880,2382,24498,9350,15148)
  }
  for k,x in expected.items():
   pr=pp[k]
   calc=(pr['gross'],sum(y[1] for y in pr['deds']),pr['gross']-sum(y[1] for y in pr['deds']),sum(y[1] for y in pr['costs']),pr['gross']-sum(y[1] for y in pr['deds'])-sum(y[1] for y in pr['costs']))
   ck(f'{width} {k} 5 independent currency computations',calc==x,calc)
  ck(f'{width} overtime hours rate arithmetic',pp['overtime']['hours']*pp['overtime']['rate']+pp['overtime']['extraHours']*pp['overtime']['extraRate']==24200)
  ck(f'{width} 7% penny rounding',round(pp['percent']['gross']*.07)==1882)
  go(page,'watch');ck(f'{width} named six watch steps',len(val(page,'NOVA_F18_06_CONFIG&&NOVA.events.query({type:"step"}).filter(e=>e.detail.engine==="F18-06")'))>=1)
  go(page,'explore')
  ck(f'{width} initial allocations empty',len(ex(page)['placed'])==0)
  drag(page,'d0','ded',steps=28)
  ck(f'{width} real pointer drop deduction',ex(page)['placed']==['d0'],ex(page))
  # fast pointer movement second token to different zone
  drag(page,'c0','cost',steps=5)
  ck(f'{width} fast real pointer drop budget',set(ex(page)['placed'])=={'d0','c0'},ex(page))
  drag(page,'c0','remove',placed=True)
  ck(f'{width} real pointer regrab returns expense',ex(page)['placed']==['d0'],ex(page))
  drag(page,'c1','invalid',steps=16)
  ck(f'{width} invalid drop springs home',ex(page)['placed']==['d0'],ex(page))
  # cancel with Escape
  tk=page.locator('#F18-06 .f1806-svg .f1806-token[data-id="c1"][data-kind="source"]')
  tk.scroll_into_view_if_needed();bb=tk.bounding_box();at=(bb['x']+bb['width']/2,bb['y']+bb['height']/2)
  page.mouse.move(*at);page.mouse.down();page.mouse.move(at[0]+60,at[1]+100,steps=7);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(100)
  ck(f'{width} Escape retains only correct allocations',ex(page)['placed']==['d0'])
  ck(f'{width} Escape leaves no floating piece',page.locator('#F18-06 .nv-drag-lift').count()==0)
  page.locator('#F18-06 .f1806-token[data-id="c1"][data-kind="source"]').focus();page.keyboard.press('Enter')
  ck(f'{width} keyboard Enter adds expense',set(ex(page)['placed'])=={'d0','c1'})
  page.locator('#F18-06 .f1806-token[data-id="c1"][data-kind="placed"]').focus();page.keyboard.press('Delete')
  ck(f'{width} keyboard Delete removes expense',ex(page)['placed']==['d0'])
  page.locator('#F18-06 .f1806-token[data-id="d0"][data-kind="placed"]').focus();page.keyboard.press('Enter')
  ck(f'{width} keyboard Enter removes placed deduction',ex(page)['placed']==[])
  # each preset independently validates tokens and allocation, target math
  for k,pr in pp.items():
   val(page,f'NOVA_F18_06_CONFIG._explore.select("{k}")')
   xx=ex(page)
   ck(f'{width} explore {k} selected',xx['preset']==k)
   ck(f'{width} explore {k} visible tokens',page.locator('#F18-06 .f1806-token').count()==len(pr['deds'])+len(pr['costs']))
   ck(f'{width} explore {k} independent net',xx['totals']['net']==expected[k][2])
   ck(f'{width} explore {k} independent balance',xx['totals']['balance']==expected[k][4])
   if k=='savings':
    for item in ['c0','c1','c2','c3']:val(page,f'NOVA_F18_06_CONFIG._explore.place("{item}")')
    ck(f'{width} savings all 4 dock tokens present',page.locator('#F18-06 .f1806-token[data-kind="placed"]').count()==4)
    ck(f'{width} savings dock tokens fit their zone',val(page,'()=>{let svg=document.querySelector("#F18-06 .f1806-svg"),arr=[...svg.querySelectorAll("[data-kind=placed]")];let a=svg.getBoundingClientRect(),sc=a.width/svg.viewBox.baseVal.width;let max=((svg.viewBox.baseVal.width===440?656:635)+102)*sc+a.y;return arr.every(el=>el.getBoundingClientRect().bottom<=max+1)}'))
  go(page,'challenge')
  task_expected=[10600,24200,36540,12420,7500,24498]
  for i,v in enumerate(task_expected):
   val(page,f'NOVA_F18_06_CONFIG._challenge.task({i})')
   ck(f'{width} task {i+1} independent expected amount',val(page,'NOVA_F18_06_CONFIG._challenge.state().expected')==v)
   # wrong amount including gross, no money unit, and incorrect placement all rejected
   bad=val(page,'()=>NOVA_F18_06_CONFIG._challenge.check("12345")')
   ck(f'{width} task {i+1} requires money units',bad[0]==False,bad)
   wrong=val(page,f'()=>NOVA_F18_06_CONFIG._challenge.check("£{(v+100)/100:.2f}")')
   ck(f'{width} task {i+1} rejects wrong value',wrong[0]==False,wrong)
   goodAmount=f'£{v/100:.2f}'
   before=val(page,f'()=>NOVA_F18_06_CONFIG._challenge.check("{goodAmount}")')
   ck(f'{width} task {i+1} physical allocations required or gross exempt', before[0]==(i==1),before)
   answer=val(page,'NOVA_F18_06_CONFIG._challenge.solve()')
   ck(f'{width} task {i+1} solve amount correct',answer==goodAmount,answer)
   after=val(page,f'()=>NOVA_F18_06_CONFIG._challenge.check("{goodAmount}")')
   ck(f'{width} task {i+1} correct answer and allocations accepted',after[0],after)
   ck(f'{width} task {i+1} no answer leak in stage',('£'+f'{v/100:.2f}' not in page.locator('#F18-06 .nova-stage .f1806-side').inner_text()) or (i==1 and v==pp['overtime']['gross']))
  ck(f'{width} no javascript page errors',not errors,errors)
  page.close()
 browser.close()
report={'passed':sum(x['ok'] for x in checks),'total':len(checks),'failures':[x for x in checks if not x['ok']],'checks':checks}
(QA/'stress-results.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'passed':report['passed'],'total':report['total'],'failures':report['failures']},indent=2),flush=True)
