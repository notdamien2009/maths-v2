from pathlib import Path
from playwright.sync_api import sync_playwright
Q=Path('/mnt/data/f18_06_qa');S=Path('/mnt/data/F18-06-budget-and-payslip.html').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');page.set_content(S,wait_until='domcontentloaded')
  page.locator('#F18-06 .nova-tabs button').filter(has_text='Explore').click()
  for preset in ['shift','overtime','payslip','weekly','savings','percent']:
   page.evaluate(f'NOVA_F18_06_CONFIG._explore.select("{preset}")')
   page.screenshot(path=str(Q/f'F18-06_{width}_preset_{preset}.png'),full_page=True,animations='disabled')
  page.close()
 b.close()
print('screenshots',len(list(Q.glob('F18-06_*.png'))))
