import json
from pathlib import Path
from playwright.sync_api import sync_playwright
P=Path('/mnt/data');q=P/'f18_06_qa';r=[]
def check(n,ok,detail=''):
 r.append({'name':n,'ok':bool(ok),'detail':str(detail)[:300]})
 if not ok:print('FAIL',n,detail,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in [380,1280]:
  page=b.new_page(viewport={'width':w,'height':900},reduced_motion='reduce');errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content((P/'F18-06-budget-and-payslip.html').read_text(),wait_until='domcontentloaded')
  c=page.locator('#F18-06');stage=c.locator('.nova-stage')
  check(f'{w} 6 named steps',page.evaluate('()=>{let s=NOVA_F18_06_CONFIG;return s&&document.querySelectorAll("#F18-06 .nova-tabs button").length===4&&NOVA.events.query({type:"step"}).some(e=>e.detail.engine==="F18-06")}'))
  check(f'{w} Watch has scrub timeline',c.locator('input[type=range]').count()>=1)
  check(f'{w} Watch buttons',c.locator('button').count()>=6)
  check(f'{w} watch animation engine reduced-motion',page.evaluate('NOVA.reducedMotion()') is True)
  check(f'{w} watch stage shows calculation', '£80.00' in stage.inner_text())
  c.locator('.nova-tabs button').filter(has_text='Guided').click()
  check(f'{w} Guided prompts visible',bool(c.inner_text().lower().find('prompt')>-1 or len(c.inner_text())>900))
  check(f'{w} Guided uses neon maths scene',c.locator('svg.f1806-svg').count()==1)
  c.locator('.nova-tabs button').filter(has_text='Explore').click()
  page.evaluate('NOVA_F18_06_CONFIG._explore.select("percent")')
  check(f'{w} percentage preset net',page.evaluate('NOVA_F18_06_CONFIG._explore.state().totals.net')==24498)
  check(f'{w} non-statutory disclaimer', 'fictional' in c.inner_text().lower() or 'not a real' in c.inner_text().lower())
  c.locator('.nova-tabs button').filter(has_text='Challenge').click()
  ch=page.evaluate('NOVA_F18_06_CONFIG._challenge.solve()')
  check(f'{w} first challenge solve £106.00',ch=='£106.00')
  page.locator('#F18-06 .f1806-buttons button').filter(has_text='Check payslip').click()
  check(f'{w} actual Check button emits correct',page.evaluate('NOVA.events.query({type:"correct"}).some(e=>e.detail.engine==="F18-06"&&e.detail.correct===true)'))
  check(f'{w} actual Check shows specific success', 'Correct' in c.inner_text() or 'Correct' in c.locator('.f1806-status').inner_text())
  check(f'{w} no page errors',not errs,errs)
  page.close()
 b.close()
a={'passed':sum(x['ok'] for x in r),'total':len(r),'failures':[x for x in r if not x['ok']],'checks':r}
(q/'additional-results.json').write_text(json.dumps(a,indent=2))
print(json.dumps({'passed':a['passed'],'total':a['total'],'failures':a['failures']},indent=2))
