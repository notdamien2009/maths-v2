# NOVA F15-14 — QA REPORT

**Status:** COMPLETE FOR OWNER REVIEW — NOT GOLD-APPROVED

## Source and preservation
- Exact spec: `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, F15-14 (3D Pythagoras and trigonometry, GCSE extension).
- Reference shell: `NOVA-F15-13-Sine-and-Cosine-Rule.html` — embedded core script compared byte-for-byte to this review HTML.
- NOVA core JavaScript SHA-256: `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc`. No GitHub changes.
- One original shared-core mascot inside the stage; no duplicate portrait outside it.
- Mathematical geometry is built through the existing `NOVA.svg`, `NOVA.neonPath`, `NOVA.neonBox`, `NOVA.chalkText`, `NOVA.neonRing`, and `NOVA.ui.svgDrag` helpers.

## Exact maths — code evidence
- `calc(p)`: floor diagonal `Math.hypot(L,W)`, space diagonal `Math.hypot(base,H)`, angle of elevation `atan2(H,base) × (180/π)`.
- `position(p)`: 3D cuboid vertices from consistently projected perpendicular world-axis edges; stage has no invented cartoony 3D art.
- `draw(...)`: constructs three glass cuboid faces, floor diagonal triangle A-B-C and second right triangle A-C-G, including the line through the interior and stage formulas.
- `PRESETS`: eight named contexts including cube, room measurements, elevation and missing height.
- `NOVA_F15_14_CONFIG._questions`: twelve mathematical assessments with hidden answer diagrams, numeric validation and misconception-specific feedback.

## Browser tests actually performed
- **Mode/viewport smoke:** 10/10 passing checks (380px + 1280px, WATCH / GUIDED / EXPLORE / CHALLENGE; no JavaScript exceptions).
- **Real pointer / keyboard / maths stress:** 160/160 passing checks (both viewport widths, all eight presets, two Pythagorean identities and angle tangent, fast mouse dragging of length/width/height, invalid drops, Escape, label snapping and removal, keyboard controls, 12 challenge questions, actual submit).
- **18-step WATCH timeline and preset screenshots:** 96/96 passing checks (both viewport widths, scrub, forward, rewind, all states, all presets, no JS exceptions).
- **TOTAL:** 266/266 checks passed, zero failures in these completed suites.

## Screenshots
- `screenshots/380-watch.png`
- `screenshots/380-guided.png`
- `screenshots/380-explore.png`
- `screenshots/380-challenge.png`
- `screenshots/1280-watch.png`
- `screenshots/1280-guided.png`
- `screenshots/1280-explore.png`
- `screenshots/1280-challenge.png`
- `screenshots/380-watch-state-06.png`
- `screenshots/380-watch-state-12.png`
- `screenshots/380-watch-state-16.png`
- `screenshots/1280-watch-state-06.png`
- `screenshots/1280-watch-state-12.png`
- `screenshots/1280-watch-state-16.png`
- `screenshots/380-gcse-angle-explore.png`
- `screenshots/1280-gcse-angle-explore.png`

## Known limitations / acceptance
- Browser automation was performed in headless Chromium at the two specified CSS widths, not on a physical touchscreen or inside the NOVA lesson app.
- Some browser geometry is an isometric 2D projection of a true 3D cuboid: perpendicular edges can appear non-perpendicular after projection, as expected.
- This is the F15-14 owner REVIEW build only, not family audit, GOLD approval or live-platform integration.
