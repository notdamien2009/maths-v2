from pathlib import Path
from playwright.sync_api import sync_playwright
import json
html=Path('/mnt/data/NOVA-F15-14-3D-Pythagoras-and-Trigonometry.html').read_text()
q=Path('/mnt/data/F15-14-QA/screenshots');q.mkdir(parents=True,exist_ok=True)
checks=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'])
 for width in [380,1280]:
  pg=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce')
  errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(html,wait_until='domcontentloaded',timeout=60000)
  for i,mode in enumerate(['watch','guided','explore','challenge']):
   try:
    pg.locator('.nova-tabs button').nth(i).click(timeout=5000)
    pg.wait_for_timeout(140)
    cnt=pg.locator('#F15-14 .nova-stage svg.f1514-svg').count()
    checks.append([width,mode,'svg',cnt==1])
    pg.screenshot(path=str(q/f'{width}-{mode}.png'),full_page=True,timeout=30000)
   except Exception as e:checks.append([width,mode,'exception',False,str(e)[:200]])
  checks.append([width,'all','no page errors',not errors,errors]);print(width,errors)
  pg.close()
 b.close()
print(checks)
print('PASSED',sum(v[3] for v in checks),'/',len(checks))
Path('/mnt/data/F15-14-QA/smoke.json').write_text(json.dumps(checks,indent=2))
