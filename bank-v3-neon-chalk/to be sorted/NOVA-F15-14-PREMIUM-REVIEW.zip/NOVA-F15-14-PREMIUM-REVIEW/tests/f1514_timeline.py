from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path('/mnt/data');QA=ROOT/'F15-14-QA';(QA/'screenshots').mkdir(parents=True,exist_ok=True)
source=(ROOT/'NOVA-F15-14-3D-Pythagoras-and-Trigonometry.html').read_text();out=[]
def ck(name,yes):out.append({'test':name,'passed':bool(yes)});print(('PASS ' if yes else 'FAIL ')+name)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in [380,1280]:
  pg=b.new_page(viewport={'width':w,'height':900},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(source,wait_until='domcontentloaded');pg.wait_for_timeout(100)
  pause=pg.locator('#F15-14 button[aria-label="Pause"]');
  if pause.count():pause.click()
  scrub=pg.locator('#F15-14 input[aria-label="Scrub through steps"]');ck(f'{w} scrub available',scrub.count()==1)
  for i in range(18):
   scrub.fill(str(i));scrub.dispatch_event('input');pg.wait_for_timeout(32)
   label=pg.locator('#F15-14 .nova-stepname').inner_text()
   ck(f'{w} watch {i+1:02} index',('Step '+str(i+1)+' of 18') in label)
   ck(f'{w} watch {i+1:02} SVG',pg.locator('#F15-14 svg.f1514-svg').count()==1)
   if i in [0,3,5,7,9,11,13,15,17]:
    pg.locator('#F15-14 .nova-stage').screenshot(path=str(QA/'screenshots'/f'{w}-watch-state-{i+1:02}.png'))
  scrub.fill('0');scrub.dispatch_event('input');pg.wait_for_timeout(50)
  pg.locator('#F15-14 button[aria-label="Step forward"]').click();pg.wait_for_timeout(45)
  ck(f'{w} forward',pg.locator('#F15-14 .nova-stepname').inner_text().startswith('Step 2 of 18'))
  pg.locator('#F15-14 button[aria-label="Step back"]').click();pg.wait_for_timeout(45)
  ck(f'{w} rewind',pg.locator('#F15-14 .nova-stepname').inner_text().startswith('Step 1 of 18'))
  pg.locator('.nova-tabs button').nth(2).click()
  for name in ['cuboid-345','space-862','base-869','gcse-angle','gcse-short','gcse-room','gcse-cube','extension']:
   pg.evaluate('(v)=>NOVA_F15_14_CONFIG._explore.select(v)',name)
   ck(f'{w} explore {name}',pg.locator('#F15-14 svg.f1514-svg').count()==1)
   if name in ['cuboid-345','gcse-angle','gcse-cube','extension']:
    pg.locator('#F15-14 .nova-stage').screenshot(path=str(QA/'screenshots'/f'{w}-{name}-explore.png'))
  pg.locator('.nova-tabs button').nth(3).click()
  pg.locator('#F15-14 .nova-stage').screenshot(path=str(QA/'screenshots'/f'{w}-challenge-stage.png'))
  ck(f'{w} no JS exceptions',not errors)
  pg.close()
 b.close()
(QA/'timeline.json').write_text(json.dumps(out,indent=2))
print('TIMELINE',sum(q['passed'] for q in out),'/',len(out))
if not all(q['passed'] for q in out):raise SystemExit(1)
