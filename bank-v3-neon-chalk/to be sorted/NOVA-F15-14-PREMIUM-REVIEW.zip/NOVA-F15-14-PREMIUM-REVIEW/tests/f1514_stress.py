from pathlib import Path
from playwright.sync_api import sync_playwright
import math,json,traceback
QA=Path('/mnt/data/F15-14-QA');QA.mkdir(parents=True,exist_ok=True)
SOURCE=Path('/mnt/data/NOVA-F15-14-3D-Pythagoras-and-Trigonometry.html').read_text()
checks=[]
def ck(name,ok,detail=''):
 checks.append(dict(name=name,pass_=bool(ok),detail=str(detail)))
 print(('PASS ' if ok else 'FAIL ')+name+((' :: '+str(detail)[:160]) if not ok else ''))
def mid(b):return (b['x']+b['width']/2,b['y']+b['height']/2)
def scr(pg,x,y):return pg.evaluate('''p=>{const m=document.querySelector('#F15-14 svg.f1514-svg').getScreenCTM();return{x:m.a*p[0]+m.c*p[1]+m.e,y:m.b*p[0]+m.d*p[1]+m.f};}''',[x,y])
def projected(st,width,L=None,W=None,H=None):
 l=st['L'] if L is None else L;w=st['W'] if W is None else W;h=st['H'] if H is None else H
 z=st.get('zoom',1)
 x0,y0=(157,365) if width==380 else (181,424)
 UX,UY,VX,VY,ZZ=(22,2.7,-15,-12,-24) if width==380 else (25,3.2,-17,-14,-27)
 return x0+(UX*l+VX*w)*z,y0+(UY*l+VY*w+ZZ*h)*z
def drag(pg,loc,xy,steps=1):
 loc.scroll_into_view_if_needed(timeout=2500)
 bb=loc.bounding_box();a,b=mid(bb);screen=scr(pg,*xy)
 pg.mouse.move(a,b);pg.mouse.down();pg.mouse.move(screen['x'],screen['y'],steps=steps);pg.mouse.up();pg.wait_for_timeout(180)
def state(pg):return pg.evaluate('NOVA_F15_14_CONFIG._explore.state()')
with sync_playwright() as playwright:
 browser=playwright.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'])
 for width in [380,1280]:
  page=browser.new_page(viewport={'width':width,'height':900},reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(SOURCE,wait_until='domcontentloaded',timeout=60000)
  ck(f'{width} shared core loaded',bool(page.evaluate('NOVA && NOVA.version')))
  ck(f'{width} only one stage mascot',page.locator('#F15-14 .nova-stage .nv-dock').count()==1)
  page.locator('.nova-tabs button').nth(2).click()
  ck(f'{width} explore svg',page.locator('#F15-14 .f1514-svg').count()==1)
  # all presets and exact Pythagoras invariant
  for name in ['cuboid-345','space-862','base-869','gcse-angle','gcse-short','gcse-room','gcse-cube','extension']:
   try:
    page.evaluate('(name)=>NOVA_F15_14_CONFIG._explore.select(name)',name)
    st=state(page);c=page.evaluate('NOVA_F15_14_MATH.calc(NOVA_F15_14_CONFIG._explore.state())')
    good=abs(c['base']**2-(c['L']**2+c['W']**2))<1e-8 and abs(c['space']**2-(c['base']**2+c['H']**2))<1e-8
    ck(f'{width} {name} two Pythagoras equations',good)
    ck(f'{width} {name} trig exact',abs(math.tan(math.radians(c['theta']))-c['H']/c['base'])<1e-9)
    ck(f'{width} {name} valid angles and dims',0<c['theta']<90 and all(st[k]>=st['ranges'][k][0] and st[k]<=st['ranges'][k][1] for k in 'LWH'))
    ck(f'{width} {name} draws stage',page.locator('#F15-14 .nova-stage .f1514-svg').count()==1)
   except Exception as e:ck(f'{width} {name} invariant',False,e)
  # actual pointer test, L W H on starter
  page.evaluate('NOVA_F15_14_CONFIG._explore.select("cuboid-345")')
  for key,val in [('L',6),('W',4),('H',6)]:
   try:
    st=state(page)
    loc=page.locator(f'[data-corner="{key}"]')
    L,W,H=st['L'],st['W'],st['H']
    if key=='L':u,v=projected(st,width,L=val,W=0,H=0)
    elif key=='W':u,v=projected(st,width,L=0,W=val,H=0)
    else:u,v=projected(st,width,L=0,W=0,H=val)
    drag(page,loc,(u,v),steps=1)
    ck(f'{width} real fast mouse {key} to {val}',state(page)[key]==val,state(page)[key])
    ck(f'{width} mouse drag released {key}',not page.evaluate('Boolean(NOVA.ui._drag)'))
   except Exception as e:ck(f'{width} drag {key}',False,e)
  # invalid drop should not strand or modify
  try:
   before=state(page)['L'];drag(page,page.locator('[data-corner="L"]'),(150,130))
   ck(f'{width} invalid drop preserves L',state(page)['L']==before)
   ck(f'{width} no stranded drag after invalid',not page.evaluate('Boolean(NOVA.ui._drag)'))
  except Exception as e:ck(f'{width} invalid drop',False,e)
  # Esc cancellation on drag
  try:
   loc=page.locator('[data-corner="H"]');loc.scroll_into_view_if_needed();b=loc.bounding_box();mx,my=mid(b);before=state(page)['H'];page.mouse.move(mx,my);page.mouse.down();page.mouse.move(mx+40,my-20,steps=2);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(150)
   ck(f'{width} Escape cancels corner drag',state(page)['H']==before and not page.evaluate('Boolean(NOVA.ui._drag)'))
  except Exception as e:ck(f'{width} Escape drag',False,e)
  # keyboard dimension
  try:
   page.evaluate('NOVA_F15_14_CONFIG._explore.select("cuboid-345")')
   loc=page.locator('[data-corner="L"]');loc.focus();old=state(page)['L'];page.keyboard.press('ArrowRight');page.wait_for_timeout(60)
   ck(f'{width} keyboard L increases',state(page)['L']==old+1)
  except Exception as e:ck(f'{width} keyboard L',False,e)
  # label mouse matching and removal
  for key in ['base','space','height']:
   try:
    page.evaluate('NOVA_F15_14_CONFIG._explore.select("cuboid-345")');st=state(page)
    A=projected(st,width,L=0,W=0,H=0);C=projected(st,width);G=projected(st,width); # manually anchors
    B=projected(st,width,L=st['L'],W=0,H=0)
    D=projected(st,width,L=0,W=st['W'],H=0)
    CC=projected(st,width,L=st['L'],W=st['W'],H=0)
    GG=projected(st,width,L=st['L'],W=st['W'],H=st['H'])
    if key=='base':q=((A[0]+CC[0])/2-30,(A[1]+CC[1])/2-23)
    elif key=='space':q=((A[0]+GG[0])/2+30,(A[1]+GG[1])/2-22)
    else:q=((CC[0]+GG[0])/2+28,(CC[1]+GG[1])/2)
    drag(page,page.locator(f'[data-label="{key}"]'),q,steps=9)
    ck(f'{width} real mouse label {key} place',bool(state(page)['placed'].get(key)),state(page)['placed'])
    if state(page)['placed'].get(key):
     ty=505 if width==380 else 493; tx=14 if width==380 else 499;bw=126 if width==380 else 110
     xy=(tx+bw/2,ty+18)
     drag(page,page.locator(f'[data-label="{key}"]'),xy,steps=7)
     ck(f'{width} real mouse {key} removal',not state(page)['placed'].get(key),state(page)['placed'])
   except Exception as e:ck(f'{width} mouse label {key}',False,e)
  # keyboard label toggling
  try:
   page.evaluate('NOVA_F15_14_CONFIG._explore.select("cuboid-345")')
   loc=page.locator('[data-label="base"]');loc.focus();page.keyboard.press('Enter');ck(f'{width} keyboard label place',bool(state(page)['placed'].get('base')))
   loc=page.locator('[data-label="base"]');loc.focus();page.keyboard.press('Enter');ck(f'{width} keyboard label remove',not bool(state(page)['placed'].get('base')))
  except Exception as e:ck(f'{width} keyboard label',False,e)
  # challenge all tasks and check logic
  page.locator('.nova-tabs button').nth(3).click()
  qs=page.evaluate('NOVA_F15_14_CONFIG._questions')
  ck(f'{width} 12 challenge tasks',len(qs)==12)
  for i,q in enumerate(qs):
   try:
    answer=page.evaluate('(i)=>NOVA_F15_14_CONFIG._answer(NOVA_F15_14_CONFIG._questions[i])',i)
    accepted=page.evaluate('(a)=>NOVA_F15_14_CONFIG._check(NOVA_F15_14_CONFIG._questions[a.i],a.v)',{'i':i,'v':answer})
    wrong=page.evaluate('(a)=>NOVA_F15_14_CONFIG._check(NOVA_F15_14_CONFIG._questions[a.i],a.v)',{'i':i,'v':answer+14})
    ck(f'{width} question {i+1} correct',accepted[0] is True and math.isfinite(answer),accepted)
    ck(f'{width} question {i+1} incorrect rejected',wrong[0] is False,wrong)
   except Exception as e:ck(f'{width} question {i+1}',False,e)
  # user submission instead of internals
  try:
   inp=page.locator('#F15-14 .nova-panel input').first
   ans=page.evaluate('NOVA_F15_14_CONFIG._answer(NOVA_F15_14_CONFIG._questions[0])')
   inp.fill(str(ans));page.get_by_text('Check',exact=True).last.click(timeout=4000)
   txt=page.locator('#F15-14').inner_text()
   ck(f'{width} real challenge submit',('Correct' in txt or 'correct' in txt),txt[-190:])
  except Exception as e:ck(f'{width} challenge submit',False,e)
  ck(f'{width} no page errors',not errors,errors)
  page.close()
 browser.close()
(QA/'stress.json').write_text(json.dumps(checks,indent=2))
print('TOTAL:',sum(q['pass_'] for q in checks),'/',len(checks));print('FAILURES',[(q['name'],q['detail']) for q in checks if not q['pass_']][:10])
if not all(q['pass_'] for q in checks):raise SystemExit(1)
