# NOVA F15-14 — REVIEW ZIP
Standalone HTML in `engine/`. Open directly in Chrome, Edge or Firefox. All NOVA core assets are embedded. See QA-REPORT.md for checks and test scope. Review both viewport sizes and all four modes before owner signoff. No GitHub changes.
