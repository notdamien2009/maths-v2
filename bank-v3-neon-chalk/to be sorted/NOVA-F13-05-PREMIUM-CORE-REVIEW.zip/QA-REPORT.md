# F13-05 Cube-stacking Volume — Browser QA Report

**Build:** Premium NOVA core review · F13-05 · October 2026
**Automated checks:** **135/135 passed**, 0 failed.
**Environment:** Chromium with Playwright, viewports 1280×980 and 380×980.

## Checked

- Byte-identical official embedded NOVA runtime and unchanged original base stage stylesheet.
- Actual embedded WebP cat helper art, NOVA Chalk font and neon shape primitives.
- One stage-contained mascot and one speech bubble, unchanged stage background and no horizontal overflow.
- Ten Watch teaching steps, Guided, Explore and Challenge at both screen widths.
- Nine presets with exact 3D cube counts, from 1 to 18 cubes.
- Layer-reveal, hidden ghost outline and individual layer inspection; cube total remains correct if upper layers are hidden.
- Real pointer click, rapid held drag across multiple cells, one undo record per drag, pointer release, undo/redo, add/remove tool.
- Keyboard arrows, Enter, Delete and mode switching.
- Three mathematics challenges with wrong-total, right-total/wrong-layers and correct-model feedback.
- No unhandled JavaScript errors at either tested viewport.

## Important scope note

This automated QA verifies observed browser behaviour and mathematical states; it does **not** grant visual GOLD approval. The user should review screenshots and the interactive HTML.

## Re-run

`python qa.py` in an environment with Playwright and Chromium installed. Change hard-coded project paths if copying to a different workspace.
