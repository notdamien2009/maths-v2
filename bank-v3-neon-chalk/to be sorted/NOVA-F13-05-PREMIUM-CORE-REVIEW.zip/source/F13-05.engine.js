/* NOVA F13-05 · CUBE-STACKING VOLUME. Original F0/F1/F12 core, fonts, mascot, and stage are not modified. */
var NOVA_F13_05_CONFIG={startMode:'watch',preset:'cuboid',presets:{one:'One unit cube',row:'Four-cube row',base:'3 × 2 base layer',tower:'Four-high tower',cuboid:'3 × 2 × 3 cuboid',cube:'2 × 2 × 2 cube',stairs:'Stepped stack',corner:'Corner construction',mixed:'Uneven layers'}};
(function(){'use strict';
var h=NOVA.h,S=NOVA.svg,F=NOVA.f12,C=NOVA_F13_05_CONFIG,EN='F13-05',N=4,MAX=4;
var K={cyan:'#30e5ff',orange:'#ffb570',purple:'#bca0ff',green:'#65f1b9',gold:'#ffd979'};
function blank(){return Array.from({length:N},function(){return [0,0,0,0];});}
function make(v){var g=blank();v.forEach(function(c){g[c[0]][c[1]]=c[2];});return g;}
function fillRect(x0,y0,l,w,d){var v=[];for(var x=x0;x<x0+l;x++)for(var y=y0;y<y0+w;y++)v.push([x,y,d]);return make(v);}
function model(name){switch(name){
 case 'one':return make([[1,1,1]]);
 case 'row':return fillRect(0,1,4,1,1);
 case 'base':return fillRect(1,1,3,2,1);
 case 'tower':return make([[1,1,4]]);
 case 'cuboid':return fillRect(1,1,3,2,3);
 case 'cube':return fillRect(1,1,2,2,2);
 case 'stairs':return make([[0,2,1],[1,2,2],[2,2,3]]);
 case 'corner':return make([[1,1,2],[1,2,2],[2,1,1]]);
 case 'mixed':return make([[0,1,1],[1,1,2],[2,1,3],[2,2,2],[1,2,1]]);
 default:return blank();}}
function clone(g){return g.map(function(a){return a.slice();});}
function total(g){return g.reduce(function(s,a){return s+a.reduce(function(q,v){return q+v;},0);},0);}
function maxHeight(g){return Math.max.apply(null,[0].concat.apply([0],g));}
function area(g){return g.flat().filter(Boolean).length;}
function inLayer(g,k){return g.flat().filter(function(v){return v>=k;}).length;}
function perLayers(g){return Array.from({length:MAX},function(_,i){return inLayer(g,i+1);});}
function cuboid(g){var pts=[];for(var x=0;x<N;x++)for(var y=0;y<N;y++)if(g[x][y])pts.push([x,y,g[x][y]]);
 if(!pts.length)return null;
 var xs=pts.map(function(a){return a[0];}),ys=pts.map(function(a){return a[1];}),hh=pts[0][2],loX=Math.min.apply(null,xs),hiX=Math.max.apply(null,xs),loY=Math.min.apply(null,ys),hiY=Math.max.apply(null,ys),L=hiX-loX+1,W=hiY-loY+1;
 if(pts.length!==L*W||pts.some(function(p){return p[2]!==hh;}))return null;
 return {length:L,width:W,height:hh,area:L*W,volume:L*W*hh,loX:loX,loY:loY};}
function state(p){var g=model(p||'cuboid');return {grid:g,preset:p||'cuboid',focus:[1,1],tool:'add',showGhost:false,showNumbers:false,reveal:MAX,selectedLayer:1,viewMode:'all',drag:null,undo:[],redo:[],paintOnChange:null,challengeTarget:null,_svg:null};}
function el(p,tag,attrs){return S.el(tag,attrs,p);}
function path(pts){return 'M'+pts.map(function(p){return p[0].toFixed(2)+','+p[1].toFixed(2);}).join('L')+'Z';}
function P(W,H,g){var mobile=W<520,u=mobile?47:59,OX=W/2,OY=mobile?269:292;return {W:W,H:H,u:u,point:function(x,y,z){return [OX+(x-y)*u*.8660254,OY+(x+y-4)*u*.5-z*u];}};}
function txt(g,x,y,s,role,size,anchor){return NOVA.chalkText(g,x,y,String(s),{role:role||'given',size:size||16,anchor:anchor||'middle'});}
function neon(g,pts,role,width){return NOVA.neonPath(g,path(pts),{role:role||'op',width:width||2.0});}
function grad(sv){var defs=sv.querySelector('defs')||el(sv,'defs',{}),data=[['top','#d8ffff','#438bab','#082d4e'],['x','#b9b6ff','#665fbc','#21175b'],['y','#fff2cd','#bb6b49','#4c2848']];
 data.forEach(function(p){var gr=el(defs,'linearGradient',{id:'f13v-'+p[0],x1:'5%',y1:'0%',x2:'95%',y2:'95%'});[[0,p[1],.91],[.36,p[2],.79],[1,p[3],.96]].forEach(function(z){el(gr,'stop',{offset:z[0],'stop-color':z[1],'stop-opacity':z[2]});});});
 var halo=el(defs,'radialGradient',{id:'f13v-halo'});el(halo,'stop',{offset:0,'stop-color':'#1392af','stop-opacity':.32});el(halo,'stop',{offset:1,'stop-color':'#1392af','stop-opacity':0});}
function polyContains(px,py,ps){var yes=false;for(var i=0,j=ps.length-1;i<ps.length;j=i++){var a=ps[i],b=ps[j];if(((a[1]>py)!==(b[1]>py))&&(px<(b[0]-a[0])*(py-a[1])/(b[1]-a[1])+a[0]))yes=!yes;}return yes;}
function ptsTop(p,x,y,z){return [p.point(x,y,z),p.point(x+1,y,z),p.point(x+1,y+1,z),p.point(x,y+1,z)];}
function floor(root,p,st){var mesh=el(root,'g',{opacity:.65,'aria-hidden':'true'});
 for(var t=0;t<=N;t++){var a=p.point(t,0,0),b=p.point(t,N,0),c=p.point(0,t,0),d=p.point(N,t,0);
  [ [a,b], [c,d] ].forEach(function(q){el(mesh,'path',{d:'M'+q[0][0]+','+q[0][1]+'L'+q[1][0]+','+q[1][1],stroke:'#2a829f',opacity:t===0||t===N?.55:.33,'stroke-width':1.25,fill:'none','stroke-dasharray':'4 9'});});}
 for(var x=0;x<=N;x++)for(var y=0;y<=N;y++){var a=p.point(x,y,0);el(mesh,'circle',{cx:a[0],cy:a[1],r:1.9,fill:'#9bdaf1',opacity:.6});}
 var bg=el(root,'g',{'aria-hidden':'true'});el(bg,'ellipse',{cx:p.W/2,cy:p.H*.44,rx:p.W*.36,ry:p.H*.43,fill:'url(#f13v-halo)'});root.insertBefore(bg,mesh);
 }
function faces(root,p,st){var cubes=[],lim=st.reveal;
 for(var x=0;x<N;x++)for(var y=0;y<N;y++)for(var z=0;z<st.grid[x][y];z++)cubes.push([x,y,z]);
 cubes.sort(function(a,b){return (a[0]+a[1]+a[2]*.7)-(b[0]+b[1]+b[2]*.7);});
 var grp=el(root,'g',{'data-maths':'unit-cube-geometry',class:'f13-v-cubes'});
 cubes.forEach(function(c){var x=c[0],y=c[1],z=c[2],shown=z<lim,ghost=!shown&&st.showGhost;if(!shown&&!ghost)return;
 var cell=el(grp,'g',{'data-cube':x+','+y+','+z,class:'f13-v-solid-cube',opacity:ghost?.19:1}),f=st.focus[0]===x&&st.focus[1]===y,top=z===st.grid[x][y]-1||z===lim-1,
 xFace=x===N-1||st.grid[x+1][y]<=z,yFace=y===N-1||st.grid[x][y+1]<=z;
 var A=p.point(x,y,z),B=p.point(x+1,y,z),D=p.point(x,y+1,z),Q=p.point(x+1,y+1,z),E=p.point(x,y,z+1),G=p.point(x+1,y+1,z+1),F=p.point(x+1,y,z+1),H=p.point(x,y+1,z+1);
 function patch(v,k){var gg=el(cell,'g',{class:'f13-v-face','data-side':k});el(gg,'path',{d:path(v),fill:ghost?'none':'url(#f13v-'+k+')',stroke:'none'});neon(gg,v,k==='top'?'op':k==='x'?'support':'focus',f?2.7:2.0);}
 if(xFace)patch([B,Q,G,F],'x');if(yFace)patch([D,Q,G,H],'y');if(top)patch([E,F,G,H],'top');
 if(shown&&top&&st.showNumbers){var q=ptsTop(p,x,y,z+1),m=[q.reduce(function(t,v){return t+v[0];},0)/4,q.reduce(function(t,v){return t+v[1];},0)/4];txt(cell,m[0],m[1]+6,z+1,'given',17);}
 });
 // Persistent selection highlight on the top of a column, even if that column is empty.
 var fx=st.focus[0],fy=st.focus[1],fz=Math.min(st.grid[fx][fy],lim),q=ptsTop(p,fx,fy,fz),sel=el(root,'g',{'aria-hidden':'true'});el(sel,'path',{d:path(q),fill:'#ffd979',opacity:.10,stroke:'#ffd979','stroke-width':2.5,'stroke-dasharray':'5 6'});
 q.forEach(function(a){el(sel,'circle',{cx:a[0],cy:a[1],r:2.8,fill:'#ffe6ac'});});
 }
function card(root,x,y,w,h,col,name,highlight){var g=el(root,'g',{class:'f13-v-card','data-card':name});el(g,'rect',{x:x,y:y,width:w,height:h,rx:13,fill:'#07162d',stroke:highlight?'#71e7ff':col,'stroke-width':highlight?2:1.4,'stroke-opacity':highlight?1:.56});el(g,'path',{d:'M'+(x+14)+','+(y+3)+'H'+(x+w-14),stroke:col,'stroke-width':2.1,opacity:.25});return g;}
function sliceCard(root,W,st){var mobile=W<520,x=mobile?22:130,y=mobile?410:458,w=mobile?180:252,height=mobile?138:135,c=card(root,x,y,w,height,K.cyan,'slice',true),L=Math.max(1,Math.min(MAX,st.selectedLayer)),n=inLayer(st.grid,L),box=mobile?20:20,ox=x+(w-4*box)/2,oy=y+44;
 txt(c,x+w/2,y+23,'LAYER '+L,'op',mobile?20:17);
 for(var yy=0;yy<N;yy++)for(var xx=0;xx<N;xx++){var on=st.grid[xx][yy]>=L;el(c,'rect',{x:ox+xx*box,y:oy+yy*box,width:box-2.5,height:box-2.5,rx:2,fill:on?'#134c61':'#071b32',stroke:on?K.cyan:'#244763','stroke-width':1.2});if(on)el(c,'rect',{x:ox+xx*box+2,y:oy+yy*box+2,width:box-6.5,height:4,rx:1,fill:'#8ffcff',opacity:.5});}
 txt(c,x+w/2,y+height-10,n+' cube'+(n===1?'':'s'),'given',mobile?17:14);
 var target=el(c,'rect',{x:ox,y:oy,width:box*N,height:box*N,fill:'transparent',class:'f13-v-slice-hit','data-slice-hit':'1',style:'cursor:crosshair;pointer-events:all'});
 return {x:ox,y:oy,cell:box,w:box*N,h:box*N};}
function eqCard(root,W,st){var mobile=W<520,x=mobile?218:402,y=mobile?410:458,w=mobile?180:252,height=mobile?138:135,c=card(root,x,y,w,height,K.gold,'calculation',false),g=st.grid,cb=cuboid(g),a=perLayers(g),V=total(g);txt(c,x+w/2,y+23,'VOLUME','focus',mobile?20:17);
 if(cb){txt(c,x+w/2,y+58,cb.length+' × '+cb.width+' × '+cb.height,'given',mobile?22:26);txt(c,x+w/2,y+85,'= '+V+' unit cubes','result',mobile?17:18);txt(c,x+w/2,y+height-12,cb.area+' per layer × '+cb.height,'given',mobile?15:13);}
 else {var formula=a.filter(function(x){return x>0;}).join(' + ')||'0';txt(c,x+w/2,y+58,formula,'given',mobile?17:23);txt(c,x+w/2,y+85,'= '+V+' unit cubes','result',mobile?17:18);txt(c,x+w/2,y+height-12,'Add cubes in each layer','given',mobile?15:12.5);}
 }
function renderStage(stage,st,message,pose,interactive){if(stage._f13Cleanup)stage._f13Cleanup();stage.replaceChildren();
 var g=st.grid,Hmax=maxHeight(g),c=cuboid(g),M=window.innerWidth<=580,W=M?420:780,H=M?555:605;
 NOVA.cap(stage,'CUBE-STACKING VOLUME · '+(C.presets[st.preset]||'YOUR SOLID'),interactive?'build with unit cubes':'count each layer');
 var sv=S.root(W,H,'NOVA interactive isometric stack of unit cubes, a selected horizontal layer and the total volume calculation.');sv.classList.add('f13-v-svg');sv.setAttribute('role','group');sv.setAttribute('tabindex','0');sv.setAttribute('aria-label','Interactive unit-cube volume drawing. Arrow keys move the gold target, Enter adds a cube, Delete removes one.');stage.appendChild(sv);grad(sv);
 var root=el(sv,'g',{'data-volume-root':'true'}),p=P(W,H,g),hit={};
 function draw(){root.replaceChildren();p=P(W,H,st.grid);floor(root,p,st);faces(root,p,st);hit=sliceCard(root,W,st);eqCard(root,W,st);
  var tile=stage.querySelectorAll('.f12-strip .nv-ntile .mt');[total(st.grid),inLayer(st.grid,Math.min(MAX,st.selectedLayer)),maxHeight(st.grid)].forEach(function(v,i){if(tile[i])tile[i].textContent=String(v);});sv.f13Hit=hit;}
 draw();F.strip(stage,[['unit cubes',total(g),'given'],['this layer',inLayer(g,st.selectedLayer),'focus'],['high',Hmax,'result']]);NOVA.scene.helperStrip(stage,pose||'explain',message||'Count how many cubes are in each horizontal layer.');
 if(interactive){var ac=new AbortController(),queued=false;stage._f13Cleanup=function(){ac.abort();st.drag=null;sv.classList.remove('f13-v-drag');};
  function schedule(){if(queued)return;queued=true;requestAnimationFrame(function(){queued=false;if(stage.contains(sv))draw();});}
  function coords(e){var b=sv.getBoundingClientRect();return [(e.clientX-b.left)*W/b.width,(e.clientY-b.top)*H/b.height];}
  function locate(q){if(q[0]>=hit.x&&q[0]<hit.x+hit.w&&q[1]>=hit.y&&q[1]<hit.y+hit.h)return [Math.floor((q[0]-hit.x)/hit.cell),Math.floor((q[1]-hit.y)/hit.cell)];
   var cand=[];for(var x=0;x<N;x++)for(var y=0;y<N;y++){var top=Math.min(st.grid[x][y],st.reveal),pts=ptsTop(p,x,y,top);if(polyContains(q[0],q[1],pts))cand.push([x,y,top]);}
   cand.sort(function(a,b){return b[2]-a[2]||b[0]+b[1]-a[0]-a[1];});return cand.length?[cand[0][0],cand[0][1]]:null;}
  function edit(x,y,source){var old=st.grid[x][y],next=st.tool==='remove'?Math.max(0,old-1):Math.min(MAX,old+1);if(next===old)return false;
   if(!st.drag||!st.drag.saved){st.undo.push(clone(st.grid));if(st.undo.length>60)st.undo.shift();st.redo=[];if(st.drag)st.drag.saved=true;}
   st.grid[x][y]=next;st.focus=[x,y];st.preset='own';if(st.selectedLayer>MAX)st.selectedLayer=MAX;NOVA.events.emit('value',{engine:EN,control:'stack',value:[x,y,next],source:source});if(st.paintOnChange)st.paintOnChange();schedule();return true;}
  function apply(q,from){if(!st.drag)return;var k=locate(q);if(!k)return;var key=k.join(',');if(st.drag.seen.has(key))return;st.drag.seen.add(key);edit(k[0],k[1],from);}
  sv.addEventListener('pointerdown',function(e){if(e.pointerType==='mouse'&&e.button!==0)return;var q=coords(e);if(!locate(q))return;st.drag={id:e.pointerId,last:q,seen:new Set(),saved:false};try{sv.setPointerCapture(e.pointerId);}catch(x){}sv.classList.add('f13-v-drag');apply(q,'tap');e.preventDefault();},{signal:ac.signal});
  sv.addEventListener('pointermove',function(e){if(!st.drag||st.drag.id!==e.pointerId)return;var q=coords(e),r=st.drag.last,d=Math.hypot(q[0]-r[0],q[1]-r[1]),steps=Math.min(160,Math.max(1,Math.ceil(d/5)));
   for(var j=1;j<=steps;j++)apply([r[0]+(q[0]-r[0])*j/steps,r[1]+(q[1]-r[1])*j/steps],'drag');st.drag.last=q;e.preventDefault();},{signal:ac.signal});
  function end(e){if(!st.drag||st.drag.id!==e.pointerId)return;st.drag=null;sv.classList.remove('f13-v-drag');try{if(sv.hasPointerCapture(e.pointerId))sv.releasePointerCapture(e.pointerId);}catch(x){}schedule();}
  ['pointerup','pointercancel'].forEach(function(k){sv.addEventListener(k,end,{signal:ac.signal});});sv.addEventListener('lostpointercapture',function(e){if(st.drag&&st.drag.id===e.pointerId){st.drag=null;sv.classList.remove('f13-v-drag');}},{signal:ac.signal});
  sv.addEventListener('keydown',function(e){var x=st.focus[0],y=st.focus[1];if(e.key==='ArrowLeft')x=Math.max(0,x-1);if(e.key==='ArrowRight')x=Math.min(3,x+1);if(e.key==='ArrowUp')y=Math.max(0,y-1);if(e.key==='ArrowDown')y=Math.min(3,y+1);
   if(e.key.startsWith('Arrow')){e.preventDefault();st.focus=[x,y];schedule();return;}
   if(['Enter',' ','Backspace','Delete'].indexOf(e.key)>=0){e.preventDefault();var old=st.tool;st.tool=e.key==='Delete'||e.key==='Backspace'?'remove':'add';st.drag=null;edit(x,y,'keyboard');st.tool=old;}
   if(e.key==='Escape'){st.drag=null;sv.classList.remove('f13-v-drag');}},{signal:ac.signal});window.addEventListener('blur',function(){st.drag=null;sv.classList.remove('f13-v-drag');},{signal:ac.signal});
 }
 sv.f13Draw=draw;st._svg=sv;return sv;
}
var STEPS=[
 {name:'A cube is one unit of volume',preset:'one',layer:1,reveal:1,focus:[1,1],pose:'explain',narration:'This is a unit cube. It takes up one cubic unit of space. A cube with edges one centimetre long has a volume of one cubic centimetre.',prompt:'What does one unit cube measure?',},
 {name:'Build a horizontal row',preset:'row',layer:1,reveal:1,focus:[1,1],pose:'point-right',narration:'A straight row of four unit cubes has a volume of four cubic units. We can count each one.',prompt:'How many cubes are in the row?'},
 {name:'Make a base layer',preset:'base',layer:1,reveal:1,focus:[1,1],pose:'explain',narration:'Now arrange three cubes along the length and two across the width. Each complete layer has six cubes, because three times two equals six.',prompt:'Why are there six cubes in this layer?'},
 {name:'One layer is an area',preset:'cuboid',layer:1,reveal:1,focus:[1,1],pose:'think',narration:'The first layer is three by two, so it has six cubes. That is the base area measured in square units. We will need the height to calculate volume.',prompt:'Is the base area the volume yet?'},
 {name:'Stack a second layer',preset:'cuboid',layer:2,reveal:2,focus:[1,1],pose:'point-right',narration:'Add a second identical layer above the first. Now six plus six makes twelve unit cubes. That is two layers of six.',prompt:'What does the second layer add?'},
 {name:'Build three layers',preset:'cuboid',layer:3,reveal:3,focus:[1,1],pose:'celebrate',narration:'The third layer adds another six. Three layers of six cubes give eighteen cubic units altogether.',prompt:'Count the layers to check eighteen.'},
 {name:'Link stacking to a formula',preset:'cuboid',layer:3,reveal:4,focus:[2,2],pose:'explain',narration:'For a cuboid, multiply its length by its width by its height. Three times two times three equals eighteen cubic units.',prompt:'Which numbers count the cubes in a layer and the number of layers?'},
 {name:'A two-by-two-by-two cube',preset:'cube',layer:2,reveal:4,focus:[1,1],pose:'point-right',narration:'This cube has two rows and two columns in every layer. There are four cubes per layer and two layers, making eight unit cubes.',prompt:'How many cubes are hidden by the visible faces?'},
 {name:'Not every solid has equal layers',preset:'stairs',layer:2,reveal:4,focus:[1,2],pose:'think',narration:'This stepped solid has three cubes on the bottom, two on the second layer, and one on the third. Add three, two and one to find six cubic units. The cuboid formula is not suitable for this stepped shape.',prompt:'Why is length times width times height misleading here?'},
 {name:'Volume is space, not surface',preset:'mixed',layer:1,reveal:4,focus:[2,1],pose:'explain',narration:'Count the solid unit cubes, including hidden cubes inside the stack. Volume measures the space filled, not the number of visible faces or surface squares.',prompt:'What should you count when a cube is hidden?'}
];
function watchState(z){var st=state(z.preset);st.selectedLayer=z.layer;st.reveal=z.reveal;st.focus=z.focus.slice();return st;}
var def={id:EN,title:'Cube-stacking volume',config:C,steps:STEPS,
 alt:'Neon-glass isometric unit-cube construction with a selected cross-section layer and volume equation. Every cube represents one cubic unit.',
 staticAlt:'Count cubic units: a cuboid three cubes long, two cubes wide, three cubes high contains three times two times three equals eighteen cubes. For an uneven stack, add the number of cubes in each horizontal layer.',
 render:function(i,stage){var z=STEPS[i];renderStage(stage,watchState(z),z.name,z.pose,false);},
 exploreIntro:'Build with unit cubes. Move across the slice plan or tap a top face to add a cube. Reveal the layers to check the volume.',
 explore:function(panel,stage,api){var st=state('cuboid');if(api.onCleanup)api.onCleanup(function(){if(stage._f13Cleanup)stage._f13Cleanup();});
  var selector=h('select',{class:'nova-input','aria-label':'Choose a cube volume construction'});Object.keys(C.presets).forEach(function(k){selector.appendChild(h('option',{value:k,text:C.presets[k]}));});selector.value='cuboid';
  function paint(msg){renderStage(stage,st,msg||'Try another layer. Count all cubes, including hidden cubes.','explain',true);}
  selector.onchange=function(){st.grid=model(selector.value);st.preset=selector.value;st.undo=[];st.redo=[];st.focus=[1,1];st.reveal=MAX;st.selectedLayer=1;paint();NOVA.events.emit('value',{engine:EN,control:'preset',value:st.preset});};
  panel.appendChild(h('div',{class:'pr-row'},[h('label',{},['CONSTRUCTION ',selector])]));
  var bt={},toolRow=h('div',{class:'pr-row'});[['add','＋ Add cube'],['remove','− Remove cube']].forEach(function(t){var b=h('button',{class:'nova-btn'+(st.tool===t[0]?' primary':''),text:t[1],onclick:function(){st.tool=t[0];Object.keys(bt).forEach(function(k){bt[k].classList.toggle('primary',k===st.tool);});}});bt[t[0]]=b;toolRow.appendChild(b);});panel.appendChild(toolRow);
  function undo(){if(!st.undo.length)return;st.redo.push(clone(st.grid));st.grid=st.undo.pop();paint();}function redo(){if(!st.redo.length)return;st.undo.push(clone(st.grid));st.grid=st.redo.pop();paint();}
  panel.appendChild(h('div',{class:'pr-row'},[
   h('button',{class:'nova-btn ghost',text:'↶ Undo',onclick:undo}),h('button',{class:'nova-btn ghost',text:'↷ Redo',onclick:redo}),
   h('button',{class:'nova-btn ghost',text:'Clear',onclick:function(){st.undo.push(clone(st.grid));st.grid=blank();st.redo=[];st.focus=[1,1];st.preset='own';paint('A clean workspace. Start stacking unit cubes.');}}),
   h('button',{class:'nova-btn ghost',text:'Reset',onclick:function(){st.grid=model(selector.value);st.undo=[];st.redo=[];st.focus=[1,1];paint();}})
  ]));
  var row=h('div',{class:'pr-row'}),label=h('label',{class:'f13-v-sliderlabel'},['SHOW LAYERS ']),slider=h('input',{type:'range',min:'0',max:'4',step:'1',value:'4','aria-label':'Reveal first N layers'}),shown=h('span',{class:'f13-v-output',text:'ALL'});label.appendChild(slider);label.appendChild(shown);row.appendChild(label);panel.appendChild(row);
  slider.oninput=function(){st.reveal=+slider.value;shown.textContent=st.reveal===4?'ALL':String(st.reveal);paint('The faded or hidden layer is still part of the total volume.');};
  var layerLabel=h('label',{class:'f13-v-sliderlabel'},['INSPECT LAYER ']),layerSlider=h('input',{type:'range',min:'1',max:'4',step:'1',value:'1','aria-label':'Inspect layer number'}),layerOut=h('span',{class:'f13-v-output',text:'1'});layerLabel.appendChild(layerSlider);layerLabel.appendChild(layerOut);panel.appendChild(h('div',{class:'pr-row'},[layerLabel]));
  layerSlider.oninput=function(){st.selectedLayer=+layerSlider.value;layerOut.textContent=String(st.selectedLayer);paint('Every square lit in the slice is one unit cube on this level.');};
  var checks=h('div',{class:'pr-row'});[['showGhost','Outline hidden upper layers'],['showNumbers','Number the top faces']].forEach(function(t){var input=h('input',{type:'checkbox','aria-label':t[1]});input.checked=st[t[0]];input.onchange=function(){st[t[0]]=input.checked;paint();};checks.appendChild(h('label',{class:'f13-v-check'},[input,' '+t[1]]));});panel.appendChild(checks);
  panel.appendChild(h('p',{class:'f13-v-help',text:'Tap a cube top or a square in the layer plan to add to that column (up to four high). Drag across the layer plan to fill several columns. Focus the drawing: arrow keys move the gold cursor, Enter adds and Delete removes. The total is the number of solid cubes, not the number of visible faces.'}));
  paint();C._explore={state:st,preset:function(k){selector.value=k;selector.onchange();},undo:undo,redo:redo,clear:function(){st.grid=blank();paint();},draw:paint};
 },
 challenge:function(panel,api,stage){var tasks=[
  {name:'A cube with 8 units',target:fillRect(1,1,2,2,2),q:'Build a solid 2 cubes long, 2 cubes wide, and 2 cubes high. The volume must be 8 cubic units.',hint:'Start with a 2 by 2 square of cubes, then stack a second cube onto each column.'},
  {name:'A cuboid with 12 units',target:fillRect(1,1,3,2,2),q:'Build a cuboid that is 3 cubes long, 2 cubes wide, and 2 cubes high. How many unit cubes does it contain?',hint:'There should be six cubes in each layer, and you need two equal layers.'},
  {name:'Six cubes, unequal layers',target:make([[0,2,1],[1,2,2],[2,2,3]]),q:'Make a staircase with 3 cubes on the bottom layer, 2 on the second, and 1 on the third, rising left to right. Its volume is 6 cubic units.',hint:'Build three neighbouring columns at heights one, two and three, starting from the first three cells in the second-back row.'}
 ];
 var st=state('one'),k=0,qp=h('p',{class:'pr-task'}),prog=h('span',{class:'f13-v-progress',text:''});
 function verdict(a,b){var V=total(a),T=total(b);if(V!==T)return 'Volume does not match. Count all the cubes, including those behind other cubes. You have '+V+' but need '+T+'.';
  var layers=perLayers(a),targetLayers=perLayers(b);if(layers.some(function(n,i){return n!==targetLayers[i];}))return 'The total is right, but the layers do not match. Look at how many cubes are in each horizontal layer.';
  return 'The layer counts match, but the shape is arranged differently. Check the length, width and position of each column.';}
 function load(i){k=i;st.grid=blank();st.preset='own';st.focus=[1,1];st.tool='add';st.undo=[];st.redo=[];st.reveal=MAX;st.selectedLayer=1;st.challengeTarget=tasks[i].target;
  qp.textContent=(k+1)+' / 3 · '+tasks[k].q;st.paintOnChange=function(){prog.textContent=total(st.grid)+' / '+total(tasks[k].target)+' cubic units';};st.paintOnChange();renderStage(stage,st,'Build the named solid. Count every cube in every layer.','think',true);}
 function check(){return st.grid.every(function(row,x){return row.every(function(v,y){return v===tasks[k].target[x][y];});});}
 panel.appendChild(qp);panel.appendChild(h('div',{class:'pr-row'},[
  h('button',{class:'nova-btn primary',text:'Check my volume model',onclick:function(){var ok=check();api.check(ok,ok?'Correct. You built the exact stack and counted all the hidden and visible unit cubes.':verdict(st.grid,tasks[k].target),{task:k,total:total(st.grid),expected:total(tasks[k].target),layers:perLayers(st.grid)});
   if(ok&&k<tasks.length-1){var t=setTimeout(function(){load(k+1);},1050);if(api.onCleanup)api.onCleanup(function(){clearTimeout(t);});}}}),
  h('button',{class:'nova-btn ghost',text:'Hint',onclick:function(){api.hint(tasks[k].hint);}}),
  h('button',{class:'nova-btn ghost',text:'Clear model',onclick:function(){st.grid=blank();st.undo=[];st.redo=[];st.focus=[1,1];st.paintOnChange();renderStage(stage,st,'Try again from an empty base.','think',true);}}),prog
 ]));
 panel.appendChild(h('p',{class:'f13-v-help',text:'Tap the small layer-plan squares repeatedly to build up a column, or add cubes on top of existing cubes. Arrow keys move the gold target; Enter adds a cube and Delete removes it. Every level is one cubic unit high.'}));
 load(0);C._challenge={state:st,task:function(){return k;},load:load,targets:tasks,check:check,feedback:verdict};
 }};
NOVA.bankMount({id:EN,num:'F13·05',title:'Cube-stacking volume',def:def,linked:['F0-01','F0-02','F0-03','F0-04','F0-05','F12-03','F13-01','F13-02','F13-03','F13-04'],spec:{
 purpose:'Make volume tangible by stacking solid unit cubes into horizontal layers, then derive volume = base area × height for a cuboid. Applicable to Y7-049, Y8-059 and Y8-060.',
 params:'4 × 4 editable footprint, up to 4 stacked unit cubes per column, live exact cube counts, layer cross-section, 3D neon shaded faces, volume equation and hidden-cube reasoning.',
 presets:'One cube, four-cube row, 3×2 base, tower, 3×2×3 cuboid, 2×2×2 cube, steps, corner and uneven layers.',
 steps:STEPS.map(function(z){return z.name;}).join(' → '),
 interactions:'Ten Watch/Guided teaching beats, Explore with drag-to-build, undo/redo, layer reveal/inspection, keyboard equivalent; Challenge 3 exact cube stack constructions.',
 traps:'Do not confuse volume with visible faces or surface area; hidden cubes still count; uneven stacks require sum of layer cubes; cubic units (not square units) for volume.',
 gcse:'Volume of cuboids and composite unit-cube solids, base area times perpendicular height, counting cross-sections and cubic measurement.'}});
var log=document.getElementById('log'),logEvent=function(e){log.textContent=new Date(e.time).toLocaleTimeString()+' '+e.type+' '+JSON.stringify(e.detail)+'\n'+log.textContent.slice(0,5000);};NOVA.events.history().forEach(logEvent);NOVA.events.on('*',logEvent);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
