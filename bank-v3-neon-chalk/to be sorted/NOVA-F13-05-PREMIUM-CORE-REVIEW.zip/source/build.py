from pathlib import Path
P=Path('/mnt/data/f13_05_premium')
base=Path('/mnt/data/F12-03-geoboard-builder(1).html').read_text()
a=base.index('<script>\n/* ===== F12-03 CONFIG:')
b=base.index('</script>',a)
engine=(P/'engine.js').read_text()
result=base[:a]+'<script>\n'+engine+'\n'+base[b:]
result=result.replace('<title>NOVA F12-03 · Geoboard builder</title>','<title>NOVA F13-05 · Premium Cube-Stacking Volume</title>')
result=result.replace('data-run="F12 · 2D shapes, perimeter and area · F12-03" data-title="Geoboard builder" data-sub="Stretch a band round pegs to make shapes, then read their area, perimeter and name."','data-run="F13 · 3D shapes, volume and surface area · F13-05" data-title="Cube-stacking volume" data-sub="Build 3D solids one unit cube at a time. Reveal horizontal layers and discover why length × width × height works."')
css='''
/* F13-05 component-only presentation. Above CSS is the unmodified official NOVA production shell. */
.f13-v-svg{display:block!important;width:100%!important;max-width:840px!important;height:auto!important;margin:1px auto 0!important;touch-action:none;user-select:none;cursor:crosshair;outline:none}
.f13-v-svg:focus-visible{outline:2px dashed var(--math-cyan);outline-offset:-3px;border-radius:10px}
.f13-v-svg.f13-v-drag{cursor:grabbing}
.nova-stage>.f13-v-svg{flex:0 0 auto}
.f13-v-check,.f13-v-sliderlabel{display:inline-flex;align-items:center;gap:8px;color:var(--v-ink);font:700 .88rem var(--nova-font-ui)}
.f13-v-sliderlabel{flex-wrap:wrap}.f13-v-sliderlabel input{width:min(190px,37vw);accent-color:var(--math-cyan)}
.f13-v-check input{accent-color:var(--math-cyan)}
.f13-v-output{font:800 1.12rem var(--nova-font-chalk-draw);color:var(--math-cyan)}
.f13-v-help{font:700 .89rem/1.5 var(--nova-font-ui);color:var(--v-ink);margin:8px 0}
.f13-v-progress{font:700 1.04rem var(--nova-font-chalk-draw);color:var(--math-cyan)}
.f13-v-svg [data-slice-hit]{cursor:crosshair}
@media(max-width:580px){.f13-v-help{font-size:.83rem}.f12-strip{gap:5px;padding-left:4px;padding-right:4px}.f12-strip .nv-ntile{padding:3px 9px;font-size:1.05rem}.f13-v-sliderlabel{font-size:.82rem}}
'''
result=result.replace('</style>\n</head>',css+'</style>\n</head>',1)
out=Path('/mnt/data/F13-05-Cube-Stacking-Volume-PREMIUM-CORE.html');out.write_text(result)
(P/'source'/'F13-05.engine.js').write_text(engine)
(P/'source'/'approved-F12-03-base.html').write_text(base)
(P/'source'/'build.py').write_text(Path(__file__).read_text())
print('CREATED',out,out.stat().st_size,'bytes')
