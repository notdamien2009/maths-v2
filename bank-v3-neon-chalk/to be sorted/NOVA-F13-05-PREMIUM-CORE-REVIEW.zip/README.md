# NOVA Maths V2 — F13-05 Cube-stacking Volume

**Status:** Premium-core review build for the user to visually inspect, not GOLD approval.
**GitHub:** No repository updates were made.

## Production lineage

- Exact embedded official NOVA inline JavaScript core from `F12-03-geoboard-builder(1).html` is retained byte-for-byte.
- The approved F12 stage CSS, NOVA neon drawing primitives, NOVA Chalk and official WebP helper pose pack remain intact.
- Only the F13-05 engine code, page title/header and an additive component-specific style block are new.
- Base source is included for reproducible local rebuilding. The original attached file was not modified.

## What it teaches

- One solid unit cube = one cubic unit of volume.
- Number of cubes in a rectangular layer = length × width.
- Cuboid volume = number per layer × number of layers = length × width × height.
- Irregular stacks require counting each horizontal layer; hidden cubes still contribute to volume.
- The difference between cubic volume and square surface/area.

## Learning and interaction

- **Watch / Guided:** 10 named teaching steps, including the 3×2×3 cuboid with 18 cubic units.
- **Explore:** Nine construction presets, add/remove a unit cube, drag paint across a layer plan, keyboard editing, undo/redo, layer-reveal and layer-inspect sliders, ghosted hidden layers, optional top-face numbers.
- **Challenge:** 2×2×2 unit cube, 3×2×2 cuboid, 3-2-1 stepped stack, with model-specific feedback.
- Each construction is represented as a 4×4 grid of columns with heights 0–4. No unsupported floating cubes.

## Contents

- `F13-05-Cube-Stacking-Volume-PREMIUM-CORE.html` — standalone page. Open in a modern browser.
- `source/F13-05.engine.js` — editable component-only JavaScript.
- `source/approved-F12-03-base.html` — unmodified reusable base, for local rebuild comparison.
- `source/build.py` — reproducible assembly script. Adjust input paths for your local computer.
- `qa.py`, `QA-RESULTS.json`, `QA-REPORT.md` — browser test code and evidence.
- `screenshots/` — desktop/mobile browser captures of the real page.

## QA and acceptance

135/135 checks passed in headless Chromium at 1280px and 380px.
Screenshots inspected for premium core visual continuity and official mascot docking.
User visual review required before GOLD designation.
