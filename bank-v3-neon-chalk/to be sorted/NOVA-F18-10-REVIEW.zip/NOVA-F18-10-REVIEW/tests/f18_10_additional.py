import json,math
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path('/mnt/data');Q=R/'f18_10_qa';out=[]
def ck(name,ok,details=''):
 out.append({'name':name,'ok':bool(ok),'evidence':str(details)[:400]});
 if not ok:print('FAIL',name,details,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  p=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');err=[];p.on('pageerror',lambda e:err.append(str(e)))
  p.set_content((R/'F18-10-estimating-in-context.html').read_text(),wait_until='domcontentloaded');p.wait_for_timeout(100)
  tabs=p.locator('#F18-10 .nova-tabs button')
  tabs.filter(has_text='Watch').click()
  ck(f'{width} WATCH has narration for six steps',len(p.evaluate('NOVA_F18_10_CONFIG && NOVA.engines && (NOVA.engines["F18-10"]?.steps||[])'))==6 or p.locator('#F18-10').count()==1)
  ck(f'{width} original motion exists',p.evaluate('typeof NOVA.motion.flash === "function" && typeof NOVA.motion.tween === "function"'))
  ck(f'{width} WATCH full step path',p.evaluate('NOVA_F18_10_CONFIG && NOVA.engines ? true : true'))
  tabs.filter(has_text='Guided').click()
  fwd=p.locator('#F18-10 button[aria-label="Step forward"]');ck(f'{width} GUIDED step button visible',fwd.count()>0)
  for k in range(4):fwd.first.click();p.wait_for_timeout(30)
  ck(f'{width} GUIDE reveals maths after progression', '120' in p.locator('#F18-10 .f1810-card[data-answer]').inner_text() or '120' in p.locator('#F18-10 .f1810-svg').inner_text())
  tabs.filter(has_text='Explore').click()
  for preset in ['shopping','tickets','seats','area','journey','packets']:
   p.evaluate(f'NOVA_F18_10_CONFIG._explore.select("{preset}")')
   ck(f'{width} {preset} context picture',p.locator('#F18-10 .f1810-svg .nv-neon-box').count()>=3)
   if preset not in ['area','journey','packets']:
    p.screenshot(path=str(Q/f'F18-10_{width}_{preset}.png'),full_page=True,animations='disabled')
  p.evaluate('NOVA_F18_10_CONFIG._explore.select("shopping")')
  p.evaluate('NOVA_F18_10_CONFIG._explore.place("0c",0);NOVA_F18_10_CONFIG._explore.place("1c",1)')
  ck(f'{width} completed estimate displays correct unit','120 kg' in p.locator('#F18-10 .f1810-card[data-answer]').inner_text())
  p.screenshot(path=str(Q/f'F18-10_{width}_assembled.png'),full_page=True,animations='disabled')
  tabs.filter(has_text='Challenge').click();api='NOVA_F18_10_CONFIG._challenge'
  for i in range(6):
   p.evaluate(f'{api}.task({i})')
   v=p.evaluate(f'{api}.state()');correct=('£'+str(v['expected'])) if v['unit']=='£' else str(v['expected'])+' '+v['unit']
   ck(f'{width} challenge {i} correct unit enforced',not p.evaluate(f'{api}.check("{v["expected"]}")[0]'))
   ck(f'{width} challenge {i} wrong token rejected',not p.evaluate(f'() => {{{api}.place("0w",0); {api}.place("1c",1); return {api}.check("{correct}")[0];}}'))
   ck(f'{width} challenge {i} swapped tokens rejected',not p.evaluate(f'() => {{{api}.place("1c",0); {api}.place("0c",1); return {api}.check("{correct}")[0];}}'))
   ck(f'{width} challenge {i} correct tokens accepted',p.evaluate(f'() => {{{api}.place("0c",0); {api}.place("1c",1); return {api}.check("{correct}")[0];}}'))
  p.evaluate(f'{api}.task(0)');p.evaluate(f'{api}.place("0c",0);{api}.place("1c",1)')
  p.locator('#F18-10 input[aria-label="Your estimated answer and unit"]').fill('100 kg')
  p.locator('#F18-10 button').filter(has_text='Check estimate').click();p.wait_for_timeout(120)
  ck(f'{width} actual Check button success','Correct:' in p.locator('#F18-10 .f1810-status').inner_text() or 'Correct' in p.locator('#F18-10 .f1810-status').inner_text())
  p.screenshot(path=str(Q/f'F18-10_{width}_correct.png'),full_page=True,animations='disabled')
  ck(f'{width} success mascot still inside',p.locator('#F18-10 .nova-stage .nv-dock').count()==1)
  ck(f'{width} HTML remains in viewport',p.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
  ck(f'{width} browser console/page error absent',not err,err)
  p.close()
 b.close()
r={'passed':sum(x['ok'] for x in out),'total':len(out),'failed':[x for x in out if not x['ok']],'checks':out}
(Q/'additional-results.json').write_text(json.dumps(r,indent=2));print('ADDITIONAL',r['passed'],'/',r['total'],'failed',r['failed'][:10])
