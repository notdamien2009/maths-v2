from playwright.sync_api import sync_playwright
from pathlib import Path
P='/mnt/data/F18-10-estimating-in-context.html'
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  p=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.set_content(Path(P).read_text(),wait_until='domcontentloaded');p.wait_for_timeout(160)
  print(width,'root',p.locator('#F18-10').count(),'errors',errors[:3]);
  for mode in ('Watch','Guided','Explore','Challenge'):
   p.locator('#F18-10 .nova-tabs button').filter(has_text=mode).click();p.wait_for_timeout(100)
   print(width,mode,'svg',p.locator('#F18-10 .f1810-svg').count(),'dock',p.locator('#F18-10 .nova-stage .nv-dock').count(),'scroll',p.evaluate('document.documentElement.scrollWidth-innerWidth'),'errors',errors[-2:]);p.screenshot(path=f'/mnt/data/f18_10_{width}_{mode.lower()}.png',full_page=True,animations='disabled')
  p.close()
 b.close()
