import json,math
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path('/mnt/data');QA=R/'f18_10_qa';QA.mkdir(exist_ok=True)
checks=[]
def ck(name,ok,evidence=''):
 checks.append({'name':name,'ok':bool(ok),'evidence':str(evidence)[:350]});
 if not ok: print('FAIL',name,evidence,flush=True)
def ev(p,j):return p.evaluate(j)
def go(p,mode):p.locator('#F18-10 .nova-tabs button').filter(has_text=mode).click();p.wait_for_timeout(60)
def st(p):return ev(p,'NOVA_F18_10_CONFIG._explore.state()')
def cs(p):return ev(p,'NOVA_F18_10_CONFIG._challenge.state()')
def rect(p,sel):
 x=p.locator(sel);x.scroll_into_view_if_needed(timeout=5000);return x.bounding_box()
def target(p,x,y):
 r=ev(p,'() => {const s=document.querySelector("#F18-10 .f1810-svg"),r=s.getBoundingClientRect(),v=s.viewBox.baseVal;return {x:r.x,y:r.y,w:r.width,h:r.height,vw:v.width,vh:v.height}}')
 return r['x']+x*r['w']/r['vw'],r['y']+y*r['h']/r['vh']
def drag(p,key,slot=0,placed=False,dest='slot',steps=15):
 sel=f'#F18-10 .f1810-token[data-token="{key}"]'+(f'[data-placed="{slot}"]' if placed else '[data-source]')
 b=rect(p,sel);a=(b['x']+b['width']/2,b['y']+b['height']/2)
 destpoint={'slot':target(p,123 if slot==0 else 320,528),'remove':target(p,219,745),'invalid':target(p,205,174)}[dest]
 p.mouse.move(*a);p.mouse.down();p.mouse.move(*destpoint,steps=steps);p.mouse.up();p.wait_for_timeout(460)
with sync_playwright() as w:
 b=w.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  p=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.set_content((R/'F18-10-estimating-in-context.html').read_text(),wait_until='domcontentloaded');p.wait_for_timeout(150)
  ck(f'{width} engine mounted',p.locator('#F18-10').count()==1)
  ck(f'{width} source core drag present',ev(p,'typeof NOVA.ui.svgDrag')=='function')
  ck(f'{width} no external scripts or styles',ev(p,'document.querySelectorAll("script[src],link[rel=stylesheet]").length')==0)
  ck(f'{width} six presets',len(ev(p,'Object.keys(NOVA_F18_10_CONFIG.presets)'))==6)
  ck(f'{width} no horizontal overflow',ev(p,'document.documentElement.scrollWidth<=innerWidth+1'))
  for mode in ['Watch','Guided','Explore','Challenge']:
   go(p,mode)
   ck(f'{width} {mode} SVG',p.locator('#F18-10 .f1810-svg').count()==1)
   ck(f'{width} {mode} mascot inside stage',p.locator('#F18-10 .nova-stage .nv-dock').count()==1)
   ck(f'{width} {mode} premium primitives',p.locator('#F18-10 .f1810-svg .nv-neon-box').count()>=3)
   ck(f'{width} {mode} no second Bob',ev(p,'getComputedStyle(document.querySelector("#F18-10 .nova-bob")).display')=='none')
   ck(f'{width} {mode} horizontal overflow absent',ev(p,'document.documentElement.scrollWidth<=innerWidth+1'))
   p.screenshot(path=str(QA/f'F18-10_{width}_{mode.lower()}.png'),full_page=True,animations='disabled')
  go(p,'Explore')
  for key,ans in [('shopping',120),('tickets',6000),('seats',1000),('area',135),('journey',50),('packets',100)]:
   ev(p,f'NOVA_F18_10_CONFIG._explore.select("{key}")')
   v=st(p);ck(f'{width} {key} selected',v['preset']==key)
   ck(f'{width} {key} rounding result',math.isclose(v['estimate'],ans,rel_tol=1e-9),v)
   ck(f'{width} {key} four choice chips',p.locator('#F18-10 .f1810-token[data-source]').count()==4)
   if key in ['area','journey','packets']:
    p.screenshot(path=str(QA/f'F18-10_{width}_{key}.png'),full_page=True,animations='disabled')
  ev(p,'NOVA_F18_10_CONFIG._explore.select("shopping")')
  drag(p,'0c',0)
  ck(f'{width} actual mouse places first token',st(p)['slots']==['0c',None],st(p))
  drag(p,'1c',1,steps=3)
  ck(f'{width} fast real mouse places second token',st(p)['slots']==['0c','1c'],st(p))
  drag(p,'0c',0,placed=True,dest='remove')
  ck(f'{width} mouse regrab removes first token',st(p)['slots']==[None,'1c'],st(p))
  drag(p,'0c',0,dest='invalid',steps=3)
  ck(f'{width} invalid drag springs back',st(p)['slots']==[None,'1c'],st(p))
  ck(f'{width} no dangling drag lift',p.locator('#F18-10 .nv-drag-lift').count()==0)
  bnd=rect(p,'#F18-10 .f1810-token[data-source="0c"]');src=(bnd['x']+bnd['width']/2,bnd['y']+bnd['height']/2)
  p.mouse.move(*src);p.mouse.down();p.mouse.move(src[0]+35,src[1]-60,steps=2);p.keyboard.press('Escape');p.mouse.up();p.wait_for_timeout(90)
  ck(f'{width} Escape cancels without moving state',st(p)['slots']==[None,'1c'],st(p))
  ck(f'{width} Escape leaves no floating chip',p.locator('#F18-10 .nv-drag-lift').count()==0)
  p.locator('#F18-10 .f1810-token[data-source="0c"]').focus();p.keyboard.press('Enter')
  ck(f'{width} keyboard Enter places',st(p)['slots']==['0c','1c'],st(p))
  p.locator('#F18-10 .f1810-token[data-placed="0"]').focus();p.keyboard.press('Delete')
  ck(f'{width} keyboard Delete removes',st(p)['slots']==[None,'1c'],st(p))
  # check alternate wrong token can be placed, but no revealing colour code
  ev(p,'NOVA_F18_10_CONFIG._explore.place("0w",0)')
  ck(f'{width} wrong token can be explored',st(p)['slots']==['0w','1c'])
  go(p,'Challenge')
  expected=[100,6000,1200,91,50,90];units=['kg','£','seats','m²','km/h','kg']
  for i,(v,u) in enumerate(zip(expected,units)):
   ev(p,f'NOVA_F18_10_CONFIG._challenge.task({i})');t=cs(p)
   ck(f'{width} challenge {i} numerical target',math.isclose(t['expected'],v,rel_tol=1e-9),t)
   correct=f'£{v}' if u=='£' else f'{v} {u}'
   wrong=f'£{v+2}' if u=='£' else f'{v+2} {u}'
   ck(f'{width} challenge {i} missing units rejected',not ev(p,f'NOVA_F18_10_CONFIG._challenge.check("{v}")')[0])
   ck(f'{width} challenge {i} wrong number rejected',not ev(p,f'NOVA_F18_10_CONFIG._challenge.check("{wrong}")')[0])
   ck(f'{width} challenge {i} formula slots required',not ev(p,f'NOVA_F18_10_CONFIG._challenge.check("{correct}")')[0])
   ev(p,'NOVA_F18_10_CONFIG._challenge.place("0c",0)');ev(p,'NOVA_F18_10_CONFIG._challenge.place("1c",1)')
   ck(f'{width} challenge {i} correct accepted',ev(p,f'NOVA_F18_10_CONFIG._challenge.check("{correct}")')[0])
   ck(f'{width} challenge {i} does not reveal answer prior to check',str(v) not in p.locator('#F18-10 .f1810-card[data-answer]').inner_text())
  ck(f'{width} JavaScript page errors absent',not errors,errors)
  p.close()
 b.close()
res={'passed':sum(x['ok'] for x in checks),'total':len(checks),'failed':[x for x in checks if not x['ok']],'checks':checks}
(QA/'stress-results.json').write_text(json.dumps(res,indent=2));print('RESULT',res['passed'],'/',res['total'],'failures',res['failed'][:20])
