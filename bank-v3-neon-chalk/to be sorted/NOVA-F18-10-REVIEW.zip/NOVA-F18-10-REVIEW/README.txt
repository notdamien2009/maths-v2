NOVA Maths V2 — F18-10 Estimating in Context
STATUS: BUILT FOR OWNER REVIEW — NOT GOLD APPROVED

Open F18-10-estimating-in-context.html in a modern browser. The HTML is fully standalone with original embedded NOVA shared core and NOVA Chalk fonts, helper poses and 4-mode shell.

WATCH: six-stage teaching and narration sequence
GUIDED: paced explanation and worked reasoning
EXPLORE: six context presets and drag/keyboard rounding-token interaction
CHALLENGE: six independent unit-sensitive estimate problems

Presets: deliveries, tickets, arena seats, garden area, coach speed, and parcels. The correct rounding values and incorrect place-value distractors have identical styling in Challenge.

TESTS: 180/180 main stress checks + 80/80 supplementary browser checks passed at 380px and 1280px; 24 final screenshots included. Browser and mouse tested; physical touchscreen and owner sign-off outstanding.

No changes, commits or uploads to GitHub.
F18-09 Currency Exchange remains a preset of F18-02, not an engine.

Review QA: F18-10-QA-REPORT.html
Tests: tests/*.py and tests/*.json
Screenshots: screenshots/*.png
