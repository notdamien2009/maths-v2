# F16-16 · Data-Collection Designer — Premium Review QA

**Approval:** owner review pending; NOT GOLD. **GitHub:** unchanged.

## Source & build
- Exact F16-16 specification read from `00-master/NOVA-MASTER-FOR-OTHER-AI.md` in private GitHub, read-only. Lessons Y7-065 and Y9-052.
- Shared NOVA JS/CSS in `tests/pinned-core.*` copied byte-for-byte from earlier F16-15 audited review source; no changes to the shared core or mascot artwork. Fresh byte comparison with current GitHub core could not be established and remains open.
- Offline, self-contained single HTML with original NOVA glow, Chalk and stage helper. The source is `src/F16-16.js` and `src/F16-16.css`; `build/build-f16-16.py` validates both pinned-core SHA-256 hashes and inlines the sources.
- Built standalone SHA-256 `2b3c48bcdd4d32c84c4484db16b98550ab334dee085eff4ac4f2a53ed89eecbc`. Builder reproducibility confirmed.

## Teaching/maths
- Two preset response banks of twelve observations each, four disjoint categories, correct tally-of-five diagonal notation and live frequencies.
- Y7-065 counts: Reading 2, Sport 5, Art 2, Music 3, total 12.
- Y9-052 counts: Walk 4, Bus 3, Cycle 4, Car 1, total 12.
- Watch: 10 step/narration slots with progressive recording and a deliberately biased-question comparison.
- Guided uses the existing core step controller; Explore and Challenge are working independently.
- Bias prompts distinguish question framing from respondent selection; changing the survey design does not retroactively modify the example answers.
- Challenge 1 counts all response cards; Challenge 2 rejects a leading/double-barrelled question; Challenge 3 rejects convenience-sampling audience.

## Completed browser assertions
| Suite | Passed | Failed |
|---|---:|---:|
| 380px Chromium, full four modes, two presets, native mouse + Challenge | 51 | 0 |
| 1280px Chromium, full four modes, two presets, native mouse + Challenge | 51 | 0 |
| **Total independent assertions** | **102** | **0** |

Full reproducible instructions, test inputs and every assertion outcome: `tests/stress_f1616.py`, `tests/F16-16-RESULTS-380.json` and `tests/F16-16-RESULTS-1280.json`.
- Native pointer tests moved response cards in one fast movement, refused wrong rows, re-grabbed existing tally marks and removed them. Escape cancelled an in-progress drag without leaving detached marks. Keyboard Space placed and removed response cards.
- 12 final screenshots in `shots/F16-16/`: Watch, Guided, Explore and Challenge at 380px/1280px, plus fully recorded table and misleading Y9 question/audience at each width. Screenshot capture recorded zero page errors and no horizontal overflow.
- Exactly one original helper dock inside the stage in all tested modes. Drawing occupies more than 60% of the stage at mobile and desktop.

## Remaining owner acceptance gates
- Physical touchscreen and manual drag-feel testing.
- Owner side-by-side visual comparison with F0/F2 and F16-01–15.
- Fresh byte-for-byte comparison against the latest GitHub current core (not accessible to our container as original raw bytes).
- Owner must explicitly grant GOLD approval; family cannot be considered GOLD by this report.
