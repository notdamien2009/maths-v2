# F16-16 review build
Open `F16/F16-16-data-collection-designer.html` directly in a browser.
Build: `python3 build/build-f16-16.py` (checks locked pinned core SHA-256).
QA: `python3 tests/stress_f1616.py 380` then `python3 tests/stress_f1616.py 1280` (Playwright and Chromium required).
All files are review-only; none modify GitHub or any existing NOVA core file.
