#!/usr/bin/env python3
from pathlib import Path
import sys,json,time
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];raw=(R/'F16/F16-16-data-collection-designer.html').read_text();W=int(sys.argv[1]) if len(sys.argv)>1 else 380
results=[]
def check(name,condition,details=None):
 ok=bool(condition);results.append(dict(name=name,passed=ok,detail=details if not ok else None));print(('PASS' if ok else 'FAIL'),name,(str(details)[:160] if not ok else ''),flush=True)
def get(page):return page.evaluate('NOVA_F16_16_CONFIG._explore.get()')
def xy(page,x,y):return page.evaluate('''p=>{let s=document.querySelector('.f1616-svg');let pt=s.createSVGPoint();pt.x=p[0];pt.y=p[1];let v=pt.matrixTransform(s.getScreenCTM());return {x:v.x,y:v.y}}''',[x,y])
def drag(page,source,x,y):
 source.scroll_into_view_if_needed(timeout=12000);box=source.bounding_box();assert box, 'source not visible';sx=box['x']+box['width']/2;sy=box['y']+box['height']/2;dst=xy(page,x,y)
 page.mouse.move(sx,sy);page.mouse.down();page.mouse.move(dst['x'],dst['y'],steps=1);page.mouse.up();page.wait_for_timeout(320)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':W,'height':1000},reduced_motion='reduce');errors=[];page.on('pageerror',lambda x:errors.append(str(x)))
 page.set_content(raw,wait_until='domcontentloaded',timeout=90000);page.wait_for_timeout(150)
 for mode in ['Watch','Guided','Explore','Challenge']:
  page.get_by_role('tab',name=mode,exact=True).click();page.wait_for_timeout(120)
  v=page.evaluate('''()=>{let a=document.querySelector('.nova-stage')?.getBoundingClientRect(),b=document.querySelector('.f1616-svg')?.getBoundingClientRect();return {stage:a.height,svg:b.height,dock:document.querySelectorAll('.nova-stage .nv-dock').length,overflow:document.documentElement.scrollWidth>innerWidth,cards:document.querySelectorAll('.f1616-svg [data-card-id]').length}}''')
  check(f'{W} {mode} shell and drawing',v['dock']==1 and not v['overflow'] and (mode=='Watch' or v['cards']==12) and v['svg']/v['stage']>=.6,v)
 page.get_by_role('tab',name='Explore',exact=True).click();page.wait_for_timeout(250)
 for preset in ['y7-065','y9-052']:
  page.locator('.f1616-controls select').first.select_option(preset);page.wait_for_timeout(150)
  q=page.evaluate('''()=>NOVA_F16_16_CONFIG.presets[NOVA_F16_16_CONFIG.preset]''');s=get(page)
  check(f'{W} {preset} initial state',s['total']==0 and len(s['records'])==12,s)
  check(f'{W} {preset} data distribution',sum([q['data'].count(i) for i in range(4)])==12,q['data'])
  page.locator('.f1616-controls select').nth(1).select_option('1');check(f'{W} {preset} leading question detected',get(page)['question']==1)
  page.locator('.f1616-controls select').nth(2).select_option('1');check(f'{W} {preset} convenience audience detected',get(page)['audience']==1)
  page.locator('.f1616-controls select').nth(1).select_option('0');page.locator('.f1616-controls select').nth(2).select_option('0')
  firstCat=q['data'][0];other=(firstCat+1)%4
  # Attempt to drop a source card in the wrong row; must spring home.
  y0=(366+106+other*42+17) if W==380 else (368+111+other*71+27)
  drag(page,page.locator('[data-card-id="0"]'),270,y0)
  check(f'{W} {preset} wrong row rejected',get(page)['total']==0,get(page))
  check(f'{W} {preset} wrong drop clean',not page.evaluate('!!NOVA.ui._drag'))
  # Fast movement to correct row.
  y=(366+106+firstCat*42+17) if W==380 else (368+111+firstCat*71+27)
  drag(page,page.locator('[data-card-id="0"]'),280,y)
  check(f'{W} {preset} fast mouse records correct card',get(page)['total']==1 and get(page)['counts'][firstCat]==1,get(page))
  check(f'{W} {preset} recorded tally shown',page.locator('[data-placed-id="0"]').count()==1)
  rm=(380,903) if W==380 else (700,845)
  drag(page,page.locator('[data-placed-id="0"]'),*rm)
  check(f'{W} {preset} regrab tally and remove',get(page)['total']==0 and page.locator('[data-card-id="0"]').count()==1,get(page))
  check(f'{W} {preset} remove clean',not page.evaluate('!!NOVA.ui._drag'))
  # Escape during fast movement: the data must remain unchanged.
  loc=page.locator('[data-card-id="1"]');loc.scroll_into_view_if_needed();bb=loc.bounding_box();t=xy(page,280,y)
  page.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);page.mouse.down();page.mouse.move(t['x'],t['y'],steps=1);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(350)
  check(f'{W} {preset} Escape restores card',get(page)['total']==0 and not page.evaluate('!!NOVA.ui._drag'),get(page))
  # keyboard fallback and count identity
  page.locator('[data-card-id="0"]').focus();page.keyboard.press('Space');page.wait_for_timeout(130)
  check(f'{W} {preset} keyboard records',get(page)['total']==1,get(page))
  page.locator('[data-placed-id="0"]').focus();page.keyboard.press('Space');page.wait_for_timeout(140)
  check(f'{W} {preset} keyboard removes',get(page)['total']==0,get(page))
  page.get_by_role('button',name='Record all 12').click();s=get(page)
  true_counts=[q['data'].count(i) for i in range(4)]
  check(f'{W} {preset} all twelve recorded',s['total']==12 and s['counts']==true_counts,(s,true_counts))
  page.get_by_role('button',name='Clear responses').click();check(f'{W} {preset} clear',get(page)['total']==0,get(page))
  # Challenge 3 tasks with wrong/correct responses
  page.get_by_role('tab',name='Challenge',exact=True).click();page.wait_for_timeout(220)
  check(f'{W} {preset} challenge initial',page.evaluate('NOVA_F16_16_CONFIG._challenge.task()')==0)
  page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(180)
  check(f'{W} {preset} incomplete task rejected',page.evaluate('NOVA_F16_16_CONFIG._challenge.task()')==0)
  for i in range(12):
   page.locator(f'[data-card-id="{i}"]').focus();page.keyboard.press('Space');page.wait_for_timeout(40)
  check(f'{W} {preset} challenge accurate tally',page.evaluate('NOVA_F16_16_CONFIG._challengeState().counts')==true_counts)
  page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(850)
  check(f'{W} {preset} challenge tally accepted',page.evaluate('NOVA_F16_16_CONFIG._challenge.task()')==1)
  page.locator('[data-question-choice]').select_option('1');page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(140)
  check(f'{W} {preset} leading question rejected',page.evaluate('NOVA_F16_16_CONFIG._challenge.task()')==1)
  page.locator('[data-question-choice]').select_option('0');page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(850)
  check(f'{W} {preset} neutral question accepted',page.evaluate('NOVA_F16_16_CONFIG._challenge.task()')==2)
  page.locator('[data-audience-choice]').select_option('1');page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(150)
  check(f'{W} {preset} biased sampling rejected',page.evaluate('NOVA_F16_16_CONFIG._challenge.task()')==2)
  page.locator('[data-audience-choice]').select_option('0');page.get_by_role('button',name='Check',exact=True).click();page.wait_for_timeout(220)
  check(f'{W} {preset} correct sampling accepted','correct' in page.locator('.nova-panel').inner_text().lower() or page.evaluate('NOVA_F16_16_CONFIG._challenge.task()')>=3)
  page.get_by_role('tab',name='Explore',exact=True).click();page.wait_for_timeout(130)
 check(f'{W} no JS errors',not errors,errors)
 browser.close()
output=R/f'tests/F16-16-RESULTS-{W}.json';output.write_text(json.dumps({'width':W,'count':len(results),'passed':sum(x['passed'] for x in results),'fails':[x for x in results if not x['passed']],'checks':results},indent=2))
print('SUMMARY',W,sum(x['passed'] for x in results),'/',len(results),flush=True)
sys.exit(0 if all(x['passed'] for x in results) else 1)
