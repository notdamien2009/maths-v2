NOVA Maths V2 · F18-07 Interest Growth Chart — REVIEW EDITION

One fully standalone HTML page based on the ORIGINAL NOVA F0/F2 production core.

Modes: WATCH (six teaching steps), GUIDED, EXPLORE (drag year tokens and sliders), CHALLENGE (six tasks).
Presets: First savings, Holiday fund, Junior saver, Low rate, GCSE compound comparison.

MATHS POLICY
- All calculations in integer pence.
- Simple interest adds the percentage of the original capital each year.
- Compound interest rounds to the nearest penny at the END OF EACH YEAR.
- Bar heights represent INTEREST EARNED, not the entire capital-plus-interest balance.
- To earn the challenge correct mark, pupils must select the intended year and enter a money answer including the unit.

AUTOMATED QA
- Browser stress: 260/260 passed.
- Additional UI tests: 28/28 passed.
- 8/8 mode/viewport smoke checks with no runtime errors or horizontal overflow.
- 20 screenshots (380px and 1280px): eight modes, eight preset images, two year-selection and two challenge-success views.
- In-person touchscreen validation and owner review still outstanding.

STATUS: For review, NOT GOLD-approved.
GITHUB: No commits, pushes or modifications.
