from playwright.sync_api import sync_playwright
from pathlib import Path
P='/mnt/data/F18-07-interest-growth-chart.html'
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  pg=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e: errors.append(str(e)))
  pg.set_content(Path(P).read_text(),wait_until='domcontentloaded');pg.wait_for_timeout(200)
  print(width,'mode root',pg.locator('#F18-07').count(),'errors',errors[:4]);print('initial',pg.locator('#F18-07 .nova-tabs').count())
  for mode in ['Watch','Guided','Explore','Challenge']:
   pg.locator('#F18-07 .nova-tabs button').filter(has_text=mode).click();pg.wait_for_timeout(100)
   print(width,mode,'SVGs',pg.locator('#F18-07 .f1807-svg').count(),'mascot',pg.locator('#F18-07 .nova-stage .nv-dock').count(),'overflow',pg.evaluate('document.documentElement.scrollWidth-innerWidth'),'errors',errors[-3:])
   pg.screenshot(path=f'/mnt/data/f18_07_{width}_{mode.lower()}.png',full_page=True,animations='disabled')
  pg.close()
 b.close()
