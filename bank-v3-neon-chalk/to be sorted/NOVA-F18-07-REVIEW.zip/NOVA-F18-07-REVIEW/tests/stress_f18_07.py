import json, math
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data'); QA=ROOT/'f18_07_qa';QA.mkdir(exist_ok=True)
HTML=(ROOT/'F18-07-interest-growth-chart.html').read_text()
checks=[]
def ck(n,truth,info=''):
 checks.append({'name':n,'ok':bool(truth),'evidence':str(info)[:450]})
 if not truth: print('FAIL',n,info,flush=True)
def go(p,mode):
 p.locator('#F18-07 .nova-tabs button').filter(has_text=mode.title()).click();p.wait_for_timeout(60)
def val(p,s):return p.evaluate(s)
def ex(p):return val(p,'NOVA_F18_07_CONFIG._explore.state()')
def rect(p,sel):
 el=p.locator(sel);el.scroll_into_view_if_needed(timeout=6000);return el.bounding_box()
def point(bb):return bb['x']+bb['width']/2,bb['y']+bb['height']/2
def destination(p,x,y):
 info=val(p,'''()=>{var e=document.querySelector('#F18-07 .f1807-svg'),r=e.getBoundingClientRect(),b=e.viewBox.baseVal;return {x:r.x,y:r.y,w:r.width,h:r.height,bw:b.width,bh:b.height}}''')
 return info['x']+x*info['w']/info['bw'],info['y']+y*info['height'] / info['bh'] if 'height' in info else info['y']+y*info['h']/info['bh']
def drag(p,year,kind='source',target='dock',steps=22):
 bb=rect(p,f'#F18-07 .f1807-chip[data-year="{year}"][data-kind="{kind}"]');src=point(bb)
 vb=val(p,'()=>document.querySelector("#F18-07 .f1807-svg").viewBox.baseVal.width')
 x=vb/2;y={'dock':621,'remove':520,'invalid':120}[target]
 dst=destination(p,x,y)
 p.mouse.move(*src);p.mouse.down();p.mouse.move(*dst,steps=steps);p.mouse.up();p.wait_for_timeout(140)
 return [src,dst]
with sync_playwright() as py:
 b=py.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  p=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.set_content(HTML,wait_until='domcontentloaded');p.wait_for_timeout(120)
  ck(f'{width} original helper drag kit',val(p,'typeof NOVA.ui.svgDrag')=='function')
  ck(f'{width} exactly one engine',p.locator('#F18-07').count()==1)
  ck(f'{width} no horizontal overflow',val(p,'document.documentElement.scrollWidth<=innerWidth+1'))
  ck(f'{width} all five presets available',len(val(p,'Object.keys(NOVA_F18_07_CONFIG.presets)'))==5)
  ck(f'{width} no external requests',val(p,'document.querySelectorAll("script[src],link[rel=stylesheet]").length')==0)
  for mode in ('watch','guided','explore','challenge'):
   go(p,mode)
   ck(f'{width} {mode} SVG',p.locator('#F18-07 .f1807-svg').count()==1)
   ck(f'{width} {mode} one mascot inside',p.locator('#F18-07 .nova-stage .nv-dock').count()==1)
   ck(f'{width} {mode} neon drawing objects',p.locator('#F18-07 .f1807-svg .nv-neon-box').count()>=3)
   ck(f'{width} {mode} no extra Bob portrait',val(p,'getComputedStyle(document.querySelector("#F18-07 .nova-bob")).display')=='none')
   p.screenshot(path=str(QA/f'F18-07_{width}_{mode}.png'),full_page=True,animations='disabled')
  # check year-by-year against independent integer-pence calculations
  for key,preset in val(p,'NOVA_F18_07_CONFIG.presets').items():
   q=preset['p'];bp=preset['bp'];annual=round(q*bp/10000);com=q
   go(p,'explore');val(p,f'NOVA_F18_07_CONFIG._explore.select("{key}")');st=ex(p);actual=st['table'];ck(f'{width} {key} preset chosen',st['preset']==key)
   ck(f'{width} {key} chart years',len(actual)==preset['years']+1)
   for yr in range(1,preset['years']+1):
    com+=math.floor(com*bp/10000+0.5)
    ck(f'{width} {key} yr{yr} simple',actual[yr]['si']==annual*yr)
    ck(f'{width} {key} yr{yr} compound',actual[yr]['ci']==com-q)
   ck(f'{width} {key} year markers visible',p.locator('#F18-07 .f1807-chip[data-kind=source]').count()==preset['years'])
  go(p,'explore');val(p,'NOVA_F18_07_CONFIG._explore.select("first")')
  ck(f'{width} empty first marker',ex(p)['placed'] is False)
  ck(f'{width} drag year 3',bool(drag(p,3)),ex(p))
  ck(f'{width} actual pointer select year3',ex(p)['placed'] and ex(p)['chosen']==3,ex(p))
  ck(f'{width} placed can be re-grabbed',bool(drag(p,3,'placed','remove')),ex(p))
  ck(f'{width} actual pointer remove',not ex(p)['placed'],ex(p))
  drag(p,4,'source','invalid',steps=3)
  ck(f'{width} invalid drop returns home',not ex(p)['placed'],ex(p))
  ck(f'{width} invalid drop no dangling',p.locator('#F18-07 .nv-drag-lift').count()==0)
  # ESC mid drag
  bb=rect(p,'#F18-07 .f1807-chip[data-year="2"][data-kind="source"]');src=point(bb)
  p.mouse.move(*src);p.mouse.down();p.mouse.move(src[0]+40,src[1]-50,steps=4);p.keyboard.press('Escape');p.mouse.up();p.wait_for_timeout(110)
  ck(f'{width} Escape preserves state',not ex(p)['placed'])
  ck(f'{width} Escape no floating chip',p.locator('#F18-07 .nv-drag-lift').count()==0)
  # keyboard
  p.locator('#F18-07 .f1807-chip[data-year="2"][data-kind="source"]').focus();p.keyboard.press('Enter')
  ck(f'{width} keyboard add',ex(p)['placed'] and ex(p)['chosen']==2)
  p.locator('#F18-07 .f1807-chip[data-year="2"][data-kind="placed"]').focus();p.keyboard.press('Delete')
  ck(f'{width} keyboard remove',not ex(p)['placed'])
  # sliders
  val(p,'NOVA_F18_07_CONFIG._explore.adjust(60000,700,6)')
  changed=ex(p)
  ck(f'{width} adjustable capital/rate/years',changed['p']['p']==60000 and changed['p']['bp']==700 and changed['p']['years']==6)
  ck(f'{width} six year bars visible',p.locator('#F18-07 .f1807-chip').count()==6)
  go(p,'challenge');ts=val(p,'NOVA_F18_07_CONFIG._challenge.tasks')
  expected=[3000,18600,6000,86400,5527,4587] # last differs? Check below against independent amount
  for i,t in enumerate(ts):
   val(p,f'NOVA_F18_07_CONFIG._challenge.task({i})')
   st=val(p,'NOVA_F18_07_CONFIG._challenge.state()');correct=st['expected']
   ck(f'{width} challenge {i} numeric expected > 0',correct>0,correct)
   ck(f'{width} challenge {i} rejects missing currency',not val(p,'NOVA_F18_07_CONFIG._challenge.check("100")')[0])
   ck(f'{width} challenge {i} rejects incorrect amount',not val(p,f'NOVA_F18_07_CONFIG._challenge.check("£{(correct+100)/100:.2f}")')[0])
   good=f'£{correct/100:.2f}'
   ck(f'{width} challenge {i} requires selected year',not val(p,f'NOVA_F18_07_CONFIG._challenge.check("{good}")')[0])
   val(p,f'NOVA_F18_07_CONFIG._challenge.select({t["year"]})')
   ck(f'{width} challenge {i} correct year and answer accepted',val(p,f'NOVA_F18_07_CONFIG._challenge.check("{good}")')[0])
   ck(f'{width} challenge {i} answer not revealed in cards', good not in p.locator('#F18-07 .f1807-side').inner_text(),good)
  ck(f'{width} no JS errors',not errors,errors)
  p.close()
 b.close()
report={'passed':sum(z['ok'] for z in checks),'total':len(checks),'failed':[z for z in checks if not z['ok']],'checks':checks}
(QA/'stress-results.json').write_text(json.dumps(report,indent=2))
print('STRESS',report['passed'],report['total'],report['failed'][:20],flush=True)
