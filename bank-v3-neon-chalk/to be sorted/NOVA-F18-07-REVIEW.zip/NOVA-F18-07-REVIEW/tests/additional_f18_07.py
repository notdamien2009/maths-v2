import json
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data');QA=ROOT/'f18_07_qa';HTML=(ROOT/'F18-07-interest-growth-chart.html').read_text()
checks=[]
def ck(name,pass_,evidence=''):
 checks.append({'name':name,'ok':bool(pass_),'evidence':str(evidence)[:450]})
 if not pass_: print('FAIL',name,evidence,flush=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  p=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce');p.set_content(HTML,wait_until='domcontentloaded')
  for mode in ['Watch','Explore','Challenge']:
   p.locator('#F18-07 .nova-tabs button').filter(has_text=mode).click()
   if mode=='Watch':
    steps=p.evaluate('NOVA_F18_07_CONFIG._dummy||[]')
    names=p.evaluate('NOVA.events.query({type:"step"}).filter(e=>e.detail.engine==="F18-07").map(e=>e.detail.index)')
    ck(f'{width} watch step emitted',len(names)>0,names)
    ck(f'{width} six step buttons present',p.locator('#F18-07 .nova-tl button').count()>2)
    ck(f'{width} watch first stage clean',p.locator('#F18-07 .f1807-svg').count()==1)
    # Use the shared step navigation rather than internal config mutation
    buttons=p.locator('#F18-07 .nova-tl button')
    for btn in buttons.all()[:6]:
     pass
    # Text in watch is available via core steps display.
    ck(f'{width} watch named narration steps','of 6' in p.locator('#F18-07 .nova-tl').inner_text())
   if mode=='Explore':
    p.evaluate('NOVA_F18_07_CONFIG._explore.select("first")')
    p.evaluate('NOVA_F18_07_CONFIG._explore.choose(5)')
    ck(f'{width} explore inspected year5',p.evaluate('NOVA_F18_07_CONFIG._explore.state().chosen')==5)
    ck(f'{width} explore compound gain £55.27', '£55.27' in p.locator('#F18-07 .f1807-side').inner_text())
    p.screenshot(path=str(QA/f'F18-07_{width}_year5-selected.png'),full_page=True,animations='disabled')
    # Preset gallery sample
    for k in ['holiday','regular','smaller','gcse']:
     p.evaluate(f'NOVA_F18_07_CONFIG._explore.select("{k}")')
     p.screenshot(path=str(QA/f'F18-07_{width}_preset-{k}.png'),full_page=True,animations='disabled')
     ck(f'{width} preset {k} visible without overflow',p.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   if mode=='Challenge':
    p.evaluate('NOVA_F18_07_CONFIG._challenge.task(0)')
    p.evaluate('NOVA_F18_07_CONFIG._challenge.select(3)')
    p.locator('#F18-07 input[aria-label="Money answer, with pounds or pence"]').fill('£30.00')
    p.get_by_role('button',name='Check interest').click()
    ck(f'{width} live answer passes via UI',p.locator('#F18-07 .f1807-status[data-good]').count()==1)
    ck(f'{width} core answer chip appears',p.locator('#F18-07 .f1807-answer').count()==1)
    ck(f'{width} mascot celebration',p.locator('#F18-07 .nv-dock').count()==1)
    p.screenshot(path=str(QA/f'F18-07_{width}_challenge-correct.png'),full_page=True,animations='disabled')
    # Independent math data in compound challenging preset
    p.evaluate('NOVA_F18_07_CONFIG._challenge.task(5)')
    target=p.evaluate('NOVA_F18_07_CONFIG._challenge.state().expected')
    ck(f'{width} GCSE 6% compound difference nonzero',target>0,target)
  p.close()
 b.close()
report={'passed':sum(v['ok'] for v in checks),'total':len(checks),'failures':[v for v in checks if not v['ok']],'checks':checks}
(QA/'additional-results.json').write_text(json.dumps(report,indent=2));print(json.dumps({'passed':report['passed'],'total':report['total'],'failures':report['failures']},indent=2))
