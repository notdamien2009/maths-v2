# NOVA Maths V2 — F17-04 Relative-Frequency Convergence — Review QA

**Date:** 13 October 2026  
**Status:** BUILT FOR OWNER REVIEW · NOT GOLD-APPROVED  
**GitHub:** Private repository read-only; no file changes, commits, pushes or uploads.  
**Standalone HTML SHA-256:** `8b07614483291cef92c028497302dbb45a1571a92e80a331d11a047ba71472d3`  
**Browser:** Actual headless Chromium / Playwright at desktop 1280px and mobile 380px. Physical touch testing was **not** performed.

## 1. Authority and presentation
- Canonical F17-04 specification: GitHub `notdamien2009/maths-v2`, `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, section **F17-04 Relative-frequency convergence**. Covers Y7-076, Y8-073, Y9-042 and Y9-046.
- Embedded actual NOVA F0/F2 shared core and font faces from the F17-03 production reference, not a separately recreated shell (HTML lines 16–1737). Original single NOVA mascot dock is provided through `NOVA.scene.helperStrip`; one stage mascot verified in each of eight viewport/mode combinations (`tests/F17-04-SMOKE.json`).
- Shared local F17-02 pointer recapture and F17-03 ±0.08 SVG-unit hit-zone rounding guard were **inherited inside this standalone HTML only**. They have not been written to GitHub. See line ~1707.
- Graph uses `NOVA.plot.frame`, `NOVA.neonLine`, `NOVA.neonPath`, `NOVA.neonRing`, `NOVA.neonBox`, and `NOVA.chalkText` (HTML ~1768–1823). Fractions use stacked numerator, neon bar and denominator in NOVA Chalk (HTML ~1748). Two large chalk axes labels are supplied; default 10px core plot tick text is hidden only on F17-04 to avoid duplicates (CSS line ~625).
- Exactly **14 screenshots**: all four modes × both widths (8), and Y8/Y9 preset comparisons × both widths (6). These are browser captures of the delivered HTML.

## 2. Mathematics and evidence
| Preset | Experiment | Favourable / equally likely outcomes | Theoretical probability |
|---|---|---|---|
| Y7-076 | Fair coin: HEADS | 1/2 | 0.5 |
| Y8-073 | Fair six-faced die: 5 or 6 | 2/6 = 1/3 | 0.333… |
| Y9-042 | Eight equiprobable outcomes: 1, 2, 3 | 3/8 | 0.375 |
| Y9-046 | Two fair dice: sum exactly 7 | 6/36 = 1/6 | 0.1666… |

Each trial samples outcomes from `NOVA.rng.create` and checks the corresponding favourable-event predicate in the engine, instead of constructing an artificially converging line. See `sample()` and `runTrials()` at HTML lines ~1750–1755. The observed curve uses each **cumulative** number of wins / number of trials, plotted by `NOVA.neonPath`. The dashed theoretical line always remains fixed. The sample can temporarily drift *further* from theory; the guided material and Challenge 4 explicitly address this misconception.

## 3. Functions verified
- WATCH: Six concept-specific named narration steps, with shared NOVA play/pause/step/scrub/rewind timeline; desktop and mobile screenshots.
- GUIDED: Scaffolded steps and changing graph states, with changing helper speech.
- EXPLORE: Four presets; live 1, 20, 100, 500 trials; cumulative successes and relative frequency; exact fixed theoretical reference; a real SVG draggable probability-prediction chip with five traditional fraction slots (1/6, 1/4, 1/3, 3/8, 1/2), fast pointer movement, re-grab to change, invalid drop spring-back, red REMOVE tray, Escape cancellation and keyboard-equivalent select/placement/removal. Recorded tests in `tests/F17-04-STRESS-RESULTS.json`, relevant engine lines ~1795–1822 and ~1847–1871.
- CHALLENGE: Four real checked tasks with targeted corrective feedback: 9/20 = 0.45 observed, 8/24 = 1/3 observed, six ordered sum-seven pairs, and the fact that convergence is not monotonically guaranteed. Tested both correct and misconception answers at two widths, engine lines ~1873–1884.

## 4. Executed QA, not assumed
- **136/136 passing** explicit interaction/mathematical assertions in `tests/F17-04-STRESS-RESULTS.json`; 0 failures. Real Playwright mouse movement and clicks are used for both fast drag, re-grab, invalid drop, removal, Escape and keyboard alternatives. Each of four presets generated 100 independent further trial outcomes per viewport in the test.
- **12/12 passing** actual normal-motion checks in `tests/F17-04-NORMAL-MOTION-RESULTS.json`, covering incremental animated batch updates, exact run completion, early mode-switch cleanup, available watch controls and absence of page errors.
- **8/8 successful mode/viewport smoke renders**, each with exactly one chart and one in-stage mascot, no horizontal overflow or JS page error, in `tests/F17-04-SMOKE.json`.
- **No claim of physical touchscreen, Safari, Firefox, audible TTS or independent owner visual sign-off.** Those remain review tasks.

## 5. Owner acceptance
Inspect the 380px and 1280px screenshots against approved-style F0/F2 engines. Try all lesson presets and the drag/re-grab controls on your own browser and touchscreen. Review the educational graph labels and mascot dialogue. Report targeted issues for correction. **Do not promote F17-04 to GOLD until you approve it.**
