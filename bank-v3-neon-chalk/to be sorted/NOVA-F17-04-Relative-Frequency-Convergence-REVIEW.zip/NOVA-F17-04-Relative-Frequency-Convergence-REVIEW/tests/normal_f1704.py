from playwright.sync_api import sync_playwright
from pathlib import Path
import json
html=Path('/mnt/data/F17-04-Relative-Frequency-Convergence-PREMIUM-REVIEW.html').read_text(); tests=[]
def ck(name,v,extra=None):tests.append(dict(test=name,passed=bool(v),detail=extra));print('PASS' if v else 'FAIL',name,extra if extra is not None else '',flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  page=b.new_page(viewport={'width':width,'height':970},reduced_motion='no-preference')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded',timeout=60000)
  page.locator('.nova-tab[data-m="watch"]').click()
  ck(f'{width} animated watch play/pause controls available',page.locator('.nova-tl button').count()>0)
  page.locator('.nova-tab[data-m="explore"]').click()
  before=page.evaluate('NOVA_F17_04_CONFIG._explore.get().trials')
  page.get_by_role('button',name='Run 20 trials').click()
  page.wait_for_timeout(150)
  mid=page.evaluate('NOVA_F17_04_CONFIG._explore.get().trials');ck(f'{width} trial animation runs gradually',before<mid<=before+20,{'before':before,'mid':mid})
  page.wait_for_timeout(1250)
  after=page.evaluate('NOVA_F17_04_CONFIG._explore.get().trials');ck(f'{width} run finishes without duplicate trials',after==before+20,{'after':after})
  ck(f'{width} after animation chart rendered',page.locator('.nova-stage svg [data-experimental-curve]').count()==1)
  # Switch mode mid-animation to ensure cleanup and no exceptions.
  page.get_by_role('button',name='Run 100 trials').click();page.wait_for_timeout(100);page.locator('.nova-tab[data-m="challenge"]').click();page.wait_for_timeout(550)
  ck(f'{width} mode switch cancels animated running',page.locator('.nova-stage svg.f174-plot').count()==1)
  ck(f'{width} animated checks have no page JS errors',not errors,errors[-1] if errors else None)
  page.close()
 b.close()
Path('/mnt/data/f17_work/F17-04-NORMAL-MOTION-RESULTS.json').write_text(json.dumps({'total':len(tests),'passed':sum(t['passed'] for t in tests),'failed':[t for t in tests if not t['passed']],'tests':tests},indent=2))
