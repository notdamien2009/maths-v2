# NOVA Maths V2 — F17-04 review package

**Component:** F17-04 · Relative-Frequency Convergence (Probability and Sets)  
**Status:** Review only; not GOLD-approved. GitHub untouched.

1. Open `F17-04-Relative-Frequency-Convergence-PREMIUM-REVIEW.html` in a desktop browser; no network connection is required.
2. Check WATCH, GUIDED, EXPLORE and CHALLENGE at normal desktop width and 380px/mobile.
3. In EXPLORE, switch among all four lesson presets; run trial batches, drag the prediction marker between fraction slots, return it via the red REMOVE tray, and test the keyboard alternative.
4. Open `QA-REPORT.md` for the executed browser QA summary; review all images under `screenshots/` and actual scripts/results under `tests/`.

The standalone HTML embeds the NOVA core, original chalk fonts and original helper assets. No files were committed or pushed to GitHub.
