/* NOVA F15-09 · Trig Solver — canonical shared NOVA core embedded unchanged above */
(function(){'use strict';
var H=NOVA.h,S=NOVA.svg,E=S.el,M=NOVA.motion,ID='F15-09',RAD=Math.PI/180;
var CONFIG=window.NOVA_F15_09_CONFIG={startMode:'watch',preset:'sinOpp',events:['value','step','mode','hintUsed','correct','theta','preset','label','ratio'],presets:{
 sinOpp:{label:'Y9 · Sine finds opposite',mode:'side',theta:30,known:'h',given:12,unknown:'o',unit:'cm',dp:1},
 cosAdj:{label:'Y9 · Cosine finds adjacent',mode:'side',theta:60,known:'h',given:14,unknown:'a',unit:'cm',dp:1},
 tanOpp:{label:'Y9 · Tangent finds opposite',mode:'side',theta:35,known:'a',given:8,unknown:'o',unit:'m',dp:1},
 sinHyp:{label:'Y9 · Sine finds hypotenuse',mode:'side',theta:40,known:'o',given:7,unknown:'h',unit:'cm',dp:1},
 cosHyp:{label:'Y9 · Cosine finds hypotenuse',mode:'side',theta:55,known:'a',given:6,unknown:'h',unit:'m',dp:1},
 tanAdj:{label:'Y9 · Tangent finds adjacent',mode:'side',theta:38,known:'o',given:9,unknown:'a',unit:'cm',dp:1},
 inverseSin:{label:'Y9 · Inverse sine finds angle',mode:'angle',a:8,o:6,known:'o',second:'h',unit:'cm',dp:1},
 inverseCos:{label:'Y9 · Inverse cosine finds angle',mode:'angle',a:8,o:Math.sqrt(105),known:'a',second:'h',unit:'cm',dp:1},
 inverseTan:{label:'Y9 · Inverse tangent finds angle',mode:'angle',a:9,o:7,known:'o',second:'a',unit:'m',dp:1},
 gcse:{label:'GCSE · Divide to find hypotenuse',mode:'side',theta:47,known:'a',given:9,unknown:'h',unit:'cm',dp:2}
}};
var STEPS=[
 {name:'Find the square corner',pose:'explain',prompt:'Locate the ninety-degree corner before calculating.'},
 {name:'Choose the reference angle',pose:'point-down',prompt:'Which acute angle are we working relative to?'},
 {name:'Opposite, adjacent, hypotenuse',pose:'ruler',prompt:'Which two side roles are relevant to this question?'},
 {name:'Identify the givens',pose:'magnify',prompt:'What is known, and what does the question ask you to find?'},
 {name:'Select the matching side pair',pose:'compare',prompt:'Is the known–unknown pair O–H, A–H or O–A?'},
 {name:'Choose sine, cosine or tangent',pose:'idea',prompt:'SOH, CAH or TOA: which one uses these sides?'},
 {name:'Build the proper fraction',pose:'show-one',prompt:'Keep the numerator and denominator in the correct order.'},
 {name:'Substitute the known numbers',pose:'show-two',prompt:'Replace the side symbols with the given values.'},
 {name:'Rearrange carefully',pose:'think',prompt:'Does the unknown need multiplying, dividing or inverse trig?'},
 {name:'Evaluate with degree mode',pose:'count',prompt:'Keep the calculator in degrees and full precision.'},
 {name:'Round only at the end',pose:'show-three',prompt:'Write the answer with the required accuracy and unit.'},
 {name:'Check the result',pose:'checking',prompt:'Substitute back into the ratio. Does it agree?'},
 {name:'A changed triangle',pose:'magnify',prompt:'How would a new angle change the length calculation?'},
 {name:'Transfer to the next problem',pose:'celebrate',prompt:'Identify, choose, rearrange, calculate, check.'}
];
function fmt(x,p){if(!Number.isFinite(x))return '?';if(Math.abs(x)<1e-10)x=0;return p==null?String(Number(x.toFixed(2))):Number(x).toFixed(p);}
function clamp(x,a,b){return Math.max(a,Math.min(b,x));}
function clone(x){return JSON.parse(JSON.stringify(x));}
var NAMES={a:'Adjacent',o:'Opposite',h:'Hypotenuse',theta:'Angle θ'};
function related(x,y){var k=[x,y].sort().join('');return k==='ho'?'sin':k==='ah'?'cos':k==='ao'?'tan':null;}
function sides(st){var theta=st.mode==='angle'?Math.atan2(st.o,st.a)/RAD:st.theta;
 if(st.mode==='angle'){var h0=st.fixedHyp||Math.hypot(st.a,st.o);return {a:h0*Math.cos(theta*RAD),o:h0*Math.sin(theta*RAD),h:h0,theta:theta};}
 var q={a:Math.cos(theta*RAD),o:Math.sin(theta*RAD),h:1},k=st.given/q[st.known];return {a:q.a*k,o:q.o*k,h:k,theta:theta};}
function details(st){var v=sides(st),r=st.mode==='angle'?related(st.known,st.second):related(st.known,st.unknown),n=r==='sin'?'o':r==='cos'?'a':'o',d=r==='sin'||r==='cos'?'h':'a',ratio=v[n]/v[d],answer=st.mode==='angle'?v.theta:v[st.unknown],need=st.mode==='angle'?'theta':st.unknown;
 return {v:v,ratio:r,n:n,d:d,ratioValue:ratio,answer:answer,need:need,inverse:st.mode==='angle'};}
function formula(st){var D=details(st),r=D.ratio,v=D.v;if(st.mode==='angle')return ['θ = '+r+'⁻¹('+fmt(v[D.n],2)+' ÷ '+fmt(v[D.d],2)+')',r+'⁻¹('+fmt(D.ratioValue,4)+')'];
 var f=r+' θ',other=st.known,missing=st.unknown,n=D.n,d=D.d;
 if(missing===n)return [NAMES[missing]+' = '+f+' × '+fmt(v[d],2),'Multiply by the denominator'];
 return [NAMES[missing]+' = '+fmt(v[n],2)+' ÷ '+f,'Divide by the trig ratio'];}
window.NOVA_F15_09_MATH={sides:sides,details:details,presets:CONFIG.presets,formula:formula};
function emit(key,val){NOVA.events.emit('value',{engine:ID,key:key,control:key,value:val});}
function chalk(g,x,y,t,r,size,anchor){return NOVA.chalkText(g,x,y,String(t),{role:r||'unknown',size:size||18,anchor:anchor||'middle'});}
function seg(g,a,b,r,w){return NOVA.neonPath(g,'M'+fmt(a[0],3)+' '+fmt(a[1],3)+' L'+fmt(b[0],3)+' '+fmt(b[1],3),{role:r||'op',width:w||4});}
function path(g,d,r,w){return NOVA.neonPath(g,d,{role:r||'op',width:w||3.4});}
function neonBox(g,x,y,w,h,r){return NOVA.neonBox(g,x,y,w,h,{role:r||'support'});}
function frac(g,x,y,up,down){chalk(g,x,y,up,'support',19);seg(g,[x-75,y+13],[x+75,y+13],'op',2.8);chalk(g,x,y+40,down,'result',19);}
function btn(s,fn){return H('button',{class:'nova-btn',text:s,onclick:fn});}
function row(parent,items){parent.appendChild(H('div',{class:'f159-row'},items));}
function geometry(st,mob){var v=sides(st),L=mob?266:305,R=[mob?104:135,mob?376:398],theta=v.theta*RAD,A=[R[0]+L*Math.cos(theta),R[1]],B=[R[0],R[1]-L*Math.sin(theta)];return {W:mob?420:820,H:mob?930:600,R:R,A:A,B:B,L:L,v:v,mid:{a:[(R[0]+A[0])/2,R[1]],o:[R[0],(R[1]+B[1])/2],h:[(A[0]+B[0])/2,(A[1]+B[1])/2]}};}
function labelText(st,key,d,step,interactive){if(st.mode==='angle'){if(key===st.known||key===st.second)return fmt(d.v[key],2)+' '+st.unit;return step>=9&&!interactive?fmt(d.v[key],2):'';}
 if(key===st.known)return fmt(st.given,2)+' '+st.unit;if(key===st.unknown)return step>=10&&!interactive?fmt(d.answer,st.dp)+' '+st.unit:'x';return step>=11&&!interactive?fmt(d.v[key],2):'';}
function narr(st,idx){var d=details(st),f=formula(st),name=st.mode==='angle'?'the angle':NAMES[st.unknown].toLowerCase();var lines=[
 'First find the right angle. The green side facing it is the hypotenuse.',
 st.mode==='angle'?'This time the orange acute angle is unknown. We must recover it from two known lengths.':'The orange angle is '+fmt(d.v.theta,1)+' degrees. Side names are measured from this angle.',
 'Opposite faces the orange angle. Adjacent is the shorter side touching it. Hypotenuse faces the square corner.',
 'The question gives '+NAMES[st.known].toLowerCase()+(st.mode==='angle'?' and '+NAMES[st.second].toLowerCase():'')+' and asks you for '+name+'.',
 'We need '+NAMES[d.n].toLowerCase()+' and '+NAMES[d.d].toLowerCase()+'. Those are the two sides in the chosen ratio.',
 'The matching trigonometric ratio is '+d.ratio+'. Select the ratio by its two sides, not by a memorised guess.',
 'Write '+d.ratio+' theta equals '+NAMES[d.n].toLowerCase()+' divided by '+NAMES[d.d].toLowerCase()+'.',
 'Insert the given length or pair of lengths into the ratio. Keep the fraction order correct.',
 st.mode==='angle'?'Both sides are known. First divide, then take inverse '+d.ratio+' to recover the angle.':f[1]+'. We are solving for '+name+'.',
 st.mode==='angle'?'Use inverse '+d.ratio+' in degree mode. The angle comes from the side ratio.':'Evaluate the trig function using degrees. Keep the calculator value until your final step.',
 'Rounded answer: '+fmt(d.answer,st.dp)+(st.mode==='angle'?' degrees.':' '+st.unit+'.'),
 'Substitute the answer back into '+d.ratio+' theta. The two sides must reproduce the same ratio.',
 'Changing the angle changes which length is needed, but never changes the side-role rule.',
 'On the next triangle: label the sides, select the correct fraction, rearrange, calculate and check.'
];return lines[idx]||lines[0];}
function draw(stage,st,opt){opt=opt||{};stage.textContent='';var mob=innerWidth<=540,q=geometry(st,mob),d=details(st),v=d.v,step=opt.step==null?13:opt.step,inter=!!opt.interactive;
 var sv=S.root(q.W,q.H,'Premium neon right-angle triangle trig solver. '+(st.mode==='angle'?'Two given sides find angle theta.':'Given angle and side find a missing length.')+' Chosen ratio '+d.ratio+'.');sv.classList.add('f159-board');
 var g=E('g',{style:'opacity:.12;pointer-events:none'},sv),i;for(i=0;i<9;i++)seg(g,[35+i*42,77],[35+i*42,410],'support',.6);for(i=0;i<8;i++)seg(g,[32,93+i*43],[mob?391:430,93+i*43],'support',.6);
 path(sv,'M'+q.R.join(' ')+' L'+q.A.join(' ')+' L'+q.B.join(' ')+' Z','op',4);
 seg(sv,q.R,q.A,'given',5);seg(sv,q.R,q.B,'support',5);seg(sv,q.A,q.B,'result',5.2);
 path(sv,'M'+(q.R[0]+22)+' '+q.R[1]+' L'+(q.R[0]+22)+' '+(q.R[1]-22)+' L'+q.R[0]+' '+(q.R[1]-22),'focus',3);
 // Exact arc centred at the reference angle endpoint A.
 var rr=35,arcx=q.A[0]-rr,arcy=q.A[1],end=[q.A[0]-rr*Math.cos(v.theta*RAD),q.A[1]-rr*Math.sin(v.theta*RAD)];path(sv,'M'+fmt(arcx,2)+' '+fmt(arcy,2)+' A'+rr+' '+rr+' 0 0 1 '+fmt(end[0],2)+' '+fmt(end[1],2),'focus',3.2);
 chalk(sv,q.A[0]-50,q.A[1]-25,st.mode==='angle'&&(step<10||inter)?'θ ?':'θ '+fmt(v.theta,1)+'°','focus',mob?18:20);
 chalk(sv,mob?207:246,54,'Find the missing '+(st.mode==='angle'?'angle':'side'),'unknown',mob?21:24);
 var labels={a:{pt:[q.mid.a[0],q.mid.a[1]+31],role:'given'},o:{pt:[q.mid.o[0]-16,q.mid.o[1]],role:'support',anchor:'end'},h:{pt:[q.mid.h[0]+17,q.mid.h[1]-12],role:'result',anchor:'start'}};
 Object.keys(labels).forEach(function(k){var it=labels[k],label=labelText(st,k,d,step,inter);if(label)chalk(sv,it.pt[0],it.pt[1],label,it.role,mob?18:21,it.anchor||'middle');if(step>=2||inter){var roleName=k==='a'?'Adj':k==='o'?'Opp':'Hyp';if(!inter||!st.placed||!st.placed[k])chalk(sv,it.pt[0]+(k==='o'?-5:0),it.pt[1]+(k==='a'?21:-22),roleName,it.role,15,it.anchor||'middle');}});
 if(step>=5||inter){var kx=mob?26:475,ky=mob?448:96,bw=mob?368:317,bh=mob?250:297;
 neonBox(sv,kx,ky,bw,bh,'op');chalk(sv,kx+bw/2,ky+30,st.mode==='angle'?'Angle finder':'Side finder','focus',21);
 chalk(sv,kx+bw/2,ky+66,d.ratio+' θ =','focus',19);frac(sv,kx+bw/2,ky+90,NAMES[d.n],NAMES[d.d]);
 if(step>=7||inter){var tx=st.mode==='angle'?fmt(v[d.n],2)+' ÷ '+fmt(v[d.d],2):fmt(v[st.known],2)+' '+st.unit;chalk(sv,kx+bw/2,ky+165,'Known: '+tx,'given',mob?18:20);}
 if(step>=8||inter){var f=formula(st)[0];if(f.length>39){var a=f.indexOf(' = ');chalk(sv,kx+bw/2,ky+200,f.slice(0,a+2),'unknown',18);chalk(sv,kx+bw/2,ky+229,f.slice(a+3),'unknown',18);}else chalk(sv,kx+bw/2,ky+210,f,'unknown',mob?17:19);}
 if(step>=10||inter){var aa=fmt(d.answer,st.dp)+(st.mode==='angle'?'°':' '+st.unit);chalk(sv,kx+bw/2,ky+(mob?242:267),'Answer: '+aa,'result',mob?20:22);}
 }else{chalk(sv,mob?205:610,mob?509:176,'Name the sides first','focus',mob?19:23);}
 // Explore uses built-in F2 SVG pointer capture, with a stable visual scale.
 if(inter){var sy=mob?768:455,sx=mob?45:480,w=mob?329:306;seg(sv,[sx,sy],[sx+w,sy],'support',5);
 var handle=(v.theta-15)/60*w+sx;
 for(i=15;i<=75;i+=15){var pos=sx+(i-15)/60*w;seg(sv,[pos,sy-8],[pos,sy+8],'given',2);chalk(sv,pos,sy+29,i+'°','unknown',15);}
 chalk(sv,sx+w/2,sy-26,'Drag to change θ','focus',19);
 var hd=E('g',{tabindex:'0',role:'slider','data-handle':'theta','aria-label':'Move acute angle by arrow keys or drag, from 15 to 75 degrees','aria-valuemin':'15','aria-valuemax':'75','aria-valuenow':fmt(v.theta,0)},sv);
 NOVA.neonRing(hd,handle,sy,{r:12,role:'focus'});
 var zs=[];for(i=15;i<=75;i+=5){var tx=sx+(i-15)/60*w;zs.push({x:tx-11,y:sy-15,w:22,h:30,id:String(i),kind:'drop'});}
 NOVA.ui.svgDrag(sv,hd,{box:{x:handle-15,y:sy-15,w:30,h:30},zones:function(){return zs;},onDrop:function(id){opt.setTheta(+id);return true;}});
 hd.addEventListener('keydown',function(e){if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(e.key))return;e.preventDefault();var n=e.key==='Home'?15:e.key==='End'?75:clamp(v.theta+(e.key==='ArrowLeft'||e.key==='ArrowDown'?-1:1),15,75);opt.setTheta(n,'theta');});
 var B=q.B,gr=E('g',{tabindex:'0',role:'slider','data-vertex':'b','aria-label':'Drag opposite vertex to alter theta with right angle held fixed'},sv);NOVA.neonRing(gr,B[0],B[1],{r:11,role:'support'});
 var vt=[];for(i=15;i<=75;i+=5){var py=q.R[1]-q.L*Math.sin(i*RAD);vt.push({x:B[0]-7,y:py-6,w:14,h:12,id:String(i),kind:'drop'});}
 NOVA.ui.svgDrag(sv,gr,{box:{x:B[0]-13,y:B[1]-13,w:26,h:26},zones:function(){return vt;},onDrop:function(id){opt.setTheta(+id);return true;}});
 gr.addEventListener('keydown',function(e){if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();opt.setTheta(clamp(v.theta+(e.key==='ArrowLeft'||e.key==='ArrowDown'?-1:1),15,75),'vertex-b');});
 // Second constrained vertex: horizontal adjacent leg, the right angle stays fixed.
 var av=E('g',{tabindex:'0',role:'slider','data-vertex':'a','aria-label':'Drag the adjacent vertex along the horizontal leg while preserving the square corner'},sv);
 NOVA.neonRing(av,q.A[0],q.A[1],{r:10,role:'given'});
 var atargets=[];for(i=15;i<=75;i+=10){var ax=q.R[0]+q.L*Math.cos(i*RAD);atargets.push({x:ax-5,y:q.A[1]-6,w:10,h:12,id:String(i),kind:'drop'});}
 NOVA.ui.svgDrag(sv,av,{box:{x:q.A[0]-13,y:q.A[1]-13,w:26,h:26},zones:function(){return atargets;},onDrop:function(id){opt.setTheta(+id);return true;}});
 av.addEventListener('keydown',function(e){if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();opt.setTheta(clamp(v.theta+(e.key==='ArrowLeft'||e.key==='ArrowDown'?-1:1),15,75),'vertex-a');});

 var names={a:['Adjacent','given'],o:['Opposite','support'],h:['Hypotenuse','result']},trayY=mob?858:540,tx0=mob?11:485,bw=mob?124:99;
 Object.keys(names).forEach(function(k,j){var ar=names[k],placed=!!(st.placed&&st.placed[k]),mid=q.mid[k],x=placed?clamp(mid[0]-bw/2,5,q.W-bw-4):tx0+j*(bw+8),y=placed?clamp(mid[1]-25,82,q.H-69):trayY;
 var gg=E('g',{tabindex:'0',role:'button','data-label':k,'aria-label':'Drag '+ar[0]+' card to its correct side or press Enter to place or remove'},sv);neonBox(gg,x,y,bw,34,ar[1]);chalk(gg,x+bw/2,y+24,ar[0],ar[1],mob?17:16);
 var zones=Object.keys(names).map(function(id){var p=q.mid[id];return {x:p[0]-38,y:p[1]-33,w:76,h:66,id:id,kind:'drop'};});if(placed)zones.push({x:tx0-4,y:trayY-8,w:bw*3+28,h:52,id:'remove',kind:'remove'});
 NOVA.ui.svgDrag(sv,gg,{box:{x:x,y:y,w:bw,h:34},zones:function(){return zones;},onDrop:function(id){if(id!==k){st.feedback='That is not the '+ar[0].toLowerCase()+' side. Look relative to theta.';opt.update();return false;}st.placed[k]=true;emit('label',k);st.feedback='Correct. The '+ar[0].toLowerCase()+' side is now labelled.';opt.update();return true;},onRemove:function(){st.placed[k]=false;st.feedback=ar[0]+' returned to the tray.';opt.update();}});
 gg.addEventListener('keydown',function(ev){if(ev.key!=='Enter'&&ev.key!==' ')return;ev.preventDefault();st.placed[k]=!st.placed[k];emit('label',k);opt.update(k);});
 });
 }
 stage.appendChild(sv);NOVA.scene.helperStrip(stage,opt.pose||'explain',opt.say||narr(st,step));
 if(opt.animate&&!NOVA.reducedMotion()){var draw=sv.querySelector('.nv-neon-tube');if(draw){draw.style.opacity='.28';M.tween(470,function(t){if(draw.isConnected)draw.style.opacity=String(.28+.72*t);},M.ease.out,()=>{if(draw.isConnected)draw.style.opacity='1';});}}
 return sv;
}
function stepRender(i,stage){var st=clone(CONFIG.presets[CONFIG.preset]);if(st.mode==='angle'){st.fixedHyp=Math.hypot(st.a,st.o);}draw(stage,st,{step:i,pose:STEPS[i].pose,say:narr(st,i),animate:true});}
var DEF={id:ID,title:'Trig Solver',config:CONFIG,steps:STEPS,render:stepRender,
 alt:'Interactive premium neon right-angled triangle that solves lengths using sine cosine tangent and angles using inverse functions.',
 staticAlt:'Side finder: sin θ = opposite/hypotenuse; cos θ = adjacent/hypotenuse; tan θ = opposite/adjacent. Solve missing length with multiplication or division. Angle finder: use inverse trig of known-side ratio. Work in degrees.',
 exploreIntro:'Choose a missing-side or inverse-angle preset. Drag the angle marker, reposition the constrained vertex or assign side-role labels. Compare the exact working with the neon triangle.',
 explore:function(panel,stage,api){var st=clone(CONFIG.presets[CONFIG.preset]);if(st.mode==='angle')st.fixedHyp=Math.hypot(st.a,st.o);st.placed={};st.feedback='Move the angle marker or place the three side-name cards.';
 var preset=H('select',{class:'nova-input','aria-label':'Choose side or angle solver preset'});Object.keys(CONFIG.presets).forEach(k=>preset.appendChild(H('option',{value:k,text:CONFIG.presets[k].label})));preset.value=CONFIG.preset;
 var slider=H('input',{type:'range',min:'15',max:'75',step:'1',value:fmt(sides(st).theta,0),'aria-label':'Acute reference angle in degrees'});
 var feedback=H('div',{class:'f159-output','aria-live':'polite'});
 function update(focus){slider.value=fmt(sides(st).theta,0);draw(stage,st,{step:13,interactive:true,pose:Object.values(st.placed).filter(Boolean).length===3?'celebrate':'ruler',say:st.feedback,update:update,setTheta:changeTheta});var d=details(st);feedback.textContent='θ = '+fmt(d.v.theta,1)+'°. '+NAMES[d.need]+' = '+fmt(d.answer,st.dp)+(st.mode==='angle'?'°':' '+st.unit)+'. '+st.feedback;
 if(focus){var q=stage.querySelector('[data-handle="'+focus+'"], [data-label="'+focus+'"], [data-vertex="'+String(focus).replace('vertex-','')+'"]');if(q)q.focus({preventScroll:true});}}
 function changeTheta(t,focus){t=clamp(+t,15,75);if(st.mode==='angle'){st.a=st.fixedHyp*Math.cos(t*RAD);st.o=st.fixedHyp*Math.sin(t*RAD);}else st.theta=t;st.placed={};st.feedback='Theta is now '+fmt(t,0)+' degrees. The trig equation and missing value have changed.';emit('theta',t);update(focus);}
 preset.onchange=function(){CONFIG.preset=preset.value;st=clone(CONFIG.presets[CONFIG.preset]);if(st.mode==='angle')st.fixedHyp=Math.hypot(st.a,st.o);st.placed={};st.feedback='New preset loaded. Identify the correct pair of sides.';emit('preset',CONFIG.preset);update();};
 slider.oninput=function(){changeTheta(+slider.value);};
 row(panel,[H('label',{text:'Problem preset'}),preset]);row(panel,[H('label',{text:'Angle θ'}),slider]);
 row(panel,[btn('−5°',()=>changeTheta(sides(st).theta-5)),btn('+5°',()=>changeTheta(sides(st).theta+5)),btn('30°',()=>changeTheta(30)),btn('45°',()=>changeTheta(45)),btn('60°',()=>changeTheta(60))]);
 row(panel,[btn('Reset',function(){st=clone(CONFIG.presets[CONFIG.preset]);if(st.mode==='angle')st.fixedHyp=Math.hypot(st.a,st.o);st.placed={};st.feedback='Original example restored.';update();})]);panel.appendChild(feedback);update();CONFIG._explore={state:()=>st,select:k=>{preset.value=k;preset.onchange();},setTheta:changeTheta,paint:update};
 },
 challenge:function(panel,api,stage){var Q=[
  {preset:'sinOpp',q:'Hypotenuse 12 cm, θ = 30°. Find opposite to 1 decimal place.',hint:'SOH: opposite = 12 × sin 30°. Multiply by the hypotenuse.',dp:1},
  {preset:'cosAdj',q:'Hypotenuse 14 cm, θ = 60°. Find adjacent to 1 decimal place.',hint:'CAH: adjacent = 14 × cos 60°.',dp:1},
  {preset:'tanOpp',q:'Adjacent 8 m, θ = 35°. Find opposite to 1 decimal place.',hint:'TOA: opposite = 8 × tan 35°.',dp:1},
  {preset:'sinHyp',q:'Opposite 7 cm, θ = 40°. Find hypotenuse to 1 decimal place.',hint:'SOH: hypotenuse = 7 ÷ sin 40°. Do not multiply.',dp:1},
  {preset:'cosHyp',q:'Adjacent 6 m, θ = 55°. Find hypotenuse to 1 decimal place.',hint:'CAH: hypotenuse = 6 ÷ cos 55°.',dp:1},
  {preset:'tanAdj',q:'Opposite 9 cm, θ = 38°. Find adjacent to 1 decimal place.',hint:'TOA: adjacent = 9 ÷ tan 38°.',dp:1},
  {preset:'inverseSin',q:'Opposite 6 cm and hypotenuse 10 cm. Find angle θ to 1 decimal place.',hint:'Use sin⁻¹(6 ÷ 10), with your calculator in degrees.',dp:1},
  {preset:'inverseCos',q:'Adjacent 8 cm and hypotenuse 13 cm. Find angle θ to 1 decimal place.',hint:'Use cos⁻¹(8 ÷ 13), not sine.',dp:1},
  {preset:'inverseTan',q:'Opposite 7 m and adjacent 9 m. Find angle θ to 1 decimal place.',hint:'Use tan⁻¹(7 ÷ 9) in degrees.',dp:1},
  {preset:'gcse',q:'GCSE: adjacent 9 cm and θ = 47°. Find hypotenuse to 2 decimal places.',hint:'Use 9 ÷ cos 47°. Keep full precision until rounding.',dp:2}
 ];Q.forEach(x=>{var preset=CONFIG.presets[x.preset];x.st=clone(preset);x.ans=details(preset).answer;});
 function check(t,guess){if(!Number.isFinite(guess))return [false,'Enter a finite number without units.'];var unit=t.st.mode==='angle'?'°':' '+t.st.unit;
 if(Math.abs(guess-t.ans)<Math.pow(10,-t.dp)/2+1e-8)return [true,'Correct: '+fmt(t.ans,t.dp)+unit+'. The ratio and the triangle agree.'];
 var d=details(t.st),theta=d.v.theta*RAD,mult=d.v[t.st.known]*(d.ratio==='sin'?Math.sin(theta):d.ratio==='cos'?Math.cos(theta):Math.tan(theta));
 if(t.st.mode==='angle'){if(guess>0&&guess<1.05)return [false,'That is the side ratio, not an angle. Use inverse '+d.ratio+' in degree mode.'];if(Math.abs(guess-(90-t.ans))<.12)return [false,'You may have used the complementary angle or swapped opposite and adjacent.'];}
 else{if(Math.abs(guess-mult)<.11 && t.st.unknown=== 'h')return [false,'You multiplied when the unknown was the hypotenuse. Divide the given side by the trig ratio.'];if(Math.abs(guess-d.v.h)<.12 && t.st.unknown!=='h')return [false,'That is the hypotenuse. Check which side is actually unknown.'];}
 if(guess<0)return [false,'A right-triangle side length or acute angle must be positive.'];return [false,t.st.mode==='angle'?'Identify both given sides, divide in the correct order, then use inverse trig in degrees.':'Choose the ratio containing the known and unknown sides, then rearrange for x.'];}
 function show(i){var st=clone(Q[i].st);if(st.mode==='angle')st.fixedHyp=Math.hypot(st.a,st.o);draw(stage,st,{step:7,pose:'think',say:'The orange angle or the x-marked side is the unknown. Read only the numerical givens and select the matching ratio.'});}
 var tasks=Q.map(t=>({q:t.q,build:NOVA.entryTask('Answer without units',ID),check:v=>check(t,v),hint:t.hint,solve:ctl=>{var e=ctl.querySelector('input');if(e){e.value=fmt(t.ans,t.dp);e.dispatchEvent(new Event('input',{bubbles:true}));}}}));
 NOVA.challengeRun(panel,api,tasks,show,CONFIG);CONFIG._challengeQuestions=Q;CONFIG._check=check;
 }
};
(function(){function active(){var d=NOVA.ui._drag;return d&&d.el&&d.el.closest&&d.el.closest('#'+ID)?d:null;}
 document.addEventListener('pointermove',function(e){if(!e.isTrusted)return;var d=active();if(!d)return;d.el.dispatchEvent(new PointerEvent('pointermove',{pointerId:e.pointerId,pointerType:e.pointerType,clientX:e.clientX,clientY:e.clientY,buttons:e.buttons,bubbles:false,cancelable:true}));},true);
 document.addEventListener('pointerup',function(e){var d=active();if(d)d.up(e);},true);
 document.addEventListener('pointercancel',function(e){var d=active();if(d)d.cancel(e);},true);
 window.addEventListener('blur',function(){var d=active();if(d)d.cancel();});})();
NOVA.bankMount({id:ID,num:'F15·09',title:'Trig Solver',def:DEF,
 years:'Y9-032 finding trigonometric side lengths; Y9-033 inverse-trigonometric angles; GCSE extensions.',
 linked:['F0-02','F0-03','F14-11','F15-06 (ratio builder)','F15-07 (angle slider)','F15-08 (unit circle)'],spec:{
 purpose:'Solve for an unknown leg or hypotenuse with direct sine/cosine/tangent, or for the reference acute angle with inverse trig.',
 params:'Reference angle, known side(s), target unknown, length unit, accuracy, related trig function; exact internally.',
 presets:'Y9-032 six side problems; Y9-033 three inverse-angle problems; GCSE division to two decimals.',
 steps:'14 teaching states from right angle and side-role identification to proper stacked fraction, substitution, rearranging, evaluation, rounding and checking.',
 interactions:'Watch timeline and Sir Bob narration slots; Guided scaffold; Explore constrained vertex/angle drag, snap labels and live solution; ten checked Challenge questions.',
 traps:'Swapping O/A/H; selecting wrong trig ratio; multiplying rather than dividing for hypotenuse; inverse trig vs ordinary trig; early rounding; radians rather than degrees.',
 gcse:'Degree-mode inverse trig, precise hypotenuse division, two-decimal outputs and one-step checking.'}});
var lg=document.getElementById('log');if(lg){var fn=e=>{lg.textContent=new Date(e.time).toLocaleTimeString()+' '+e.type+' '+JSON.stringify(e.detail)+'\n'+lg.textContent.slice(0,4500);};NOVA.events.history().forEach(fn);NOVA.events.on('*',fn);document.getElementById('clearlog').onclick=function(){lg.textContent='';};}
})();
