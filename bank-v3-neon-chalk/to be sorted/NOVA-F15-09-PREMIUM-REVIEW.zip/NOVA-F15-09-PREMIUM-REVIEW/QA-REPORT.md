# NOVA F15-09 — Trig Solver | Review QA

**Status:** COMPLETED FOR OWNER REVIEW — **not** GOLD-approved. No repository changes, commits, uploads or pushes.

## Source grounding / non-drift

- Canonical private-repository specification: `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, section `F15-09 Trig solver`.
- Current handover: `bank-v3-neon-chalk/HANDOVER-v3.md`.
- Visual and interaction source: actual delivered `NOVA-F15-07-Angle-Slider-Ratio-Table.html` and F15-06/F15-08 comparative review files.
- Embedded NOVA shared core SHA-256 in F15-07: `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc`.
- Embedded NOVA shared core SHA-256 in F15-09: `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc` — **identical**, not rewritten or replaced.
- The local scoped CSS and engine logic are custom to F15-09. Fonts and mascot artwork are inherited from the unchanged embedded core; only one mascot is docked inside the learning stage. Bob narration strip uses the existing core.
- Offline-capable standalone HTML contains both core and complete engine scripts inline. Browser `set_content()` passed without local network calls.

## Maths requirements and evidence

- `source/F15-09-engine.js`: `sides()` computes exact right-triangle geometry with sin/cos/tan, `details()` selects each ratio based on the known and target sides, `formula()` distinguishes multiplying vs dividing, and `draw()` uses `NOVA.neonPath`, `NOVA.neonBox`, `NOVA.chalkText`, `NOVA.neonRing`, `NOVA.ui.svgDrag`.
- `source/F15-09-engine.js`: 10 presets cover Y9-032 missing opposite, adjacent, hypotenuse using all 3 ratios; Y9-033 inverse sine/cosine/tangent; GCSE two-decimal hypotenuse.
- Traditional stacked fraction display: `frac()` uses chalk numerator above core neon fraction bar above denominator.
- All 10 expected values independently computed in Python and compared with the JavaScript solver at both widths. Check `tests/stress-results.json`, label **Independent expected answers all agree**.
- All 10 displayed challenge answers were accepted to their specified rounding accuracy; incorrect values rejected. `tests/stress-results.json` shows normal and rounded answers plus specific diagnostic feedback for inverted/inverse ratio and multiplication-instead-of-division.
- 14 Watch/Guided teaching states follow from side identification to fraction, substitution, rearrangement, degrees, rounding, verification and transfer. These are configured in `source/F15-09-engine.js` `STEPS` and narrated by `narr()`.

## Browser and interaction test scope

- Browser: headless Chromium (`/usr/bin/chromium`), reduced-motion enabled, viewports **380 × 950** and **1280 × 950**.
- Screens: screenshots/380-watch.png, 380-guided.png, 380-explore.png, 380-challenge.png and desktop equivalents. Further inverse-sine, missing-hypotenuse and GCSE screenshots are included at both widths.
- Browser suite: **116/116 checks passed**. Includes 4 modes; 10 presets; correct geometry; real mouse angle slider 30°→55° and one-step 55°→20°; invalid drop recovery; opposite vertex drag; keyboard increment, Home, End; keyboard label toggling; Escape cancel; challenge validation and an actual answer submission. Test: `tests/stress_f1509.py`, output: `tests/stress-results.json`.
- Focused pointer suite: **12/12 checks passed**. Includes real mouse adjacent vertex drag at both widths, each of 3 role label cards snapped onto its mathematical side, re-grab and red tray removal, and no stranded objects. Test: `tests/labels_f1509.py`, output: `tests/label-pointer-results.json`.
- **Combined documented results: 128/128 passed, 0 failed.** These refer to the recorded test assertions, not a claim of exhaustive proof across devices/browsers.
- No page exceptions occurred during the two-viewport automated suite.

## Visual review observations

- 380px screenshots reviewed for headline placement, proportional triangle geometry, right-angle marker, fractions, readable stage labels, mobile stacking and mascot position. Solution-card/angle-marker spacing was corrected and the checks rerun after that correction.
- Desktop screenshots reviewed for drawing-card balance and stage coverage; the mathematical drawing, working panel and tutor use the original dark neon-chalk core.
- The scene has one helper in the stage and one Bob narration strip with no additional helper portrait. All 14 screenshots show correct stage styling.
- Print static fallback is supplied by shared core plus local print CSS; **no physical printer output test was performed**.
- Touchscreen hardware, Firefox and Safari have **not** been tested; these remain manual review checks for the owner.

## Final review gate

Build is **ready for owner review**, not GOLD. Owner to check real mobile touch interactions, spoken tutor voice pronunciation, wording, and visual polish before approving and before any future GitHub update.
