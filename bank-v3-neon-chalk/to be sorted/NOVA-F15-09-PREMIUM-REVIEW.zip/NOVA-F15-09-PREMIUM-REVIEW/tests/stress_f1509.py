"""F15-09 independent browser / maths / pointer QA. Run: python tests/stress_f1509.py"""
import json,math,re,sys,hashlib
from pathlib import Path
from playwright.sync_api import sync_playwright
BASE=Path('/mnt/data');src=(BASE/'NOVA-F15-09-Trig-Solver.html').read_text();OUT=BASE/'f15-reference'/'F15-09-QA';OUT.mkdir(exist_ok=True)
checks=[]
def ck(width,name,passed,detail=''):
 checks.append({'viewport':width,'test':name,'passed':bool(passed),'detail':str(detail)[:280]})
 print(('PASS' if passed else 'FAIL'),width,name,str(detail)[:90],flush=True)

def on_board(page,x,y):
 return page.evaluate('''([x,y])=>{let s=document.querySelector('.f159-board'); let p=s.createSVGPoint();p.x=x;p.y=y;let pt=p.matrixTransform(s.getScreenCTM());return [pt.x,pt.y]}''',[x,y])
def drag(page,a,b,steps=8):
 xa,ya=on_board(page,*a);xb,yb=on_board(page,*b)
 page.mouse.move(xa,ya);page.mouse.down();page.mouse.move(xb,yb,steps=steps);page.mouse.up();page.wait_for_timeout(120)

with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
 for width in (380,1280):
  page=browser.new_page(viewport={'width':width,'height':950},reduced_motion='reduce');errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
  page.set_content(src,wait_until='domcontentloaded');page.wait_for_timeout(100)
  ck(width,'Canonical NOVA core present',bool(page.evaluate('typeof NOVA.bankMount === "function" && typeof NOVA.ui.svgDrag === "function" && typeof NOVA.neonPath === "function"')))
  ck(width,'Four modes loaded',len(page.locator('.nova-tab').all_text_contents())==4)
  ck(width,'Correct header',page.locator('#nova-header').get_attribute('data-run').endswith('F15-09'))
  ck(width,'No JavaScript errors on load',not errors,errors)
  js=page.evaluate('''()=>{let m=window.NOVA_F15_09_MATH,c=window.NOVA_F15_09_CONFIG;return Object.entries(c.presets).map(([k,p])=>({key:k,mode:p.mode,theta:m.sides(p).theta,correct:m.details(p).answer,ratio:m.details(p).ratio, a:m.sides(p).a,o:m.sides(p).o,h:m.sides(p).h, given:p.given,unit:p.unit,known:p.known}));}''')
  ck(width,'Ten named curriculum presets',len(js)==10)
  ck(width,'All preset angles acute',all(0<x['theta']<90 for x in js))
  ck(width,'All preset geometries satisfy Pythagoras',all(abs(x['h']**2-x['a']**2-x['o']**2)<1e-9 for x in js))
  ck(width,'All preset answers finite positive',all(math.isfinite(x['correct']) and x['correct']>0 for x in js))
  ck(width,'All ratio selections correct',all(x['ratio'] in ('sin','cos','tan') for x in js))
  expected={'sinOpp':6.,'cosAdj':7.,'tanOpp':8*math.tan(math.radians(35)),'sinHyp':7/math.sin(math.radians(40)),'cosHyp':6/math.cos(math.radians(55)),'tanAdj':9/math.tan(math.radians(38)),'inverseSin':math.degrees(math.asin(.6)),'inverseCos':math.degrees(math.acos(8/13)),'inverseTan':math.degrees(math.atan2(7,9)),'gcse':9/math.cos(math.radians(47))}
  ck(width,'Independent expected answers all agree',all(abs(x['correct']-expected[x['key']])<1e-9 for x in js))
  for mode in ['Watch','Guided','Explore','Challenge']:
   page.get_by_text(mode,exact=True).first.click();page.wait_for_timeout(60)
   ck(width,mode+' loads without page error',not errors,errors)
   ck(width,mode+' draws premium SVG',bool(page.locator('.nova-stage .f159-board').count()))
   page.screenshot(path=str(OUT/f'{width}-{mode.lower()}.png'),full_page=True,animations='disabled')
  page.get_by_text('Explore',exact=True).first.click()
  st=lambda:page.evaluate('window.NOVA_F15_09_CONFIG._explore.state()')
  cfg=page.evaluate('Object.keys(window.NOVA_F15_09_CONFIG.presets)')
  for key in cfg:
   page.evaluate('(k)=>window.NOVA_F15_09_CONFIG._explore.select(k)',key)
   ck(width,'Explore preset '+key+' selected',page.evaluate('window.NOVA_F15_09_CONFIG.preset')==key)
   ck(width,'Explore '+key+' triangle drawn',page.locator('.f159-board [data-vertex="b"]').count()==1)
  page.evaluate('window.NOVA_F15_09_CONFIG._explore.select("sinOpp")')
  page.locator('[aria-label="Acute reference angle in degrees"]').evaluate("e=>{e.value=45;e.dispatchEvent(new Event('input',{bubbles:true}))}")
  ck(width,'HTML slider sets θ=45',abs(st()['theta']-45)<1e-6)
  page.locator('[data-handle="theta"]').focus();page.keyboard.press('ArrowLeft');ck(width,'Keyboard lowers θ',st()['theta']==44,st()['theta'])
  page.keyboard.press('Home');ck(width,'Home goes to 15°',st()['theta']==15)
  page.keyboard.press('End');ck(width,'End goes to 75°',st()['theta']==75)
  page.evaluate('window.NOVA_F15_09_CONFIG._explore.setTheta(30)')
  # a real mouse drag, with handles scrolled into view, and a rapid 1-step move.
  page.locator('[data-handle="theta"]').scroll_into_view_if_needed()
  mob=width==380;sx=45 if mob else 480;w=329 if mob else 306;sy=768 if mob else 455
  pth=lambda t:(sx+(t-15)/60*w,sy)
  drag(page,pth(30),pth(55),8);ck(width,'Real mouse drags angle 30°→55°',st()['theta']==55,st()['theta'])
  page.locator('[data-handle="theta"]').scroll_into_view_if_needed()
  drag(page,pth(55),pth(20),1);ck(width,'Fast mouse angle 55°→20°',st()['theta']==20,st()['theta'])
  current=st()['theta'];drag(page,pth(current),(sx+w/2,sy-150),5);ck(width,'Invalid angle drop restores state',st()['theta']==current,st()['theta'])
  ck(width,'No stranded pointer after invalid angle',page.evaluate('!NOVA.ui._drag || !NOVA.ui._drag.el'))
  # constrained opposite vertex drag from current to a grid target
  page.evaluate('window.NOVA_F15_09_CONFIG._explore.setTheta(40)')
  page.locator('[data-vertex="b"]').scroll_into_view_if_needed()
  q=page.evaluate('''()=>{var e=document.querySelector('.f159-board'),h=window.innerWidth<=540,L=h?266:305,Ry=h?376:398,Rx=h?104:135;return {L,Ry,Rx};}''')
  vert=lambda theta:(q['Rx'],q['Ry']-q['L']*math.sin(math.radians(theta)))
  drag(page,vert(40),vert(60),10);ck(width,'Real mouse moves constrained vertex 40°→60°',st()['theta']==60,st()['theta'])
  page.locator('[data-label="o"]').focus();page.keyboard.press('Enter');ck(width,'Keyboard places opposite label',st()['placed'].get('o') is True)
  page.locator('[data-label="o"]').focus();page.keyboard.press('Enter');ck(width,'Keyboard removes opposite label',st()['placed'].get('o') is False)
  page.locator('[data-handle="theta"]').scroll_into_view_if_needed();pt=on_board(page,*pth(60));page.mouse.move(*pt);page.mouse.down();page.keyboard.press('Escape');page.mouse.up()
  ck(width,'Escape returns without stranded drag',page.evaluate('!NOVA.ui._drag || !NOVA.ui._drag.el'))
  page.get_by_text('Challenge',exact=True).first.click();Q=page.evaluate('window.NOVA_F15_09_CONFIG._challengeQuestions.map(q=>({preset:q.preset,ans:q.ans,dp:q.dp,mode:q.st.mode}))')
  ck(width,'Ten challenge tasks',len(Q)==10)
  ck(width,'All expected values rounded accepted',page.evaluate('''()=>window.NOVA_F15_09_CONFIG._challengeQuestions.every(t=>window.NOVA_F15_09_CONFIG._check(t,+t.ans.toFixed(t.dp))[0])'''))
  ck(width,'Unrounded answers accepted',page.evaluate('''()=>window.NOVA_F15_09_CONFIG._challengeQuestions.every(t=>window.NOVA_F15_09_CONFIG._check(t,t.ans)[0])'''))
  ck(width,'Wrong value rejected',page.evaluate('''()=>window.NOVA_F15_09_CONFIG._challengeQuestions.every(t=>!window.NOVA_F15_09_CONFIG._check(t,t.ans+10)[0])'''))
  ck(width,'Angle ratio misconception feedback',page.evaluate('''()=>window.NOVA_F15_09_CONFIG._check(window.NOVA_F15_09_CONFIG._challengeQuestions[6],0.6)[1].includes('ratio')'''))
  ck(width,'Hypotenuse multiplication misconception feedback',page.evaluate('''()=>window.NOVA_F15_09_CONFIG._check(window.NOVA_F15_09_CONFIG._challengeQuestions[3],7*Math.sin(40*Math.PI/180))[1].includes('multiplied')'''))
  # Active answer submission and progress (question 1)
  page.locator('.nova-stage').scroll_into_view_if_needed()
  entry=page.locator('input').filter(has_not=page.locator('[type=range]'))
  f=page.locator('.nova-panel input').first
  try:
   page.get_by_text('Check',exact=True).first.wait_for(timeout=1000)
   answer=page.locator('.nova-panel input').last
   answer.fill('6.0');page.get_by_text('Check',exact=True).first.click()
   ck(width,'Actual Challenge answer submission',page.get_by_text('Correct',exact=False).count()>0)
  except Exception as ex:ck(width,'Actual Challenge answer submission',False,str(ex))
  ck(width,'No console exceptions after interactions',not errors,errors)
  page.close()
 browser.close()
(OUT/'stress-results.json').write_text(json.dumps(checks,indent=2))
print('TOTAL',len(checks),'PASSED',sum(a['passed'] for a in checks),'FAILED',sum(not a['passed'] for a in checks))
sys.exit(1 if any(not a['passed'] for a in checks) else 0)
