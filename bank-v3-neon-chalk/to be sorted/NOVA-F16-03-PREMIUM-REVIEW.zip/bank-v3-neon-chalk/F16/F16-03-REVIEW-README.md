# NOVA F16-03 — Line Graph · Premium Review

Open `F16/F16-03-line-graph.html` in a local browser. It is a complete offline self-contained HTML.

Four teaching modes: Watch (9 progressive steps), Guided, Explore (fixed-time draggable observations, zoom scale, keyboard and exact-value editing), Challenge (restore a source reading, greatest interval increase, critique a cropped axis).

Presets: Y7-072 Temperature and Y7-071 Misleading time-series graphs. Use the controls to switch lesson contexts. Choose modes with the original NOVA mode tabs.

QA records and PNG screenshots: `F16/F16-03-QA.md`, `tests/`, `shots/F16-03/`.

**Built for review, NOT GOLD. No GitHub writes.**
