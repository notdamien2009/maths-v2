from pathlib import Path
import json
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parents[1];html=(p/'F16/F16-03-line-graph.html').read_text();checks=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in (380,1280):
  pg=b.new_page(viewport={'width':width,'height':950},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));pg.set_content(html,wait_until='load',timeout=90000)
  for mode in ('watch','guided','explore','challenge'):
   pg.locator(f'.nova-tab[data-m="{mode}"]').click();pg.wait_for_timeout(45)
   checks.append({'name':f'{width} {mode} rendered, one mascot, no errors or overflow','passed':pg.locator('.f16l-plot').count()==1 and pg.locator('.nova-stage .nv-dock').count()==1 and pg.evaluate('document.documentElement.scrollWidth<=innerWidth+2') and not errors})
   pg.screenshot(path=str(p/'shots'/f'F16-03-{width}-{mode}.png'),full_page=True,animations='disabled')
  pg.locator('.nova-tab[data-m="explore"]').click()
  pg.locator('select[aria-label="Lesson context"]').select_option('misleading')
  pg.locator('select[aria-label="Vertical axis view"]').select_option('10')
  checks.append({'name':f'{width} final corrected zoom label','passed':pg.locator('.f16l-plot').text_content().find('Axis cropped at 10')>=0})
  pg.screenshot(path=str(p/'shots'/f'F16-03-{width}-misleading-zoom.png'),full_page=True,animations='disabled')
  pg.close()
 b.close()
(p/'tests/final-smoke-results.json').write_text(json.dumps({'total':len(checks),'passed':sum(x['passed'] for x in checks),'checks':checks},indent=2))
print('SMOKE',sum(x['passed'] for x in checks),'/',len(checks),[x for x in checks if not x['passed']])
