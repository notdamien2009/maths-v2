from playwright.sync_api import sync_playwright
from pathlib import Path
import json,math,time
P=Path(__file__).resolve().parents[1]; HTML=(P/'F16/F16-03-line-graph.html').read_text()
results=[];console=[]
def t(name,cond,detail=None):
 ok=bool(cond);results.append({'name':name,'passed':ok,'detail':detail});print(('PASS' if ok else 'FAIL'),name,detail or '',flush=True)
def value(pg):return pg.evaluate('NOVA_F16_03_CONFIG._explore.get()')
def dest(pg,i,target):
 return pg.evaluate('''({i,target})=>{let sv=document.querySelector('.f16l-plot'), C=window.NOVA_F16_03_CONFIG, s=C._explore.get(), p=C.presets[C.preset]; let W=innerWidth<=540?{x:67,y:173,w:344,h:374}:{x:112,y:137,w:555,h:363};
 let pt=sv.createSVGPoint();pt.x=W.x+(i/5)*W.w;pt.y=W.y+W.h-(target-s.baseline)/(p.max-s.baseline)*W.h;let z=pt.matrixTransform(sv.getScreenCTM());return {x:z.x,y:z.y};}''',{'i':i,'target':target})
def source(pg,i):
 return pg.evaluate('''i=>{let sv=document.querySelector('.f16l-plot'), C=window.NOVA_F16_03_CONFIG, s=C._explore.get(), p=C.presets[C.preset]; let W=innerWidth<=540?{x:67,y:173,w:344,h:374}:{x:112,y:137,w:555,h:363};let pt=sv.createSVGPoint();pt.x=W.x+(i/5)*W.w;pt.y=W.y+W.h-(s.values[i]-s.baseline)/(p.max-s.baseline)*W.h;let z=pt.matrixTransform(sv.getScreenCTM());return {x:z.x,y:z.y};}''',i)
def scroll(pg):pg.locator('.f16l-plot').scroll_into_view_if_needed(timeout=10000)
def drag(pg,i,target,steps=12):
 scroll(pg);a=source(pg,i);b=dest(pg,i,target);pg.mouse.move(a['x'],a['y']);pg.mouse.down();pg.mouse.move(b['x'],b['y'],steps=steps);pg.mouse.up();pg.wait_for_timeout(450)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in (380,1280):
  pg=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1,reduced_motion='reduce')
  errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('console',lambda m:console.append({'width':width,'type':m.type,'text':m.text}) if m.type=='error' else None)
  pg.set_content(HTML,wait_until='load',timeout=90000);pg.wait_for_timeout(150)
  for mode in ('watch','guided','explore','challenge'):
   pg.locator(f'.nova-tab[data-m="{mode}"]').click();pg.wait_for_timeout(90)
   t(f'{width} {mode} graph rendered',pg.locator('.f16l-plot').count()==1)
   t(f'{width} {mode} stage has one mascot',pg.locator('.nova-stage .nv-dock').count()==1)
   t(f'{width} {mode} no overflow',pg.evaluate('document.documentElement.scrollWidth<=innerWidth+2'))
   t(f'{width} {mode} shared core intact',pg.evaluate("typeof NOVA.neonPlot==='function'&&typeof NOVA.ui.svgDrag==='function'&&typeof NOVA.scene.helperStrip==='function'"))
   pg.screenshot(path=str(P/'shots'/f'F16-03-{width}-{mode}.png'),full_page=True,animations='disabled')
  pg.locator('.nova-tab[data-m="watch"]').click();pg.wait_for_timeout(70)
  for phase,expected in enumerate((0,0,1,2,3,4,6,6,6)):
   pg.evaluate('''i=>{window.F16_03.timeline.pause();window.F16_03.timeline.go(i,'test')}''',phase);pg.wait_for_timeout(75)
   count=pg.locator('.f16l-plot [data-line]').count();pts=pg.locator('.f16l-plot .nv-marker').count()
   t(f'{width} watch phase {phase} continuous line',count==(1 if expected>1 else 0),f'paths {count}')
  pg.locator('.nova-tab[data-m="explore"]').click();pg.wait_for_timeout(100)
  for preset in ('temperature','misleading'):
   pg.locator('select[aria-label="Lesson context"]').select_option(preset)
   d=pg.evaluate(f'NOVA_F16_03_CONFIG.presets.{preset}');q=value(pg)
   t(f'{width} {preset} source values',q['values']==d['values'])
   t(f'{width} {preset} six draggable points',pg.locator('[data-point-handle]').count()==6)
   t(f'{width} {preset} one continuous line',pg.locator('[data-line]').count()==1)
   pg.locator('select[aria-label="Vertical axis view"]').select_option(str(d['crop']))
   t(f'{width} {preset} axis crops without changing data',value(pg)['baseline']==d['crop'] and value(pg)['values']==d['values'])
   pg.locator('select[aria-label="Vertical axis view"]').select_option('0')
   t(f'{width} {preset} restores baseline',value(pg)['baseline']==0)
  pg.locator('select[aria-label="Lesson context"]').select_option('temperature')
  pg.locator('select[aria-label="Choose a reading"]').select_option('2')
  pg.locator('input[aria-label="Set selected measured value"]').fill('13')
  pg.get_by_role('button',name='Set reading').click();t(f'{width} exact entry sets point',value(pg)['values'][2]==13)
  pg.get_by_role('button',name='Increase +1').click();t(f'{width} plus increments',value(pg)['values'][2]==14)
  pg.get_by_role('button',name='Decrease −1').click();t(f'{width} minus decrements',value(pg)['values'][2]==13)
  pg.get_by_role('button',name='Reset graph').click();t(f'{width} reset exact readings',value(pg)['values'][2]==15)
  drag(pg,2,11,12)
  t(f'{width} native mouse drag 15→11',value(pg)['values'][2]==11,value(pg)['values'])
  drag(pg,2,13,1)
  t(f'{width} fast native mouse drag 11→13',value(pg)['values'][2]==13,value(pg)['values'])
  t(f'{width} no stranded active pointer',pg.evaluate('NOVA.ui._drag===null'))
  # dragging X far away should not snap to a reading for another timestamp
  scroll(pg);a=source(pg,2);b=dest(pg,3,9);old=value(pg)['values'][2]
  pg.mouse.move(a['x'],a['y']);pg.mouse.down();pg.mouse.move(b['x'],b['y'],steps=5);pg.mouse.up();pg.wait_for_timeout(300)
  t(f'{width} invalid horizontal drop preserves measurement',value(pg)['values'][2]==old)
  # Escape and pointer cleanup
  scroll(pg);a=source(pg,2)
  pg.mouse.move(a['x'],a['y']);pg.mouse.down();pg.mouse.move(a['x']+13,a['y']-75,steps=4);pg.keyboard.press('Escape');pg.mouse.up();pg.wait_for_timeout(350)
  t(f'{width} Escape cancels pointer',pg.evaluate('NOVA.ui._drag===null'))
  t(f'{width} Escape preserves plotted data',value(pg)['values'][2]==old)
  pg.locator('[data-point-handle="2"]').focus();pg.keyboard.press('ArrowUp');pg.wait_for_timeout(90)
  t(f'{width} keyboard arrow increments point',value(pg)['values'][2]==old+1)
  # Challenge: actual incorrect answer, corrected reading, correct interval, axis judgement
  pg.locator('.nova-tab[data-m="challenge"]').click();pg.wait_for_timeout(90)
  pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(100)
  t(f'{width} challenge wrong reading detected',pg.locator('.nova-fb.bad').count()>0)
  pg.locator('input[aria-label="Correct measured reading"]').fill('15')
  pg.get_by_role('button',name='Plot this reading').click()
  pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(1020)
  t(f'{width} challenge first corrected',pg.locator('.pr-task').inner_text().startswith('Between which consecutive'))
  pg.locator('.rs-opts button').first.click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(160)
  t(f'{width} wrong greatest-increase interval detected',pg.locator('.nova-fb.bad').count()>0)
  pg.locator('.rs-opts button').nth(1).click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(1020)
  t(f'{width} largest increase advances to zoom critique',pg.locator('.pr-task').inner_text().startswith('This graph now'))
  pg.locator('.rs-opts button').nth(1).click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(140)
  t(f'{width} false zero-rule misconception detected',pg.locator('.nova-fb.bad').count()>0)
  pg.locator('.rs-opts button').first.click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(140)
  t(f'{width} correct scale-interpretation accepted',pg.locator('.nova-fb.ok').count()>0)
  t(f'{width} no JS exceptions across whole stress run',not errors,errors)
  pg.close()
 browser.close()
(P/'tests/results.json').write_text(json.dumps({'passed':sum(r['passed'] for r in results),'total':len(results),'failed':[r for r in results if not r['passed']],'tests':results,'console_errors':console},indent=2))
print('SUMMARY',sum(r['passed'] for r in results),'/',len(results),'FAIL',len([r for r in results if not r['passed']]))
