# NOVA F14-10 Congruence Tester — Review QA

**Status:** Owner review, not GOLD approval. **GitHub unchanged.**

## Source and architecture
- Premium shell, NOVA core, embedded NOVA Chalk and mascot artwork are copied unchanged from the supplied F14-09 premium engine (itself based on supplied F0/F2 reference HTML); only the page metadata, a local component stylesheet and F14-10 component code were changed.
- Standalone single HTML with no network imports. One `.nova-stage > .nv-dock` on all modes; no extra mascot outside the stage.
- Four modes: Watch, Guided, Explore, Challenge. The Watch mode uses the core timeline and NOVA.motion easing. A static and reduced-motion fallback is supplied by the core.

## Verified automated checks
- 114/114 browser and interaction checks (`_f14_10_regression.py`): each mode at 380px and 1280px, one mascot per stage, no JS page errors, no horizontal overflow; all seven named KS3 presets' congruence/false results; eight challenge tasks and advancement; keyboard Enter for overlay challenge.
- 12/12 real-pointer tests (`_f14_10_pointer_qa.py`): drag green candidate to original on 380px and 1280px, one mascot after drag, no JS errors, Escape recovery, no stranded drag, keyboard overlay.
- 8 mode screenshots and two SSA evidence screenshots are included for visual inspection.
- SSA trap mathematics: AB=6, BC=4 and included-at-A? **No:** angle A=30 degrees is *not* the included angle between AB and BC, yielding two different positive solutions for AC. These alternatives have equal AB and BC, and angle A, but differ in size and outline. Display scaled uniformly (factor 0.6) for the canvas; the mathematical SSA ambiguity is preserved.
- AAA trap scales the entire triangle by 1.32; lengths therefore differ although angles remain equal.

## Maths teaching check
- SSS: three corresponding side lengths fix the triangle.
- SAS: two corresponding sides and the **included** angle fix the triangle.
- ASA: two corresponding angles and the included side fix the triangle.
- RHS: in right-angled triangles, corresponding hypotenuse and one corresponding side fix the triangle.
- AAA and SSA are insufficient as general congruence conditions; enlargement is not congruence unless scale factor is 1 in magnitude.
- Rigid translation, rotation and reflection preserve side lengths and angles; overlay intentionally displays the final correspondence.

## Visual review still required
Screenshots and automated assertions cannot replace the owner's side-by-side premium visual approval against F0-02 and F2-03, or a full manual touch-device test. No GOLD claim is made.

## Included files
- `F14-10-congruence-tester-PREMIUM.html`
- `screenshots/F14-10-{380,1280}-{watch,guided,explore,challenge}.png`
- `screenshots/F14-10-380-SSA-{stage,overlay}.png`
- `README-QA.md` (this document)
