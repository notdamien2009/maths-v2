# F17-12 · Expected Outcomes — Spec Card

**Family:** F17 Probability and Sets. **Lessons:** Y9-045 Independent events. **Year groups:** Year 9; GCSE extension.

**Purpose:** Calculate a theoretical expected number of independent joint successes using `trials × P(A) × P(B)`, and contrast that expectation with random experimental outcomes. Explain that expected frequencies may be fractional and are not guaranteed observed counts.

**Parameters:** Exact rational P(A) (3/5, 1/2, 2/3, 4/5), P(B) (2/5, 1/3, 1/2, 3/4), planned trials (25, 50, 60, 100, 120, 200, 500), independent simulated trials, four forecast snap choices. **Preset:** Y9-045; parameter variations are not separate engines.

**WATCH:** Identify independence → show probabilities → multiply for AND → multiply by trial count → simulate → compare expected and observed. Each step has Sir Bob narration slots and distinct Pip helper speech; play/pause, step forward/back, scrub, rewind.

**GUIDED:** Why independence justifies the multiplication rule, visual proof and predicted-v-observed comparison.

**EXPLORE:** Change fractions and trials, drag the forecast marker to a valid target, re-grab and replace it or remove it. Actual random trials are independent Bernoulli experiments for both A and B, not deliberately chosen successes. Supplied keyboard equivalents.

**CHALLENGE:** Four checked tasks, including 25/6 ≈ 4.17 expected outcomes, with specific diagnostic feedback for using the wrong single-event chance, adding, or rounding to a whole number prematurely.

**Linked:** F0-02, F0-03, F0-04, F0-06, F17-04, F17-07, F17-11. **GCSE:** Expected frequencies, independence and statistical variability.

**Core:** Exact original embedded NOVA core and NOVA Chalk fonts from F17-11. No changes to source repository, no new mascot or independent drawing system.
