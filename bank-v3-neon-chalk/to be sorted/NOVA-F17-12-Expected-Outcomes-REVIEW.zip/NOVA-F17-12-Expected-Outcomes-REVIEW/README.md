# NOVA F17-12 · Expected Outcomes

This is a **standalone premium review build**, not a GOLD-approved engine.

Open `F17-12-Expected-Outcomes-PREMIUM-REVIEW.html` directly in a browser. No external scripts or fonts are required.

Four tabs: WATCH, GUIDED, EXPLORE and CHALLENGE. In Explore, edit the two independent chances and trial count, drag a forecast token into a snap slot, or use keyboard controls. Then run trials to compare theoretical expectation with observed successes.

**Archive contents:** standalone HTML, specification card, QA report, 20 screenshots, local component JS/CSS and executable Playwright Python QA scripts with generated JSON and logs.

**No GitHub changes were made.** Touchscreen hardware testing and owner GOLD approval remain outstanding.
