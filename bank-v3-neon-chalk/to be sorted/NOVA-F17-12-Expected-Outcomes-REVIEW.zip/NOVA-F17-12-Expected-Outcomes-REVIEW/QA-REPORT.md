# NOVA F17-12 · QA Report — Review Build

**Status:** BUILT FOR OWNER REVIEW — NOT GOLD-APPROVED.  
**Date:** 13 October 2026.  
**Standalone HTML:** `F17-12-Expected-Outcomes-PREMIUM-REVIEW.html`  
**SHA-256 (HTML):** `06d31b8c1da737616c78f4550b0f40eacf2824065b048e821d29c1b76ed44853`  
**Original embedded core:** byte-for-byte identical to F17-11; core SHA-256 `bc8b287a321aff1b3aeda8383879c68a6e7abf7542a6a9b72576a1c027bc4c6e`.  
**Repository changes:** NONE (private GitHub accessed read-only).

## Executed acceptance checks

| Suite | Passed | Failed | Evidence |
|---|---:|---:|---|
| Chromium viewport, rendering, maths, mouse dragging, invalid drop, Escape recovery, keyboard, trials | 66 | 0 | `tests/qa.py`, `tests/core-results.json`, `tests/core.log` |
| All 4 Challenge items, wrong-answer feedback and correct marking at both widths | 18 | 0 | `tests/challenge.py`, `tests/challenge-results.json`, `tests/challenge.log` |
| Actual normal-motion scrub, pointer cancellation and focus/keyboard | 12 | 0 | `tests/motion.py`, `tests/motion-results.json`, `tests/motion.log` |
| 32 exact rational probability/trials combinations × 3 invariants | 96 | 0 | `tests/math.py`, `tests/math-results.json`, `tests/math.log` |
| Watch play, pause, forward, back, scrub, reset at 380 and 1280 | 12 | 0 | `tests/timeline.py`, `tests/timeline-results.json`, `tests/timeline.log` |
| **TOTAL** | **204** | **0** | Actual executed test logs and saved JSON |

## Structural and visual evidence

- Original unchanged core JavaScript and fonts: standalone HTML's first script and inline stylesheet. Core SHA-256 verified programmatically against the F17-11 file.
- Drawing construction uses `NOVA.neonBox`, `NOVA.neonPath`, `NOVA.neonRing`, `NOVA.neonLine` and `NOVA.chalkText`; inspect `source/F17-12.engine.js` around lines 27–72. No alternative SVG library.
- Stacked numerator, neon fraction bar, denominator: `source/F17-12.engine.js` line 20. Screenshot `screenshots/F17-12-380-watch.png`.
- Single original helper inside learning stage: 380/1280 all-four-mode screenshot series, plus browser DOM assertion exactly one `.nova-stage .nv-dock` in every mode.
- Green valid drop zones, removal area, snap, re-grab and keyboard alternative: `source/F17-12.engine.js` line 72, core suite mouse and cancellation assertions.
- Seeded independent two-event experiments, reset trial history on parameter change: `source/F17-12.engine.js` line 17; observed tally always between zero and completed trials.
- `WATCH` stepper / named narration slots: line 93; timeline and normal-motion reports.
- Accessible Explore parameters, changing exact ratios and trial count: line 94; mobile+desktop Explore screenshots including non-integer expectation.
- No answer revealed on Challenge stage (question still displays event probabilities): line 115; Challenge screenshots and `core-results.json` assertion.
- All eight viewport/mode screenshots and twelve extra screenshots: **20 screenshot PNGs**.
- Engine registry / spec card: `source/F17-12.engine.js` line 127; `SPEC-CARD.md`.

## Mathematical cases checked

- Base Y9-045: P(A)=3/5, P(B)=2/5, joint chance=6/25, N=100, expected=24.
- Alternatives: P(A)=1/2, P(B)=1/3, N=60, expected=10; P(A)=2/3, P(B)=3/4, N=80, expected=40.
- Fractional expected value: P(A)=1/2, P(B)=1/3, N=25 gives 25/6 ≈ 4.17 — correctly accepted to two decimals; not rounded to an integer.
- All 4 × 4 × 2 combinations of independent probability pairs and N∈{25,100} tested in Chromium for exact joint fraction, expected result and distinct prediction options (96 checks).

## Not tested / acceptance limitations

- Physical touchscreen dragging on iOS/Android hardware was **not performed**; browser pointer events were tested in Chromium using actual mouse movement, plus synthetic pointercancel and keyboard controls.
- Safari and Firefox cross-browser compatibility was **not tested**.
- Automated assertions do not replace the owner's teaching, visual, and learner psychology review.
- **No GOLD approval is implied.** Owner decision required.
