import asyncio,json,math
from fractions import Fraction
from pathlib import Path
from playwright.async_api import async_playwright
checks=[]
def ck(name,passed,detail=None):checks.append({'name':name,'passed':bool(passed),'detail':detail})
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await b.new_page(viewport={'width':1280,'height':900},reduced_motion='reduce');page.set_default_timeout(5000)
  await page.set_content(Path('/mnt/data/F17-12-Expected-Outcomes-PREMIUM-REVIEW.html').read_text());await page.locator('button').filter(has_text='Explore').first.click()
  aa=[(3,5),(1,2),(2,3),(4,5)];bb=[(2,5),(1,3),(1,2),(3,4)]
  for n in [25,100]:
   for a in aa:
    for q in bb:
     await page.evaluate('(v)=>NOVA_F17_12_CONFIG._explore.set({a:v.a,b:v.b,planned:v.n})',{'a':a,'b':q,'n':n})
     x=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
     f=Fraction(*a)*Fraction(*q)
     ck(f'{a}×{q}, N={n} exact independent probability', x['prob']==[f.numerator,f.denominator], str(x['prob']))
     ck(f'{a}×{q}, N={n} exact expected count', abs(x['expected']-float(n*f))<1e-8,str(x['expected']))
     ck(f'{a}×{q}, N={n} four distinct forecast targets',len(set(x['choices']))==4,str(x['choices']))
  await b.close()
 Path('/mnt/data/f17_12_work/tests/math-results.json').write_text(json.dumps({'passed':sum(v['passed'] for v in checks),'total':len(checks),'checks':checks},indent=2))
 print('RESULT',sum(v['passed'] for v in checks), '/',len(checks))
 if sum(v['passed'] for v in checks)!=len(checks):print('FAILURES', [x for x in checks if not x['passed']][:8])
asyncio.run(main())
