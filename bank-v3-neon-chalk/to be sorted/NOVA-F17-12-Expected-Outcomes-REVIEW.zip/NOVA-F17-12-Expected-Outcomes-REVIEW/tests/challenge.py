import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
FILE=Path('/mnt/data/F17-12-Expected-Outcomes-PREMIUM-REVIEW.html')
rec=[]
def ck(msg,ok,detail=''):
 rec.append({'name':msg,'passed':bool(ok),'detail':str(detail)[:350]});print(('PASS' if ok else 'FAIL'),msg,detail)
async def run(page,w):
 errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 await page.set_content(FILE.read_text(),wait_until='load');await page.locator('button').filter(has_text='Challenge').first.click();await page.wait_for_timeout(200)
 answers=[('40','24'),('30','10'),('60','40'),('4','4.17')]
 for i,(bad,good) in enumerate(answers):
  q=page.locator('.nova-engine').locator('input[aria-label="Expected successes"]'); await q.fill(bad)
  await page.get_by_role('button',name='Check',exact=True).click();await page.wait_for_timeout(140)
  txt=(await page.locator('main').inner_text())
  ck(f'{w} question {i+1} wrong feedback',any(x in txt.lower() for x in ['uses the probability','counts','not every','not necessarily','incorrect','try again','denominator']),txt[-290:])
  await q.fill(good);await page.get_by_role('button',name='Check',exact=True).click();await page.wait_for_timeout(190)
  txt=await page.locator('main').inner_text()
  ck(f'{w} question {i+1} correct',('Correct' in txt or 'correct' in txt or 'next' in txt.lower()),txt[-330:])
  await page.screenshot(path=f'/mnt/data/f17_12_work/screenshots/F17-12-{w}-challenge-q{i+1}.png',full_page=True)
  if i<3:
   n=page.get_by_role('button',name='Next',exact=False)
   print('next btns',await page.locator('.nova-engine button').all_text_contents())
   if await n.count():await n.last.click()
   else:
    # advance may be via automatic progression, check text
    await page.wait_for_timeout(500)
  await page.wait_for_timeout(120)
 ck(f'{w} no Challenge exceptions',not errs,errs)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for w in [380,1280]:
   page=await b.new_page(viewport={'width':w,'height':900},reduced_motion='reduce');page.set_default_timeout(5000)
   try:await run(page,w)
   except Exception as e: ck(f'{w} entire Challenge completed',False,str(e))
   await page.close()
  await b.close()
 Path('/mnt/data/f17_12_work/tests/challenge-results.json').write_text(json.dumps({'passed':sum(x['passed'] for x in rec),'total':len(rec),'checks':rec},indent=2))
 print('TOTAL',sum(x['passed'] for x in rec),'/',len(rec))
asyncio.run(main())
