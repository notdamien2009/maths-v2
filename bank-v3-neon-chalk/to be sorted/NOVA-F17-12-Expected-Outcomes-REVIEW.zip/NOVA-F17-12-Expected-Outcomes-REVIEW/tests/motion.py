import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
FILE=Path('/mnt/data/F17-12-Expected-Outcomes-PREMIUM-REVIEW.html')
checks=[]
def ck(k,v,d=''):
 checks.append({'name':k,'passed':bool(v),'detail':str(d)[:230]});print(('PASS' if v else 'FAIL'),k,str(d)[:120])
async def run(page,w):
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 await page.set_content(FILE.read_text(),wait_until='load');await page.wait_for_timeout(150)
 slider=page.locator('input[aria-label="Scrub through steps"]')
 ck(f'{w} Watch scrub control',await slider.count()==1)
 await slider.evaluate('e=>{e.value="2";e.dispatchEvent(new Event("input",{bubbles:true}));e.dispatchEvent(new Event("change",{bubbles:true}));}')
 await page.wait_for_timeout(180)
 ck(f'{w} Watch scrub redraw',await page.locator('svg.f1712-plot').count()==1)
 await page.locator('button').filter(has_text='Explore').first.click();await page.wait_for_timeout(80)
 p=page.locator('[data-forecast]');await p.scroll_into_view_if_needed();bbox=await p.bounding_box()
 await page.keyboard.press('Tab');await p.focus();await page.keyboard.press('ArrowRight');await page.wait_for_timeout(100)
 state=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()');ck(f'{w} arrow keyboard choice',state['predicted']==1,state['predicted'])
 before=state['predicted'];bbox=await page.locator('[data-forecast]').bounding_box();cx=bbox['x']+bbox['width']/2;cy=bbox['y']+bbox['height']/2
 await page.mouse.move(cx,cy);await page.mouse.down();await page.mouse.move(cx+43,cy-32,steps=2)
 await page.locator('[data-forecast]').dispatch_event('pointercancel',{'bubbles':True,'pointerId':1,'pointerType':'mouse'})
 await page.mouse.up();await page.wait_for_timeout(130)
 state=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{w} pointercancel restores placed model',state['predicted']==before,state['predicted'])
 # All controls still present and draggable after cancellation
 ck(f'{w} no stranded token',await page.locator('[data-forecast]').count()==1)
 ck(f'{w} no browser exceptions',not errors,errors)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for w in [380,1280]:
   page=await b.new_page(viewport={'width':w,'height':900},reduced_motion='no-preference');page.set_default_timeout(5000)
   try:await run(page,w)
   except Exception as e:ck(f'{w} motion suite intact',False,str(e))
   await page.close()
  await b.close()
 Path('/mnt/data/f17_12_work/tests/motion-results.json').write_text(json.dumps({'passed':sum(c['passed'] for c in checks),'total':len(checks),'checks':checks},indent=2))
 print('SUMMARY',sum(c['passed'] for c in checks),'/',len(checks))
asyncio.run(main())
