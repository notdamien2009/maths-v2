import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
rec=[]
def ck(msg,v):rec.append({'name':msg,'passed':bool(v)});print('PASS' if v else 'FAIL',msg)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w in [380,1280]:
   page=await b.new_page(viewport={'width':w,'height':900},reduced_motion='no-preference')
   await page.set_content(Path('/mnt/data/F17-12-Expected-Outcomes-PREMIUM-REVIEW.html').read_text())
   # First Watch is playing automatically; pause so manual checks are deterministic.
   pause=page.get_by_role('button',name='Pause',exact=True)
   if await pause.count(): await pause.click()
   ck(f'{w} Play exists after pause',await page.get_by_role('button',name='Play',exact=True).count()==1)
   await page.get_by_role('button',name='Reset',exact=True).click()
   if await page.get_by_role('button',name='Pause',exact=True).count():await page.get_by_role('button',name='Pause',exact=True).click()
   await page.get_by_role('button',name='Step forward',exact=True).click(timeout=4000)
   ck(f'{w} forward increments scrub',await page.locator('input[aria-label="Scrub through steps"]').input_value()=='1')
   await page.get_by_role('button',name='Step back',exact=True).click()
   ck(f'{w} step-back decrements scrub',await page.locator('input[aria-label="Scrub through steps"]').input_value()=='0')
   scrub=page.locator('input[aria-label="Scrub through steps"]');await scrub.evaluate('(e)=>{e.value="4";e.dispatchEvent(new Event("input",{bubbles:true}));e.dispatchEvent(new Event("change",{bubbles:true}));}')
   ck(f'{w} scrub sets stage step',await scrub.input_value()=='4')
   await page.get_by_role('button',name='Reset',exact=True).click()
   ck(f'{w} rewind resets to zero',await scrub.input_value()=='0')
   await page.get_by_role('button',name='Play',exact=True).click();await page.wait_for_timeout(100)
   ck(f'{w} play enters pause mode',await page.get_by_role('button',name='Pause',exact=True).count()==1)
   await page.close()
  await b.close()
 Path('/mnt/data/f17_12_work/tests/timeline-results.json').write_text(json.dumps({'passed':sum(c['passed'] for c in rec),'total':len(rec),'checks':rec},indent=2))
 print('RESULT',sum(c['passed'] for c in rec), '/',len(rec))
asyncio.run(main())
