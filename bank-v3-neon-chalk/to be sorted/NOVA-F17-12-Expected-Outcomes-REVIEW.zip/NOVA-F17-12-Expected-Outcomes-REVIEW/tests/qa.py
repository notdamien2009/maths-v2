import asyncio,json,math,traceback
from pathlib import Path
from playwright.async_api import async_playwright
PATH=Path('/mnt/data/F17-12-Expected-Outcomes-PREMIUM-REVIEW.html')
checks=[]
def ck(name,yes,extra=None):
 checks.append({'name':name,'ok':bool(yes),'detail':extra});print(('PASS' if yes else 'FAIL'),name,extra or '')
async def mode(page,name):
 await page.locator('button').filter(has_text=name).first.click(timeout=3500);await page.wait_for_timeout(170)
async def toScreen(page,x,y):
 return await page.locator('svg.f1712-plot').evaluate('''(el,pt)=>{let p=el.createSVGPoint();p.x=pt.x;p.y=pt.y;const t=p.matrixTransform(el.getScreenCTM());return {x:t.x,y:t.y}}''',{'x':x,'y':y})
async def drag(page,to,steps=11):
 box=await page.locator('[data-forecast]').bounding_box();assert box, 'missing marker';a={'x':box['x']+box['width']/2,'y':box['y']+box['height']/2}
 await page.mouse.move(a['x'],a['y']);await page.mouse.down();await page.mouse.move(to['x'],to['y'],steps=steps);await page.mouse.up();await page.wait_for_timeout(120)
async def run_tests(page,width):
 errs=[];page.on('pageerror',lambda ex:errs.append(str(ex)))
 await page.set_content(PATH.read_text(),wait_until='load',timeout=30000);await page.wait_for_timeout(120)
 for md in ['Watch','Guided','Explore','Challenge']:
  await mode(page,md)
  ck(f'{width} {md} canvas',await page.locator('svg.f1712-plot').count()==1)
  ck(f'{width} {md} single in-stage mascot',await page.locator('.nova-stage .nv-dock').count()==1)
  ck(f'{width} {md} no script exceptions',not errs,str(errs[-1]) if errs else None)
  await page.screenshot(path=f'/mnt/data/f17_12_work/screenshots/F17-12-{width}-{md.lower()}.png',full_page=True)
 await mode(page,'Explore');ck(f'{width} expose model',await page.evaluate('!!NOVA_F17_12_CONFIG._explore'))
 st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} fraction product 6/25',st['prob']==[6,25],st['prob'])
 ck(f'{width} expected 24 from 100',st['expected']==24,st['expected'])
 ck(f'{width} four options distinct',len(set(st['choices']))==4,st['choices'])
 target=await toScreen(page,[209,390,572,753][0] if width==1280 else 72,849 if width==1280 else 927)
 # Ensure target scrolled into view; mouse moves can autoscroll via locator first.
 await page.locator('svg.f1712-plot').scroll_into_view_if_needed()
 target=await toScreen(page,209 if width==1280 else 72,849 if width==1280 else 927)
 await drag(page,target,17)
 st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} actual mouse snap',st['predicted']==0,st['predicted'])
 target=await toScreen(page,390 if width==1280 else 170,849 if width==1280 else 927)
 await drag(page,target,2)
 st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} fast regrab and move',st['predicted']==1,st['predicted'])
 # invalid drop into centre of graph far from a valid zone
 target=await toScreen(page,120 if width==1280 else 70,500 if width==1280 else 400)
 await drag(page,target,8)
 st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} invalid drop returned',st['predicted']==1,st['predicted'])
 # cancellation during active dragging; event dispatched to current active node
 box=await page.locator('[data-forecast]').bounding_box()
 await page.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2)
 await page.mouse.down()
 await page.mouse.move(box['x']+box['width']/2+36,box['y']+box['height']/2+26,steps=3)
 await page.keyboard.press('Escape');await page.mouse.up();await page.wait_for_timeout(150)
 st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} Escape retained previous snap',st['predicted']==1,st['predicted'])
 target=await toScreen(page,761 if width==1280 else 334,966 if width==1280 else 1091)
 await drag(page,target)
 st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} remove-zone works',st['predicted']==None,st['predicted'])
 await page.get_by_role('button',name='Place forecast').click();st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} keyboard accessible placement',st['predicted']==0,st['predicted'])
 await page.get_by_role('button',name='Remove forecast').click();st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} keyboard accessible removal',st['predicted']==None,st['predicted'])
 await page.get_by_role('button',name='Simulate 10',exact=True).click();st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} exact trial counter',st['actual']==10,st['actual'])
 ck(f'{width} success bounded',0<=st['success']<=10,st['success'])
 await page.get_by_role('button',name='Simulate 100',exact=True).click();st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} batch accumulates',st['actual']==110,st['actual'])
 await page.get_by_role('button',name='Reset trials').click();st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} reset counts',st['actual']==0 and st['success']==0)
 await page.get_by_label('Probability A').select_option('1-2')
 await page.get_by_label('Probability B').select_option('1-3')
 await page.get_by_label('Planned trials',exact=True).select_option('25')
 st=await page.evaluate('NOVA_F17_12_CONFIG._explore.get()')
 ck(f'{width} exact rational product 1/6',st['prob']==[1,6],st['prob'])
 ck(f'{width} noninteger expectation 25/6',abs(st['expected']-25/6)<1e-8,st['expected'])
 ck(f'{width} model change clears history',st['actual']==0 and st['success']==0)
 # watch step rewind and scrub basic state (test without relying on autoplay start)
 await mode(page,'Watch');tabs=await page.locator('.nova-stage').count();ck(f'{width} Watch stage intact after Explore',tabs==1)
 await mode(page,'Challenge');challenge_text=await page.locator('main').inner_text()
 ck(f'{width} question hides expected count', 'EXPECTED COUNT\n?' in challenge_text or 'EXPECTED COUNT ?' in challenge_text,challenge_text[-250:])
 ck(f'{width} Challenge has entry',await page.locator('input').count()>0)
 # capture challenge control surface diagnostics
 print('CHALLENGE CONTROLS',width,(await page.locator('main button').all_text_contents())[-16:])
 print('INPUTS',width,await page.locator('main input').evaluate_all('(els)=>els.map(e=>({type:e.type,placeholder:e.placeholder,outer:e.outerHTML.slice(0,270)}))'))
 return errs
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  for width in (380,1280):
   page=await browser.new_page(viewport={'width':width,'height':1000},reduced_motion='reduce');page.set_default_timeout(6000)
   try: print('ERRORS',width,await run_tests(page,width))
   except Exception as e: ck(f'{width} suite uninterrupted',False,str(e));traceback.print_exc()
   await page.close()
  await browser.close()
 Path('/mnt/data/f17_12_work/tests/core-results.json').write_text(json.dumps({'passed':sum(k['ok'] for k in checks),'total':len(checks),'checks':checks},indent=2))
 print('SUMMARY',sum(k['ok'] for k in checks),'/',len(checks))
asyncio.run(main())
