import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
P=Path('/mnt/data/F17-12-Expected-Outcomes-PREMIUM-REVIEW.html')
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w in [380,1280]:
   page=await b.new_page(viewport={'width':w,'height':950},reduced_motion='reduce')
   await page.set_content(P.read_text());await page.locator('button').filter(has_text='Explore').first.click()
   await page.get_by_label('Probability A',exact=True).select_option('1-2')
   await page.get_by_label('Probability B',exact=True).select_option('1-3')
   await page.get_by_label('Planned trials',exact=True).select_option('25')
   await page.screenshot(path=f'/mnt/data/f17_12_work/screenshots/F17-12-{w}-fractional-expected.png',full_page=True)
   await page.get_by_label('Planned trials',exact=True).select_option('100')
   await page.get_by_role('button',name='Simulate 100',exact=True).click()
   await page.screenshot(path=f'/mnt/data/f17_12_work/screenshots/F17-12-{w}-simulated-100.png',full_page=True)
   await page.close()
  await b.close()
asyncio.run(main())
