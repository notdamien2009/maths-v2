import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
URL='http://127.0.0.1:8877/F17-12-Expected-Outcomes-PREMIUM-REVIEW.html'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for width in [380,1280]:
   page=await browser.new_page(viewport={'width':width,'height':900},reduced_motion='reduce')
   problems=[]
   page.on('pageerror',lambda e: problems.append(str(e)))
   await page.set_content(Path('/mnt/data/F17-12-Expected-Outcomes-PREMIUM-REVIEW.html').read_text(),wait_until='load',timeout=30000)
   await page.wait_for_timeout(700)
   print('viewport',width,'errors',problems,'title',await page.title(),'engine',await page.locator('.nova-engine').count())
   print('buttons:', (await page.locator('button').all_text_contents())[:28]);print('main:',(await page.locator('main').inner_text())[:600])
   print('svg',await page.locator('svg.f1712-plot').count(),'dock',await page.locator('.nv-dock').count())
   await page.screenshot(path=f'/mnt/data/f17_12_work/screenshots/F17-12-{width}-watch.png',full_page=True)
   await page.close()
  await browser.close()
asyncio.run(main())
