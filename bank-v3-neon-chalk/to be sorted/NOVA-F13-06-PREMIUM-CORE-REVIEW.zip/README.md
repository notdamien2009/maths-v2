# NOVA F13-06 · Prism Volume Slicer

Premium-core independent review build. This is the **corrected F13 source lineage**, not the rejected standalone F13-01/02/03 prototypes.

## Files

- `F13-06-Prism-Volume-Slicer-PREMIUM-CORE.html` — complete standalone lesson component (full NOVA inline runtime, fonts, SVG, mascot pose packs and interactions). Open locally in Edge or Chrome.
- `source/F13-06.engine.js` — additive source engine (only the new prism visual and interaction logic).
- `source/F13-06.component.css` — additive local component styles; shared shell styles unchanged.
- `source/approved-F13-05-base.html` — frozen production base for exact reconstruction; not to be edited or deployed as F13-06.
- `source/build.py` — repeatable offline assembly; run `python build.py` inside the `source` folder (or invoke it from any working directory). Produces the standalone HTML one directory above.
- `screenshots/` — actual desktop and mobile Chromium renderings of Watch, Explore, Challenge and the prism families.
- `QA-REPORT.md`, `QA-RESULTS.json`, `recheck.py` — browser/mathematics QA and reproducible checks.

## Controls

Watch and Guided take learners through 11 teaching steps. Explore has a cross-section selector, perpendicular length (1–8), slice position (0–100%), repeated-slice and front-face visibility. Drag horizontally on the drawing to move the slice; focus it and use left/right arrows or Home/End as a keyboard equivalent. Challenge asks for both area in square units and volume in cubic units across three prism problems and marks them independently.

**Do not replace F0/F1/F2 core code or the official mascot.** This ZIP does not change GitHub or any NOVA lessons.
