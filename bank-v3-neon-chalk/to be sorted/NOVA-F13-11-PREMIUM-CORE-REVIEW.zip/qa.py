from pathlib import Path
import json, math, hashlib
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data/f13_11_premium'); HTML=(ROOT/'F13-11-Cross-Sections-Explorer-PREMIUM-CORE.html').read_text()
BASE=(ROOT/'source/F13-10-Sphere-Volume-and-Surface-Area-PREMIUM-CORE.html').read_text();CHECK=[]
def test(t,b,detail=''):
 CHECK.append({'test':t,'pass':bool(b),'detail':str(detail)[:500] if not b else ''})
 if not b: print('FAIL',t,detail,flush=True)
def near(a,b,tol=.009):return a is not None and abs(float(a)-b)<max(tol,abs(b)*tol)
def read(page):return page.evaluate('''()=>{let q=document.querySelector('[data-f13x-root]');return q?{shape:q.dataset.shape,orientation:q.dataset.orientation,position:+q.dataset.position,area:+q.dataset.area,type:q.dataset.sectionType,vertices:+q.dataset.vertices}:null}''')
def click_mode(p,mode):p.locator('.nova-tabs button').filter(has_text=mode).click();p.wait_for_timeout(60)
core=lambda x:x[x.index('/* === NOVA FAMILY CORE v1.4 : JS START ==='):x.index('/* F13-10 SPHERE VOLUME + SURFACE AREA')] if '/* F13-10 SPHERE VOLUME + SURFACE AREA' in x else x[x.index('/* === NOVA FAMILY CORE v1.4 : JS START ==='):x.index('/* F13-11 CROSS-SECTIONS EXPLORER:')]
test('Official full NOVA JS core preserved exactly',core(BASE)==core(HTML))
test('Official chalk font remains embedded','font-face{font-family:"NOVA Chalk"' in HTML)
test('Same production stylesheet before additive component',BASE[BASE.index('<style>'):BASE.index('/* F13-10 Sphere: additive production-component styles.')]==HTML[HTML.index('<style>'):HTML.index('/* F13-11 additive styles:')])
test('Standalone with no script CDN','<script src=' not in HTML)
test('F13-11 page title','NOVA F13-11 · Premium Cross-Sections Explorer' in HTML)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for W in [1280,380]:
  print('START',W,flush=True)
  pg=b.new_page(viewport={'width':W,'height':900},device_scale_factor=1);pg.set_default_timeout(8000);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(HTML,wait_until='load');pg.wait_for_timeout(180)
  test(f'{W} load stage',pg.locator('.nova-stage').count()==1)
  test(f'{W} one mascot dock under stage',pg.locator('.nova-stage > .nv-dock').count()==1)
  test(f'{W} embedded official cat image',pg.locator('.nova-stage .nv-dock image').count()>0)
  test(f'{W} NOVA background',pg.locator('body[data-topic="geometry"]').count()==1)
  test(f'{W} no horizontal overflow',pg.evaluate('document.documentElement.scrollWidth<=innerWidth+2'))
  test(f'{W} initial section square with area 9',read(pg)['type']=='square' and near(read(pg)['area'],9),read(pg))
  test(f'{W} main 3D solid and true 2D section',pg.locator('[data-maths="solid-surface"]').count()==1 and pg.locator('[data-maths="true-section"]').count()==1)
  pos=pg.locator('.nova-stage').bounding_box();dock=pg.locator('.nv-dock').bounding_box()
  test(f'{W} mascot in stage bounds',dock and pos and dock['x']>=pos['x']-3 and dock['x']+dock['width']<=pos['x']+pos['width']+5 and dock['y']+dock['height']<=pos['y']+pos['height']+5,(pos,dock))
  pg.locator('.nova-stage').scroll_into_view_if_needed();pg.screenshot(path=str(ROOT/'screenshots'/f'{W}-watch.png'))
  for mode in ['Guided','Watch','Explore']:
   click_mode(pg,mode)
   test(f'{W} {mode} mode loads',pg.locator('.nova-stage').count()==1 and pg.locator('.nova-stage > .nv-dock').count()==1)
  test(f'{W} Explore API',pg.evaluate('!!NOVA_F13_11_CONFIG._explore'))
  api='NOVA_F13_11_CONFIG._explore'
  # Expected central horizontal plane areas in square units
  expected=[('cube',9,'square'),('cuboid',8,'rectangle'),('tri',3,'triangle'),('pyramid',4,'square'),('cylinder',4*math.pi,'circle'),('cone',math.pi,'circle'),('sphere',9*math.pi,'circle')]
  for shape,area,typ in expected:
   pg.evaluate(f"{api}.setShape('{shape}')");pg.wait_for_timeout(80);q=read(pg)
   test(f'{W} {shape} horizontal section area',near(q['area'],area),q)
   test(f'{W} {shape} section type',q['type']==typ,q)
   test(f'{W} {shape} visible flat section',pg.locator('[data-maths="true-section"]').count()==1)
   test(f'{W} {shape} single official mascot',pg.locator('.nova-stage > .nv-dock').count()==1)
   if shape in ['cube','pyramid','cone','sphere']:
    pg.locator('.nova-stage').scroll_into_view_if_needed();pg.screenshot(path=str(ROOT/'screenshots'/f'{W}-{shape}-centre.png'))
  pg.evaluate(f"{api}.setShape('cube')");pg.evaluate(f"{api}.setPosition(.6)");pg.wait_for_timeout(60)
  test(f'{W} cube equal square area after moving cut',near(read(pg)['area'],9))
  pg.evaluate(f"{api}.setShape('pyramid')");pg.evaluate(f"{api}.setPosition(.6)");pg.wait_for_timeout(60)
  test(f'{W} pyramid smaller square towards tip',near(read(pg)['area'],.64),read(pg))
  pg.evaluate(f"{api}.setShape('sphere')");pg.evaluate(f"{api}.setPosition(.6)");pg.wait_for_timeout(80)
  test(f'{W} sphere circular area 5.76π at 60%',near(read(pg)['area'],5.76*math.pi),read(pg))
  pg.locator('.nova-stage').scroll_into_view_if_needed();pg.screenshot(path=str(ROOT/'screenshots'/f'{W}-sphere-raised.png'))
  pg.evaluate(f"{api}.setShape('cylinder')");pg.evaluate(f"{api}.setPosition(.6)");pg.wait_for_timeout(65)
  test(f'{W} cylinder same circular area at 60%',near(read(pg)['area'],4*math.pi),read(pg))
  pg.evaluate(f"{api}.setPosition(0)");pg.evaluate(f"{api}.setOrientation('vertical')");pg.wait_for_timeout(70)
  test(f'{W} cylinder centre vertical rectangle area16',near(read(pg)['area'],16,.025) and read(pg)['type']=='rectangle',read(pg))
  pg.locator('.nova-stage').scroll_into_view_if_needed();pg.screenshot(path=str(ROOT/'screenshots'/f'{W}-cylinder-vertical.png'))
  pg.evaluate(f"{api}.setShape('cube')");pg.evaluate(f"{api}.setOrientation('tilted')");pg.wait_for_timeout(75)
  test(f'{W} tilted cut intersects cube',read(pg)['vertices']>=4 and read(pg)['area']>0,read(pg))
  pg.locator('.nova-stage').scroll_into_view_if_needed();pg.screenshot(path=str(ROOT/'screenshots'/f'{W}-cube-tilted.png'))
  pg.evaluate(f"{api}.setShape('sphere')");pg.evaluate(f"{api}.setOrientation('vertical')");pg.wait_for_timeout(80)
  test(f'{W} sphere vertical centre circle area approximately9π',near(read(pg)['area'],9*math.pi,.022),read(pg))
  pg.evaluate(f"{api}.setOrientation('horizontal')");pg.evaluate(f"{api}.setShape('cube')");pg.wait_for_timeout(100)
  s=pg.locator('.f13x-svg');s.scroll_into_view_if_needed();s.focus();before=pg.evaluate(f'{api}.state.yaw');pg.keyboard.press('ArrowRight');pg.wait_for_timeout(40)
  test(f'{W} keyboard right rotates',pg.evaluate(f'{api}.state.yaw')>before)
  before=read(pg)['position'];pg.keyboard.press('PageUp');pg.wait_for_timeout(40)
  test(f'{W} keyboard pageup shifts slicing plane',read(pg)['position']>before)
  pg.keyboard.press('Home');pg.wait_for_timeout(40)
  test(f'{W} Home resets cut position and yaw',near(read(pg)['position'],0) and near(pg.evaluate(f'{api}.state.yaw'),.74))
  # stress rapid pointer interactions and release capture
  s.scroll_into_view_if_needed();bb=s.bounding_box();yaw=pg.evaluate(f'{api}.state.yaw')
  for n in range(18):
   x=bb['x']+bb['width']*.22;y=bb['y']+bb['height']*.42
   pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+36+(n%4)*9,y+(n%3)*6,steps=1);pg.mouse.up()
  pg.wait_for_timeout(110)
  test(f'{W} 18 fast drags rotate',abs(pg.evaluate(f'{api}.state.yaw')-yaw)>.15)
  test(f'{W} pointer not stuck after drags',pg.locator('.f13x-svg.grabbing').count()==0)
  click_mode(pg,'Challenge')
  test(f'{W} challenge loads',pg.locator('select[aria-label="Cross-section shape"]').count()==1)
  for i,(sh,area) in enumerate([('square','9'),('circle','4'),('circle','9')]):
   pg.evaluate(f'NOVA_F13_11_CONFIG._challenge.load({i})');pg.wait_for_timeout(35)
   if i==0:
    pg.locator('select[aria-label="Cross-section shape"]').select_option('circle')
    pg.locator('input[aria-label="Cross-section area answer"]').fill('9')
    test(f'{W} challenge incorrect shape rejected',pg.evaluate('NOVA_F13_11_CONFIG._challenge.check()') is False)
   pg.locator('select[aria-label="Cross-section shape"]').select_option(sh)
   pg.locator('input[aria-label="Cross-section area answer"]').fill(area)
   test(f'{W} challenge {i+1} correct',pg.evaluate('NOVA_F13_11_CONFIG._challenge.check()') is True)
  pg.locator('.nova-stage').scroll_into_view_if_needed();pg.screenshot(path=str(ROOT/'screenshots'/f'{W}-challenge.png'))
  test(f'{W} no Javascript errors',len(errors)==0,errors)
  pg.close()
 b.close()
out={'passed':sum(x['pass'] for x in CHECK),'total':len(CHECK),'failures':[x for x in CHECK if not x['pass']],'checks':CHECK,'sha256':hashlib.sha256((ROOT/'F13-11-Cross-Sections-Explorer-PREMIUM-CORE.html').read_bytes()).hexdigest()}
(ROOT/'QA-RESULTS.json').write_text(json.dumps(out,indent=2));print('FINAL',out['passed'],'/',out['total'],out['failures'],flush=True)
