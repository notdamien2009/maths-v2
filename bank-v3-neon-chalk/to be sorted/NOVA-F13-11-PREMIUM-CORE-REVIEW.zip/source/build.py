"""F13-11: Replace only the previous additive styles/engine; preserve the full official NOVA core byte-for-byte."""
from pathlib import Path
P=Path(__file__).resolve().parent
base=(P/'F13-10-Sphere-Volume-and-Surface-Area-PREMIUM-CORE.html').read_text()
css=(P/'f13_11_addon.css').read_text()
js=(P/'f13_11_engine.js').read_text()
a=base.index('/* F13-10 Sphere: additive production-component styles.')
b=base.index('</style>',a)
base=base[:a]+css+'\n'+base[b:]
a=base.index('/* F13-10 SPHERE VOLUME + SURFACE AREA')
b=base.rfind('</script>')
base=base[:a]+js+'\n'+base[b:]
base=base.replace('NOVA F13-10 · Premium Sphere Volume and Surface Area','NOVA F13-11 · Premium Cross-Sections Explorer')
base=base.replace('data-run="F13 · 3D shapes, volume and surface area · F13-10" data-title="Sphere volume and surface area" data-sub="Explore curved area, radii, cross-sections and the enclosing-cylinder volume relationship."', 'data-run="F13 · 3D shapes, volume and surface area · F13-11" data-title="Cross-sections explorer" data-sub="Move a cutting plane through a 3D solid and discover the true two-dimensional shape inside."')
out=P.parent/'F13-11-Cross-Sections-Explorer-PREMIUM-CORE.html'
out.write_text(base)
print('Built',out,out.stat().st_size)
