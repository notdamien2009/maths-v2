/* F13-11 CROSS-SECTIONS EXPLORER: additive engine over the unchanged embedded NOVA core. */
var NOVA_F13_11_CONFIG={startMode:'watch',preset:'cube',presets:{cube:'Cube · equal square faces',cuboid:'Cuboid · rectangular faces',tri:'Triangular prism',pyramid:'Square-based pyramid',cylinder:'Cylinder',cone:'Cone',sphere:'Sphere'}};
(function(){'use strict';
var S=NOVA.svg,F=NOVA.f12,h=NOVA.h,CFG=NOVA_F13_11_CONFIG,EN='F13-11';
var C={cyan:'#45eeff',blue:'#659eff',purple:'#bca4ff',orange:'#ffad7d',gold:'#ffe27d',green:'#76f5bb',white:'#e8f8ff'};
var META={cube:{name:'CUBE',dimensions:'SIDE 3',label:'square'},cuboid:{name:'CUBOID',dimensions:'4 × 2 × 3',label:'rectangle'},tri:{name:'TRIANGULAR PRISM',dimensions:'TRIANGLE × 4',label:'triangle'},pyramid:{name:'SQUARE PYRAMID',dimensions:'BASE 4 · HEIGHT 4',label:'square'},cylinder:{name:'CYLINDER',dimensions:'r = 2 · h = 4',label:'circle'},cone:{name:'CONE',dimensions:'r = 2 · h = 4',label:'circle'},sphere:{name:'SPHERE',dimensions:'r = 3',label:'circle'}};
function clamp(a,b,c){return Math.max(b,Math.min(c,a));}
function fmt(a){return String(Math.round(a*1000)/1000);}
function v(x,y,z){return [x,y,z];}
function add(a,b){return [a[0]+b[0],a[1]+b[1],a[2]+b[2]];}
function sub(a,b){return [a[0]-b[0],a[1]-b[1],a[2]-b[2]];}
function mul(a,t){return [a[0]*t,a[1]*t,a[2]*t];}
function dot(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}
function norm(a){var m=Math.hypot.apply(null,a);return m?mul(a,1/m):[0,0,0];}
function el(p,tag,o){return S.el(tag,o||{},p);}
function tx(p,x,y,t,role,size){return NOVA.chalkText(p,x,y,String(t),{role:role||'given',size:size||18,anchor:'middle'});}
function path(p,d,color,w,opacity,fill,other){return el(p,'path',Object.assign({d:d,fill:fill||'none',stroke:color||C.cyan,'stroke-width':w||1.5,opacity:opacity==null?1:opacity,'stroke-linejoin':'round','stroke-linecap':'round'},other||{}));}
function poly(p,pts,stroke,w,opacity,fill,attrs){if(!pts||pts.length<2)return null;return path(p,'M'+pts.map(q=>fmt(q[0])+','+fmt(q[1])).join('L')+'Z',stroke,w,opacity,fill,attrs);}
function line(p,a,b,col,w,op,dash){return path(p,'M'+fmt(a[0])+','+fmt(a[1])+'L'+fmt(b[0])+','+fmt(b[1]),col,w,op,'none',dash?{'stroke-dasharray':dash}:{});}
function grad(d,id,stops,attrs,kind){var g=el(d,kind||'linearGradient',Object.assign({id:id},attrs||{}));stops.forEach(q=>el(g,'stop',{offset:q[0],'stop-color':q[1],'stop-opacity':q[2]}));}
function defs(svg){var d=svg.querySelector('defs')||el(svg,'defs');
 grad(d,'f13x-glass',[['0%','#7eebff',.78],['34%','#326bcc',.75],['76%','#1d356f',.8],['100%','#0b1a44',.87]],{x1:'0%',y1:'0%',x2:'90%',y2:'95%'});
 grad(d,'f13x-glow',[['0%','#97f2ff',.85],['100%','#64a8ff',.04]],{cx:'40%',cy:'40%',r:'65%'},'radialGradient');
 grad(d,'f13x-cut',[['0%','#fff7b6',.98],['58%','#ffcb65',.81],['100%','#ff8654',.79]],{x1:'20%',y1:'10%',x2:'80%',y2:'90%'});
 grad(d,'f13x-chamber',[['0%','#1e65b5',.28],['100%','#081433',0]],{cx:'50%',cy:'45%',r:'60%'},'radialGradient');
 var f=el(d,'filter',{id:'f13x-blur',x:'-100%',y:'-100%',width:'300%',height:'300%'});el(f,'feGaussianBlur',{stdDeviation:9});}
function box(w,d,hh){var x=w/2,y=d/2,z=hh/2;
 var b=[v(-x,-y,-z),v(x,-y,-z),v(x,y,-z),v(-x,y,-z)],t=b.map(p=>v(p[0],p[1],z));
 return [[...t],[b[3],b[2],b[1],b[0]],[b[0],b[1],t[1],t[0]],[b[1],b[2],t[2],t[1]],[b[2],b[3],t[3],t[2]],[b[3],b[0],t[0],t[3]]];}
function regularPrism(xys,height){var n=xys.length,z=height/2,b=xys.map(p=>v(p[0],p[1],-z)),t=xys.map(p=>v(p[0],p[1],z));var faces=[t,b.slice().reverse()];for(var i=0;i<n;i++)faces.push([b[i],b[(i+1)%n],t[(i+1)%n],t[i]]);return faces;}
function pyramid(){var xys=[[-2,-2],[2,-2],[2,2],[-2,2]],a=v(0,0,2),b=xys.map(p=>v(p[0],p[1],-2));var f=[b.slice().reverse()];for(var i=0;i<4;i++)f.push([b[i],b[(i+1)%4],a]);return f;}
function cone(){var N=72,b=[],a=v(0,0,2);for(var i=0;i<N;i++){var q=i*2*Math.PI/N;b.push(v(2*Math.cos(q),2*Math.sin(q),-2));}var f=[b.slice().reverse()];for(var j=0;j<N;j++)f.push([b[j],b[(j+1)%N],a]);return f;}
function cylinder(){var N=72,b=[],t=[];for(var i=0;i<N;i++){var q=i*2*Math.PI/N,x=2*Math.cos(q),y=2*Math.sin(q);b.push(v(x,y,-2));t.push(v(x,y,2));}var f=[t,b.slice().reverse()];for(var j=0;j<N;j++)f.push([b[j],b[(j+1)%N],t[(j+1)%N],t[j]]);return f;}
function sphere(){var f=[],A=48,B=22;for(var j=0;j<B;j++){var a=-Math.PI/2+j*Math.PI/B,b=-Math.PI/2+(j+1)*Math.PI/B;for(var i=0;i<A;i++){var u=i*2*Math.PI/A,w=(i+1)*2*Math.PI/A;function pp(lat,lon){return [3*Math.cos(lat)*Math.cos(lon),3*Math.cos(lat)*Math.sin(lon),3*Math.sin(lat)];}
 f.push([pp(a,u),pp(a,w),pp(b,w),pp(b,u)]);}}return f;}
var meshs={cube:function(){return box(3,3,3);},cuboid:function(){return box(4,2,3);},tri:function(){return regularPrism([[-1.5,-1],[1.5,-1],[0,1]],4);},pyramid:pyramid,cylinder:cylinder,cone:cone,sphere:sphere};
var cache={};function mesh(id){return cache[id]||(cache[id]=meshs[id]());}
function plane(s){var n=s.orient==='vertical'?v(1,0,0):s.orient==='tilted'?norm(v(.5,.25,1)):v(0,0,1);var pts=mesh(s.shape).flat();var limits=pts.map(p=>dot(n,p));var min=Math.min.apply(null,limits),max=Math.max.apply(null,limits);return {n:n,k:(min+max)/2+s.pos*(max-min)/2,lo:min,hi:max};}
function clip(face,n,k){var arr=[],cuts=[];for(var i=0;i<face.length;i++){var a=face[i],b=face[(i+1)%face.length],da=dot(n,a)-k,db=dot(n,b)-k;if(da<=1e-8)arr.push(a);if((da< -1e-8&&db>1e-8)||(da>1e-8&&db< -1e-8)){var q=add(a,mul(sub(b,a),da/(da-db)));arr.push(q);cuts.push(q);}if(Math.abs(da)<1e-8)cuts.push(a);}return {face:arr,cuts:cuts};}
function basis(n){var other=Math.abs(n[2])<.88?v(0,0,1):v(1,0,0);var u=norm(cross(other,n)),w=norm(cross(n,u));return [u,w];}
function shapeSections(s){var faces=mesh(s.shape),pl=plane(s),clipped=[],points=[];for(var i=0;i<faces.length;i++){var c=clip(faces[i],pl.n,pl.k);if(c.face.length>=3)clipped.push(c.face);points.push.apply(points,c.cuts);}var unique=[];for(var q of points){if(!unique.some(p=>Math.hypot.apply(null,sub(p,q))<.0008))unique.push(q);}
 // For round solids the exact cutting circle avoids tessellation artefacts at horizontal sections.
 var horiz=s.orient==='horizontal';if(horiz&&(s.shape==='sphere'||s.shape==='cylinder'||s.shape==='cone')){
   var radius=s.shape==='sphere'?Math.sqrt(Math.max(0,9-pl.k*pl.k)):s.shape==='cylinder'?2:Math.max(0,(2-pl.k)/2);
   if(radius>1e-7){unique=[];for(var i=0;i<96;i++){var a=2*Math.PI*i/96;unique.push([radius*Math.cos(a),radius*Math.sin(a),pl.k]);}}
 }
 if(s.shape==='sphere'){var sphereUV=basis(pl.n),sphereCentre=mul(pl.n,pl.k),sphereR=Math.sqrt(Math.max(0,9-pl.k*pl.k));unique=[];for(var j=0;j<96;j++){var theta=j*2*Math.PI/96;unique.push(add(sphereCentre,add(mul(sphereUV[0],sphereR*Math.cos(theta)),mul(sphereUV[1],sphereR*Math.sin(theta)))));}}
 var uv=basis(pl.n),centre=unique.length?mul(unique.reduce((a,b)=>add(a,b),v(0,0,0)),1/unique.length):v(0,0,0);
 unique.sort((a,b)=>Math.atan2(dot(sub(a,centre),uv[1]),dot(sub(a,centre),uv[0]))-Math.atan2(dot(sub(b,centre),uv[1]),dot(sub(b,centre),uv[0])));
 var area=0;for(var i=0;i<unique.length;i++){var a=sub(unique[i],centre),b=sub(unique[(i+1)%unique.length],centre);area+=dot(cross(a,b),pl.n)*.5;}area=Math.abs(area);
 if(s.shape==='sphere')area=Math.PI*Math.max(0,9-pl.k*pl.k);
 if(horiz){if(s.shape==='cylinder')area=Math.PI*4;if(s.shape==='cone')area=Math.PI*Math.pow(Math.max(0,(2-pl.k)/2),2);}
 var type=s.shape==='sphere'?'circle':s.orient==='horizontal'?META[s.shape].label:s.shape==='cube'?'square':s.shape==='cuboid'?'rectangle':s.shape==='cylinder'&&s.orient==='vertical'?'rectangle':s.shape==='cone'&&s.orient==='vertical'&&Math.abs(pl.k)<1e-7?'triangle':'cross-section';
 return {clipped:clipped,points:unique,centre:centre,uv:uv,area:Math.max(0,area),pl:pl,type:type};}
function camera(s,p,W,cx,cy,scale){var co=Math.cos(s.yaw),si=Math.sin(s.yaw),cp=Math.cos(s.pitch),sp=Math.sin(s.pitch);var side=co*p[0]-si*p[1],deep=si*p[0]+co*p[1];return [cx+scale*side,cy+scale*(sp*deep-cp*p[2]),cp*deep+sp*p[2]];}
function faceNorm(p){return norm(cross(sub(p[1],p[0]),sub(p[2],p[0])));}
function rgba(hh,a){var t=hh.replace('#','');return 'rgba('+parseInt(t.slice(0,2),16)+','+parseInt(t.slice(2,4),16)+','+parseInt(t.slice(4,6),16)+','+a+')';}
function view3d(g,s,geo,mob,cx,cy,scale){var cam=p=>camera(s,p,0,cx,cy,scale),P=geo.pl,n=P.n,k=P.k;
 var viewer=norm([Math.sin(s.yaw)*Math.cos(s.pitch),Math.cos(s.yaw)*Math.cos(s.pitch),Math.sin(s.pitch)]);
 var floor=el(g,'g',{'aria-hidden':'true'});
 el(floor,'ellipse',{cx:cx,cy:cy+159,rx:mob?123:169,ry:mob?25:33,fill:'#05102c',opacity:.64,filter:'url(#f13x-blur)'});
 el(floor,'ellipse',{cx:cx,cy:cy+152,rx:mob?124:163,ry:mob?18:23,fill:'none',stroke:C.cyan,'stroke-width':.9,opacity:.27});
 var grid=el(g,'g',{'aria-hidden':'true'});for(var a=-3;a<=3;a++){var q=cam([a,-3,-2.7]),r=cam([a,3,-2.7]);line(grid,q,r,C.blue,.75,.12);q=cam([-3,a,-2.7]);r=cam([3,a,-2.7]);line(grid,q,r,C.blue,.75,.12);}
 // Gold plane sits behind the opaque lower section of the solid, never outside the overall stage.
 var uv=geo.uv,centre=geo.centre;
 // The finite translucent plane follows the actual section's extent. Avoid giant crossing diagonals on a mobile screen.
 var ex=Math.max(.5,...geo.points.map(q=>Math.abs(dot(sub(q,centre),uv[0]))))+.32;
 var ey=Math.max(.5,...geo.points.map(q=>Math.abs(dot(sub(q,centre),uv[1]))))+.32;
 var planePts=[add(centre,add(mul(uv[0],-ex),mul(uv[1],-ey))),add(centre,add(mul(uv[0],ex),mul(uv[1],-ey))),add(centre,add(mul(uv[0],ex),mul(uv[1],ey))),add(centre,add(mul(uv[0],-ex),mul(uv[1],ey)))];
 var planeProjected=planePts.map(q=>cam(q));poly(g,planeProjected,C.gold,1.05,.20,rgba(C.gold,.025),{'stroke-dasharray':'5 8','data-maths':'cutting-plane','data-cut-level':fmt(k)});
 // Show a delicate ghost of the removed upper geometry: the original solid remains legible.
 var ghosts=el(g,'g',{'aria-hidden':'true','data-maths':'removed-portion'}),seen={};
 if(s.shape==='sphere'){
   var outer=Math.abs(scale*3);el(ghosts,'circle',{cx:cx,cy:cy,r:outer,fill:'none',stroke:C.cyan,'stroke-width':1.1,opacity:.16,'stroke-dasharray':'5 7'});
 }else{
   mesh(s.shape).forEach(function(face,fi){for(var ii=0;ii<face.length;ii++){
     if((s.shape==='cylinder'||s.shape==='cone')&&ii%4!==0&&fi>1)continue;
     var a=face[ii],b=face[(ii+1)%face.length],da=dot(n,a)-k,db=dot(n,b)-k;
     if(da<=.01&&db<=.01)continue;
     if(da<=0)a=add(a,mul(sub(b,a),(-da)/(db-da)));
     else if(db<=0)b=add(a,mul(sub(b,a),da/(da-db)));
     var key=[a,b].map(p=>p.map(z=>Math.round(z*100)/100).join(',')).sort().join('|');if(seen[key])continue;seen[key]=true;
     var ra=cam(a),rb=cam(b);line(ghosts,ra,rb,C.blue,.95,.20,'4 6');
   }});
 }
 var surfaces=geo.clipped.map((p,i)=>{var nn=faceNorm(p),r=p.map(cam),dep=r.reduce((a,b)=>a+b[2],0)/r.length;return {p:p,nn:nn,r:r,depth:dep,id:i};}).filter(o=>dot(o.nn,viewer)>.008);
 surfaces.sort((a,b)=>a.depth-b.depth);
 var glass=el(g,'g',{'data-maths':'solid-surface','data-solid':s.shape});
 surfaces.forEach((f,i)=>{var lit=clamp(.4+dot(f.nn,norm([.4,-.1,.9]))*.38,.16,.94);var tint=f.nn[2]>.4?C.cyan:f.nn[0]>.22?C.blue:f.nn[1]>.22?C.purple:C.orange;
   poly(glass,f.r,tint,1.05,.82,rgba(tint,.14+.29*lit));
   if(i%4===0)poly(glass,f.r,C.white,.35,.16,'none');});
 if(geo.points.length>2){var edge=geo.points.map(cam);poly(g,edge,C.gold,2.9,.98,'url(#f13x-cut)',{'data-maths':'section-face','data-section-vertices':geo.points.length});poly(g,edge,C.white,.85,.33,'none');for(var i=0;i<Math.min(edge.length,40);i+=Math.max(1,Math.round(edge.length/12)))el(g,'circle',{cx:edge[i][0],cy:edge[i][1],r:2.4,fill:C.gold,opacity:.85});}
 else tx(g,cx,cy-5,'NO SECTION','focus',mob?14:16);
 // moveable section annotation anchored to viewport rather than concealing centre of maths
 tx(g,cx,cy+180,s.orient==='horizontal'?'HORIZONTAL CUT':s.orient==='vertical'?'VERTICAL CUT':'TILTED CUT','given',mob?12:16);
}
function section2d(g,s,geo,mob,cx,cy){var R=mob?70:111;
 el(g,'ellipse',{cx:cx,cy:cy,rx:R+7,ry:R+7,fill:'url(#f13x-chamber)',stroke:C.blue,'stroke-width':1.5,opacity:.8});
 el(g,'circle',{cx:cx,cy:cy,r:R+9,fill:'none',stroke:C.cyan,'stroke-width':1.2,opacity:.2,'stroke-dasharray':'3 7'});
 for(var z=-1;z<=1;z++){line(g,[cx-R,cy+z*R/2],[cx+R,cy+z*R/2],C.blue,.7,.16);line(g,[cx+z*R/2,cy-R],[cx+z*R/2,cy+R],C.blue,.7,.16);}
 var pp=geo.points.map(q=>[dot(sub(q,geo.centre),geo.uv[0]),dot(sub(q,geo.centre),geo.uv[1])]);var rx=Math.max(.01,...pp.map(q=>Math.abs(q[0]))),ry=Math.max(.01,...pp.map(q=>Math.abs(q[1]))),sc=Math.min(R*.87/rx,R*.87/ry);
 if(pp.length>2){var xy=pp.map(q=>[cx+q[0]*sc,cy-q[1]*sc]);poly(g,xy,C.gold,2.6,1,'url(#f13x-cut)',{'data-maths':'true-section','data-geometry':geo.type});
   if(pp.length<=6)xy.forEach(q=>el(g,'circle',{cx:q[0],cy:q[1],r:2.6,fill:C.white,opacity:.85}));}
 else tx(g,cx,cy,'TIP / EDGE','given',mob?13:18);
 tx(g,cx,cy-R-28,'TRUE SECTION VIEW','focus',mob?13.3:19);
 tx(g,cx,cy+R+28,geo.type.toUpperCase(),'result',mob?16:21);
}
function niceArea(geo,s){var a=geo.area;if(a<.0001)return '0';if(s.shape==='sphere'||s.orient==='horizontal'&&(s.shape==='cylinder'||s.shape==='cone')){var coeff=a/Math.PI;return fmt(coeff)+'π';}return ((s.shape==='cylinder'||s.shape==='cone')&&s.orient!=='horizontal'?'≈':'')+fmt(a);}
function readout(g,x,y,w,title,main,sub,col,mob){el(g,'rect',{x:x,y:y,width:w,height:98,rx:12,fill:'#06162e',stroke:col,'stroke-width':1.65});line(g,[x+13,y+5],[x+w-13,y+5],col,2,.6);tx(g,x+w/2,y+23,title,'given',mob?12:16);tx(g,x+w/2,y+63,main,'result',mob?22:29);tx(g,x+w/2,y+88,sub,'given',mob?10.5:13);}
function draw(root,s,W){root.replaceChildren();var mob=W===420,cc=mob?131:244,cy=258,sc=(mob?64:85)*3.6/(s.shape==='sphere'?6:s.shape==='cuboid'?4:4),xp=mob?336:603,geo=shapeSections(s);
 el(root,'ellipse',{cx:W/2,cy:252,rx:W*.53,ry:232,fill:'url(#f13x-chamber)',opacity:.8});
 tx(root,W/2,33,'CUT A 3D SOLID · REVEAL A 2D SHAPE','given',mob?14.5:20);
 tx(root,cc,85,META[s.shape].name,'focus',mob?15.5:21);
 tx(root,xp,85,'2D FACE INSIDE','focus',mob?13.5:19);
 view3d(root,s,geo,mob,cc,cy,sc);section2d(root,s,geo,mob,xp,250);
 readout(root,mob?11:112,462,mob?193:268,'SECTION AREA',niceArea(geo,s)+' units²','inside the cutting plane',C.gold,mob);
 readout(root,mob?215:399,462,mob?194:268,'CUT POSITION',Math.round(s.pos*100)+'%','plane travels through solid',C.cyan,mob);
 tx(root,W/2,594,s.shape==='sphere'?'SPHERE SLICES ARE CIRCLES · SIZE CHANGES':s.shape==='cylinder'&&s.orient==='horizontal'?'CYLINDER CIRCLES STAY THE SAME SIZE':s.shape==='pyramid'?'PYRAMID SECTIONS SHRINK TOWARDS THE TIP':'A CROSS-SECTION IS A TWO-DIMENSIONAL SHAPE','result',mob?12:16);
 root.setAttribute('data-shape',s.shape);root.setAttribute('data-area',geo.area);root.setAttribute('data-position',s.pos);root.setAttribute('data-orientation',s.orient);root.setAttribute('data-section-type',geo.type);root.setAttribute('data-vertices',geo.points.length);
 s.geometry=geo;}
function makeState(shape,orient,pos){return {shape:shape||'cube',orient:orient||'horizontal',pos:pos||0,yaw:.74,pitch:.57,geometry:null,refresh:null};}
function makeStage(stage,s,msg,pose,interactive){if(stage._f13Cleanup)stage._f13Cleanup();stage.replaceChildren();var mob=innerWidth<=580,W=mob?420:780;
 NOVA.cap(stage,'CROSS-SECTIONS · '+META[s.shape].name+' · '+META[s.shape].dimensions,'3D GEOMETRY');
 var svg=S.root(W,612,'Three-dimensional solid intersected by a movable cutting plane, with the mathematically correct two-dimensional section displayed beside the solid.');svg.classList.add('f13x-svg');svg.setAttribute('tabindex','0');svg.setAttribute('role','group');svg.setAttribute('aria-label','3D solid and cutting plane. Drag to rotate. Arrow keys rotate. Up and Down while Alt is held move the plane.');stage.appendChild(svg);defs(svg);
 var root=el(svg,'g',{'data-f13x-root':'true'}),raf=0,pointer=null,last=null,controller=new AbortController();
 function render(){draw(root,s,W);var ca=stage.querySelector('.nv-cap span');if(ca)ca.textContent='CROSS-SECTIONS · '+META[s.shape].name+' · '+META[s.shape].dimensions;var q=stage.querySelectorAll('.f12-strip .nv-ntile .mt');var vs=[META[s.shape].name,s.geometry.type,niceArea(s.geometry,s)];vs.forEach((t,i)=>{if(q[i])q[i].textContent=t;});}
 function refresh(){if(raf)cancelAnimationFrame(raf);raf=requestAnimationFrame(function(){raf=0;render();NOVA.events.emit('value',{engine:EN,control:'section',value:{shape:s.shape,orientation:s.orient,position:s.pos,area:s.geometry.area,type:s.geometry.type}});});}
 s.refresh=refresh;render();F.strip(stage,[['solid',META[s.shape].name,'focus'],['section',s.geometry.type,'op'],['area',niceArea(s.geometry,s),'result']]);NOVA.scene.helperStrip(stage,pose||'explain',msg||'A cross-section is the flat 2D shape left by cutting through a 3D solid.');
 s.cleanup=function(){controller.abort();if(raf)cancelAnimationFrame(raf);pointer=null;last=null;svg.classList.remove('grabbing');};stage._f13Cleanup=s.cleanup;
 if(interactive){svg.addEventListener('pointerdown',function(e){if(e.pointerType==='mouse'&&e.button!==0)return;pointer=e.pointerId;last=[e.clientX,e.clientY];svg.classList.add('grabbing');try{svg.setPointerCapture(pointer);}catch(err){}e.preventDefault();},{signal:controller.signal});
 svg.addEventListener('pointermove',function(e){if(e.pointerId!==pointer||!last)return;var d=[e.clientX-last[0],e.clientY-last[1]];last=[e.clientX,e.clientY];s.yaw+=d[0]*2.4/(svg.getBoundingClientRect().width||420);s.pitch=clamp(s.pitch-d[1]*1.5/(svg.getBoundingClientRect().width||420),.1,1.24);refresh();},{signal:controller.signal});
 function release(e){if(e.pointerId!==pointer)return;pointer=null;last=null;svg.classList.remove('grabbing');try{if(svg.hasPointerCapture(e.pointerId))svg.releasePointerCapture(e.pointerId);}catch(err){}}
 svg.addEventListener('pointerup',release,{signal:controller.signal});svg.addEventListener('pointercancel',release,{signal:controller.signal});svg.addEventListener('lostpointercapture',function(e){if(pointer===e.pointerId){pointer=null;last=null;svg.classList.remove('grabbing');}},{signal:controller.signal});window.addEventListener('blur',function(){pointer=null;last=null;svg.classList.remove('grabbing');},{signal:controller.signal});}
 svg.addEventListener('keydown',function(e){if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','PageUp','PageDown'].includes(e.key))return;e.preventDefault();if(e.key==='ArrowLeft')s.yaw-=.14;if(e.key==='ArrowRight')s.yaw+=.14;if(e.key==='ArrowUp')s.pitch=clamp(s.pitch+.12,.1,1.24);if(e.key==='ArrowDown')s.pitch=clamp(s.pitch-.12,.1,1.24);if(e.key==='PageUp'||(e.altKey&&e.key==='ArrowUp'))s.pos=clamp(s.pos+.1,-.95,.95);if(e.key==='PageDown'||(e.altKey&&e.key==='ArrowDown'))s.pos=clamp(s.pos-.1,-.95,.95);if(e.key==='Home'){s.yaw=.74;s.pitch=.57;s.pos=0;}refresh();},{signal:controller.signal});return svg;}
function btn(t,fun,cl){return h('button',{class:'nova-btn'+(cl?' '+cl:''),text:t,onclick:fun});}
function row(p,items){p.appendChild(h('div',{class:'pr-row'},items));}
function slider(t,val,cb){var input=h('input',{type:'range',min:'-90',max:'90',step:'1',value:String(val),'aria-label':t}),count=h('span',{class:'f13x-value',text:val+'%'});input.oninput=function(){count.textContent=input.value+'%';cb(+input.value/100);};return {input:input,node:h('label',{class:'f13x-label'},[t+' ',input,count]),set:function(n){input.value=String(Math.round(n*100));count.textContent=input.value+'%';}};}
var STEPS=[
 {n:'Meet cross-sections',s:'cube',o:'horizontal',p:0,h:'explain',m:'A cross-section is the flat shape you find by slicing all the way through a solid. The cut reveals a two-dimensional shape.',q:'Is the section two-dimensional or three-dimensional?'},
 {n:'Cut through a cube',s:'cube',o:'horizontal',p:0,h:'point-right',m:'A horizontal cut through this cube leaves a square. Its side is three units, so its section area is nine square units.',q:'What is the area of a square with side three?'},
 {n:'Move the plane',s:'cube',o:'horizontal',p:.55,h:'think',m:'The plane moves upwards, but every horizontal section of this cube has the same three-by-three square shape.',q:'Does the size of this cube section change?'},
 {n:'Turn the cutting plane',s:'cuboid',o:'vertical',p:0,h:'point-right',m:'Turn the plane vertically through the cuboid. Now the section is a rectangle with different dimensions.',q:'Why is a vertical section sometimes a different rectangle?'},
 {n:'Find a triangle',s:'tri',o:'horizontal',p:0,h:'explain',m:'A triangular prism has a triangle at every horizontal height. The same triangle repeats along the whole length of the prism.',q:'What two-dimensional shape appears?'},
 {n:'Slice a pyramid',s:'pyramid',o:'horizontal',p:-.65,h:'think',m:'A square pyramid narrows upwards. Near the base we see a large square section.',q:'What happens when we move the cut closer to the apex?'},
 {n:'Approach the apex',s:'pyramid',o:'horizontal',p:.67,h:'point-right',m:'Near the tip the square becomes much smaller. A pyramid does not have constant-sized horizontal cross-sections.',q:'Is this section larger or smaller than the previous one?'},
 {n:'Cut through a cylinder',s:'cylinder',o:'horizontal',p:0,h:'explain',m:'A cylinder has an equal circular section at each horizontal height. Its radius is two units, giving four pi square units.',q:'Does the radius of a horizontal cylinder section change?'},
 {n:'Turn the cylinder cut',s:'cylinder',o:'vertical',p:0,h:'point-right',m:'A vertical cut through the middle of the cylinder creates a rectangle. The direction of a cut matters.',q:'What shape appears in the vertical section?'},
 {n:'Slice a cone',s:'cone',o:'horizontal',p:.42,h:'think',m:'A cone gives circles when sliced horizontally, but each circle becomes smaller as the cut approaches the tip.',q:'How does this differ from the cylinder?'},
 {n:'Slice a sphere',s:'sphere',o:'horizontal',p:0,h:'explain',m:'Through the centre of a sphere, the circle is at its largest. This sphere has radius three, so the middle area is nine pi square units.',q:'Where is the sphere section largest?'},
 {n:'Move off centre',s:'sphere',o:'horizontal',p:.6,h:'celebrate',m:'Move away from the centre and the sphere section gets smaller. At a distance of one point eight units, its section area is five point seven six pi square units.',q:'Can a sphere section shrink while the sphere stays unchanged?'}
 ];
var def={id:EN,title:'Cross-sections explorer',config:CFG,steps:STEPS.map(q=>({name:q.n,narration:q.m,prompt:q.q,dur:1900})),
 alt:'A luminous glass solid intersected by a movable gold cutting plane. Beside it the actual two-dimensional section is displayed at true shape proportions. Change the solid, the direction of the cut, and the plane location.',
 staticAlt:'A cross-section is the two-dimensional figure produced by cutting a three-dimensional solid with a plane. Horizontal cuts of a cube give squares, a triangular prism gives triangles, a cylinder gives circles, while a pyramid and cone taper towards their tip; sphere sections are circles whose size changes with distance from the centre.',
 render:function(i,stage){var q=STEPS[i],s=makeState(q.s,q.o,q.p);makeStage(stage,s,q.m,q.h,false);},
 exploreIntro:'Choose a solid and move a cutting plane through it. Compare the highlighted section on the 3D solid with its true two-dimensional outline, then rotate the model to inspect it.',
 explore:function(panel,stage,api){var s=makeState('cube'),sel=h('select',{class:'nova-input','aria-label':'Choose three-dimensional solid'}),orient=h('select',{class:'nova-input','aria-label':'Cut direction'});
 Object.keys(CFG.presets).forEach(k=>sel.appendChild(h('option',{value:k,text:CFG.presets[k]})));
 [['horizontal','Horizontal · across'],['vertical','Vertical · through'],['tilted','Tilted · angled']].forEach(q=>orient.appendChild(h('option',{value:q[0],text:q[1]})));
 var cut=slider('SLICE HEIGHT',0,function(q){s.pos=q;s.refresh();});
 row(panel,[h('label',{class:'f13x-label'},['SOLID ',sel]),h('label',{class:'f13x-label'},['CUT ',orient])]);row(panel,[cut.node]);
 function preset(k){s.shape=k;s.yaw=.74;s.pitch=.57;s.pos=0;sel.value=k;cut.set(0);s.refresh();}sel.onchange=function(){preset(sel.value);};
 orient.onchange=function(){s.orient=orient.value;s.pos=0;cut.set(0);s.refresh();};
 row(panel,[btn('Move down',function(){s.pos=clamp(s.pos-.1,-.9,.9);cut.set(s.pos);s.refresh();},'ghost'),btn('Move up',function(){s.pos=clamp(s.pos+.1,-.9,.9);cut.set(s.pos);s.refresh();},'ghost'),btn('Rotate ↶',function(){s.yaw-=.18;s.refresh();},'ghost'),btn('Rotate ↷',function(){s.yaw+=.18;s.refresh();},'ghost'),btn('Reset',function(){s.orient='horizontal';orient.value=s.orient;preset('cube');},'ghost')]);
 panel.appendChild(h('p',{class:'f13x-instructions',text:'Drag the 3D drawing to rotate. Arrow keys rotate when focused; Page Up and Page Down move the section plane. The gold section is the inside face made by the cut, not the surface area of the entire solid.'}));
 makeStage(stage,s,'Move the plane through the solid, then compare the cross-section on the left with its flat shape on the right.','explain',true);if(api.onCleanup)api.onCleanup(function(){if(stage._f13Cleanup)stage._f13Cleanup();});
 CFG._explore={state:s,preset:preset,setShape:preset,setOrientation:function(a){s.orient=a;orient.value=a;s.refresh();},setPosition:function(v){s.pos=clamp(v,-.9,.9);cut.set(s.pos);s.refresh();},turn:function(a,b){s.yaw+=a;s.pitch=clamp(s.pitch+b,.1,1.24);s.refresh();}};
 },
 challenge:function(panel,api,stage){var tasks=[
 {s:'cube',o:'horizontal',p:0,shape:'square',ans:9,kind:'plain',q:'A cube has side length 3. What is the horizontal cross-section shape and its area in square units?',hint:'The cut creates a 3-by-3 square.'},
 {s:'cylinder',o:'horizontal',p:0,shape:'circle',ans:4,kind:'pi',q:'A cylinder has radius 2. Name the horizontal section and give the coefficient of π in its area.',hint:'Circle area is π × radius squared. Enter 4 for 4π.'},
 {s:'sphere',o:'horizontal',p:0,shape:'circle',ans:9,kind:'pi',q:'A sphere has radius 3. Name the central section and give the coefficient of π in its area.',hint:'A slice through the centre is a circle of radius 3, so its area is 9π.'}];
 var k=0,timer=0,prompt=h('p',{class:'pr-task'}),sh=h('select',{class:'nova-input','aria-label':'Cross-section shape'}),answer=h('input',{class:'nova-input',type:'number',step:'any',inputmode:'decimal','aria-label':'Cross-section area answer'}),feedback=h('p',{class:'f13x-feedback','aria-live':'polite'});
 ['Select a shape','square','rectangle','triangle','circle','hexagon'].forEach(x=>sh.appendChild(h('option',{value:x==='Select a shape'?'':x,text:x})));
 function load(i){k=i;sh.value='';answer.value='';feedback.textContent='';var t=tasks[i];prompt.textContent=(i+1)+' / '+tasks.length+' · '+t.q;makeStage(stage,makeState(t.s,t.o,t.p),'Look at the 3D cut and the 2D section before answering.','think',false);}
 function check(){var t=tasks[k],x=+answer.value,valid=answer.value.trim()!==''&&Number.isFinite(x),ok=sh.value===t.shape&&valid&&Math.abs(x-t.ans)<.00001;
 var msg=ok?'Correct. You identified the section and used the right square-unit area.':sh.value!==t.shape?'Look at the shape inside the gold cutting plane. The cut gives a flat figure.':!valid?'Enter the section area, then check.':t.kind==='pi'?'For a circle, square the radius and give the coefficient of π.':'Multiply the two side lengths of the square, not three dimensions.';
 feedback.textContent=msg;api.check(ok,msg,{task:k,shape:sh.value,area:x});if(ok&&k<tasks.length-1){if(timer)clearTimeout(timer);timer=setTimeout(function(){load(k+1);},1100);}return ok;}
 panel.appendChild(prompt);row(panel,[h('label',{class:'f13x-answer'},['SECTION ',sh]),h('label',{class:'f13x-answer'},['AREA ',answer])]);row(panel,[btn('Check answers',check,'primary'),btn('Hint',function(){api.hint(tasks[k].hint);},'ghost')]);panel.appendChild(feedback);panel.appendChild(h('p',{class:'f13x-instructions',text:'For circular sections, enter the coefficient of π only. Every area is measured in square units.'}));if(api.onCleanup)api.onCleanup(function(){if(timer)clearTimeout(timer);if(stage._f13Cleanup)stage._f13Cleanup();});load(0);CFG._challenge={tasks:tasks,load:load,check:check,shape:sh,answer:answer,task:function(){return k;}};
 }
};
NOVA.bankMount({id:EN,num:'F13·11',title:'Cross-sections explorer',def:def,linked:['F0-01','F0-02','F0-03','F0-04','F0-05','F13-01','F13-06','F13-09','F13-10'],spec:{
 purpose:'Show the true 2D section created by moving a cutting plane through a 3D solid; connect cross-sectional shape to cutting direction and position.',
 params:'Seven solids; horizontal, vertical or tilted cutting planes; normalized position from −90% to +90%; exact circular sections for sphere, cone and cylinder in horizontal mode.',
 presets:'Cube, cuboid, triangular prism, square pyramid, cylinder, cone, sphere.',
 steps:STEPS.map(x=>x.n).join(' → '),
 interactions:'12 teaching beats, three plane orientations, continuous slice position, smooth pointer/keyboard rotation, three marked area/shape challenges.',
 traps:'A cross-section is not the entire surface area; different plane directions create different sections; cylinders keep equal horizontal circles, while cones and pyramids taper; spheres give circles of varying area.',
 gcse:'Recognise cross-sections of 3D solids, distinguish slicing directions and calculate square and circular cross-sectional areas.'}});
var log=document.getElementById('log'),ev=function(x){log.textContent=new Date(x.time).toLocaleTimeString()+' '+x.type+' '+JSON.stringify(x.detail)+'\n'+log.textContent.slice(0,4000);};NOVA.events.history().forEach(ev);NOVA.events.on('*',ev);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
