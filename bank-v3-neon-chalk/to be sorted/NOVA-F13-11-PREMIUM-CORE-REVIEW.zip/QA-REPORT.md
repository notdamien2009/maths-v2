# F13-11 — Premium core QA report

**Result:** 121/121 checks passed; 0 failures. Browser: local Chromium; 1280×900 and 380×900 desktop/mobile viewport tests.

## Scope
- Official embedded NOVA JS core bit-for-bit unchanged relative to F13-10 production base.
- Original NOVA CSS, embedded Chalk font and official mascot dock intact.
- Stage/render at 1280px and 380px; no horizontal overflow; official cat stays within stage.
- Seven solids, each correct horizontal section and mathematical area.
- Cylinder vertical section, cube tilted plane, sphere vertical and offset circle areas.
- Twelve teaching beats available through the existing Watch/Guided engine.
- Explore: pointer/keyboard rotation, position slider, all preset transitions.
- 18 rapid pointer drags per viewport and pointer capture cleanup.
- Challenge: three shape-and-area tasks, correct and incorrect responses.
- Console/page errors: none during tested paths.

**SHA-256 final HTML:** `04c4bb9e064c76d4cd60a81a224079ecdf15f6f2c5c50c74c98cd6ec8388f0bf`

All files are for local review. Visual acceptance remains with the user. Tilted cuts through cone/cylinder are faceted approximations; sphere is analytic.
