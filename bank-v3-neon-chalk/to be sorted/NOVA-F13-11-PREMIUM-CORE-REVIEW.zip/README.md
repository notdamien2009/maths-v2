# NOVA F13-11 — Cross-Sections Explorer
Premium-core review build · 12 October 2026

## Deliverables
- `F13-11-Cross-Sections-Explorer-PREMIUM-CORE.html` — standalone, works locally/offline, original NOVA core and mascot assets inline.
- `source/f13_11_engine.js` — additive component source.
- `source/f13_11_addon.css` — component-only styles.
- `source/build.py` — reproducible builder preserving the F13-10 official core, styles, fonts and mascot.
- `source/F13-10-Sphere-Volume-and-Surface-Area-PREMIUM-CORE.html` — immutable reference base file (not modified).
- `screenshots/` — actual desktop (1280px) and mobile (380px) browser renderings.
- `QA-REPORT.md` and `QA-RESULTS.json` — results and cases.

## Interaction
12 Watch/Guided teaching steps. Explore includes seven solids, horizontal/vertical/tilted cutting planes, a slice-position slider, and pointer/keyboard rotation. Challenge checks three shape+area tasks. Section areas are measured in square units; do not confuse them with surface areas of the full 3D solids.

## Mathematical design notes
- Cube side 3: central horizontal square area 9.
- Cuboid 4 × 2 × 3: central horizontal rectangle area 8.
- Triangular prism: horizontal triangle area 3.
- Square pyramid base side 4, height 4: central horizontal square area 4 and shrinks toward its apex.
- Cylinder radius 2: horizontal circle area 4π at every height; vertical central rectangle area 16.
- Cone radius 2, height 4: horizontal midpoint circle area π; sections narrow toward its apex.
- Sphere radius 3: a planar cut at signed offset z from the centre has exact area π(9 − z²). Orientations may change but the true section remains circular.

The sphere and horizontal circular sections use analytic geometry. Other tilted cuts are polygon–plane intersections (curved solids use a fine faceted approximation); approximate non-horizontal cylinder/cone areas are prefixed with ≈. The software does not pretend such computed shapes are physically perfect CNC cutting geometry.

## Production status
Functional premium-core *review*, not GOLD until user reviews it. No GitHub changes made. The previous rejected standalone F13-01/02/03 builds have not been used.
