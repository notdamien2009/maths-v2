/* NOVA F15-07 — angle slider and trigonometric ratio table. Reuses the canonical NOVA embedded core. */
(function(){'use strict';
var H=NOVA.h,S=NOVA.svg,E=S.el,M=NOVA.motion,ID='F15-07';
var RAD=Math.PI/180;
var CONFIG=window.NOVA_F15_07_CONFIG={startMode:'watch',preset:'y9ratios',events:['value','step','mode','hintUsed','correct','theta','ratio','preset','label'],
 presets:{
  y9ratios:{label:'Y9-031 · Explore angle ratios',theta:35,c:10,min:15,max:75,unit:'cm',kind:'angle'},
  y9compare:{label:'Y9-031 · Compare 30° and 60°',theta:30,c:12,min:15,max:75,unit:'cm',kind:'compare'},
  y9scale:{label:'Y9-031 · Similar triangles (×2)',theta:45,c:8,min:15,max:75,unit:'cm',kind:'similar'},
  y9invsin:{label:'Y9-033 · Inverse sine',theta:30,c:10,min:15,max:75,unit:'cm',kind:'inverse',ratio:'sin'},
  y9invcos:{label:'Y9-033 · Inverse cosine',theta:60,c:10,min:15,max:75,unit:'cm',kind:'inverse',ratio:'cos'},
  y9invtan:{label:'Y9-033 · Inverse tangent',theta:45,c:10,min:15,max:75,unit:'cm',kind:'inverse',ratio:'tan'},
  gcse:{label:'GCSE · Non-special angle',theta:37,c:14,min:15,max:75,unit:'m',kind:'inverse',ratio:'tan'}
 }};
var STEPS=[
 {name:'The right-angle landmark',pose:'explain',narration:'Pythagoras and trigonometry start with a right angled triangle. The little square marks the fixed ninety degree corner.',prompt:'Find the square corner before doing any ratio.'},
 {name:'Choose our angle',pose:'point-down',narration:'Theta is the orange angle between the blue base and green hypotenuse. Changing theta will change the triangle.',prompt:'Which corner is theta?'},
 {name:'Adjacent touches theta',pose:'ruler',narration:'The adjacent side is the shorter blue side next to theta. The hypotenuse also touches theta, but it is a separate role.',prompt:'Which shorter side touches theta?'},
 {name:'Opposite faces theta',pose:'point-left',narration:'The purple opposite side lies across from theta. It does not touch the orange angle.',prompt:'Which side faces the chosen angle?'},
 {name:'Hypotenuse never changes role',pose:'compare',narration:'The long green side faces the right angle. We will keep its length fixed while we change theta.',prompt:'How can both shorter sides change while the longest stays fixed?'},
 {name:'Sweep the acute angle',pose:'magnify',narration:'As the angle grows, the triangle gets taller and less wide. The fixed green hypotenuse anchors the sweep.',prompt:'Which leg gets longer when theta increases?'},
 {name:'Sine comes from opposite',pose:'show-one',narration:'Sine theta equals opposite divided by hypotenuse. With a fixed hypotenuse, sine increases as theta grows.',prompt:'What happens to sine when opposite becomes longer?'},
 {name:'Cosine comes from adjacent',pose:'show-two',narration:'Cosine theta equals adjacent divided by hypotenuse. With a fixed hypotenuse, cosine decreases as theta grows.',prompt:'What happens to cosine as the base shrinks?'},
 {name:'Tangent compares two legs',pose:'show-three',narration:'Tangent theta equals opposite divided by adjacent. As one grows and the other shrinks, tangent rises rapidly.',prompt:'Why does tangent change faster at larger angles?'},
 {name:'Read the ratio table',pose:'count',narration:'Each row is one angle. Read its sine, cosine and tangent in the same row. All the values come from actual triangle ratios.',prompt:'Which table column gets smaller as the angle increases?'},
 {name:'Spot the pattern',pose:'idea',narration:'Sine rises and cosine falls as the acute angle increases. At forty five degrees they are equal.',prompt:'What makes sine and cosine equal at forty five degrees?'},
 {name:'Scale does not change ratios',pose:'magnify',narration:'If every side becomes twice as long, the angle and all three side ratios stay exactly the same.',prompt:'Why does doubling both numbers in a fraction keep the ratio?'},
 {name:'Reverse the ratio',pose:'think',narration:'Inverse sine, inverse cosine and inverse tangent find the angle from a known ratio. First choose the correct pair of sides.',prompt:'If opposite and hypotenuse are known, which inverse ratio finds theta?'},
 {name:'Check and transfer',pose:'celebrate',narration:'Work in degrees, match the sides to theta, divide in the right order, then use the inverse function to recover the angle.',prompt:'Does your angle agree with how tall or wide the triangle looks?'}
];
function fmt(v,dp){if(!Number.isFinite(v))return '—';return dp==null?Number(v.toFixed(2)).toString():Number(v).toFixed(dp);}
function clamp(v,a,b){return Math.min(b,Math.max(a,v));}
function copy(a){return JSON.parse(JSON.stringify(a));}
function vals(st){var t=st.theta*RAD,c=+st.c,a=c*Math.cos(t),o=c*Math.sin(t);return {theta:st.theta,c:c,a:a,o:o,sin:o/c,cos:a/c,tan:o/a};}
function inverse(which,r){if(which==='sin')return Math.asin(r)/RAD;if(which==='cos')return Math.acos(r)/RAD;return Math.atan(r)/RAD;}
window.NOVA_F15_07_MATH={values:vals,inverse:inverse,presets:CONFIG.presets};
function emit(key,value){NOVA.events.emit('value',{engine:ID,key:key,control:key,value:value});}
function chalk(g,x,y,t,role,size,anchor){return NOVA.chalkText(g,x,y,String(t),{role:role||'unknown',size:size||18,anchor:anchor||'middle'});}
function line(g,x1,y1,x2,y2,role,width){return NOVA.neonPath(g,'M'+fmt(x1,3)+' '+fmt(y1,3)+' L'+fmt(x2,3)+' '+fmt(y2,3),{role:role||'op',width:width||3});}
function nbox(g,x,y,w,h,role){return NOVA.neonBox(g,x,y,w,h,{role:role||'support'});}
function poly(g,pts,role){return NOVA.neonPath(g,'M'+pts.map(p=>p.map(k=>fmt(k,3)).join(' ')).join(' L')+' Z',{role:role||'op',width:3.8,fill:true});}
function elbtn(label,handler){return H('button',{class:'nova-btn',text:label,onclick:handler});}
function row(p,els){p.appendChild(H('div',{class:'f157-row'},els));}
function frac(g,x,y,n,d,role){chalk(g,x,y,n,role,17);line(g,x-39,y+12,x+39,y+12,'op',2.2);chalk(g,x,y+36,d,'result',17);}
function geometry(st,mob){var W=mob?420:820,Y=mob?391:371,origin=[mob?100:103,Y],scale=mob?26.5:28;
 var v=vals(st),R=origin,A=[origin[0]+v.a*scale,Y],B=[origin[0],Y-v.o*scale];return {W:W,H:mob?998:590,R:R,A:A,B:B,sc:scale,v:v,midA:[(R[0]+A[0])/2,Y],midO:[R[0],(R[1]+B[1])/2],midH:[(A[0]+B[0])/2,(A[1]+B[1])/2]};}
function sliderCoord(theta,mob){return (mob?61:59)+(theta-15)/60*(mob?298:322);}
function graph(stage,st,o){o=o||{};stage.textContent='';var mob=window.innerWidth<=540,q=geometry(st,mob),v=q.v,R=q.R,A=q.A,B=q.B,step=o.step==null?13:o.step;
 var svg=S.root(q.W,q.H,'Neon right-angled triangle at '+fmt(v.theta)+' degrees. Opposite '+fmt(v.o,2)+' adjacent '+fmt(v.a,2)+' hypotenuse '+fmt(v.c,2)+'; sine '+fmt(v.sin,3)+' cosine '+fmt(v.cos,3)+' tangent '+fmt(v.tan,3)+'. Live table for acute angles 15 to 75 degrees.');svg.classList.add('f157-board');
 // Soft construction grid: core neon primitives, dimmed rather than competing with main geometry.
 var grid=E('g',{style:'opacity:.10;pointer-events:none'},svg);for(var i=0;i<9;i++){var gx=45+i*41;line(grid,gx,83,gx,403,'support',.6);}for(i=0;i<8;i++){var gy=98+i*42;line(grid,41,gy,mob?373:403,gy,'support',.6);}
 if(step===11&&!o.interactive){var k=.5,sc=q.sc*k,r2=[mob?42:42,mob?397:390],a2=[r2[0]+v.a*sc,r2[1]],b2=[r2[0],r2[1]-v.o*sc];var gs=E('g',{style:'opacity:.31;pointer-events:none'},svg);line(gs,...r2,...a2,'given',3);line(gs,...r2,...b2,'support',3);line(gs,...a2,...b2,'result',3);chalk(svg,mob?238:330,72,'Solid side = 2 × dashed','focus',mob?18:21);}
 poly(svg,[R,A,B],'op');line(svg,...R,...A,'given',4.8);line(svg,...R,...B,'support',4.8);line(svg,...A,...B,'result',5);
 NOVA.neonPath(svg,'M'+(R[0]+20)+' '+R[1]+' L'+(R[0]+20)+' '+(R[1]-20)+' L'+R[0]+' '+(R[1]-20),{role:'unknown',width:3});
 var radius=36,p1=[A[0]-radius,A[1]],p2=[A[0]-radius*Math.cos(v.theta*RAD),A[1]-radius*Math.sin(v.theta*RAD)];
 NOVA.neonPath(svg,'M'+p1.join(' ')+' A'+radius+' '+radius+' 0 0 1 '+p2.join(' '),{role:'focus',width:3.3});
 chalk(svg,A[0]-52,A[1]-27,'θ '+fmt(v.theta)+'°','focus',mob?17:18);
 var show=step>=2||o.interactive;
 if(show){chalk(svg,q.midA[0],q.midA[1]+23,'Adj '+fmt(v.a,1),'given',mob?17:19);}
 if(step>=3||o.interactive){chalk(svg,q.midO[0]-13,q.midO[1],'Opp '+fmt(v.o,1),'support',mob?17:19,'end');}
 if(step>=4||o.interactive){chalk(svg,q.midH[0]+17,q.midH[1]-14,'Hyp '+fmt(v.c,1),'result',mob?17:19,'start');}
 chalk(svg,mob?211:243,54,'Changing θ changes the ratios','unknown',mob?19:22);
 if(step>=5||o.interactive){chalk(svg,mob?235:241,100,'Right angle stays 90°','focus',mob?16:18);}
 // Angle rail and angle marker: precise discrete targets from the canonical drag kit.
 var sy=mob?463:450,px0=sliderCoord(15,mob),px1=sliderCoord(75,mob);line(svg,px0,sy,px1,sy,'support',5);
 for(var k=15;k<=75;k+=15){var ex=sliderCoord(k,mob);line(svg,ex,sy-7,ex,sy+8,'given',2);chalk(svg,ex,sy+28,k+'°','unknown',mob?14:16);}
 var hx=sliderCoord(v.theta,mob);NOVA.neonRing(svg,hx,sy,{r:11,role:'focus'});
 chalk(svg,mob?200:216,sy-24,'Drag the angle marker','focus',18);
 // Table: exact ratios (fixed reference rows plus current-angle row, live values never hardcoded).
 var tx=mob?17:435,ty=mob?516:104,tw=mob?386:368,hd=mob?41:42,rh=mob?40:43;
 nbox(svg,tx,ty,tw,hd,'op');chalk(svg,tx+tw/2,ty+29,'Live trig ratio table','unknown',mob?20:19);
 var headers=['θ','sin θ','cos θ','tan θ'],cw=tw/4;
 headers.forEach(function(t,i){chalk(svg,tx+(i+.5)*cw,ty+hd+22,t,i===1?'support':i===2?'given':i===3?'focus':'unknown',mob?16:18);});
 var tableAngles=[15,30,45,60,75];if(!tableAngles.includes(v.theta))tableAngles.push(v.theta);tableAngles.sort((a,b)=>a-b);
 // A seven-row table is more compact than a scrolling list, and always contains the active value.
 tableAngles.forEach(function(deg,i){var y=ty+hd+32+i*rh,selected=Math.abs(deg-v.theta)<1e-8,role=selected?'focus':(i%2?'support':'op');
 nbox(svg,tx+1,y,tw-2,rh-3,role);if(!selected){var rect=svg.lastElementChild;if(rect)rect.style.opacity='.34';}
 var t=deg*RAD,reveal=o.interactive?3:Math.max(0,step-5),values=[deg+'°',reveal>=1?fmt(Math.sin(t),3):'·',reveal>=2?fmt(Math.cos(t),3):'·',reveal>=3?fmt(Math.tan(t),3):'·'];values.forEach(function(s,j){chalk(svg,tx+(j+.5)*cw,y+rh*.61,s,selected?'focus':j===1?'support':j===2?'given':j===3?'result':'unknown',mob?17:18);});
 });
 if(step>=6||o.interactive){var yy=mob?868:518,n=st.ratio||'sin',which=n==='sin'?['Opp','Hyp',v.sin]:n==='cos'?['Adj','Hyp',v.cos]:['Opp','Adj',v.tan];
 chalk(svg,mob?58:450,yy,n+' θ =','focus',mob?19:21,'start');frac(svg,mob?225:638,yy-18,which[0],which[1],'support');chalk(svg,mob?339:770,yy+5,'= '+fmt(which[2],3),'result',mob?18:21);
 }
 if(o.interactive){
  // Movable angle ring with NOVA F2.svgDrag discrete 5-degree snap targets.
  var group=E('g',{tabindex:'0',role:'slider','data-handle':'theta','aria-label':'Drag the angle marker from 15 to 75 degrees or use arrow keys','aria-valuemin':'15','aria-valuemax':'75','aria-valuenow':String(v.theta)},svg);
  NOVA.neonRing(group,hx,sy,{r:13,role:'focus'});
  var zs=[];for(var deg=15;deg<=75;deg+=5){var xx=sliderCoord(deg,mob);zs.push({x:xx-11,y:sy-15,w:22,h:30,id:String(deg),kind:'drop'});}
  NOVA.ui.svgDrag(svg,group,{box:{x:hx-15,y:sy-15,w:30,h:30},zones:function(){return zs;},onDrop:function(id){st.theta=+id;st.placed={};st.feedback='Theta is '+id+' degrees. Every table value follows the new triangle.';emit('theta',st.theta);o.update();return true;}});
  group.addEventListener('keydown',function(e){if(!['ArrowLeft','ArrowDown','ArrowRight','ArrowUp','Home','End'].includes(e.key))return;e.preventDefault();st.theta=e.key==='Home'?15:e.key==='End'?75:clamp(st.theta+((e.key==='ArrowRight'||e.key==='ArrowUp')?1:-1),15,75);st.placed={};emit('theta',st.theta);o.update('theta');});
  // Both acute triangle vertices are constrained to the same fixed-hypotenuse sweep.
  [['a',A,'given'],['b',B,'support']].forEach(function(item){var id=item[0],pt=item[1],gr=E('g',{role:'slider',tabindex:'0','data-vertex':id,'aria-label':'Move '+(id==='a'?'adjacent':'opposite')+' vertex along its constrained axis to adjust angle. Arrow keys change the angle.','aria-valuenow':fmt(st.theta)},svg);NOVA.neonRing(gr,pt[0],pt[1],{r:10,role:item[2]});var targets=[];for(var ang=15;ang<=75;ang+=5){var lv=vals({theta:ang,c:st.c}),pos=id==='a'?[R[0]+lv.a*q.sc,R[1]]:[R[0],R[1]-lv.o*q.sc];targets.push({x:pos[0]-4,y:pos[1]-4,w:8,h:8,id:String(ang),kind:'drop'});}NOVA.ui.svgDrag(svg,gr,{box:{x:pt[0]-12,y:pt[1]-12,w:24,h:24},zones:function(){return targets;},onDrop:function(value){st.theta=+value;st.placed={};emit('theta',st.theta);o.update();return true;}});gr.addEventListener('keydown',function(e){if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();st.theta=clamp(st.theta+((e.key==='ArrowRight'||e.key==='ArrowUp')?1:-1),15,75);st.placed={};emit('theta',st.theta);o.update('vertex-'+id);});});
  // Movable role cards, re-grabbable after snapping, with remove tray; exact targets.
  var targets={opp:{name:'Opposite',pos:q.midO,role:'support'},adj:{name:'Adjacent',pos:q.midA,role:'given'},hyp:{name:'Hypotenuse',pos:q.midH,role:'result'}};
  var ly=mob?928:520,xx0=mob?8:60,bw=mob?125:110;
  Object.keys(targets).forEach(function(key,i){var t=targets[key],placed=!!st.placed[key],px=placed?clamp(t.pos[0]-bw/2,5,q.W-bw-5):xx0+i*(bw+9),py=placed?clamp(t.pos[1]-34,75,q.H-58):ly;
   var gr=E('g',{tabindex:'0',role:'button','data-label':key,'aria-label':'Move '+t.name+' label to its matching side, or press Enter to place it'},svg);nbox(gr,px,py,bw,31,t.role);chalk(gr,px+bw/2,py+23,t.name,t.role,mob?16:17);
   var zones=Object.keys(targets).map(function(k){return {x:targets[k].pos[0]-32,y:targets[k].pos[1]-28,w:64,h:56,id:k,kind:'drop'};});
   if(placed)zones.push({x:xx0-2,y:ly-5,w:bw*3+24,h:40,id:'remove',kind:'remove'});
   NOVA.ui.svgDrag(svg,gr,{box:{x:px,y:py,w:bw,h:31},zones:function(){return zones;},onDrop:function(k){if(k!==key){st.feedback='That is not '+t.name.toLowerCase()+'. Identify the side relative to theta.';o.update();return false;}st.placed[key]=true;st.feedback='Correct: '+t.name+' is placed relative to theta.';emit('label',key);o.update();return true;},onRemove:function(){st.placed[key]=false;st.feedback=t.name+' returned to the label tray.';o.update();}});
   gr.addEventListener('keydown',function(e){if(e.key!=='Enter'&&e.key!==' ')return;e.preventDefault();st.placed[key]=!st.placed[key];emit('label',key);st.feedback=t.name+(st.placed[key]?' labelled.':' returned to tray.');o.update(key);});
  });
 }
 stage.appendChild(svg);
 if(step>=11&&!o.interactive)stage.appendChild(H('div',{class:'f157-copy',text:step===12?'Use inverse trig: θ = sin⁻¹(opposite ÷ hypotenuse), cos⁻¹(adjacent ÷ hypotenuse), or tan⁻¹(opposite ÷ adjacent).':'The entire family of similar triangles preserves each ratio at the same angle.'}));
 NOVA.scene.helperStrip(stage,o.pose||'explain',o.say||'Move theta to see how the ratios change.');
 if(o.animate&&!NOVA.reducedMotion()){var tile=svg.querySelector('.nv-neon-tube');if(tile){tile.style.opacity='.25';M.tween(480,function(t){if(tile.isConnected)tile.style.opacity=String(.25+.75*t);},M.ease.out,function(){if(tile.isConnected)tile.style.opacity='1';});}}
 return svg;
}
function stepRender(i,stage){var st=copy(CONFIG.presets[CONFIG.preset]),t=STEPS[i];st.ratio=i>=8?'tan':i===7?'cos':'sin';if(i===5)st.theta=60;if(i===10)st.theta=45;
 graph(stage,st,{step:i,say:t.narration,pose:t.pose,animate:true});}
var DEF={id:ID,title:'Angle Slider and Ratio Table',config:CONFIG,steps:STEPS,render:stepRender,
 alt:'Interactive acute right triangle with an orange angle slider and a live table of sine cosine and tangent values.',
 staticAlt:'For angle theta, opposite = c sin(theta), adjacent = c cos(theta); tan theta = opposite divided by adjacent. The live table shows 15°, 30°, 45°, 60°, 75° and the selected angle. Inverse trig recovers theta from a side ratio.',
 exploreIntro:'Change the angle using the neon slider, mouse drags, arrow keys or preset controls. Identify the three sides; compare the live sine, cosine and tangent values. Hypotenuse stays fixed.',
 explore:function(panel,stage,api){var base=CONFIG.presets[CONFIG.preset],st=copy(base);st.ratio='sin';st.placed={};st.feedback='Move the neon angle marker. Observe the three linked ratios.';
 var preset=H('select',{class:'nova-input','aria-label':'Angle and ratio learning preset'});Object.keys(CONFIG.presets).forEach(function(k){preset.appendChild(H('option',{value:k,text:CONFIG.presets[k].label}));});preset.value=CONFIG.preset;
 var angle=H('input',{type:'range',min:15,max:75,step:1,value:st.theta,'aria-label':'Angle theta in degrees'});
 var which=H('select',{class:'nova-input','aria-label':'Highlighted trigonometric ratio'});[['sin','Sine · opposite over hypotenuse'],['cos','Cosine · adjacent over hypotenuse'],['tan','Tangent · opposite over adjacent']].forEach(function(k){which.appendChild(H('option',{value:k[0],text:k[1]}));});
 var report=H('div',{class:'f157-output','aria-live':'polite'});
 function paint(focus){angle.value=st.theta;which.value=st.ratio;var v=vals(st);graph(stage,st,{interactive:true,step:13,pose:Object.values(st.placed).filter(Boolean).length===3?'celebrate':'ruler',say:st.feedback||'Sweep the angle to discover the ratio pattern.',update:paint});report.textContent='θ = '+fmt(st.theta)+'°. Opposite '+fmt(v.o,2)+' '+st.unit+'; adjacent '+fmt(v.a,2)+' '+st.unit+'; hypotenuse '+fmt(v.c,2)+' '+st.unit+'. sin θ = '+fmt(v.sin,3)+', cos θ = '+fmt(v.cos,3)+', tan θ = '+fmt(v.tan,3)+'. '+st.feedback;
 if(focus){var f=stage.querySelector('[data-handle="'+focus+'"], [data-label="'+focus+'"], [data-vertex="'+String(focus).replace('vertex-','')+'"]');if(f)f.focus({preventScroll:true});}}
 preset.onchange=function(){CONFIG.preset=preset.value;base=CONFIG.presets[CONFIG.preset];st=copy(base);st.ratio='sin';st.placed={};st.feedback='Preset loaded. The hypotenuse remains fixed while theta changes.';emit('preset',CONFIG.preset);paint();};
 angle.oninput=function(){st.theta=+angle.value;st.placed={};st.feedback='Watch how one leg grows and the other shrinks.';emit('theta',st.theta);paint();};
 which.onchange=function(){st.ratio=which.value;emit('ratio',st.ratio);paint();};
 row(panel,[H('label',{text:'Preset'}),preset]);row(panel,[H('label',{text:'Angle θ'}),angle,H('strong',{text:'15°–75°'})]);
 row(panel,[elbtn('−5°',function(){st.theta=clamp(st.theta-5,15,75);st.placed={};emit('theta',st.theta);paint();}),elbtn('+5°',function(){st.theta=clamp(st.theta+5,15,75);st.placed={};emit('theta',st.theta);paint();}),elbtn('30°',function(){st.theta=30;st.placed={};paint();}),elbtn('45°',function(){st.theta=45;st.placed={};paint();}),elbtn('60°',function(){st.theta=60;st.placed={};paint();})]);
 row(panel,[H('label',{text:'Focus ratio'}),which,elbtn('Reset',function(){st=copy(base);st.ratio='sin';st.placed={};paint();})]);panel.appendChild(report);paint();
 CONFIG._explore={state:function(){return st;},select:function(k){preset.value=k;preset.onchange();},paint:paint};
 },
 challenge:function(panel,api,stage){var Q=[
 {q:'At θ = 30°, find sin θ to 2 decimal places.',theta:30,c:10,ratio:'sin',ans:.5,dp:2,hint:'Sine = opposite ÷ hypotenuse. sin 30° = 0.5.',wrong:[{v:.866,msg:'That is cosine 30°, not sine.'},{v:2,msg:'Sine of an acute angle cannot exceed 1.'}]},
 {q:'At θ = 60°, find cos θ to 2 decimal places.',theta:60,c:12,ratio:'cos',ans:.5,dp:2,hint:'Cosine = adjacent ÷ hypotenuse.',wrong:[{v:.866,msg:'That is sine 60°. You selected the opposite side.'},{v:2,msg:'You inverted cosine. Divide adjacent by hypotenuse.'}]},
 {q:'At θ = 45°, find tan θ to 2 decimal places.',theta:45,c:10,ratio:'tan',ans:1,dp:2,hint:'Opposite and adjacent are equal at 45°, so their ratio is 1.',wrong:[{v:.707,msg:'That is the sine or cosine of 45°, not tangent.'}]},
 {q:'At θ = 35°, find sin θ to 3 decimal places.',theta:35,c:10,ratio:'sin',ans:Math.sin(35*RAD),dp:3,hint:'Enter calculator degree mode: sin 35°.',wrong:[{v:Math.cos(35*RAD),msg:'That is cosine, not sine. Use the opposite side.'}]},
 {q:'Opposite = 5 cm and hypotenuse = 10 cm. Find θ to the nearest degree.',theta:30,c:10,ratio:'sin',ans:30,dp:0,hint:'θ = sin⁻¹(5 ÷ 10). Enter 0.5 into inverse sine in degree mode.',wrong:[{v:.5,msg:'You found the ratio but were asked for the angle. Use inverse sine.'},{v:60,msg:'60° comes from inverse cosine of 0.5; the given pair needs sine.'}]},
 {q:'Adjacent = 5 cm and hypotenuse = 10 cm. Find θ to the nearest degree.',theta:60,c:10,ratio:'cos',ans:60,dp:0,hint:'θ = cos⁻¹(5 ÷ 10).',wrong:[{v:30,msg:'30° uses inverse sine of 0.5; your ratio is adjacent over hypotenuse.'},{v:.5,msg:'0.5 is the ratio, not the angle.'}]},
 {q:'Opposite = 8 cm, adjacent = 8 cm. Find θ to the nearest degree.',theta:45,c:Math.hypot(8,8),ratio:'tan',ans:45,dp:0,hint:'θ = tan⁻¹(8 ÷ 8).',wrong:[{v:1,msg:'1 is tangent 45°, not the angle itself.'}]},
 {q:'GCSE: opposite = 6.0 m and adjacent = 8.0 m. Find θ to 1 decimal place.',theta:Math.atan(6/8)/RAD,c:10,ratio:'tan',ans:Math.atan(6/8)/RAD,dp:1,hint:'tan θ = 6 ÷ 8. Use tan⁻¹(0.75), then round once.',wrong:[{v:.75,msg:'You stopped at the ratio. Apply inverse tangent to find the angle.'},{v:53.1,msg:'You inverted the tangent ratio: opposite must be divided by adjacent.'}]},
 {q:'GCSE: find the angle θ if sin θ = 0.6. Give your answer to 1 decimal place.',theta:Math.asin(.6)/RAD,c:10,ratio:'sin',ans:Math.asin(.6)/RAD,dp:1,hint:'θ = sin⁻¹(0.6). Check the calculator is in degrees.',wrong:[{v:.6,msg:'0.6 is the sine ratio, not its corresponding angle.'},{v:53.1,msg:'That uses inverse cosine of 0.6. You need inverse sine.'}]}
 ];
 function check(t,v){if(!Number.isFinite(v))return [false,'Enter a finite number, without units.'];if(Math.abs(v-t.ans)<Math.pow(10,-t.dp)/2+1e-8)return [true,'Correct: '+fmt(t.ans,t.dp)+(t.dp===0?'°':(t.ans>2?'°':' (ratio)'))+'.'];for(var k of t.wrong)if(Math.abs(v-k.v)<(t.dp===0?.51:.025))return [false,k.msg];if(v<0)return [false,'Acute angles and the corresponding right-triangle ratios must be positive.'];if(t.ans>2&&v<=1)return [false,'You have the ratio, not the angle. Use the inverse trig function in degree mode.'];if(t.ans<=1&&t.ratio!=='tan'&&v>1)return [false,'For acute angles, sine and cosine must be at most 1.'];return [false,t.ans>2?'Identify the right pair of sides, form the ratio, then use the correct inverse trig key.':'Check the side roles at theta and calculate the indicated ratio.'];}
 function show(i){var t=Q[i];graph(stage,{theta:t.theta,c:t.c,unit:'cm',ratio:t.ratio,placed:{}},{step:10,pose:'think',say:'Read opposite, adjacent and hypotenuse relative to the orange angle. Select the appropriate ratio.'});}
 var tasks=Q.map(function(t){return {q:t.q,build:NOVA.entryTask('Number without units',ID),check:function(v){return check(t,v);},hint:t.hint,solve:function(ctl){var e=ctl.querySelector('input');if(e){e.value=fmt(t.ans,t.dp);e.dispatchEvent(new Event('input',{bubbles:true}));}}};});
 NOVA.challengeRun(panel,api,tasks,show,CONFIG);CONFIG._challengeQuestions=Q;CONFIG._check=check;
 }
};
/* Same F15-06 document-level pointer continuity safeguard; no shared-core mutation. */
(function(){function active(){var d=NOVA.ui._drag;return d&&d.el&&d.el.closest&&d.el.closest('#'+ID)?d:null;}
 document.addEventListener('pointermove',function(e){if(!e.isTrusted)return;var d=active();if(!d)return;d.el.dispatchEvent(new PointerEvent('pointermove',{pointerId:e.pointerId,pointerType:e.pointerType,clientX:e.clientX,clientY:e.clientY,buttons:e.buttons,bubbles:false,cancelable:true}));},true);
 document.addEventListener('pointerup',function(e){var d=active();if(d)d.up(e);},true);
 document.addEventListener('pointercancel',function(e){var d=active();if(d)d.cancel(e);},true);
 window.addEventListener('blur',function(){var d=active();if(d)d.cancel();});
})();
NOVA.bankMount({id:ID,num:'F15·07',title:'Angle Slider and Ratio Table',def:DEF,
 years:'Y9-031 trigonometric ratios; Y9-033 inverse trigonometry to find angles; GCSE Foundation and Higher extension.',
 linked:['F0-02','F0-03','F0-04','F14-11','F15-06 (ratio builder)','F15-08 (unit circle)'],spec:{
 purpose:'Show in one linked visual how acute angle, right-triangle leg lengths and the sine/cosine/tangent ratios change; recover angles using inverse trigonometry.',
 params:'Angle θ (15°–75°); constant hypotenuse c; derived adjacent and opposite; chosen ratio; angle table; precision; units.',
 presets:'Y9-031 angle explorer, 30° vs 60°, similar right triangles; Y9-033 inverse sine/cosine/tangent; GCSE arbitrary angle.',
 steps:'14 named stages: reference triangle, side roles, angle sweep, the three ratios, ratio table, patterns, similarity, inverse functions and transfer.',
 interactions:'Watch timeline and Bob narration; Guided scaffold; Explore angle slider/vertex handle dragging, movable side-role cards, true live ratio table; nine checked Challenge problems.',
 traps:'Interchanging opposite and adjacent; assuming sine and cosine both rise; thinking ratios scale with triangle size; treating 0.5 as an angle; using trig instead of inverse trig; radians/degrees confusion.',
 gcse:'Exact internal trigonometric values, degree-mode inverse functions, round only the final angle, 1 dp questions.'}});
var lg=document.getElementById('log');if(lg){function event(e){lg.textContent=new Date(e.time).toLocaleTimeString()+' '+e.type+' '+JSON.stringify(e.detail)+'\n'+lg.textContent.slice(0,5000);}NOVA.events.history().forEach(event);NOVA.events.on('*',event);document.getElementById('clearlog').onclick=function(){lg.textContent='';};}
})();
