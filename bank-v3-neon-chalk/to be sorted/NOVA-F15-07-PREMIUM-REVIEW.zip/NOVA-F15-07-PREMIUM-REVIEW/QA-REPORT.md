# NOVA F15-07 — Production QA for owner review

**Status:** BUILT FOR REVIEW — NOT GOLD APPROVED.  **No GitHub changes.**

## Canonical design and build sources
- The exact F15-07 master prompt was read from `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`.
- The embedded NOVA shared core is **byte-for-byte identical** to the independently delivered F15-06 core. SHA-256: `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc`.
- Original F15-06 stage and helper design references were inspected; there is one docked NOVA helper inside the stage.
- The standalone HTML is self-contained, with no external CSS, script, or font file dependencies.

## Spec card
- **Teaching objective:** Connect acute angle θ to opposite, adjacent and hypotenuse; show the exact changing sine/cosine/tangent ratios; recover angles using inverse trigonometric functions.
- **Year/lessons:** Y9-031 trigonometric ratios; Y9-033 finding angles. GCSE extension.
- **Parameters:** θ = 15°…75°; constant hypotenuse; seven named presets; sin/cos/tan selection; units and precision.
- **Animation:** 14 named teaching states, each with teaching-specific narration and changing original mascot pose.
- **Watch/Guided:** original NOVA controls for rewind, play/pause, scrub, step and reset; sequential table reveal at the correct teaching steps.
- **Explore:** neon angle rail + real pointer drag, two right-triangle vertices constrained to a fixed hypotenuse, three draggable role cards, keyboard equivalents, removal tray, angle buttons, live ratios/triangle, preset selector.
- **Challenge:** nine independently checked numerical tasks (special ratios, acute trig values, inverse sine/cosine/tangent; GCSE 1dp).
- **Mathematical traps:** label inversion; using cosine for opposite/hypotenuse; sine/cosine growth misconception; treating a ratio as an angle; incorrect inverse operation; rounded intermediary values.

## Tests actually executed
- **110/110** primary checks passed across 380 and 1280 pixels; see `tests/stress-results.json`.
- **56/56** extended tests passed across 380 and 1280 pixels; see `tests/extended-results.json`.
- **Combined 166/166 tests passed, 0 recorded failures.**
- The suite verifies actual mouse moves on the SVG angle ring, both constrained triangle vertices, correct/incorrect label-zone snapping, label regrab and red-tray removal, Escape and pointer cleanup, keyboard equivalents, all seven presets, mathematical identities and nine checks submitted through the actual challenge control at both screen widths.
- All four modes rendered without JavaScript errors at 380 and 1280 pixels. Screenshots are in `screenshots/` (8 final mode captures).
- Timeline controls were separately exercised in browser: forward, scrub to step 11, back, reset to step 1 (all changed to the expected named state).
- No claim is made of a separate physical touchscreen test or final owner sign-off.

## Review evidence with source locations (source is `F15-07-engine.js`)
| Requirement | Evidence |
|---|---|
| Named curriculum presets and event keys | `F15-07-engine.js:5` |
| 14 detailed teaching states | `F15-07-engine.js:15` |
| Exact trig / inverse maths | `F15-07-engine.js:34`; `:35` |
| Mathematically correct right triangle, Pythagoras-preserving geometry | `F15-07-engine.js:45` |
| Core neon shapes and correct angle arc | `F15-07-engine.js:53` |
| LIVE table with staged reveal and correct ratios | `F15-07-engine.js:78` |
| Genuine fast-drag angle marker and snapping | `F15-07-engine.js:85` |
| Constrained original triangle vertices | `F15-07-engine.js:91` |
| Side-card snap, regrab and removal | `F15-07-engine.js:93` |
| Keyboard equivalents | `F15-07-engine.js:89` |
| Proper stacked chalk mathematical fractions | `F15-07-engine.js:44` |
| User-facing Challenge calculations and diagnostic feedback | `F15-07-engine.js:130` |
| Original helper placement | `F15-07-engine.js:105` plus final screenshots |
| Four-mode viewport evidence | `screenshots/380-*.png`, `screenshots/1280-*.png` |

## Remaining acceptance
Owner review is required before describing this engine as GOLD-approved. The reference screenshot quality, drag responsiveness on the user's own hardware, pedagogical usefulness and final integration into lessons are to be judged by the owner.
