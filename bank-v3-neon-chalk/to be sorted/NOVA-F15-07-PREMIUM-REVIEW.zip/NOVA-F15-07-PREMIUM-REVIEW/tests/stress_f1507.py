import json, math, pathlib, re,sys
from playwright.sync_api import sync_playwright
html=pathlib.Path('/mnt/data/NOVA-F15-07-Angle-Slider-Ratio-Table.html').read_text()
PASS=[];FAIL=[]
def ck(condition,thing):
 (PASS if condition else FAIL).append(thing)
def jspos(page,x,y):
 return page.evaluate('''([x,y])=>{let s=document.querySelector('.nova-stage .f157-board'),p=s.createSVGPoint();p.x=x;p.y=y;let q=p.matrixTransform(s.getScreenCTM());return {x:q.x,y:q.y}}''',[x,y])
def drag(page,start,end,steps=1):
 page.mouse.move(start['x'],start['y']);page.mouse.down();page.mouse.move(end['x'],end['y'],steps=steps);page.mouse.up();page.wait_for_timeout(380)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1);errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded');page.wait_for_timeout(200)
  ck(page.locator('.nova-tabs button').count()==4,f'{width}: four modes')
  ck(page.locator('.nv-dock').count()==1,f'{width}: one helper inside stage')
  for mode in ['Watch','Guided','Explore','Challenge']:
   page.locator('.nova-tabs button').get_by_text(mode,exact=True).click();page.wait_for_timeout(150)
   ck(page.locator('.nova-stage .f157-board').count()==1,f'{width}: {mode} rendered')
  page.locator('.nova-tabs button').get_by_text('Explore',exact=True).click()
  page.wait_for_timeout(110)
  data=page.evaluate('''()=>window.NOVA_F15_07_MATH.values(NOVA_F15_07_CONFIG._explore.state())''')
  ck(abs(data['sin']**2+data['cos']**2-1)<1e-12,f'{width}: sine squared + cosine squared')
  ck(abs(data['tan']-data['sin']/data['cos'])<1e-12,f'{width}: tangent identity')
  ck(len(page.locator('.f157-board [data-label]').all())==3,f'{width}: three draggable role cards')
  ck(page.locator('.f157-board [data-handle="theta"]').count()==1,f'{width}: angle drag handle')
  ck(page.locator('.f157-board [data-vertex]').count()==2,f'{width}: two constrained vertices')
  ck(page.locator('.f157-board').text_content().find('0.574')!=-1,f'{width}: live sin 35 table')
  # Test slider range callback.
  page.locator('input[aria-label="Angle theta in degrees"]').fill('55')
  v=page.evaluate('''()=>window.NOVA_F15_07_CONFIG._explore.state().theta''')
  ck(v==55,f'{width}: slider 55 degrees')
  # Keyboard equivalent for slider handle.
  knob=page.locator('.f157-board [data-handle="theta"]');knob.focus();page.keyboard.press('ArrowRight');
  ck(page.evaluate('''()=>window.NOVA_F15_07_CONFIG._explore.state().theta''')==56,f'{width}: keyboard arrow 56 degrees')
  # real mouse via SVG coord; need scroll the stage handle into visible viewport
  knob=page.locator('.f157-board [data-handle="theta"]');knob.scroll_into_view_if_needed()
  mob=width==380; y=463 if mob else 450; x=61+(56-15)/60*298 if mob else 59+(56-15)/60*322; ex=61+(65-15)/60*298 if mob else 59+(65-15)/60*322
  start=jspos(page,x,y);end=jspos(page,ex,y)
  drag(page,start,end,1)
  value=page.evaluate('''()=>window.NOVA_F15_07_CONFIG._explore.state().theta''');ck(value==65,f'{width}: mouse fast drag snaps 65 (got {value})')
  # Escape cancels a half drag: move before Escape then release.
  page.locator('.f157-board [data-handle="theta"]').scroll_into_view_if_needed()
  sx=61+(65-15)/60*298 if mob else 59+(65-15)/60*322
  st=jspos(page,sx,y);nxt=jspos(page,61+(30-15)/60*298 if mob else 59+(30-15)/60*322,y)
  page.mouse.move(st['x'],st['y']);page.mouse.down();page.mouse.move(nxt['x'],nxt['y'],steps=3);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(470)
  ck(page.evaluate('''()=>window.NOVA_F15_07_CONFIG._explore.state().theta''')==65,f'{width}: Escape cancels drag')
  ck(page.evaluate('''()=>!NOVA.ui._drag'''),f'{width}: no stuck active drag')
  # Move a label by actual mouse to the right zone; test wrong drop then correct.
  stdata=page.evaluate('''()=>NOVA_F15_07_CONFIG._explore.state()''');th=stdata['theta']*math.pi/180;c=stdata['c'];sc=26.5 if mob else 28;r=[100,391] if mob else [103,371];A=[r[0]+c*math.cos(th)*sc,r[1]];B=[r[0],r[1]-c*math.sin(th)*sc];midA=[(r[0]+A[0])/2,r[1]];midO=[r[0],(r[1]+B[1])/2]
  lab=page.locator('.f157-board [data-label="opp"]');lab.scroll_into_view_if_needed();bounds=lab.bounding_box();st={'x':bounds['x']+bounds['width']/2,'y':bounds['y']+bounds['height']/2}
  wrong=jspos(page,*midA);drag(page,st,wrong,5)
  ck(page.evaluate('''()=>!NOVA_F15_07_CONFIG._explore.state().placed.opp'''),f'{width}: wrong label refused')
  ck(page.evaluate('''()=>!NOVA.ui._drag'''),f'{width}: no floating label after invalid drop')
  lab=page.locator('.f157-board [data-label="opp"]');lab.scroll_into_view_if_needed();bounds=lab.bounding_box();st={'x':bounds['x']+bounds['width']/2,'y':bounds['y']+bounds['height']/2}
  right=jspos(page,*midO);drag(page,st,right,6)
  ck(page.evaluate('''()=>!!NOVA_F15_07_CONFIG._explore.state().placed.opp'''),f'{width}: correct label snaps')
  # keyboard toggle after placement
  lab=page.locator('.f157-board [data-label="opp"]');lab.focus();page.keyboard.press('Enter')
  ck(page.evaluate('''()=>!NOVA_F15_07_CONFIG._explore.state().placed.opp'''),f'{width}: label keyboard toggles back')
  # test presets and geometry in the browser, 0 deg returns invalid etc
  for name in ['y9ratios','y9compare','y9scale','y9invsin','y9invcos','y9invtan','gcse']:
   page.evaluate('''(n)=>NOVA_F15_07_CONFIG._explore.select(n)''',name)
   v=page.evaluate('''()=>NOVA_F15_07_MATH.values(NOVA_F15_07_CONFIG._explore.state())''')
   ck(abs(v['a']**2+v['o']**2-v['c']**2)<1e-7,f'{width}: preset {name} Pythagoras')
   ck(abs(math.atan2(v['o'],v['a'])*180/math.pi-v['theta'])<1e-8,f'{width}: preset {name} angle correct')
  page.locator('.nova-tabs button').get_by_text('Challenge',exact=True).click();page.wait_for_timeout(250)
  for j in range(9):
   q=page.evaluate('''(i)=>NOVA_F15_07_CONFIG._challengeQuestions[i]''',j)
   check=page.evaluate('''(i)=>{let c=NOVA_F15_07_CONFIG;let q=c._challengeQuestions[i];return [c._check(q,q.ans)[0],c._check(q,q.ans+10)[0]]}''',j)
   ck(check==[True,False],f'{width}: challenge {j+1} maths and checking')
   ck(abs(q['ans']-q['theta'])<1e-9 or q['ans']<=1,f'{width}: challenge {j+1} expected solution')
  # Test actual form submission, including step change.
  page.evaluate('''()=>NOVA_F15_07_CONFIG._challenge.solve()''')
  page.locator('#F15-07 .nova-panel button').filter(has_text='Check').first.click();page.wait_for_timeout(1050)
  ck(page.evaluate('''()=>NOVA_F15_07_CONFIG._challenge.task()''')>=1,f'{width}: submit correct -> next task')
  ck(len(errs)==0,f'{width}: 0 script errors {errs}')
  page.close()
 browser.close()
path=pathlib.Path('/mnt/data/f15-reference/F15-07-QA')
path.joinpath('stress-results.json').write_text(json.dumps({'passed':len(PASS),'failed':len(FAIL),'checks':PASS,'failures':FAIL},indent=2))
print('TOTAL',len(PASS),'PASS;',len(FAIL),'FAIL');print('FAILURES',json.dumps(FAIL,indent=2));sys.exit(bool(FAIL))
