import http.server,threading, functools,json,sys,time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data');OUT=ROOT/'f15-reference'/'F15-07-QA';OUT.mkdir(exist_ok=True)
S=http.server.ThreadingHTTPServer(('127.0.0.1',8897),functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(ROOT)))
th=threading.Thread(target=S.serve_forever,daemon=True);th.start();print('HTTP serving')
errs=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=browser.new_page(viewport={'width':width,'height':900}, device_scale_factor=1)
  page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content((ROOT/'NOVA-F15-07-Angle-Slider-Ratio-Table.html').read_text(),wait_until='domcontentloaded',timeout=30000)
  page.wait_for_timeout(500)
  print(width,'title',page.title(),'buttons',page.locator('.nova-tabs button').all_text_contents(), 'svg count',page.locator('.nova-stage svg').count())
  for mode in ['watch','guided','explore','challenge']:
   button=page.locator('.nova-tabs button').filter(has_text=mode.capitalize()).first
   if not button.count(): print('NO BUTTON',mode);continue
   button.click();page.wait_for_timeout(270)
   stage=page.locator('.nova-stage').first
   stage.screenshot(path=str(OUT/f'{width}-{mode}.png'),animations='disabled')
   print(width,mode,'svg',stage.locator('svg').count(),'text',stage.inner_text()[:150].replace('\n',' / '),'width',stage.bounding_box()['width'])
  page.close()
 browser.close()
S.shutdown()
print('ERRORS',errs)
