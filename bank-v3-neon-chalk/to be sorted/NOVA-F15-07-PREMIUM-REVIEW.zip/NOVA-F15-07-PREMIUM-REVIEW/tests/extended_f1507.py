from playwright.sync_api import sync_playwright
from pathlib import Path
import math,json,sys
file=Path('/mnt/data/NOVA-F15-07-Angle-Slider-Ratio-Table.html')
passes=[];fails=[]
def check(v,label): (passes if v else fails).append(label)
def pos(page,x,y):return page.evaluate('''([x,y])=>{let s=document.querySelector('.f157-board'),p=s.createSVGPoint();p.x=x;p.y=y;let a=p.matrixTransform(s.getScreenCTM());return {x:a.x,y:a.y}}''',[x,y])
def drag(page,a,b,steps=1):
 page.mouse.move(a['x'],a['y']);page.mouse.down();page.mouse.move(b['x'],b['y'],steps=steps);page.mouse.up();page.wait_for_timeout(260)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':900});errors=[];page.on('pageerror',lambda x:errors.append(str(x)))
  page.set_content(file.read_text(),wait_until='domcontentloaded');page.locator('.nova-tabs button').get_by_text('Explore',exact=True).click();page.wait_for_timeout(300)
  page.evaluate('''()=>NOVA_F15_07_CONFIG._explore.select('y9ratios')''')
  mob=width==380;scale=26.5 if mob else 28;R=[100,391] if mob else [103,371]
  # Drag blue adjacent endpoint horizontally from 35° to 40°, then purple opposite endpoint vertically 40° -> 45°.
  for name,from_angle,to_angle in [('a',35,40),('b',40,45)]:
   handle=page.locator(f'[data-vertex="{name}"]');handle.scroll_into_view_if_needed()
   st=lambda theta: [R[0]+10*math.cos(theta*math.pi/180)*scale,R[1]] if name=='a' else [R[0],R[1]-10*math.sin(theta*math.pi/180)*scale]
   a=pos(page,*st(from_angle));bb=pos(page,*st(to_angle));drag(page,a,bb,1)
   v=page.evaluate('''()=>NOVA_F15_07_CONFIG._explore.state().theta''')
   check(v==to_angle,f'{width}: real vertex {name} snap {from_angle} to {to_angle} got {v}')
   check(not page.evaluate('''()=>Boolean(NOVA.ui._drag)'''),f'{width}: vertex {name} pointer cleanup')
  # Sine and cosine table live at 45°, one current row only.
  vals=page.evaluate('''()=>NOVA_F15_07_MATH.values(NOVA_F15_07_CONFIG._explore.state())''')
  check(abs(vals['sin']-2**-.5)<1e-12 and abs(vals['cos']-vals['sin'])<1e-12,f'{width}: 45-degree equal legs')
  check(page.locator('.f157-board').text_content().count('0.707')>=2,f'{width}: table reflects 45 degrees')
  # Label correct and drag it back to red tray using a real pointer.
  label=page.locator('[data-label="hyp"]');label.scroll_into_view_if_needed();bound=label.bounding_box();a={'x':bound['x']+bound['width']/2,'y':bound['y']+bound['height']/2}
  vv=page.evaluate('''()=>NOVA_F15_07_CONFIG._explore.state()''');theta=vv['theta'];c=vv['c'];B=[R[0],R[1]-c*math.sin(theta*math.pi/180)*scale];A=[R[0]+c*math.cos(theta*math.pi/180)*scale,R[1]];midH=[(A[0]+B[0])/2,(A[1]+B[1])/2]
  dest=pos(page,*midH);drag(page,a,dest,6)
  check(bool(page.evaluate('''()=>NOVA_F15_07_CONFIG._explore.state().placed.hyp''')),f'{width}: place hypotenuse card correctly')
  label=page.locator('[data-label="hyp"]');label.scroll_into_view_if_needed();bound=label.bounding_box();a={'x':bound['x']+bound['width']/2,'y':bound['y']+bound['height']/2}
  dest=pos(page,375 if mob else 375,945 if mob else 537);drag(page,a,dest,8);page.wait_for_timeout(500)
  check(not page.evaluate('''()=>NOVA_F15_07_CONFIG._explore.state().placed.hyp'''),f'{width}: regrab placed hypotenuse and remove')
  check(not page.evaluate('''()=>Boolean(NOVA.ui._drag)'''),f'{width}: drag removed without floating active element')
  # Each of 9 Challenge questions submitted through the actual input and Check button.
  page.locator('.nova-tabs button').get_by_text('Challenge',exact=True).click();page.wait_for_timeout(100)
  for i in range(9):
   ix=page.evaluate('''()=>NOVA_F15_07_CONFIG._challenge.task()''')
   check(ix==i,f'{width}: challenge step sequence {i} got {ix}')
   page.evaluate('''()=>NOVA_F15_07_CONFIG._challenge.solve()''')
   page.locator('#F15-07 .nova-panel button').filter(has_text='Check').first.click();page.wait_for_timeout(850)
   feedback=page.locator('#F15-07 .nova-panel').inner_text()
   check(('Correct' in feedback or 'Next task' in feedback or page.evaluate('''()=>NOVA_F15_07_CONFIG._challenge.task()''')>i),f'{width}: challenge question {i+1} actual submission')
  check(len(errors)==0,f'{width}: page errors absent {errors}')
  page.close()
 b.close()
out=Path('/mnt/data/f15-reference/F15-07-QA/extended-results.json')
out.write_text(json.dumps({'passed':len(passes),'failed':len(fails),'checks':passes,'failures':fails},indent=2))
print('EXTENDED',len(passes),'PASS',len(fails),'FAIL\n',json.dumps(fails,indent=2));sys.exit(bool(fails))
