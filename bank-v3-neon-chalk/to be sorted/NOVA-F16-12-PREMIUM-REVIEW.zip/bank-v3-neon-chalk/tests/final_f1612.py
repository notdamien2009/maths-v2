from pathlib import Path
from playwright.sync_api import sync_playwright
import json,math
R=Path(__file__).resolve().parents[1];html=(R/'F16/F16-12-histogram.html').read_text();results=[]
def verify(k,b,detail=None):
 results.append({'test':k,'passed':bool(b),'detail':detail});print(('PASS' if b else 'FAIL'),k,flush=True)
def state(pg):return pg.evaluate('NOVA_F16_12_CONFIG._explore.get()')
def drag(pg,loc,x,y):
 loc.scroll_into_view_if_needed();bb=loc.bounding_box();a=pg.locator('.f1612-svg').evaluate('''(e,xy)=>{let p=e.createSVGPoint();p.x=xy[0];p.y=xy[1];let a=p.matrixTransform(e.getScreenCTM());return {x:a.x,y:a.y}}''',[x,y]);pg.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);pg.mouse.down();pg.mouse.move(a['x'],a['y'],steps=1);pg.wait_for_timeout(130);pg.mouse.up();pg.wait_for_timeout(290)
presets={'y8-frequency':([0,5,15,20,40],[4,8,6,10]),'y8-mean':([0,10,20,40,60],[5,9,12,4]),'y9-represent':([0,5,15,35,50],[3,12,10,6])}
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in (380,1280):
  pg=b.new_page(viewport={'width':w,'height':900},reduced_motion='reduce');errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(html,wait_until='domcontentloaded',timeout=60000)
  for mode in ['Watch','Guided','Explore','Challenge']:
   pg.get_by_role('tab',name=mode,exact=True).click();pg.wait_for_timeout(90)
   a=pg.evaluate('''()=>{let v=document.querySelector('.f1612-svg').getBoundingClientRect(),s=document.querySelector('.nova-stage').getBoundingClientRect();return {fill:v.height/s.height,overflow:document.documentElement.scrollWidth>innerWidth,docks:document.querySelectorAll('.nova-stage .nv-dock').length}}''');verify(f'{w} {mode} stage geometry',a['fill']>=.6 and not a['overflow'] and a['docks']==1,a)
   if mode in ['Watch','Explore','Challenge']:
    pg.screenshot(path=str(R/'shots'/f'F16-12-{w}-{mode.lower()}.png'),full_page=True,timeout=15000)
  for key,(edges,base) in presets.items():
   pg.get_by_role('tab',name='Explore',exact=True).click();pg.locator('.f1612-form select').first.select_option(key);pg.wait_for_timeout(570)
   s=state(pg);dens=[base[i]/(edges[i+1]-edges[i]) for i in range(4)]
   verify(f'{w} {key} frequency table',s['frequencies']==base)
   verify(f'{w} {key} density and area',all(abs(a-b)<1e-8 for a,b in zip(s['density'],dens)) and sum(s['areas'])==sum(base))
   verify(f'{w} {key} total',s['total']==sum(base))
   if key=='y8-mean':verify(f'{w} midpoint mean estimation','Midpointmean≈24' in ''.join(pg.locator('.f1612-info').inner_text().split()))
   # Real pointer placement with short wait at destination so the final pointer-move event completes.
   drag(pg,pg.locator('[data-token="0"]').first,200 if w==380 else 180,132+54+57+30 if w==380 else 181+58+66+33)
   verify(f'{w} {key} native transfer',state(pg)['frequencies']==[base[0]-1,base[1]+1,*base[2:]],state(pg)['frequencies'])
   pg.get_by_role('button',name='Reset',exact=True).click()
   pg.locator('[data-handle="0"]').first.focus();pg.keyboard.press('ArrowUp');pg.wait_for_timeout(120)
   verify(f'{w} {key} histogram handle keyboard',state(pg)['frequencies'][0]==base[0]+1)
   pg.get_by_role('button',name='Reset',exact=True).click()
   pg.screenshot(path=str(R/'shots'/f'F16-12-{w}-{key}-explore.png'),full_page=True,timeout=15000)
  pg.get_by_role('tab',name='Challenge',exact=True).click()
  # Last selected preset is Year 9. Fix incorrect bar with keyboard then answer density and area.
  cs=pg.evaluate('NOVA_F16_12_CONFIG._challengeState()');verify(f'{w} challenge deliberately wrong height',cs['frequencies'][1]==cs['correct'][1]+2)
  for _ in range(2):
   pg.locator('[data-handle="1"]').first.focus();pg.keyboard.press('ArrowDown');pg.wait_for_timeout(100)
  pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(1150)
  verify(f'{w} challenge 1',pg.evaluate('NOVA_F16_12_CONFIG._challengeState().task')==1)
  for x,n in [(1,1.2),(2,10)]:
   pg.locator('input[type="text"],input[type="number"]').last.fill(str(n));pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(1140)
   verify(f'{w} challenge {x+1}', pg.evaluate('NOVA_F16_12_CONFIG._challengeState().task')==x+1 if x<2 else pg.locator('text=Correct').count()>0)
  verify(f'{w} no JavaScript errors',not errors,errors)
  pg.close()
 b.close()
R.joinpath('tests/FINAL-RESULTS.json').write_text(json.dumps({'checks':len(results),'passed':sum(t['passed'] for t in results),'failures':[t for t in results if not t['passed']],'results':results},indent=2))
print('TOTAL',sum(t['passed'] for t in results),'/',len(results),flush=True)
raise SystemExit(0 if all(t['passed'] for t in results) else 1)
