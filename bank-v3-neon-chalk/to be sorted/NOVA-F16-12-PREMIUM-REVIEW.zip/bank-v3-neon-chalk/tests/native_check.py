from playwright.sync_api import sync_playwright
from pathlib import Path
p=Path(__file__).resolve().parents[1]
html=(p/'F16/F16-12-histogram.html').read_text()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in [380,1280]:
  for attempt in range(3):
   pg=b.new_page(viewport={'width':w,'height':900},reduced_motion='reduce')
   pg.set_content(html,wait_until='domcontentloaded')
   pg.get_by_role('tab',name='Explore',exact=True).click()
   pg.wait_for_timeout(550)
   src=pg.locator('[data-token="0"]').first;src.scroll_into_view_if_needed()
   bb=src.bounding_box();a=pg.locator('.f1612-svg').evaluate('''e=>{let p=e.createSVGPoint();p.x=innerWidth<=540?200:180;p.y=innerWidth<=540?132+54+57+30:181+58+66+33;let t=p.matrixTransform(e.getScreenCTM());return {x:t.x,y:t.y}}''')
   pg.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);pg.mouse.down();pg.mouse.move(a['x'],a['y'],steps=1);pg.mouse.up();pg.wait_for_timeout(250)
   print(w,attempt,pg.evaluate('NOVA_F16_12_CONFIG._explore.get().frequencies'), flush=True)
   pg.close()
 b.close()
