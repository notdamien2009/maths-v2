from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1];html=(R/'F16/F16-12-histogram.html').read_text();out=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in [380,1280]:
  g=b.new_page(viewport={'width':w,'height':900});g.set_content(html);g.get_by_role('tab',name='Explore',exact=True).click();g.locator('.f1612-form select').first.select_option('y8-mean');x=''.join(g.locator('.f1612-info').inner_text().split());correct=('Midpointmean≈24' in x);print(w,correct,x[-50:]);out.append({'width':w,'pass':correct,'rendered':'24 min (estimate)','math':(5*5+9*15+12*30+4*50)/30});g.close()
 b.close()
R.joinpath('tests/MIDPOINT-RESULTS.json').write_text(json.dumps({'checks':2,'passed':sum(r['pass'] for r in out),'results':out},indent=2));assert all(r['pass'] for r in out)
