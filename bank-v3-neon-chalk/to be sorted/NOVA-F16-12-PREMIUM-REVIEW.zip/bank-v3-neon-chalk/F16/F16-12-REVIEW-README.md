# F16-12 · Histogram — PREMIUM REVIEW (not GOLD)

KS3 Data and Statistics: histogram using unequal continuous class intervals, frequency density heights and frequency = rectangle area. Three lesson presets: Y8-064, Y8-065 and Y9-047. Uses byte-identical protected F0/F2 shared CSS/JS from the previously delivered F16/F14 runtime; **fresh download of GitHub’s current large JS core is still outstanding**.

## Files
- `F16/F16-12-histogram.html`: one offline self-contained HTML (no remote assets).
- `src/F16-12.js` and `.css`: component-owned code/style.
- `build/F16-12.src.html`, `build/build-f16-12.py`: reproducible file generation, SHA-pinned core.
- `tests/pinned-core.*`: exact pinned shared runtime.
- `tests/RECONCILED-RESULTS.json`, `FINAL-RESULTS.json`, `MIDPOINT-RESULTS.json`: honest test record.
- `shots/`: 14 selected browser screenshots, 380px / 1280px.

## QA conclusion
Final functional evidence: 50/50 checks passed across responsive mode coverage, all 3 lesson datasets, maths/density/area checks, native table mouse placement, SVG handle keyboard operation, and three Challenge tasks at both widths. The original 50-assertion test reported 48 passing and two false negatives because it tried to find the midpoint result as contiguous text; NOVA's renderer splits text into character spans. A separate renderer-aware rerun verified those two cases with the actual visible mathematical value, and the reconcile document preserves this history. Earlier, an extra-long comprehensive stress run was interrupted and is **not** counted as passed. A 6/6 independent native pointer check also verified first-load transfers at 380/1280 after a short mount period.

## Acceptance and limitations
- Browser modes, pointer placement, chart keyboard handles, Challenge, stage coverage and no page overflow tested in Chromium.
- Full physical touch, pointercancel on a real tablet, screenreader walkthrough, colour-vision simulation, and visual owner approval remain pending.
- Charts use protected NOVA.neonPlot axes; all pupil-facing axes are drawn in NOVA Chalk.
- The shared GitHub repository was not modified.
