/* F13-12 CAPACITY AND VOLUME CONVERSION — add-on using the identical approved embedded NOVA core. */
var NOVA_F13_12_CONFIG={startMode:'watch',presets:{empty:'Empty litre cube',hundred:'100 mL',quarter:'250 mL',half:'500 mL',threeQuarter:'750 mL',full:'1000 mL = 1 litre',cubicMetre:'One cubic metre'}};
(function(){'use strict';
var EN='F13-12',S=NOVA.svg,F=NOVA.f12,h=NOVA.h,CFG=NOVA_F13_12_CONFIG;
var C={cyan:'#47efff',ice:'#bdffff',blue:'#65aeff',purple:'#b6a4ff',orange:'#ffb184',gold:'#ffdf7e',green:'#7ff7bf',white:'#e8f8ff',ink:'#06132c'};
var PRESETS={empty:['litre',0],hundred:['litre',.1],quarter:['litre',.25],half:['litre',.5],threeQuarter:['litre',.75],full:['litre',1],cubicMetre:['metre',1]};
function clamp(x,a,b){return Math.max(a,Math.min(b,x));}
function fmt(x){return String(Math.round(x*1000)/1000);}
function comma(x){return Math.round(x).toLocaleString('en-GB');}
function e(p,t,a){return S.el(t,a||{},p);}
function line(g,x1,y1,x2,y2,color,width,alpha,dash){return e(g,'line',Object.assign({x1:x1,y1:y1,x2:x2,y2:y2,stroke:color||C.cyan,'stroke-width':width||1.4,opacity:alpha==null?1:alpha,'stroke-linecap':'round'},dash?{'stroke-dasharray':dash}:{}));}
function polygon(g,pts,fill,stroke,width,opacity,attrs){return e(g,'path',Object.assign({d:'M'+pts.map(q=>fmt(q[0])+','+fmt(q[1])).join('L')+'Z',fill:fill||'none',stroke:stroke||C.cyan,'stroke-width':width||1.2,'stroke-linejoin':'round',opacity:opacity==null?1:opacity},attrs||{}));}
function tx(g,x,y,t,role,size){return NOVA.chalkText(g,x,y,String(t),{role:role||'given',size:size||19,anchor:'middle'});}
function grad(def,id,stops,attrs,radial){var g=e(def,radial?'radialGradient':'linearGradient',Object.assign({id:id},attrs||{}));stops.forEach(s=>e(g,'stop',{offset:s[0],'stop-color':s[1],'stop-opacity':s[2]}));}
function defs(svg){var d=svg.querySelector('defs')||e(svg,'defs');
 grad(d,'f13c-glass',[['0%','#eaffff',.38],['17%','#70d8ff',.18],['65%','#2356b8',.16],['100%','#265bd5',.32]],{x1:'0%',y1:'0%',x2:'95%',y2:'90%'});
 grad(d,'f13c-water',[['0%','#c5ffff',.97],['16%','#69dafa',.94],['49%','#188ade',.91],['100%','#17439d',.94]],{x1:'8%',y1:'0%',x2:'89%',y2:'100%'});
 grad(d,'f13c-side',[['0%','#5ddcf4',.8],['100%','#133985',.96]],{x1:'0%',y1:'0%',x2:'100%',y2:'100%'});
 grad(d,'f13c-unit',[['0%','#fbf3c4',.92],['40%','#f7b36d',.83],['100%','#c97e4b',.87]],{x1:'0%',y1:'0%',x2:'90%',y2:'100%'});
 grad(d,'f13c-wash',[['0%','#163884',.73],['100%','#09142e',0]],{cx:'43%',cy:'42%',r:'75%'},true);
 var bl=e(d,'filter',{id:'f13c-blur',x:'-90%',y:'-90%',width:'280%',height:'280%'});e(bl,'feGaussianBlur',{stdDeviation:'7'});
}
function mkState(preset){var q=PRESETS[preset]||PRESETS.half;return {preset:preset||'half',mode:q[0],fill:q[1],yaw:0,refresh:null,anim:0,cleanup:null,svg:null};}
function total(s){return s.mode==='litre'?1000:1000;}
function content(s){return Math.round(total(s)*s.fill);}
function volumeMetric(s){return s.mode==='litre'?content(s)+' cm³':fmt(content(s)/1000)+' m³';}
function waterMetric(s){return s.mode==='litre'?content(s)+' mL':content(s)+' L';}
function cmValue(s){return s.mode==='litre'?content(s):content(s)*1000;}
function corners(x,y,w,dep,ht){var yBack=dep*.53;return {t0:[x,y],t1:[x+dep,y-yBack],t2:[x+w+dep,y-yBack],t3:[x+w,y],b0:[x,y+ht],b1:[x+dep,y+ht-yBack],b2:[x+w+dep,y+ht-yBack],b3:[x+w,y+ht],dy:yBack};}
function tank(g,s,mobile){var x=mobile?40:115,y=mobile?149:146,w=mobile?148:221,dep=mobile?42:60,height=mobile?226:239,cor=corners(x,y,w,dep,height),f=clamp(s.fill,0,1),z=y+height*(1-f),p=corners(x,z,w,dep,height*f);
 var cg=e(g,'g',{'data-maths':'one-cube-container','data-fill-fraction':String(f),'data-unit':s.mode==='litre'?'mL':'L','data-capacity':1000});
 e(cg,'ellipse',{cx:x+w*.60,cy:y+height+22,rx:w*.73,ry:16,fill:'#112c68',opacity:.47,filter:'url(#f13c-blur)'});
 // Rear wall and depth reference, then liquid, followed by the clean front of the transparent tank.
 polygon(cg,[cor.t1,cor.t2,cor.b2,cor.b1],'#163c8a',C.purple,1.3,.22);
 polygon(cg,[cor.t0,cor.t1,cor.b1,cor.b0],'url(#f13c-glass)',C.cyan,1.5,.3);
 if(f>0){
  polygon(cg,[p.t3,p.t2,cor.b2,cor.b3],'url(#f13c-side)',C.blue,1.1,.97,{'data-maths':'water-right-face'});
  polygon(cg,[p.t0,p.t3,cor.b3,cor.b0],'url(#f13c-water)',C.cyan,1.3,.93,{'data-maths':'water-front-face'});
  polygon(cg,[p.t0,p.t1,p.t2,p.t3],'#8cf2ff',C.ice,1.75,.77,{'data-maths':'water-surface','data-height':f});
  line(cg,x,z,x+w,z,C.ice,2.5,.91);
  for(var b=1;b<8;b++){var bx=x+9+((b*37)%(w-20));var by=z+10+((b*43)%Math.max(11,height*f-14));if(by<y+height-5 && by>z+7)e(cg,'circle',{cx:bx,cy:by,r:b%3===0?3.2:1.6,fill:'#d5ffff',opacity:.44});}
 }
 polygon(cg,[cor.t0,cor.t3,cor.b3,cor.b0],'url(#f13c-glass)',C.cyan,2.25,.95);
 polygon(cg,[cor.t3,cor.t2,cor.b2,cor.b3],'url(#f13c-glass)',C.purple,2.15,.83);
 polygon(cg,[cor.t0,cor.t1,cor.t2,cor.t3],'url(#f13c-glass)',C.ice,2.5,.76);
 // Physically valid 10 cm graduation grid on front surface. These are projected 1 cm strips (not 1000 drawn cubes).
 for(var k=1;k<10;k++){var sy=y+height*k/10;line(cg,x+2,sy,x+w-2,sy,k%5===0?C.gold:C.ice,k%5===0?1.2:.7,k%5===0?.53:.21);var sx=x+w*k/10;line(cg,sx,y+3,sx,y+height-3,C.ice,.7,.21);}
 for(var d=1;d<10;d++){var off=d/10;line(cg,x+off*dep,y-off*cor.dy,x+w+off*dep,y-off*cor.dy,C.ice,.7,.17);line(cg,x+w+off*dep,y-off*cor.dy,x+w+off*dep,y+height-off*cor.dy,C.blue,.65,.18);}
 line(cg,x+12,y+10,x+12,y+height-11,C.white,3.8,.42);
 line(cg,cor.t3[0],cor.t3[1],cor.t2[0],cor.t2[1],C.blue,3.2,.8);
 // Capacity scale beside tank; 0, 250, 500, 750, 1000 at physically correct relative elevations.
 var scaleX=x-11;for(var i=0;i<=4;i++){var yy=y+height*(1-i/4);line(cg,scaleX-6,yy,scaleX-1,yy,i===4?C.green:C.gold,i%2===0?2.1:1.1,.78);}
 var cm=s.mode==='litre'?'10 cm':'1 m';
 tx(g,x+w*.5,y-48,cm+' × '+cm+' × '+cm,'focus',mobile?14.7:20);
 tx(g,x+w*.55,y+height+44,f<.001?'EMPTY':f>=.999?'COMPLETELY FULL':(Math.round(f*100)+'% FULL'),f>=.999?'result':'given',mobile?15:19);
 tx(g,x-1,y+height+12,'0', 'given',mobile?12:15);
 tx(g,x-13,y-10,'100%', 'focus',mobile?12:15);
 return cor;}
function microcube(g,cx,cy,size){var w=size,dep=size*.45,dy=size*.24,x=cx-w*.5,y=cy-w*.5;
 var A=[x,y],B=[x+dep,y-dy],C0=[x+w+dep,y-dy],D=[x+w,y],E=[x,y+w],F=[x+w,y+w],G=[x+w+dep,y+w-dy];
 e(g,'ellipse',{cx:cx+dep*.37,cy:y+w+19,rx:size*.8,ry:12,fill:'#082a56',opacity:.5,filter:'url(#f13c-blur)'});
 polygon(g,[D,C0,G,F],'#ac593b','#ffc187',1.5,.95);
 polygon(g,[A,D,F,E],'url(#f13c-unit)',C.gold,2,1,{'data-maths':'one-cubic-unit'});
 polygon(g,[A,B,C0,D],'#ffebbe',C.ice,2,.9);
 line(g,x+size*.1,y+9,x+size*.1,y+w-9,C.white,2.5,.65);
}
function tile(g,x,y,w,height,col){e(g,'rect',{x:x,y:y,width:w,height:height,rx:15,fill:'#06172d',stroke:col,'stroke-width':1.5,opacity:.96});line(g,x+14,y+5,x+w-14,y+5,col,2,.56);}
function panel(g,s,mob){var px=mob?232:487,yy=117,w=mob?180:209,ht=279;
 tile(g,px,yy,w,ht,C.orange);
 tx(g,px+w/2,yy+29,s.mode==='litre'?'ZOOM IN · 1 cm³':'ZOOM IN · 1 dm³','focus',mob?14:18);
 microcube(g,px+w/2-11,yy+123,mob?65:84);
 tx(g,px+w/2,yy+200,s.mode==='litre'?'1 cm³':'1 dm³','result',mob?22:29);
 tx(g,px+w/2,yy+224,'=','given',mob?18:21);
 tx(g,px+w/2,yy+253,s.mode==='litre'?'1 mL':'1 L','result',mob?22:29);
 tx(g,px+w/2,yy+293,s.mode==='litre'?'× 1000 IN BIG CUBE':'× 1000 IN BIG CUBE','given',mob?11.5:14.5);
 // Tiny moving colour-coded transfer markers preserve the concept of equal space.
 for(var i=0;i<3;i++)e(g,'circle',{cx:px+22+i*14,cy:yy+34,r:2.5,fill:i===1?C.gold:C.cyan,opacity:.69});
}
function readout(g,x,y,w,title,value,sub,col,mob){tile(g,x,y,w,98,col);tx(g,x+w/2,y+24,title,'given',mob?12.1:16);tx(g,x+w/2,y+62,value,'result',mob?20:28);tx(g,x+w/2,y+86,sub,'given',mob?11.3:14);}
function draw(root,s,W){root.replaceChildren();var mob=W===420;
 e(root,'ellipse',{cx:W/2,cy:236,rx:W*.55,ry:238,fill:'url(#f13c-wash)',opacity:.96});
 tx(root,W/2,33,'VOLUME TAKES SPACE · CAPACITY HOLDS LIQUID','given',mob?13.8:19);
 tx(root,mob?120:253,67,s.mode==='litre'?'ONE LITRE CUBE':'ONE CUBIC METRE','focus',mob?17:22);
 tx(root,mob?321:592,67,'SAME SPACE · NEW UNIT','focus',mob?11.8:17);
 tank(root,s,mob);panel(root,s,mob);
 if(s.mode==='litre'){
  readout(root,mob?10:105,455,mob?198:281,'WATER INSIDE',waterMetric(s),volumeMetric(s),C.cyan,mob);
  readout(root,mob?214:394,455,mob?196:281,'CUBE CAPACITY','1 L','1000 cm³ = 1000 mL',C.gold,mob);
  tx(root,W/2,587,'1 cm³ = 1 mL   ·   1000 cm³ = 1 L','result',mob?13.5:20);
 }else{
  readout(root,mob?10:105,455,mob?198:281,'WATER INSIDE',waterMetric(s),volumeMetric(s),C.cyan,mob);
  readout(root,mob?214:394,455,mob?196:281,'CUBE CAPACITY','1000 L','1 m³ = 1 000 000 cm³',C.gold,mob);
  tx(root,W/2,587,'1 m³ = 1000 L = 1 000 000 cm³','result',mob?13:19);
  tx(root,W/2,612,'DIAGRAMS NOT TO THE SAME PHYSICAL SCALE','given',mob?10:12);
 }
 root.setAttribute('data-mode',s.mode);root.setAttribute('data-fill',s.fill.toFixed(6));root.setAttribute('data-amount',content(s));root.setAttribute('data-centimetres-cubed',cmValue(s));root.setAttribute('data-capacity',s.mode==='litre'?1000:1000);root.setAttribute('data-unit',s.mode==='litre'?'mL':'L');
}
function makeStage(stage,s,spoken,pose,interactive){if(stage._f13Cleanup)stage._f13Cleanup();stage.replaceChildren();var mob=innerWidth<=580,W=mob?420:780;
 NOVA.cap(stage,'CAPACITY + VOLUME · '+(s.mode==='litre'?'10 cm × 10 cm × 10 cm':'1 m × 1 m × 1 m'),'UNIT CUBES');
 var svg=S.root(W,624,'A transparent cube with water at an adjustable level. A litre is a cube of side ten centimetres. Each cubic centimetre holds one millilitre; a cubic metre holds one thousand litres.');svg.classList.add('f13c-svg');svg.setAttribute('tabindex','0');svg.setAttribute('role','group');svg.setAttribute('aria-label','Volume and capacity cube. Drag the tank up or down to change the water level. Arrow keys change by five per cent; Home empties and End fills.');stage.appendChild(svg);defs(svg);
 var root=e(svg,'g',{'data-f13c-root':'true'}),raf=0,ctrl=new AbortController(),pointer=null;
 function render(){draw(root,s,W);var cap=stage.querySelector('.nv-cap span');if(cap)cap.textContent='CAPACITY + VOLUME · '+(s.mode==='litre'?'10 cm × 10 cm × 10 cm':'1 m × 1 m × 1 m');var sp=stage.querySelectorAll('.f12-strip .nv-ntile .mt');[waterMetric(s),volumeMetric(s),s.mode==='litre'?'1 L':'1000 L'].forEach((v,i)=>{if(sp[i])sp[i].textContent=v;});}
 function refresh(){if(raf)cancelAnimationFrame(raf);raf=requestAnimationFrame(function(){raf=0;render();NOVA.events.emit('value',{engine:EN,control:'capacity',value:{mode:s.mode,amount:content(s),unit:s.mode==='litre'?'mL':'L',cm3:cmValue(s),fill:s.fill}});});}
 s.refresh=refresh;s.svg=svg;render();F.strip(stage,[['inside',waterMetric(s),'focus'],['volume',volumeMetric(s),'op'],['whole',s.mode==='litre'?'1 L':'1000 L','result']]);NOVA.scene.helperStrip(stage,pose||'explain',spoken||'One cubic centimetre holds exactly one millilitre. Ten centimetres in every direction makes one litre.');
 function clean(){ctrl.abort();if(raf)cancelAnimationFrame(raf);if(s.anim)cancelAnimationFrame(s.anim);s.anim=0;pointer=null;svg.classList.remove('dragging');}s.cleanup=clean;stage._f13Cleanup=clean;
 function fromPointer(ev){var r=svg.getBoundingClientRect(),clientY=(ev.clientY-r.top)/r.height*624,top=146,bottom=385;s.fill=clamp((bottom-clientY)/(bottom-top),0,1);s.refresh();}
 if(interactive){svg.addEventListener('pointerdown',function(ev){if(ev.pointerType==='mouse'&&ev.button!==0)return;pointer=ev.pointerId;stop(s);fromPointer(ev);svg.classList.add('dragging');try{svg.setPointerCapture(pointer);}catch(ex){}ev.preventDefault();},{signal:ctrl.signal});
 svg.addEventListener('pointermove',function(ev){if(pointer!==ev.pointerId)return;fromPointer(ev);},{signal:ctrl.signal});
 function release(ev){if(pointer!==ev.pointerId)return;pointer=null;svg.classList.remove('dragging');try{if(svg.hasPointerCapture(ev.pointerId))svg.releasePointerCapture(ev.pointerId);}catch(ex){}}
 svg.addEventListener('pointerup',release,{signal:ctrl.signal});svg.addEventListener('pointercancel',release,{signal:ctrl.signal});svg.addEventListener('lostpointercapture',function(ev){if(pointer===ev.pointerId){pointer=null;svg.classList.remove('dragging');}},{signal:ctrl.signal});window.addEventListener('blur',function(){pointer=null;svg.classList.remove('dragging');},{signal:ctrl.signal});}
 svg.addEventListener('keydown',function(ev){if(!['ArrowUp','ArrowDown','Home','End'].includes(ev.key))return;ev.preventDefault();stop(s);if(ev.key==='ArrowUp')s.fill=clamp(s.fill+.05,0,1);if(ev.key==='ArrowDown')s.fill=clamp(s.fill-.05,0,1);if(ev.key==='Home')s.fill=0;if(ev.key==='End')s.fill=1;s.refresh();},{signal:ctrl.signal});
 return svg;
}
function stop(s){if(s.anim)cancelAnimationFrame(s.anim);s.anim=0;}
function animateTo(s,target){stop(s);var a=s.fill,t=clamp(target,0,1),start=performance.now(),dur=NOVA.reducedMotion()?1:1150;
 function frame(now){var v=clamp((now-start)/dur,0,1),ease=v*v*(3-2*v);s.fill=a+(t-a)*ease;s.refresh();if(v<1)s.anim=requestAnimationFrame(frame);else{s.fill=t;s.anim=0;s.refresh();}}s.anim=requestAnimationFrame(frame);}
function set(s,key){stop(s);var q=PRESETS[key]||PRESETS.half;s.mode=q[0];s.fill=q[1];s.preset=key;s.refresh();}
function btn(t,fun,cls){return h('button',{class:'nova-btn'+(cls?' '+cls:''),text:t,onclick:fun});}
function row(p,items){p.appendChild(h('div',{class:'pr-row'},items));}
function range(label,st,fn){var inp=h('input',{type:'range',min:'0',max:'100',step:'1',value:String(Math.round(st.fill*100)),'aria-label':label}),show=h('span',{class:'f13c-reading',text:String(Math.round(st.fill*100))+'%'});inp.oninput=function(){show.textContent=inp.value+'%';fn(+inp.value/100);};return {node:h('label',{class:'f13c-label'},[label+' ',inp,show]),input:inp,set:function(v){inp.value=Math.round(v*100);show.textContent=inp.value+'%';}};}
var STEPS=[
 {n:'Volume or capacity?',preset:'quarter',pose:'explain',m:'Volume tells us how much space a solid occupies. Capacity tells us how much a container can hold. We can measure both with cubic units.',q:'Is the amount inside the container its full capacity?'},
 {n:'Meet the centimetre cube',preset:'empty',pose:'point-right',m:'A cube that is one centimetre long, wide and high has a volume of one cubic centimetre.',q:'How many directions are multiplied to find its volume?'},
 {n:'One cube, one millilitre',preset:'hundred',pose:'explain',m:'One cubic centimetre holds exactly one millilitre of water. A cubic centimetre is a unit of space; a millilitre is a unit of capacity.',q:'How many millilitres equal one cubic centimetre?'},
 {n:'Make a 10 centimetre cube',preset:'empty',pose:'think',m:'Our larger cube has a length, width and height of ten centimetres each. It is one cubic decimetre.',q:'What do we multiply to find the big cube volume?'},
 {n:'Count 1000 small cubes',preset:'full',pose:'point-right',m:'Ten times ten times ten equals one thousand. The large cube occupies one thousand cubic centimetres.',q:'How many one-centimetre cubes fit into this ten-centimetre cube?'},
 {n:'One litre exactly',preset:'full',pose:'celebrate',m:'One thousand cubic centimetres hold one thousand millilitres. That is one litre.',q:'How many millilitres make one litre?'},
 {n:'Fill one quarter',preset:'quarter',pose:'explain',m:'A quarter of a one-litre container is two hundred and fifty millilitres. Its occupied volume is two hundred and fifty cubic centimetres.',q:'How many cubic centimetres correspond to 250 millilitres?'},
 {n:'Find the halfway mark',preset:'half',pose:'think',m:'At half full, this tank contains five hundred millilitres, equivalent to five hundred cubic centimetres, or half a litre.',q:'Is five hundred millilitres greater or less than one litre?'},
 {n:'Move to three quarters',preset:'threeQuarter',pose:'point-right',m:'Three quarters full is seven hundred and fifty millilitres, or seven hundred and fifty cubic centimetres.',q:'How much more is needed to reach one litre?'},
 {n:'Change to a cubic metre',preset:'cubicMetre',pose:'explain',m:'A cubic metre is a cube one metre in each direction. It can contain one thousand litres. The drawings are not to the same physical scale.',q:'Is one cubic metre the same as one litre?'},
 {n:'Count the litres in a metre cube',preset:'cubicMetre',pose:'point-right',m:'One metre is ten decimetres. Ten times ten times ten litre cubes fit inside one cubic metre: one thousand litres.',q:'How many one-litre cubes fit in a cubic metre?'},
 {n:'Convert with confidence',preset:'full',pose:'celebrate',m:'Remember: one cubic centimetre equals one millilitre, one thousand cubic centimetres equal one litre, and one cubic metre equals one thousand litres.',q:'Which conversion will help you in a question about water?'}
];
var def={id:EN,title:'Capacity and volume conversion',config:CFG,steps:STEPS.map(q=>({name:q.n,narration:q.m,prompt:q.q,dur:2000})),
 alt:'A ten-centimetre transparent 3D cube with graduations and animated blue water. A detailed golden one-centimetre cube shows one cubic centimetre equals one millilitre. Switch to a separate cubic-metre comparison.',
 staticAlt:'A volume of one cubic centimetre holds one millilitre. A 10 cm × 10 cm × 10 cm cube has volume 1000 cubic centimetres and capacity 1000 millilitres, which equals one litre. One cubic metre contains 1000 litres.',
 render:function(i,stage){var q=STEPS[i],s=mkState(q.preset);makeStage(stage,s,q.m,q.pose,false);},
 exploreIntro:'Fill a transparent one-litre cube, reveal equal amounts in cubic centimetres and millilitres, then switch to a cubic-metre model. The two scales are not drawn to the same physical size.',
 explore:function(panel,stage,api){var s=mkState('half'),sel=h('select',{class:'nova-input','aria-label':'Choose volume preset'});Object.keys(CFG.presets).forEach(k=>sel.appendChild(h('option',{value:k,text:CFG.presets[k]})));sel.value='half';
 var fill=range('FILL LEVEL',s,function(v){stop(s);s.fill=v;s.refresh();});
 row(panel,[h('label',{class:'f13c-label'},['PRESET ',sel]),fill.node]);
 function setPreset(k){set(s,k);sel.value=k;fill.set(s.fill);}
 sel.onchange=function(){setPreset(sel.value);};
 row(panel,[btn('Fill to full',function(){animateTo(s,1);fill.set(1);},'primary'),btn('Empty',function(){animateTo(s,0);fill.set(0);},'ghost'),btn('+ 100 mL / L',function(){stop(s);s.fill=clamp(s.fill+.1,0,1);fill.set(s.fill);s.refresh();},'ghost'),btn('Reset',function(){setPreset('half');},'ghost')]);
 panel.appendChild(h('p',{class:'f13c-instructions',text:'Drag vertically on the cube to move the water level, or focus the drawing and use Up / Down arrows (5% steps), Home (empty) and End (full). When displaying a cubic metre the scale is different: the tank has a capacity of 1000 litres.'}));
 makeStage(stage,s,'A cubic centimetre holds a millilitre. Explore how many fit in a litre, then compare with a cubic metre.','explain',true);
 if(api.onCleanup)api.onCleanup(function(){if(stage._f13Cleanup)stage._f13Cleanup();});
 CFG._explore={state:s,setPreset:setPreset,setFill:function(v){stop(s);s.fill=clamp(v,0,1);fill.set(s.fill);s.refresh();},setUnit:function(m){setPreset(m==='metre'?'cubicMetre':'full');},fillTo:function(v){animateTo(s,v);fill.set(v);},read:function(){return {unit:s.mode,fill:s.fill,amount:content(s),cm3:cmValue(s)}}};
 },
 challenge:function(panel,api,stage){var tasks=[
  {key:'quarter',q:'What volume in cm³ is equivalent to 250 mL?',answer:250,unit:'cm³',hint:'One millilitre occupies exactly one cubic centimetre.',mistake:'One cm³ equals one mL. You do not multiply or divide by one thousand here.'},
  {key:'full',q:'How many millilitres are there in 1.5 litres?',answer:1500,unit:'mL',hint:'Multiply the number of litres by one thousand.',mistake:'A litre contains one thousand millilitres. Multiply 1.5 by one thousand.'},
  {key:'cubicMetre',q:'How many litres fit into 1 cubic metre?',answer:1000,unit:'L',hint:'Think of ten layers of ten-by-ten one-litre blocks.',mistake:'One metre is ten decimetres, so multiply ten by ten by ten.'},
  {key:'threeQuarter',q:'750 mL is how many litres?',answer:.75,unit:'L',hint:'Divide millilitres by one thousand to convert to litres.',mistake:'To turn mL into L, divide by one thousand; 750 is three quarters of 1000.'}
 ];var k=0,timer=0,prompt=h('p',{class:'pr-task'}),answer=h('input',{class:'nova-input',type:'number',step:'any',inputmode:'decimal','aria-label':'Capacity conversion answer'}),unit=h('span',{class:'f13c-mark'}),feedback=h('p',{class:'f13c-feedback','aria-live':'polite'});
 function load(i){k=i;answer.value='';feedback.textContent='';var t=tasks[k];prompt.textContent=(k+1)+' / '+tasks.length+' · '+t.q;unit.textContent=t.unit;makeStage(stage,mkState(t.key),'Read the capacity, connect the space and liquid units, then calculate.','think',false);}
 function check(){var t=tasks[k],valid=answer.value.trim()!==''&&Number.isFinite(+answer.value),ok=valid&&Math.abs(+answer.value-t.answer)<1e-7,ms=ok?'Correct — you have converted the units while preserving the volume.':!valid?'Enter a number before checking.':t.mistake;
  feedback.textContent=ms;api.check(ok,ms,{task:k,value:valid?+answer.value:null,expected:t.answer,unit:t.unit});if(ok&&k<tasks.length-1){if(timer)clearTimeout(timer);timer=setTimeout(function(){load(k+1);},1150);}return ok;}
 panel.appendChild(prompt);row(panel,[h('label',{class:'f13c-answer'},['YOUR ANSWER ',answer,unit]),btn('Check',check,'primary'),btn('Hint',function(){api.hint(tasks[k].hint);},'ghost')]);panel.appendChild(feedback);
 panel.appendChild(h('p',{class:'f13c-instructions',text:'Units matter: cubic centimetres describe space, millilitres describe equal liquid capacity, and litres describe larger amounts.'}));
 if(api.onCleanup)api.onCleanup(function(){if(timer)clearTimeout(timer);if(stage._f13Cleanup)stage._f13Cleanup();});load(0);
 CFG._challenge={tasks:tasks,load:load,check:check,answer:answer,task:function(){return k;}};
 }
};
NOVA.bankMount({id:EN,num:'F13·12',title:'Capacity and volume conversion',def:def,linked:['F0-01','F0-02','F0-03','F0-04','F0-05','F13-05','F13-06','F13-07','F13-11'],spec:{
 purpose:'Make volume-to-capacity unit conversion tangible with a 3D cuboid, a 1 cm³ exemplar and a separate 1 m³ scaling model.',
 params:'1 cm³ = 1 mL; 1 dm³ = 1 L; 1000 cm³ = 1 L; 1 m³ = 1000 L = 1000000 cm³. Interactive capacity cube with a 0–100% fill scale.',
 presets:'0, 100, 250, 500, 750 or 1000 mL in a 10 cm cube; separate cubic metre and 1000-litre mode; not drawn to the same scale.',
 steps:STEPS.map(s=>s.n).join(' → '),
 interactions:'12 narrated teaching beats, filling by drag/slider/keyboard, full/empty animation, four marked conversion challenges.',
 traps:'Do not confuse cm³ and mL as numbers that need a factor of 1000; do not confuse 1 m³ with 1 L; multiply three length dimensions for volume; never infer physical scale from side-by-side schematics.',
 gcse:'Convert between cubic centimetres, cubic decimetres, cubic metres, millilitres and litres; use capacity and volume appropriately.'}});
var log=document.getElementById('log'),listener=function(x){log.textContent=new Date(x.time).toLocaleTimeString()+' '+x.type+' '+JSON.stringify(x.detail)+'\n'+log.textContent.slice(0,4000);};NOVA.events.history().forEach(listener);NOVA.events.on('*',listener);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
