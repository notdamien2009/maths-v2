"""Rebuild F13-12 from the local F13-11 premium source without altering F0/F1/F12 shared NOVA core."""
from pathlib import Path
P=Path(__file__).resolve().parent
src=(P/'F13-11-Cross-Sections-Explorer-PREMIUM-CORE.html').read_text()
css=(P/'f13_12_addon.css').read_text()
js=(P/'f13_12_engine.js').read_text()
a=src.index('/* F13-11 additive styles:');b=src.index('</style>',a)
src=src[:a]+css+'\n'+src[b:]
a=src.index('/* F13-11 CROSS-SECTIONS EXPLORER:');b=src.rfind('</script>')
src=src[:a]+js+'\n'+src[b:]
src=src.replace('NOVA F13-11 · Premium Cross-Sections Explorer','NOVA F13-12 · Premium Capacity and Volume Conversion')
src=src.replace('data-run="F13 · 3D shapes, volume and surface area · F13-11" data-title="Cross-sections explorer" data-sub="Move a cutting plane through a 3D solid and discover the true two-dimensional shape inside."','data-run="F13 · 3D shapes, volume and surface area · F13-12" data-title="Capacity and volume conversion" data-sub="See why a cubic centimetre holds one millilitre and how one litre fits into a ten-centimetre cube."')
out=P.parent/'F13-12-Capacity-and-Volume-Conversion-PREMIUM-CORE.html'
out.write_text(src)
print('Built',out,'bytes',out.stat().st_size)
