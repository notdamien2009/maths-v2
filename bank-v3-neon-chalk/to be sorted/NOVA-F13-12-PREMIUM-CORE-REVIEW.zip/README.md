# F13-12 — Capacity and Volume Conversion (premium-core review)

## Included
- Standalone F13-12 HTML, locally usable without internet.
- `source/` with original F13-11 premium base, additive F13-12 JS and CSS, reproducible `build.py`.
- `screenshots/` with actual Chromium captures at 1280px and 380px across Watch, Explore, cubic-metre and Challenge states.
- `QA-REPORT.md` and `QA-RESULTS.json` with the complete automated checks.

## Teaching
12 Watch/Guided stages demonstrate the relationship among 1cm³, 1mL, 1L, 1dm³ and 1m³. Explore supports tank fill levels, keyboard and pointer drawing control, two size regimes and capacity conversions. Challenge has four questions with targeted feedback.

## Core/layout requirements
Original NOVA core and stage untouched; official mascot, NOVA Chalk typography and neon/glass geometry retained. New engine is additive. Avoid proceeding to GOLD until visual approval. GitHub not touched.
