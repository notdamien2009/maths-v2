# NOVA F13-12 — Capacity and Volume Conversion | QA Report

Review build · 12 October 2026

**Result: 114/114 automated browser checks passed; 0 failed.**

## Source compliance
- Byte-for-byte preservation of the official NOVA JS runtime section carried over from the corrected F13-11 source.
- Byte-for-byte preservation of the base stylesheet preceding the new additive component CSS.
- Official F0-based frame, background treatment, NOVA Chalk embedded font and official NOVA cat companion.
- Original production core remains inline in a standalone offline HTML; no CDN dependencies.
- Reproducible source/build.py recreates the identical standalone HTML bytes.

## Tested at 1280px desktop and 380px mobile
- Load and responsive stage, mascot docking within stage boundaries, no horizontal page overflow or runtime JS errors.
- Watch, Guided, Explore and Challenge mode switching.
- Correct one-litre tank presets at 0/100/250/500/750/1000 mL, including correct cm³ values.
- 1 m³ = 1000 litres = 1,000,000 cm³; half a cubic metre = 500 litres.
- Physical-scale notice in the cubic-metre demonstration.
- Mouse pointer capture release after 20 rapid drag cycles; no stranded pointer state.
- Range slider, keyboard ArrowUp/ArrowDown/Home/End, fill animation and switching mode during animation.
- Four marked conversion challenges, including incorrect-answer feedback.

## Real mathematical identities
- **1 cm³ = 1 mL.**
- **10 cm × 10 cm × 10 cm = 1000 cm³ = 1000 mL = 1 L.**
- **1 m³ = 1,000,000 cm³ = 1000 L.**
- Tank fill fraction represents a uniform cross-section; therefore liquid height is proportional to the contained volume.
- The unit cube at the right is magnified; the cubic-metre comparison explicitly says the drawings are not to the same physical scale.

## Remaining production gate
This is a **visual review build, not approved GOLD** until reviewed and signed off by the user. Do not modify or push the maths-v2 GitHub repository.

SHA-256 HTML: `fed378bfc25e21b74e4e5308e54ac3a414b8b504f3313617707161d5b96682f0`
