from pathlib import Path
from playwright.sync_api import sync_playwright
import json, hashlib, math
ROOT=Path(__file__).resolve().parent
SH=ROOT/'screenshots';SH.mkdir(exist_ok=True)
HTML=(ROOT/'F13-07-Cuboid-Volume-and-Surface-Area-PREMIUM-CORE.html').read_text('utf-8')
BASE=(ROOT/'source/approved-F13-06-base.html').read_text('utf-8')
R=[]
def check(label,x):
 ok=bool(x);R.append({'check':label,'passed':ok});
 if not ok:print('FAIL',label,flush=True)
core=lambda s:s.split('<script>',1)[1].split('</script>',1)[0]
check('Official NOVA JavaScript runtime preserved exactly',core(HTML)==core(BASE))
core_css=lambda s:s.split('<style>',1)[1].split('/* F13-06 component-only styles;',1)[0]
check('Official NOVA core CSS preserved exactly',HTML.split('<style>',1)[1].startswith(core_css(BASE)))
check('No F13-06 additive engine retained','var NOVA_F13_06_CONFIG' not in HTML)
check('F13-07 new component engine embedded exactly once',HTML.count('var NOVA_F13_07_CONFIG=')==1)
check('Offline embedded fonts included','data:font/woff2;base64' in HTML)
check('Offline official mascot art included','data:image/webp;base64' in HTML)
PRESETS={'classic':(4,3,2),'cube':(3,3,3),'parcel':(5,3,2),'tower':(2,2,5),'shallow':(5,2,1)}
CH=[((3,2,2),12,32),((4,3,2),24,52),((5,2,3),30,62)]
with sync_playwright() as pw:
 br=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1280,380]:
  p=br.new_page(viewport={'width':width,'height':1000},device_scale_factor=1)
  errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
  p.set_content(HTML,wait_until='domcontentloaded',timeout=90000)
  p.evaluate('NOVA.engines["F13-07"].timeline.pause()')
  tag=f'{width}px'
  check(tag+' zero startup exceptions',not errors)
  check(tag+' engine runs from official core',p.evaluate('!!(NOVA.bankMount&&NOVA.neonPath&&NOVA.chalkText&&NOVA.f12&&NOVA.scene.helperStrip)'))
  check(tag+' official mascot assets embedded',p.evaluate('NOVA.helperImg("explain").src.startsWith("data:image/webp")'))
  check(tag+' Chalk font registered',p.evaluate('document.fonts.check("16px NOVA Chalk")'))
  check(tag+' official background present',p.evaluate('getComputedStyle(document.querySelector(".nova-stage")).backgroundImage!=="none"'))
  check(tag+' exactly one mascot in stage',p.locator('.nova-stage .nv-dockfig').count()==1)
  check(tag+' exactly one speech bubble in stage',p.locator('.nova-stage .nv-dockbub').count()==1)
  check(tag+' no full-page horizontal overflow',p.evaluate('document.documentElement.scrollWidth<=innerWidth'))
  check(tag+' six mathematically distinct faces in SVG',p.locator('[data-maths="six-exact-cuboid-faces"] [data-face]').count()==6)
  for i in range(12):
   p.evaluate('(i)=>NOVA.engines["F13-07"].timeline.go(i,"QA")',i)
   check(tag+f' Watch step {i+1} keeps stage 6 face geometry',p.locator('[data-maths="six-exact-cuboid-faces"] [data-face]').count()==6)
   check(tag+f' Watch step {i+1} mascot never duplicates',p.locator('.nova-stage .nv-dockfig').count()==1)
   check(tag+f' Watch step {i+1} shows both calculations',p.locator('.f13v-svg').count()==1 and 'SURFACE AREA' in p.locator('.f13v-svg').text_content())
   if i in [0,3,6,9,11]:p.locator('.nova-stage').screenshot(path=str(SH/f'{width}-watch-{i+1}.png'),animations='disabled')
  p.get_by_role('tab',name='Guided').click()
  check(tag+' Guided mode controls active',p.locator('.nova-stage .f13v-svg').count()==1)
  check(tag+' Guided mascot inside',p.locator('.nova-stage .nv-dockfig').count()==1)
  p.get_by_role('tab',name='Explore').click()
  check(tag+' Explore source exposed for reproducible QA',p.evaluate('!!NOVA_F13_07_CONFIG._explore.state'))
  preset=p.locator('select[aria-label="Cuboid preset"]')
  state='NOVA_F13_07_CONFIG._explore.state'
  for key,(l,w,z) in PRESETS.items():
   preset.select_option(key);p.wait_for_timeout(75)
   got=p.evaluate(f'({state})=>[({state}).l,({state}).w,({state}).ht]') if False else p.evaluate('(()=>{const s=NOVA_F13_07_CONFIG._explore.state;return [s.l,s.w,s.ht]})()')
   check(tag+f' {key} preset uses correct dimensions',got==[l,w,z])
   v=l*w*z;sa=2*(l*w+l*z+w*z)
   tiles=p.locator('.f12-strip .nv-ntile .mt').all_inner_texts()
   check(tag+f' {key} exact face areas',tiles==[str(l*w),str(l*z),str(w*z)])
   check(tag+f' {key} volume and area maths',p.evaluate(f'NOVA_F13_07_CONFIG._explore.state.l*NOVA_F13_07_CONFIG._explore.state.w*NOVA_F13_07_CONFIG._explore.state.ht')==v and p.locator('.nova-stage').inner_text().find(f'{sa} units²')!=-1)
   if key in ['cube','tower','shallow'] and width==1280:p.locator('.nova-stage').screenshot(path=str(SH/f'{width}-{key}.png'),animations='disabled')
  preset.select_option('classic');p.wait_for_timeout(85)
  p.get_by_role('button',name='Unfold net').click();p.wait_for_timeout(90)
  check(tag+' net opens to 100%',p.evaluate(state+'.unfold')==100)
  check(tag+' six visible surface rectangles in open net',p.locator('[data-maths="six-exact-cuboid-faces"] [data-face]').count()==6)
  check(tag+' 3 pairs have correct face colours',p.locator('[data-family="top"]').count()==2 and p.locator('[data-family="front"]').count()==2 and p.locator('[data-family="side"]').count()==2)
  # Check exact opposite rectangle area labels, not just arithmetic variables.
  for name,area in [('TOP',12),('BOTTOM',12),('FRONT',8),('BACK',8),('LEFT',6),('RIGHT',6)]:
   lab=p.locator(f'[data-face="{name.lower()}"]')
   check(tag+f' opened {name} face exact {area} square units',f'{area} u²' in lab.text_content())
  # Strict real-hinge test: common corners must coincide during the ENTIRE fold.
  for percent in [25,55,75]:
   slide=p.locator('input[aria-label="UNFOLD SIX FACES (%)"]');slide.fill(str(percent));slide.dispatch_event('input');p.wait_for_timeout(80)
   verts=p.evaluate(r'''(()=>{const out={};for(const e of document.querySelectorAll('[data-maths="six-exact-cuboid-faces"] [data-face]')){const d=e.querySelector('path').getAttribute('d');out[e.dataset.face]=Array.from(d.matchAll(/(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/g),m=>[+m[1],+m[2]]).slice(0,4);}return out;})()''')
   def near(a,b):return bool(a and b and math.dist(a,b)<.1)
   f=verts['front'];top=verts['top'];bt=verts['bottom'];left=verts['left'];right=verts['right'];back=verts['back']
   check(tag+f' {percent}% net: top remains hinged to front',near(top[3],f[0]) and near(top[2],f[1]))
   check(tag+f' {percent}% net: bottom remains hinged to front',near(bt[0],f[3]) and near(bt[1],f[2]))
   check(tag+f' {percent}% net: left remains hinged to front',near(left[1],f[0]) and near(left[2],f[3]))
   check(tag+f' {percent}% net: right remains hinged to front',near(right[0],f[1]) and near(right[3],f[2]))
   check(tag+f' {percent}% net: back remains hinged to top',near(back[0],top[0]) and near(back[1],top[1]))
  slide.fill('100');slide.dispatch_event('input');p.wait_for_timeout(80)
  check(tag+' open net keeps original stage and single mascot',p.locator('.nova-stage .nv-dockfig').count()==1)
  p.locator('.nova-stage').screenshot(path=str(SH/f'{width}-net.png'),animations='disabled')
  p.get_by_role('button',name='3D Solid').click();p.wait_for_timeout(80)
  check(tag+' net closes to a genuine 3D cuboid',p.evaluate(state+'.unfold')==0)
  for val,area in [('top',12),('front',8),('side',6)]:
   p.locator('select[aria-label="Highlight face pair"]').select_option(val);p.wait_for_timeout(80)
   check(tag+f' {val} equal-face pair highlights correctly',p.evaluate(state+'.group')==val and p.locator(f'[data-family="{val}"]').count()==2)
  p.locator('select[aria-label="Highlight face pair"]').select_option('all')
  cb=p.locator('input[aria-label="Show unit-square grid"]');cb.uncheck();p.wait_for_timeout(70)
  check(tag+' grid toggle off works',p.evaluate(state+'.grid')==False)
  cb.check();p.wait_for_timeout(70);check(tag+' grid toggle on works',p.evaluate(state+'.grid')==True)
  # Dimension sliders must update ALL derived facts.
  for dim,val in [('LENGTH',6),('WIDTH',4),('HEIGHT',3)]:
   q=p.locator(f'input[aria-label="{dim}"]');q.fill(str(val));q.dispatch_event('input')
  p.wait_for_timeout(80)
  check(tag+' three sliders update dimensions',p.evaluate('(()=>{let s=NOVA_F13_07_CONFIG._explore.state;return [s.l,s.w,s.ht]})()')==[6,4,3])
  check(tag+' recalculated volume 72', '72 units³' in p.locator('.nova-stage').inner_text())
  check(tag+' recalculated surface area 108', '108 units²' in p.locator('.nova-stage').inner_text())
  p.get_by_role('button',name='Reset',exact=True).click();p.wait_for_timeout(80)
  check(tag+' reset 4×3×2',p.evaluate('(()=>{let s=NOVA_F13_07_CONFIG._explore.state;return [s.l,s.w,s.ht,s.unfold]})()')==[4,3,2,0])
  svg=p.locator('.f13v-svg');svg.scroll_into_view_if_needed();svg.focus();p.keyboard.press('ArrowRight');p.wait_for_timeout(90)
  check(tag+' keyboard turn works',p.evaluate(state+'.angle')>.04)
  p.keyboard.press('Home');p.wait_for_timeout(80);check(tag+' keyboard Home resets view',p.evaluate(state+'.angle')==0)
  svg.scroll_into_view_if_needed();box=svg.bounding_box();x=box['x']+box['width']*.36;y=box['y']+box['height']*.3
  p.mouse.move(x,y);p.mouse.down()
  for j in range(25):p.mouse.move(x+box['width']*.30*j/24,y)
  p.mouse.up();p.wait_for_timeout(80)
  check(tag+' fast pointer drag turns solid',p.evaluate(state+'.angle')>.10)
  check(tag+' drag capture cleans up',not ('f13v-grab' in (svg.get_attribute('class') or '')))
  check(tag+' rotation preserves volume and area', '24 units³' in p.locator('.nova-stage').inner_text() and '52 units²' in p.locator('.nova-stage').inner_text())
  p.get_by_role('tab',name='Challenge').click()
  check(tag+' challenge prompts for volume and surface',p.locator('input[type=number]').count()==2)
  ins=p.locator('.nova-panel input[type=number]')
  p.get_by_role('button',name='Check answers').click()
  check(tag+' incomplete answer is rejected',p.locator('.nova-fb.bad').count()==1)
  for i,(d,v,a) in enumerate(CH):
   check(tag+f' challenge task {i+1} appears',p.evaluate('NOVA_F13_07_CONFIG._challenge.task()')==i)
   if i==0:
    ins.nth(0).fill('11');ins.nth(1).fill('32');p.get_by_role('button',name='Check answers').click()
    check(tag+' wrong volume diagnostic',p.locator('.nova-fb.bad').count()==1 and 'volume' in p.locator('.nova-panel').inner_text().lower())
    ins.nth(0).fill('12');ins.nth(1).fill('16');p.get_by_role('button',name='Check answers').click()
    check(tag+' missing opposite faces diagnostic',p.locator('.nova-fb.bad').count()==1 and 'OPPOSITE' in p.locator('.nova-panel').inner_text())
   ins.nth(0).fill(str(v));ins.nth(1).fill(str(a));p.get_by_role('button',name='Check answers').click()
   check(tag+f' challenge {i+1} correct V and SA accepted',p.locator('.nova-fb.ok').count()==1)
   if i<2:p.wait_for_timeout(1370)
  p.locator('.nova-stage').screenshot(path=str(SH/f'{width}-challenge.png'),animations='disabled')
  # Repeated navigation while graphics is active must not duplicate mascot.
  p.get_by_role('tab',name='Watch').click();p.evaluate('NOVA.engines["F13-07"].timeline.pause()')
  check(tag+' navigation leaves one mascot',p.locator('.nova-stage .nv-dockfig').count()==1)
  check(tag+' zero Javascript exceptions after full suite',not errors)
  check(tag+' zero horizontal overflow after full suite',p.evaluate('document.documentElement.scrollWidth<=innerWidth'))
  if width==380:
   # The strip must not wrap to a second row.
   check(tag+' face counters remain on one row',p.evaluate('(()=>{let x=[...document.querySelectorAll(".f12-strip .nv-ntile")];return x.length===3&&Math.max(...x.map(t=>t.getBoundingClientRect().top))-Math.min(...x.map(t=>t.getBoundingClientRect().top))<10})()'))
  p.close()
 br.close()
res={'total':len(R),'passed':sum(x['passed'] for x in R),'failed':sum(not x['passed'] for x in R),'results':R}
(ROOT/'QA-RESULTS.json').write_text(json.dumps(res,indent=2))
print('RESULT',res['passed'],'/',res['total'],flush=True)
if res['failed']:raise SystemExit(1)
