# NOVA F13-07 — Cuboid Volume and Surface Area

This is the premium-core review build continuing the user-approved F13-01 through F13-06 family. It replaces the previously abandoned F13 prototypes and **does not modify GitHub**.

## Open
Open `F13-07-Cuboid-Volume-and-Surface-Area-PREMIUM-CORE.html` locally in Chrome or Edge. All fonts, official helper artwork, background and NOVA runtime are embedded offline.

## Maths and lessons
Used for Y7-049, Y8-042, Y8-060, Y8-061, Y9-036 and Y9-037.
- Volume: length × width × height, measured in units³.
- Surface area: 2(length × width + length × height + width × height), measured in units².
- Preset cuboid 4 × 3 × 2: 24 units³ of volume and 52 units² surface area.
- The complete net contains six exact, mathematically dimensioned faces: two pairs of 12 units², 8 units² and 6 units².

## Interaction
Watch (12 teaching steps), Guided, Explore, Challenge (3 marked questions).
Explore has five presets, independent dimensions 1–6, an unfold slider (0–100%), three selectable face pairs, square-unit grid on/off and rotatable 3D solid by drag or keyboard arrows. Each face stays connected at a true geometric hinge throughout the unfolding motion, including the back face hinged to the top.

## Files
- Standalone HTML: complete self-contained player.
- `source/F13-07.engine.js`: additive engine; uses existing NOVA drawing and UI helpers.
- `source/F13-07.component.css`: component-local styling.
- `source/approved-F13-06-base.html`: original preceding-family reference, frozen.
- `source/build.py`: reproducible offline rebuild. Run from any working directory with Python 3.
- `screenshots/`: actual Chromium desktop/mobile screenshots, including intermediate fold.
- `qa.py` and `QA-RESULTS.json`: 239 automated browser checks.

**Review status only:** This is not a GitHub push or GOLD sign-off.
SHA256 standalone HTML: `45c3105e3bbd8fc11e6ea148ac47c8de77ebaa42622412ea311dad85b487a3f7`.
