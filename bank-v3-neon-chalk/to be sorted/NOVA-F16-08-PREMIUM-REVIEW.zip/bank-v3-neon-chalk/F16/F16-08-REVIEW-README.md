# NOVA Maths V2 · F16-08 Premium Review

**F16-08 · Range and Spread**. Standalone HTML with the original embedded NOVA neon/chalk core and original helper artwork. Offline: no network or runtime dependencies.

Open `F16/F16-08-range-and-spread.html`, test Watch/Guided/Explore/Challenge, switch the four presets in Explore, and inspect keyboard/fast mouse movement. The Y9-048 preset demonstrates how an extreme value changes the range.

To reproduce, run `python3 build/build-f16-08.py`. The build verifies pinned shared-core SHA hashes from `tests/pinned-core.js` and `tests/pinned-core.css` and inserts the component files from `src/` into the standalone. No existing repository `core/nova-core.js` or `core/nova-core.css` is changed or replaced by this ZIP.

Audit: `F16/F16-08-QA.md` and `tests/*-RESULTS.json`. The `shots/` directory includes selected captures at 380 and 1280 pixels. This package is **PREMIUM REVIEW, NOT GOLD**. GitHub was not modified.
