from playwright.sync_api import sync_playwright
from pathlib import Path
import json
R=Path('/mnt/data/nova-f16-08-work');html=(R/'F16/F16-08-range-and-spread.html').read_text();a=[]
def ok(n,v):a.append({'check':n,'pass':bool(v)});print('PASS' if v else 'FAIL',n,flush=True)
def move(p,selector,toValue,width,axis=352):
 x0,x1=(49,416) if width==380 else (90,702)
 x=x0+toValue*(x1-x0)/16
 loc=p.locator(selector);loc.scroll_into_view_if_needed();r=loc.bounding_box();pos=p.evaluate('''xy=>{let s=document.querySelector('.f168-svg'),q=s.createSVGPoint();q.x=xy[0];q.y=xy[1];let t=q.matrixTransform(s.getScreenCTM());return {x:t.x,y:t.y}}''',[x,axis+75]);p.mouse.move(r['x']+r['width']/2,r['y']+r['height']/2);p.mouse.down();p.mouse.move(pos['x'],pos['y'],steps=1);p.mouse.up();p.wait_for_timeout(120)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [380,1280]:
  p=b.new_page(viewport={'width':width,'height':970},reduced_motion='reduce');err=[];p.on('pageerror',lambda x:err.append(str(x)));p.set_content(html);p.locator('.nova-tab[data-m="challenge"]').click();p.wait_for_timeout(80)
  q=lambda:p.evaluate('NOVA_F16_08_CONFIG._challengeState()')
  ok(f'{width} started challenge at wrong endpoints',q()['pins']['a']==[1,15])
  p.get_by_role('button',name='Check').click();p.wait_for_timeout(80)
  ok(f'{width} wrong endpoints do not advance',q()['task']==0)
  move(p,'[data-handle="a:0"]',3,width)
  ok(f'{width} mouse moved left endpoint to 3',q()['pins']['a'][0]==3)
  move(p,'[data-handle="a:1"]',9,width)
  ok(f'{width} mouse moved right endpoint to 9',q()['pins']['a'][1]==9)
  p.get_by_role('button',name='Check').click();p.wait_for_timeout(950)
  ok(f'{width} drag solved Challenge task 0',q()['task']==1)
  inp=p.locator('.nova-panel input').last
  if not inp.count():inp=p.locator('input').last
  inp.fill('12');p.get_by_role('button',name='Check').click();p.wait_for_timeout(120)
  ok(f'{width} sum of endpoints rejected as range',q()['task']==1)
  inp.fill('6');p.get_by_role('button',name='Check').click();p.wait_for_timeout(950)
  ok(f'{width} correct subtraction advances',q()['task']==2)
  ok(f'{width} zero exceptions',not err)
  p.close()
 b.close()
(R/'tests/CHALLENGE-DRAG-RESULTS.json').write_text(json.dumps({'total':len(a),'passed':sum(t['pass'] for t in a),'failed':[t for t in a if not t['pass']],'checks':a},indent=2));print('TOTAL',sum(t['pass'] for t in a),'/',len(a))
