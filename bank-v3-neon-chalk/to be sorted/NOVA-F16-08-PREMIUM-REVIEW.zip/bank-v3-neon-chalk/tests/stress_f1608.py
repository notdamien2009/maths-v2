"""F16-08 Premium Review regression: actual browser assertions and native mouse drags."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1];HTML=(R/'F16/F16-08-range-and-spread.html').read_text()
results=[]
def check(label,passed,detail=''):
 results.append({'check':label,'pass':bool(passed),'detail':str(detail)[:240]});print(('PASS' if passed else 'FAIL'),label,str(detail)[:95],flush=True)
def coord(page,x,y):
 return page.evaluate('''xy=>{let s=document.querySelector('.f168-svg'),q=s.createSVGPoint();q.x=xy[0];q.y=xy[1];let p=q.matrixTransform(s.getScreenCTM());return {x:p.x,y:p.y}}''',[x,y])
def drag(page,selector,tx,ty,steps=1):
 l=page.locator(selector).first;l.scroll_into_view_if_needed();page.wait_for_timeout(65)
 b=l.bounding_box();assert b,selector
 t=coord(page,tx,ty)
 page.mouse.move(b['x']+b['width']/2,b['y']+b['height']/2)
 page.mouse.down();page.mouse.move(t['x'],t['y'],steps=steps);page.mouse.up();page.wait_for_timeout(110)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':980},reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(HTML,wait_until='load');page.wait_for_timeout(180)
  def mode(name):page.locator(f'.nova-tab[data-m="{name}"]').click();page.wait_for_timeout(90)
  def get():return page.evaluate('NOVA_F16_08_CONFIG._explore.get()')
  for m in ['watch','guided','explore','challenge']:
   mode(m)
   check(f'{width} {m} SVG',page.locator('.nova-stage .f168-svg').count()==1)
   check(f'{width} {m} single mascot dock',page.locator('.nova-stage .nv-dock').count()==1)
   check(f'{width} {m} no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'))
  check(f'{width} original core',page.evaluate('typeof NOVA.numberLine==="function" && typeof NOVA.ui.svgDrag==="function" && typeof NOVA.scene.helperStrip==="function"'))
  mode('watch')
  for i in range(9):
   try:page.evaluate('i=>{F16_08.timeline.pause();F16_08.timeline.go(i,"qa")}',i)
   except Exception as e:check(f'{width} Watch step {i}',False,str(e));continue
   page.wait_for_timeout(50);check(f'{width} Watch step {i}',page.locator('.f168-svg').count()==1)
  mode('explore')
  keys=['y7-range','y7-compare','y8-compare','y9-outlier'];expected=[(6,None),(6,11),(8,12),(15,8)]
  for k,(ra,rb) in zip(keys,expected):
   page.locator('select[aria-label="Lesson preset"]').select_option(k);page.wait_for_timeout(65)
   a=get();check(f'{width} {k} correct stats',a['rangeA']==ra and a['rangeB']==rb,a)
   check(f'{width} {k} correct number-line count',page.locator('.nv-numberline').count()==(2 if rb is not None else 1))
   check(f'{width} {k} no duplicate mascot',page.locator('.nova-stage .nv-dock').count()==1)
   check(f'{width} {k} zero JS exceptions',not errors,errors)
  # Actual mouse drags at mobile and desktop in the Y7 preset.
  page.locator('select[aria-label="Lesson preset"]').select_option('y7-range');page.wait_for_timeout(80)
  g={'x0':49,'x1':416,'y':352} if width==380 else {'x0':90,'x1':702,'y':352}
  x=lambda n:g['x0']+n*(g['x1']-g['x0'])/16
  before=get();check(f'{width} Explore bracket initializes on true extremes',before['state']['pins']['a']==[3,9])
  drag(page,'[data-observation="a:0"]',x(12),g['y']-29,steps=1)
  after=get();check(f'{width} FAST native dot move 6 to 12',after['state']['a'][0]==12,after['state']['a'])
  check(f'{width} range recalculates from dots',after['rangeA']==9,after['rangeA'])
  check(f'{width} no stranded pointer after fast drag',page.evaluate('NOVA.ui._drag===null'))
  prev=get()['state']['a'][:]
  drag(page,'[data-observation="a:0"]',x(10),82,steps=5)
  check(f'{width} invalid outside-graph drop returns',get()['state']['a']==prev,get()['state']['a'])
  check(f'{width} no stranded pointer after invalid',page.evaluate('NOVA.ui._drag===null'))
  # Escape cancellation from active pointer.
  el=page.locator('[data-observation="a:0"]');el.scroll_into_view_if_needed();bb=el.bounding_box();dest=coord(page,x(8),g['y']-20)
  page.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);page.mouse.down();page.mouse.move(dest['x'],dest['y'],steps=4);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(100)
  check(f'{width} Escape preserves observation',get()['state']['a']==prev)
  check(f'{width} Escape releases pointer',page.evaluate('NOVA.ui._drag===null'))
  # Keyboard equivalent
  page.locator('[data-observation="a:0"]').focus();page.keyboard.press('ArrowLeft');page.wait_for_timeout(85)
  check(f'{width} keyboard changes observation',get()['state']['a'][0]==11)
  # Drag minimum handle from 3 to 4 using actual pointer movement.
  drag(page,'[data-handle="a:0"]',x(4),g['y']+75,steps=1)
  check(f'{width} native bracket handle snaps to 4',get()['state']['pins']['a'][0]==4,get()['state']['pins']['a'])
  page.locator('[data-handle="a:0"]').focus();page.keyboard.press('ArrowLeft');page.wait_for_timeout(90)
  check(f'{width} keyboard bracket handle snaps to 3',get()['state']['pins']['a'][0]==3)
  # Validate Challenge calculations independently for all presets.
  for key,ans1,ans2 in [('y7-range',6,9),('y7-compare',6,11),('y8-compare',8,12),('y9-outlier',15,6)]:
   page.locator('select[aria-label="Lesson preset"]').select_option(key);mode('challenge')
   q=page.evaluate('NOVA_F16_08_CONFIG._challengeState()');
   check(f'{width} {key} Challenge starts with draggable handles',page.locator('[data-handle="a:0"]').count()==1 and q['task']==0)
   p0=page.evaluate('NOVA_F16_08_CONFIG.presets[NOVA_F16_08_CONFIG.preset].a')
   page.locator('select[aria-label="Left range handle"]').select_option(str(min(p0)))
   page.locator('select[aria-label="Right range handle"]').select_option(str(max(p0)))
   page.get_by_role('button',name='Place bracket handles').click()
   page.get_by_role('button',name='Check').click();page.wait_for_timeout(960)
   check(f'{width} {key} Challenge task 0 correct',page.evaluate('NOVA_F16_08_CONFIG._challengeState().task')==1)
   inp=page.locator('input').last
   # Locate challenge entry by placeholder or find input nearest task container.
   inps=page.locator('.nova-panel input');
   if not inps.count():inps=page.locator('input')
   inps.last.fill(str(ans1));page.get_by_role('button',name='Check').click();page.wait_for_timeout(970)
   check(f'{width} {key} Challenge task 1 correct',page.evaluate('NOVA_F16_08_CONFIG._challengeState().task')==2)
   inps=page.locator('.nova-panel input');
   if not inps.count():inps=page.locator('input')
   inps.last.fill(str(ans2));page.get_by_role('button',name='Check').click();page.wait_for_timeout(170)
   check(f'{width} {key} Challenge final correct feedback',page.locator('text=Correct').count()>=1 or page.locator('text=correct').count()>=1)
   mode('explore')
  check(f'{width} no unhandled browser exceptions',not errors,errors)
  page.close()
 b.close()
(R/'tests/STRESS-RESULTS.json').write_text(json.dumps({'total':len(results),'passed':sum(x['pass'] for x in results),'failed':[x for x in results if not x['pass']],'checks':results},indent=2))
print('RESULT',len(results),sum(x['pass'] for x in results),'pass',sum(not x['pass'] for x in results),'fail')
