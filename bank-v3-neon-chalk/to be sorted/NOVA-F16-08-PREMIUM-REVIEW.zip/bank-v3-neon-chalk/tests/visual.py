from playwright.sync_api import sync_playwright
from pathlib import Path
import json
root=Path('/mnt/data/nova-f16-08-work');url=(root/'F16/F16-08-range-and-spread.html').resolve().as_uri()
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for size in [380,1280]:
  page=b.new_page(viewport={'width':size,'height':850},device_scale_factor=1)
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content((root/'F16/F16-08-range-and-spread.html').read_text(),wait_until='load',timeout=90000);page.wait_for_timeout(250)
  print('INITIAL',size,'errors',errors,'titles',page.locator('button').all_text_contents()[:30]);
  print('DOM','numberlines',page.locator('.nv-numberline').count(),'dock',page.locator('.nv-dock').count(),'SVG',page.locator('.f168-svg').count())
  print('tab candidates',page.locator('[role=tab]').all_text_contents())
  page.screenshot(path=str(root/'shots'/f'F16-08-{size}-watch.png'),full_page=True)
  for mode in ['Explore','Challenge','Guided']:
   try:
    t=page.get_by_role('tab',name=mode)
    if t.count(): t.first.click()
    else:page.locator('button').filter(has_text=mode).first.click()
    page.wait_for_timeout(250)
    page.screenshot(path=str(root/'shots'/f'F16-08-{size}-{mode.lower()}.png'),full_page=True)
    print('MODE',size,mode,'errors',errors[-3:],'dots',page.locator('[data-observation]').count(),'handles',page.locator('[data-handle]').count(),'stage height',page.evaluate("() => {let a=document.querySelector('.f168-svg'),b=document.querySelector('.nova-stage');return a&&b?[a.getBoundingClientRect().height,b.getBoundingClientRect().height]:null}"))
   except Exception as e:print('MODE FAILED',str(e)[:400])
  page.close()
 b.close()
