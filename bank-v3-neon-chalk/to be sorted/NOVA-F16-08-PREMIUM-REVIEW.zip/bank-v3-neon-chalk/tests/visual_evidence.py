from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1];html=(R/'F16/F16-08-range-and-spread.html').read_text();rows=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':975},reduced_motion='reduce');err=[];page.on('pageerror',lambda e:err.append(str(e)));page.set_content(html,wait_until='load');page.wait_for_timeout(140)
  for key in ['y7-range','y7-compare','y8-compare','y9-outlier']:
   page.locator('.nova-tab[data-m="explore"]').click();page.locator('select[aria-label="Lesson preset"]').select_option(key);page.wait_for_timeout(65)
   for mode in ['watch','guided','explore','challenge']:
    page.locator(f'.nova-tab[data-m="{mode}"]').click();page.wait_for_timeout(80)
    if mode=='watch':page.evaluate('F16_08.timeline.pause();F16_08.timeline.go(8,"screenshots")')
    filename=f'F16-08-{width}-{key}-{mode}.png';page.screenshot(path=str(R/'shots'/filename),full_page=True,animations='disabled')
    metric=page.evaluate('''()=>{let d=document.querySelector('.nova-stage'),v=d.querySelector('.f168-svg');return {svgH:v.getBoundingClientRect().height,stageH:d.getBoundingClientRect().height,scroll:document.documentElement.scrollWidth-innerWidth,docks:d.querySelectorAll('.nv-dock').length,numberlines:v.querySelectorAll('.nv-numberline').length};}''')
    rows.append({'shot':filename,'width':width,'preset':key,'mode':mode,**metric,'errors':err[:]})
   page.locator('.nova-tab[data-m="watch"]').click()
   for step in ([0,1,2,5,6] if key=='y7-range' else [0,5,7,8] if key=='y9-outlier' else [0,7]):
    page.evaluate('i=>{F16_08.timeline.pause();F16_08.timeline.go(i,"screenshots")}',step);page.wait_for_timeout(50)
    filename=f'F16-08-{width}-{key}-watch-step{step}.png';page.screenshot(path=str(R/'shots'/filename),full_page=True,animations='disabled')
    rows.append({'shot':filename,'width':width,'preset':key,'mode':'watch','step':step,'errors':err[:]})
  page.close()
 b.close()
(R/'tests/VISUAL-RESULTS.json').write_text(json.dumps(rows,indent=2))
print('Screenshots',len(rows),'Errors',sum(bool(x['errors']) for x in rows))
print('Mobile scene ratios',sorted(set(round(x['svgH']/x['stageH'],3) for x in rows if x['width']==380 and 'svgH' in x)))
