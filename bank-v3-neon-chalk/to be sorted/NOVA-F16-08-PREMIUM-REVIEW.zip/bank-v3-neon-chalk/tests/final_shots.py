from playwright.sync_api import sync_playwright
from pathlib import Path
import json
R=Path('/mnt/data/nova-f16-08-work');html=(R/'F16/F16-08-range-and-spread.html').read_text();out=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':975},reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(html,wait_until='load');page.wait_for_timeout(100)
  for preset in ['y7-range','y7-compare','y8-compare','y9-outlier']:
   page.locator('.nova-tab[data-m="explore"]').click();page.locator('select[aria-label="Lesson preset"]').select_option(preset);page.wait_for_timeout(45)
   for mode in ['watch','guided','explore','challenge']:
    page.locator(f'.nova-tab[data-m="{mode}"]').click();page.wait_for_timeout(45)
    if mode=='watch':page.evaluate('F16_08.timeline.pause();F16_08.timeline.go(8,"qa")')
    filename=f'F16-08-{width}-{preset}-{mode}-FINAL.png';page.screenshot(path=str(R/'shots'/filename),full_page=True,animations='disabled')
    metric=page.evaluate('''()=>{let d=document.querySelector('.nova-stage'),v=d.querySelector('.f168-svg');return {svgH:Math.round(v.getBoundingClientRect().height),stageH:Math.round(d.getBoundingClientRect().height),over:document.documentElement.scrollWidth-innerWidth,docks:d.querySelectorAll('.nv-dock').length}}''')
    out.append({'screenshot':filename,'viewport':width,'preset':preset,'mode':mode,**metric,'errors':errors[:]})
   if preset in ['y7-range','y9-outlier']:
    page.locator('.nova-tab[data-m="watch"]').click();page.evaluate('F16_08.timeline.pause();F16_08.timeline.go(0,"qa")')
    filename=f'F16-08-{width}-{preset}-watch-opening-FINAL.png';page.screenshot(path=str(R/'shots'/filename),full_page=True,animations='disabled')
    out.append({'screenshot':filename,'viewport':width,'preset':preset,'mode':'watch-opening','errors':errors[:]})
  page.close()
 b.close()
(R/'tests/VISUAL-RESULTS.json').write_text(json.dumps({'screenshots':out,'total':len(out),'errors':sum(bool(x['errors']) for x in out)},indent=2))
print('Evidence:',len(out),'screenshots; errors:',sum(bool(x['errors']) for x in out));print('mobile coverage',[round(x['svgH']/x['stageH']*100) for x in out if x['viewport']==380 and 'svgH'in x]);
