from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/mnt/data');HTML=(ROOT/'NOVA-F15-11-Circle-Parts-Diagram.html').read_text();OUT=ROOT/'F15-11-QA';OUT.mkdir(exist_ok=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=b.new_page(viewport={'width':width,'height':980},device_scale_factor=1,reduced_motion='reduce')
  page.set_content(HTML,wait_until='domcontentloaded');page.wait_for_timeout(280)
  tabs=page.locator('#F15-11 .nova-tabs button')
  tabs.filter(has_text='Explore').first.click();page.wait_for_timeout(100)
  for preset in (['y9parts','y9tangent'] if width==380 else ['y9tangent','y9reverse']):
   page.evaluate('(k)=>NOVA_F15_11_CONFIG._explore.select(k)',preset);page.wait_for_timeout(150)
   page.locator('#F15-11 .nova-stage').screenshot(path=str(OUT/f'{width}-{preset}-stage.png'),animations='disabled')
  tabs.filter(has_text='Watch').first.click();page.wait_for_timeout(110)
  pause=page.locator('#F15-11 button[aria-label="Pause"]');
  if pause.count():pause.first.click()
  scrub=page.locator('#F15-11 input[aria-label="Scrub through steps"]');scrub.fill('15');scrub.dispatch_event('input');page.wait_for_timeout(170)
  page.locator('#F15-11 .nova-stage').screenshot(path=str(OUT/f'{width}-watch-16-stage.png'),animations='disabled')
  page.close()
 b.close()
print('Captured 6 additional geometry/preset screenshots.')
