from pathlib import Path
from playwright.sync_api import sync_playwright
import json
P=Path('/mnt/data/NOVA-F15-11-Circle-Parts-Diagram.html');out=Path('/mnt/data/F15-11-QA')
checks=[]
def r(a,b):checks.append({'name':a,'pass':bool(b)});print('FAIL' if not b else 'PASS',a)
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  pg=b.new_page(viewport={'width':width,'height':950},reduced_motion='reduce')
  err=[];pg.on('pageerror',lambda e:err.append(str(e)))
  pg.set_content(P.read_text(),wait_until='domcontentloaded');pg.wait_for_timeout(320)
  # pause autoreplay so manual steps are stable
  btn=pg.locator('#F15-11 button[aria-label="Pause"]')
  if btn.count():btn.click()
  sr=pg.locator('#F15-11 input[aria-label="Scrub through steps"]')
  for i in range(16):
   sr.fill(str(i));sr.dispatch_event('input');pg.wait_for_timeout(95)
   label=pg.locator('#F15-11 .nova-stepname').inner_text()
   r(f'{width} scrub step {i+1}',('Step '+str(i+1)+' of 16') in label)
   r(f'{width} step {i+1} draws stage',pg.locator('#F15-11 .f1511-board').count()==1)
  sr.fill('0');sr.dispatch_event('input');pg.wait_for_timeout(50)
  pg.locator('#F15-11 button[aria-label="Step forward"]').click();pg.wait_for_timeout(120)
  r(f'{width} step forward',pg.locator('#F15-11 .nova-stepname').inner_text().startswith('Step 2 of 16'))
  pg.locator('#F15-11 button[aria-label="Step back"]').click();pg.wait_for_timeout(120)
  r(f'{width} step back',pg.locator('#F15-11 .nova-stepname').inner_text().startswith('Step 1 of 16'))
  r(f'{width} no errors timeline',len(err)==0)
  pg.close()
 b.close()
out.joinpath('timeline.json').write_text(json.dumps({'total':len(checks),'passed':sum(x['pass'] for x in checks),'checks':checks},indent=2))
print('SUMMARY',sum(x['pass'] for x in checks),'/',len(checks))
