from pathlib import Path
import http.server, socketserver, threading, json, traceback
from playwright.sync_api import sync_playwright
from functools import partial
ROOT=Path('/mnt/data'); QA=ROOT/'F15-11-QA';QA.mkdir(exist_ok=True)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args): pass
server=socketserver.TCPServer(('127.0.0.1',8891),partial(Quiet,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
results=[]
def check(name,condition,extra=None):
 results.append({'name':name,'pass':bool(condition),'extra':extra});print(('PASS' if condition else 'FAIL'),name,extra or '')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [380,1280]:
  page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
  errs=[]
  page.on('pageerror',lambda e:errs.append(str(e)))
  page.set_content((ROOT/'NOVA-F15-11-Circle-Parts-Diagram.html').read_text(),wait_until='domcontentloaded',timeout=40000)
  page.wait_for_timeout(1000)
  check(f'{width} header',page.locator('#nova-header').count()==1)
  check(f'{width} has core',page.evaluate('typeof NOVA.bankMount')=='function')
  print('tabs',page.locator('.nova-tabs button').all_text_contents()[:10])
  print('details',page.locator('[data-mode]').evaluate_all('(x)=>x.slice(0,10).map(z=>[z.tagName,z.getAttribute("data-mode")])'))
  for mode in ['watch','guided','explore','challenge']:
   try:
    b=page.locator('.nova-tabs button').filter(has_text=mode.title()).first
    if b.count()>0:b.click(timeout=5000)
    else:page.get_by_role('button',name=mode.title(),exact=True).first.click(timeout=3000)
    page.wait_for_timeout(250)
    check(f'{width} {mode} svg',page.locator('#F15-11 svg.f1511-board').count()>0)
    page.screenshot(path=str(QA/f'{width}-{mode}.png'),full_page=True)
   except Exception as e: check(f'{width} {mode} navigation',False,str(e)[:250])
  check(f'{width} no page errors',not errs,str(errs[:3]))
  check(f'{width} original mascot inside stage',page.evaluate("document.querySelectorAll('#F15-11 .nova-stage .nv-dock').length")>=1)
  page.close()
 browser.close()
server.shutdown()
(QA/'smoke.json').write_text(json.dumps(results,indent=2))
print('TOTAL',sum(r['pass'] for r in results),'/',len(results))
