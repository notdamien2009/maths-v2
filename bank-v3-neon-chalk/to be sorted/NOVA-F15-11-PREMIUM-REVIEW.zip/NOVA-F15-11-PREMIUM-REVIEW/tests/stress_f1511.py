from pathlib import Path
from playwright.sync_api import sync_playwright
import json,math
ROOT=Path('/mnt/data'); QA=ROOT/'F15-11-QA';QA.mkdir(exist_ok=True)
HTML=(ROOT/'NOVA-F15-11-Circle-Parts-Diagram.html').read_text()
checks=[]
def check(label,result,detail=''):
 checks.append({'name':label,'pass':bool(result),'detail':str(detail)[:450]})
 if not result: print('FAIL',label,str(detail)[:350],flush=True)
def svgxy(page,x,y):
 return page.locator('#F15-11 svg.f1511-board').evaluate('(e,pt)=>{let p=e.createSVGPoint();p.x=pt[0];p.y=pt[1];let o=p.matrixTransform(e.getScreenCTM());return [o.x,o.y];}',[x,y])
def elemxy(locator):
 return locator.evaluate('e=>{let x=e.querySelector(".nv-hit")||e;let r=x.getBoundingClientRect();return [(r.left+r.right)/2,(r.top+r.bottom)/2];}')
def drag(page,source,dest):
 page.mouse.move(*source);page.mouse.down();page.mouse.move(*dest,steps=1);page.mouse.up();page.wait_for_timeout(160)
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in (380,1280):
  page=browser.new_page(viewport={'width':width,'height':1700},device_scale_factor=1,reduced_motion='reduce')
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(HTML,wait_until='domcontentloaded',timeout=35000);page.wait_for_timeout(450)
  card=page.locator('#F15-11');tabs=card.locator('.nova-tabs button')
  check(f'{width} core same style',page.evaluate('typeof NOVA.neonPath')=='function')
  check(f'{width} dock in stage',card.locator('.nova-stage .nv-dock').count()==1)
  check(f'{width} external helper portrait hidden',card.locator('.nova-bob .face').evaluate('(e)=>getComputedStyle(e).display')=='none')
  for mode in ['Watch','Guided','Explore','Challenge']:
   tabs.filter(has_text=mode).first.click();page.wait_for_timeout(110)
   check(f'{width} {mode} svg',card.locator('svg.f1511-board').count()==1)
  maths=page.evaluate('''()=>{let c=NOVA_F15_11_MATH,arr=[];for(let r of [3,4,5,6,8,9]){arr.push([r,'C',Math.abs(c.circumference(r)-2*Math.PI*r)<1e-8]);arr.push([r,'diam',Math.abs(c.circumference(r)/Math.PI-2*r)<1e-8]);for(let d of [30,60,90,120,170]){arr.push([r,d,'chord',Math.abs(c.chord(r,d)-2*r*Math.sin(d*Math.PI/360))<1e-8]);arr.push([r,d,'arc',Math.abs(c.arc(r,d)-2*Math.PI*r*d/360)<1e-8]);arr.push([r,d,'sector',Math.abs(c.sectorArea(r,d)-Math.PI*r*r*d/360)<1e-8]);}}return arr}''')
  for el in maths:check(f'{width} math '+str(el[:-1]),el[-1])
  tabs.filter(has_text='Explore').first.click();page.wait_for_timeout(150)
  c='NOVA_F15_11_CONFIG';state=lambda:page.evaluate(c+'._explore.state()')
  geom=lambda:page.evaluate('NOVA_F15_11_MATH.geometry('+c+'._explore.state())')
  check(f'{width} 3 draggable cards',card.locator('[data-label]').count()==3)
  check(f'{width} 2 draggable circle points',card.locator('[data-point]').count()==2)
  for preset in ['y8circ','y8diam','y9parts','y9tangent','y9reverse','extension','year8']:
   page.evaluate(f'(k)=>{c}._explore.select(k)',preset);page.wait_for_timeout(80)
   check(f'{width} preset {preset}',state()['radius']==page.evaluate(f'{c}.presets["{preset}"].radius'))
  # slider changes radius and circumference
  page.evaluate(c+'._explore.changeRadius(7.5)');page.wait_for_timeout(100)
  check(f'{width} mathematical radius changes',state()['radius']==7.5)
  check(f'{width} circumference recomputed',abs(page.evaluate('NOVA_F15_11_MATH.circumference('+c+'._explore.state().radius)')-15*math.pi)<1e-8)
  page.evaluate(c+'._explore.select("year8")');page.wait_for_timeout(130)
  # keyboard equivalent for points
  el=card.locator('[data-point="P"]');el.focus();page.keyboard.press('ArrowRight');page.wait_for_timeout(100)
  check(f'{width} point P keyboard',state()['theta']==35,str(state()['theta']))
  # keyboard label placement
  label=card.locator('[data-label="radius"]');label.focus();page.keyboard.press('Enter');page.wait_for_timeout(110)
  check(f'{width} radius keyboard place',bool(state()['placed'].get('radius')))
  # remove keyboard
  label=card.locator('[data-label="radius"]');label.focus();page.keyboard.press('Enter');page.wait_for_timeout(100)
  check(f'{width} radius keyboard remove',not bool(state()['placed'].get('radius')))
  # real fast mouse move P from 35 to 60
  point=card.locator('[data-point="P"]');point.scroll_into_view_if_needed();page.wait_for_timeout(100)
  drag(page,elemxy(point),svgxy(page,geom()['p'](60)['x'],geom()['p'](60)['y']) if False else svgxy(page,geom()['cx']+geom()['R']*math.cos(math.radians(60)),geom()['cy']-geom()['R']*math.sin(math.radians(60))))
  check(f'{width} point P fast mouse to 60°',state()['theta']==60,str(state()['theta']))
  # Q move to absolute 200 => delta 140
  q=card.locator('[data-point="Q"]');q.scroll_into_view_if_needed();page.wait_for_timeout(100);g=geom()
  drag(page,elemxy(q),svgxy(page,g['cx']+g['R']*math.cos(math.radians(200)),g['cy']-g['R']*math.sin(math.radians(200))))
  check(f'{width} point Q fast mouse to 200°',state()['delta']==140,str(state()['delta']))
  # cancellation P (no position applied)
  point=card.locator('[data-point="P"]');point.scroll_into_view_if_needed();page.wait_for_timeout(60);s=elemxy(point);previous=state()['theta']
  page.mouse.move(*s);page.mouse.down();page.mouse.move(s[0]+42,s[1]-24,steps=1);page.keyboard.press('Escape');page.mouse.up();page.wait_for_timeout(100)
  check(f'{width} Escape kept original angle',state()['theta']==previous)
  check(f'{width} Escape no active drag',page.evaluate('NOVA.ui._drag===null'))
  page.evaluate(c+'._explore.select("year8")');page.wait_for_timeout(120)
  # three correct drag targets
  for name in ['radius','chord','tangent']:
   el=card.locator(f'[data-label="{name}"]');el.scroll_into_view_if_needed();page.wait_for_timeout(80)
   g=geom();t=g[{'radius':'radiusTarget','chord':'chordTarget','tangent':'tangentTarget'}[name]]
   drag(page,elemxy(el),svgxy(page,t['x'],t['y']))
   check(f'{width} label {name} snap',bool(state()['placed'].get(name)),state().get('feedback'))
  # remove placed radius to red tray
  el=card.locator('[data-label="radius"]');el.scroll_into_view_if_needed();page.wait_for_timeout(90)
  g=geom();tx=13 if width==380 else 446; ty=611 if width==380 else 479
  drag(page,elemxy(el),svgxy(page,tx+45,ty+15))
  check(f'{width} radius label red remove',not state()['placed'].get('radius'),state()['feedback'])
  # wrong label drop should return
  page.evaluate(c+'._explore.select("year8")');page.wait_for_timeout(120)
  el=card.locator('[data-label="radius"]');el.scroll_into_view_if_needed();page.wait_for_timeout(90)
  g=geom();t=g['chordTarget'];drag(page,elemxy(el),svgxy(page,t['x'],t['y']))
  check(f'{width} incorrect feature rejected',not state()['placed'].get('radius'),state()['feedback'])
  check(f'{width} no stranded after invalid',page.evaluate('NOVA.ui._drag===null'))
  # direct challenge maths
  tabs.filter(has_text='Challenge').first.click();page.wait_for_timeout(150)
  res=page.evaluate('''()=>{let C=NOVA_F15_11_CONFIG;return C._challengeQuestions.flatMap(q=>{let yes=C._check(q,q.ans)[0];let no=C._check(q,q.kind==='vocab'?(q.ans==='Radius'?'Chord':'Radius'):q.ans+10)[0];return [[q.q,'correct',yes],[q.q,'incorrect',!no]];})}''')
  for q,kind,passed in res:check(f'{width} checked {kind}: {q}',passed)
  # real choice submission
  card.locator('.rs-opts button').filter(has_text='Radius').first.click();
  page.get_by_role('button',name='Check',exact=True).first.click();page.wait_for_timeout(400)
  check(f'{width} real challenge answer accepted', 'Correct: radius is the precise circle term' in page.locator('#F15-11').inner_text())
  check(f'{width} zero page errors',not errors,errors)
  page.close()
 browser.close()
QA.joinpath('stress.json').write_text(json.dumps({'checks':checks,'passed':sum(k['pass'] for k in checks),'total':len(checks)},indent=2))
print('STRESS RESULTS',sum(k['pass'] for k in checks),'/',len(checks))
print('FAILURES', [k for k in checks if not k['pass']][:20])
