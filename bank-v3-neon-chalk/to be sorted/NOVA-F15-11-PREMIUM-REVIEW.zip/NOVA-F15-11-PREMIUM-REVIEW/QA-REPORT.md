# NOVA Maths V2 — F15-11 Circle Parts Diagram · Review QA

**Status:** COMPLETE FOR REVIEW · NOT GOLD APPROVED · No repository modifications.

## Source integrity
- Exact specification: `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md` → **F15-11 Circle parts diagram**.
- Embedded canonical NOVA shared JS core copied byte-for-byte from the pre-existing `NOVA-F15-10-Special-Triangle-Values.html`: **verified equal**, 1,075,766 characters, SHA-256 `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc`.
- The original F0/F2 neon/chalk CSS, original tutor artwork, dock, palette, animated stage, controls and premium neon helpers remain embedded. New construction logic resides only in the F15-11 engine section.
- Self-contained HTML: no external network or third-party JavaScript required.

## QA summary — run on final HTML

| Suite | Passed | Total | Evidence |
|---|---:|---:|---|
| Browser render and modes | 16 | 16 | `tests/smoke.json`, `screenshots/380-*.png`, `screenshots/1280-*.png` |
| Maths, presets, pointer/keyboard interaction, Challenge | 322 | 322 | `tests/stress.json`, `tests/stress_f1511.py` |
| Timeline scrub, forward/back, all 16 states | 70 | 70 | `tests/timeline.json`, `screenshots/*-watch-16-stage.png` |
| **Total** | **408** | **408** | All pass |

### Specific verified behaviour
- Both **380px and 1280px**: WATCH, GUIDED, EXPLORE and CHALLENGE render; no page errors; exactly one original NOVA dock inside the learning stage. `tests/smoke.json`.
- All seven named presets load and recalculate their mathematical radius and circumference. `tests/stress.json`.
- Mathematical properties tested independently for radii 3, 4, 5, 6, 8, 9 and central angles 30°, 60°, 90°, 120°, 170°: circumference, chord length, minor arc length, sector area. `tests/stress.json`.
- Constrained circle point dragging P and Q tested with genuine **one-step fast mouse movement**, not keyboard-only simulation, at both widths. `tests/stress.json`.
- Three cards — Radius, Chord, Tangent — tested for correct mouse snap; invalid-zone refusal; re-grab to red removal tray; keyboard place/remove. `tests/stress.json`.
- Escape tested during pointer dragging; current geometric state retained and core drag cleaned up. `tests/stress.json`.
- Thirteen Challenge tasks: correct solutions and deliberately wrong answers checked using engine-specific `check` function, plus a real UI correct-answer submit. `tests/stress.json`.
- Sixteen WATCH states: each scrubbed, drawn and checked at both widths; step-forward and rewind checked. `tests/timeline.json`.

## Implementation references (standalone HTML line numbers)

| Item | Location |
|---|---|
| Preset configuration | line 1785 |
| Stable, circle-constrained geometry | line 1815 |
| Mathematical circumference | line 1821 |
| Arc length | line 1823 |
| Stage illustration through NOVA helpers | line 1856 |
| Label cards and geometric drop targets | line 1910 |
| Shared NOVA SVG drag helper | line 1732 |
| CHALLENGE definitions / misconception feedback | line 1962 |
| NOVA challenge wrapper | line 1517 |
| Original helper dock / narration | line 1458 |
| Existing NOVA engine mount | line 1526 |

## Teaching/content design
- 16 teaching states: circle → centre → radius → diameter → circumference → chord → arc → sector → segment → tangent → secant → doubled radius → π relationship → circumference → reverse circumference → generalisation.
- Real geometry is constructed using the canonical `NOVA.neonPath`, `NOVA.neonRing` for small markers only, `NOVA.neonBox` and `NOVA.chalkText`.
- Circle drawing scales visually only through established stage geometry; mathematical radius in centimetres is an independent variable. All circumference and arc values are computed, not hardcoded answers.
- Includes named Year 8, Year 9, and optional GCSE arc/sector extension presets.
- Challenge maths keeps the answers hidden until response; feedback specifically distinguishes sector/segment, tangent/secant, diameter/radius, circumference/area.

## Screenshot inventory
- `screenshots/1280-challenge.png`
- `screenshots/1280-explore.png`
- `screenshots/1280-guided.png`
- `screenshots/1280-watch-16-stage.png`
- `screenshots/1280-watch.png`
- `screenshots/1280-y9reverse-stage.png`
- `screenshots/1280-y9tangent-stage.png`
- `screenshots/380-challenge.png`
- `screenshots/380-explore.png`
- `screenshots/380-guided.png`
- `screenshots/380-watch-16-stage.png`
- `screenshots/380-watch.png`
- `screenshots/380-y9parts-stage.png`
- `screenshots/380-y9tangent-stage.png`


## Review caveat
Automated browser checks and screenshots cannot replace the owner's personal device review. This is **not** GOLD-approved; do not mark it GOLD until the owner signs it off.
