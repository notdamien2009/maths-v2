# NOVA F15-11 · Circle Parts Diagram — review build

Open `NOVA-F15-11-Circle-Parts-Diagram.html` in a modern browser.

**WATCH:** play, pause, 16-step teaching story, rewind and scrub.
**GUIDED:** scaffolded definition-by-definition teaching.
**EXPLORE:** drag points P and Q around the circle (or use sliders/keyboard), adjust mathematical radius, place correct geometric labels, return cards to tray.
**CHALLENGE:** 13 vocabulary, circumference, reverse-circumference, and minor-arc tasks with misconception feedback.

7 named curriculum presets for Y8-047, Y9-034, and optional GCSE.
Review status only. GitHub unchanged.
