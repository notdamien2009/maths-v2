# NOVA Maths F13-03 — Isometric Drawing Studio

**Premium-core review build**, based on the actual NOVA runtime, shell and helper art in the user's uploaded F12-03 source. Does **not** use the previously rejected standalone F13-03 design.

- Open `F13-03-Isometric-Drawing-PREMIUM-CORE.html` directly; everything is embedded and runs offline.
- Watch: nine interactive teaching scenes.
- Guided: advance through scaffolded prediction steps.
- Explore: select one of seven shapes; draw new cubes by tapping the gold tile, stack up to four, erase, inspect, undo/redo or clear. Use exact isometric dot grid; toggle pencil-edge/solid views.
- Challenge: draw a three-high tower, an adjacent row and a staircase. Exact cube counts **and locations** are checked.
- Keyboard: focus the drawing, arrows move the active tile, Enter builds, Delete removes.

The `source/` folder contains the unmodified NOVA F12-03 base file used to reproduce the inlined-core result, the new F13-03 engine and a portable local builder.
The `screenshots/` folder includes desktop/mobile reference evidence. `QA-REPORT.md` and `QA-RESULTS.json` record test coverage and results.

**Review only.** No GitHub changes made.
