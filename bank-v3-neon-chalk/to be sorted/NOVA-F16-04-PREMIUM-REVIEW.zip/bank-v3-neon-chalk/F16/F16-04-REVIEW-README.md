# F16-04 — Pie Chart Builder · Premium Review

This is a single-component review ZIP. It contains a self-contained offline HTML, teaching-specific source, deterministic build script, tests, QA report and screenshots. It does **not** alter GitHub or replace any F0/F2 files.

**Open:** `F16/F16-04-pie-chart-builder.html`.

**Teaching:** Watch (nine steps), Guided (nine scaffolded steps), Explore (move circular sector boundaries, select categories, change frequencies and reset), Challenge (correct the frequency, calculate a sector angle, identify one fifth).

**Presets:** Y7-067 clubs, travel to school and lunch choices. In all contexts 20 responses fill the 360 degree chart. Boundaries snap to whole-response increments (18 degrees per response).

**Rebuild:** In the existing `bank-v3-neon-chalk/` repository folder, run `python3 build/build-f16-04.py`. It reads the canonical `F2/F2-03-base-ten-blocks.html`, checks the embedded runtime SHA-256, then inlines the unchanged shared core and F16-04 source into the standalone HTML. It stops if the locked core has drifted. No network or external libraries are used.

**QA:** Run `python3 tests/stress.py` and `python3 tests/preset_regression.py` with local Chromium and Playwright installed. See `F16/F16-04-QA.md` and `tests/results.json`. Screenshots are under `shots/F16-04/`.

**Status:** Review only, NOT GOLD-approved. Real-device touch feel, non-reduced-motion visuals and print output remain owner acceptance checks.
