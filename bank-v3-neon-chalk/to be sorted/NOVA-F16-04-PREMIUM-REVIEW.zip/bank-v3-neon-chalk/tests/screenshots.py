from playwright.sync_api import sync_playwright
from pathlib import Path
P=Path(__file__).resolve().parents[1];html=(P/'F16/F16-04-pie-chart-builder.html' if (P/'F16/F16-04-pie-chart-builder.html').exists() else P/'output/F16-04-pie-chart-builder.html').read_text();D=P/'shots'/'F16-04' if (P/'shots'/'F16-04').is_dir() else P/'shots'
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in (380,1280):
  pg=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce')
  pg.set_content(html,wait_until='load',timeout=90000)
  for mode in ('watch','guided','explore','challenge'):
   pg.locator(f'.nova-tab[data-m="{mode}"]').click();pg.wait_for_timeout(90)
   if mode=='watch':pg.evaluate("()=>{F16_04.timeline.pause();F16_04.timeline.go(8,'screenshot')}")
   pg.screenshot(path=str(D/f'F16-04-{width}-{mode}.png'),full_page=True,animations='disabled')
  pg.locator('.nova-tab[data-m="watch"]').click();pg.evaluate("()=>{F16_04.timeline.pause();F16_04.timeline.go(0,'screenshot')}");pg.screenshot(path=str(D/f'F16-04-{width}-watch-data.png'),full_page=True,animations='disabled')
  pg.evaluate("()=>{F16_04.timeline.pause();F16_04.timeline.go(5,'screenshot')}");pg.screenshot(path=str(D/f'F16-04-{width}-watch-three-sectors.png'),full_page=True,animations='disabled')
  pg.locator('.nova-tab[data-m="guided"]').click();pg.evaluate("()=>{F16_04.timeline.pause();F16_04.timeline.go(6,'screenshot')}");pg.screenshot(path=str(D/f'F16-04-{width}-guided-complete.png'),full_page=True,animations='disabled')
  pg.locator('.nova-tab[data-m="explore"]').click()
  pg.locator('select[aria-label="Dataset"]').select_option('travel');pg.screenshot(path=str(D/f'F16-04-{width}-travel.png'),full_page=True,animations='disabled')
  pg.locator('select[aria-label="Dataset"]').select_option('lunch');pg.screenshot(path=str(D/f'F16-04-{width}-lunch.png'),full_page=True,animations='disabled')
  pg.locator('select[aria-label="Dataset"]').select_option('clubs')
  pg.locator('select[aria-label="Selected sector"]').select_option('3');pg.locator('input[aria-label="Set selected sector frequency"]').fill('3');pg.get_by_role('button',name='Set frequency').click()
  pg.screenshot(path=str(D/f'F16-04-{width}-redistributed.png'),full_page=True,animations='disabled')
  pg.locator('.nova-tab[data-m="challenge"]').click()
  pg.locator('input[aria-label="Set corrected Art frequency"]').fill('6');pg.get_by_role('button',name='Set corrected frequency').click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(900)
  pg.locator('input[aria-label="Sector angle in degrees"]').fill('108');pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(950)
  pg.locator('.rs-opts button').nth(2).click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(150)
  pg.screenshot(path=str(D/f'F16-04-{width}-challenge-solved.png'),full_page=True,animations='disabled')
  pg.close()
 b.close()
print('screenshots',len(list(D.glob('*.png'))))
