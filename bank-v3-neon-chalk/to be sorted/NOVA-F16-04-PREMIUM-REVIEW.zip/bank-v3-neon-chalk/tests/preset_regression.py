from playwright.sync_api import sync_playwright
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];html=(R/'F16/F16-04-pie-chart-builder.html' if (R/'F16/F16-04-pie-chart-builder.html').exists() else R/'output/F16-04-pie-chart-builder.html').read_text()
out=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in (380,1280):
  pg=b.new_page(viewport={'width':width,'height':900},reduced_motion='reduce')
  pg.set_content(html,wait_until='load',timeout=90000)
  for preset in ('clubs','travel','lunch'):
   pg.locator('.nova-tab[data-m="explore"]').click();pg.locator('select[aria-label="Dataset"]').select_option(preset)
   d=pg.evaluate(f'NOVA_F16_04_CONFIG.presets.{preset}')
   pg.locator('.nova-tab[data-m="challenge"]').click()
   expected=d['counts'][1];pg.locator('input[aria-label="Set corrected Art frequency"]').fill(str(expected));pg.get_by_role('button',name='Set corrected frequency').click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(950)
   correct1=pg.locator('.pr-task').inner_text().startswith('A complete circle')
   angle=expected*18
   pg.locator('input[aria-label="Sector angle in degrees"]').fill(str(angle));pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(950)
   correct2=pg.locator('.pr-task').inner_text().startswith('Which category represents exactly')
   right=d['counts'].index(4)
   pg.locator('.rs-opts button').nth(right).click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(190)
   correct3=pg.locator('.nova-fb.ok').count()>0
   out.append({'width':width,'preset':preset,'challenge1':correct1,'angle':angle,'challenge2':correct2,'challenge3':correct3})
   print(width,preset,correct1,correct2,correct3)
  pg.close()
 b.close()
(R/'tests/preset-results.json').write_text(json.dumps(out,indent=2))
assert all(r[k] for r in out for k in ('challenge1','challenge2','challenge3'))
print('PRESETS',len(out)*3,'of',len(out)*3,'challenge stage checks passed')
