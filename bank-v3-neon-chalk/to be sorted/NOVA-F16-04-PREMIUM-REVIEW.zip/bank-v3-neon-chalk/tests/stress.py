from playwright.sync_api import sync_playwright
from pathlib import Path
import json,math
P=Path(__file__).resolve().parents[1];HTML=(P/'F16/F16-04-pie-chart-builder.html' if (P/'F16/F16-04-pie-chart-builder.html').exists() else P/'output/F16-04-pie-chart-builder.html').read_text()
results=[];browsers=[]
def t(name,test,detail=''):
 ok=bool(test);results.append(dict(name=name,passed=ok,detail=str(detail)));print(('PASS' if ok else 'FAIL'),name,detail,flush=True)
def state(pg):return pg.evaluate('NOVA_F16_04_CONFIG._explore.get()')
def point(pg,idx,value=None):
 return pg.evaluate('''({idx,value})=>{const C=NOVA_F16_04_CONFIG,p=C.presets[C.preset],st=C._explore.get();let m=innerWidth<=540;let cx=m?225:267,cy=m?301:327,r=m?174:185;let cs=st.counts.slice();if(value!==null)cs[idx]=value;let sum=0;for(let k=0;k<=idx;k++)sum+=cs[k];let deg=sum*360/20-90;let rad=deg*Math.PI/180;let sv=document.querySelector('.f16p-plot');let pt=sv.createSVGPoint();pt.x=cx+r*Math.cos(rad);pt.y=cy+r*Math.sin(rad);let z=pt.matrixTransform(sv.getScreenCTM());return {x:z.x,y:z.y};}''',dict(idx=idx,value=value))
def drag(pg,idx,n,steps=10):
 pg.locator('.f16p-plot').scroll_into_view_if_needed();src=point(pg,idx);dst=point(pg,idx,n)
 pg.mouse.move(src['x'],src['y']);pg.mouse.down();pg.mouse.move(dst['x'],dst['y'],steps=steps);pg.mouse.up();pg.wait_for_timeout(460)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  pg=browser.new_page(viewport=dict(width=width,height=900),reduced_motion='reduce');errors=[]
  pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(HTML,wait_until='load',timeout=90000);pg.wait_for_timeout(110)
  for mode in ['watch','guided','explore','challenge']:
   pg.locator(f'.nova-tab[data-m="{mode}"]').click();pg.wait_for_timeout(100)
   t(f'{width} {mode} SVG',pg.locator('.f16p-plot').count()==1)
   t(f'{width} {mode} single dock',pg.locator('.nova-stage .nv-dock').count()==1)
   t(f'{width} {mode} no body overflow',pg.evaluate('document.documentElement.scrollWidth<=innerWidth+2'))
   t(f'{width} {mode} F0 core active',pg.evaluate("typeof NOVA.neonPath==='function' && typeof NOVA.ui.svgDrag==='function' && typeof NOVA.scene.helperStrip==='function'"))
  pg.locator('.nova-tab[data-m="watch"]').click();pg.wait_for_timeout(110)
  for i,expect in enumerate([0,0,0,1,2,3,4,4,4]):
   pg.evaluate("i=>{window.F16_04.timeline.pause();window.F16_04.timeline.go(i,'test')}",i);pg.wait_for_timeout(80)
   t(f'{width} Watch step {i} wedge count',pg.locator('.f16p-plot [data-sector]').count()==expect,pg.locator('.f16p-plot [data-sector]').count())
  pg.locator('.nova-tab[data-m="explore"]').click();pg.wait_for_timeout(100)
  for preset in ['clubs','travel','lunch']:
   pg.locator('select[aria-label="Dataset"]').select_option(preset);pg.wait_for_timeout(90)
   p=pg.evaluate(f'NOVA_F16_04_CONFIG.presets.{preset}');s=state(pg);t(f'{width} {preset} frequencies exact',s['counts']==p['counts'])
   t(f'{width} {preset} total 20',s['total']==20)
   t(f'{width} {preset} 360 deg',sum(n*360/s['total'] for n in s['counts'])==360)
   t(f'{width} {preset} all percentages 100%',abs(sum(n*100/s['total'] for n in s['counts'])-100)<1e-6)
   t(f'{width} {preset} three handles',pg.locator('.f16p-plot [data-boundary]').count()==3)
   t(f'{width} {preset} valid arc geometry',pg.evaluate("[...document.querySelectorAll('.f16p-plot [data-sector]')].every((e)=>e.querySelectorAll('path[d]').length>=1)"))
  pg.locator('select[aria-label="Dataset"]').select_option('clubs');pg.wait_for_timeout(90)
  drag(pg,0,7,14)
  t(f'{width} actual pointer boundary 8→7',state(pg)['counts'][:2]==[7,7],state(pg)['counts'])
  t(f'{width} drag conserves 20',state(pg)['total']==20)
  drag(pg,0,8,1)
  t(f'{width} fast one-move pointer 7→8',state(pg)['counts'][:2]==[8,6],state(pg)['counts'])
  t(f'{width} no stranded pointer',pg.evaluate('NOVA.ui._drag===null'))
  # An off-sector drop does not mutate the data.
  pg.locator('.f16p-plot').scroll_into_view_if_needed();src=point(pg,0);old=state(pg)['counts']
  pg.mouse.move(src['x'],src['y']);pg.mouse.down();pg.mouse.move(src['x']-130,src['y']-170,steps=3);pg.mouse.up();pg.wait_for_timeout(440)
  t(f'{width} invalid drop springs back',state(pg)['counts']==old)
  # Escape recovers the drag and no frequency change.
  src=point(pg,0);pg.mouse.move(src['x'],src['y']);pg.mouse.down();pg.mouse.move(src['x']+30,src['y']+35,steps=4);pg.keyboard.press('Escape');pg.mouse.up();pg.wait_for_timeout(450)
  t(f'{width} Escape clears pointer',pg.evaluate('NOVA.ui._drag===null'))
  t(f'{width} Escape preserves frequencies',state(pg)['counts']==old)
  pg.locator('[data-boundary="0"]').focus();pg.keyboard.press('ArrowLeft');pg.wait_for_timeout(115)
  t(f'{width} keyboard boundary moves',state(pg)['counts'][:2]==[7,7],state(pg)['counts'])
  pg.get_by_role('button',name='Restore original').click()
  t(f'{width} restores original',state(pg)['counts']==[8,6,4,2])
  pg.locator('select[aria-label="Selected sector"]').select_option('3')
  pg.locator('input[aria-label="Set selected sector frequency"]').fill('3')
  pg.get_by_role('button',name='Set frequency').click()
  t(f'{width} selected last sector transfers frequencies',state(pg)['counts']==[8,6,3,3],state(pg)['counts'])
  pg.get_by_role('button',name='Restore original').click()
  t(f'{width} reset after numeric change',state(pg)['counts']==[8,6,4,2])
  # Test red reset target with mouse drag.
  pg.locator('.f16p-plot').scroll_into_view_if_needed()
  src=point(pg,0);dst=pg.evaluate('''()=>{const m=innerWidth<=540,sv=document.querySelector('.f16p-plot'),pt=sv.createSVGPoint();pt.x=m?225:625;pt.y=m?725:619;let z=pt.matrixTransform(sv.getScreenCTM());return {x:z.x,y:z.y}}''')
  pg.mouse.move(src['x'],src['y']);pg.mouse.down();pg.mouse.move(dst['x'],dst['y'],steps=9);pg.mouse.up();pg.wait_for_timeout(480)
  t(f'{width} red reset accepts handle',state(pg)['counts']==[8,6,4,2])
  # Challenge tests: first wrong, then exact fix; then angle and one-fifth reasoning.
  pg.locator('.nova-tab[data-m="challenge"]').click();pg.wait_for_timeout(110)
  pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(130)
  t(f'{width} challenge detects wrong sector',pg.locator('.nova-fb.bad').count()>0)
  pg.locator('input[aria-label="Set corrected Art frequency"]').fill('6')
  pg.get_by_role('button',name='Set corrected frequency').click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(1040)
  t(f'{width} correct boundary advances',pg.locator('.pr-task').inner_text().startswith('A complete circle is 360'))
  pg.locator('input[aria-label="Sector angle in degrees"]').fill('30')
  pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(160)
  t(f'{width} percentage vs degrees detected',pg.locator('.nova-fb.bad').count()>0)
  pg.locator('input[aria-label="Sector angle in degrees"]').fill('108')
  pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(1020)
  t(f'{width} 108 degrees accepted',pg.locator('.pr-task').inner_text().startswith('Which category represents exactly'))
  pg.locator('.rs-opts button').first.click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(160)
  t(f'{width} wrong fifth detected',pg.locator('.nova-fb.bad').count()>0)
  pg.locator('.rs-opts button').nth(2).click();pg.get_by_role('button',name='Check',exact=True).click();pg.wait_for_timeout(210)
  t(f'{width} correct 20% category accepted',pg.locator('.nova-fb.ok').count()>0)
  t(f'{width} zero browser exceptions',not errors,errors)
  pg.close()
 browser.close()
(P/'tests/results.json').write_text(json.dumps({'passed':sum(r['passed'] for r in results),'total':len(results),'failed':[r for r in results if not r['passed']],'tests':results},indent=2))
print('RESULT',sum(r['passed'] for r in results),'/',len(results),'failed',len([x for x in results if not x['passed']]))
