# NOVA Maths F14-11 — Similar Shapes | Review QA

**Status:** review candidate, owner approval outstanding. **GitHub:** untouched.

## Source and design
- Built from the exact premium F14-10 standalone shell, which embeds the same NOVA core v3 / CSS / NOVA Chalk and image-based mascot as the supplied premium F0 and F2 examples.
- Single mascot dock inside stage; geometry grid and drawings are core NOVA.svg.grid, NOVA.neonPath, NOVA.neonRing and NOVA.chalkText.
- Four modes: Watch / Guided / Explore / Challenge. Six named teaching stages.
- Premium background, no additional horizontal teaching row, mobile and desktop layouts.

## Maths purpose and evidence
- Similarity requires a single matching side ratio AND equal corresponding angles. The code independently checks both, with tolerance 0.003.
- Positive linear scale factors include 0.5, 1.5, 2, 2.5 and 3. Turning and flipping preserves similarity.
- Contrasting rectangles show that equal angles alone need not establish similarity when length ratios differ.
- Ratio applications: corresponding sides; reduction; area factor k²; volume factor k³ for similar solids.
- Lesson presets: Y7 enlargement/maps, Y8 enlargement/similarity, Y9 maps/density connection/reasoning/trig/extension; plus built-in F6-13 proportion in geometry and F15-05 similar triangles.
- Challenge: nine tasks, including the final interactive scale-handle question.

## Browser tests
- Standard browser and maths regression: **158 / 158 passed**, **0 failed**.
- Real-pointer and cancel stress: **20 / 20 passed**, **0 failed**.
- Additional manual browser sequence: all six Guided stages at 380px and 1280px rendered without JavaScript errors.
- Viewports: **380 × 900/1000** and **1280 × 900/1000**. No horizontal overflow; exactly one mascot dock inside the stage in every mode. 
- Pointer interaction: image and gold scale-handle real drag, in-stage drop, target snapping, no stranded active drag, Escape recovery. Both handles have arrow-key equivalents.

## Visual samples
- 8 mode screenshots: Watch / Guided / Explore / Challenge at 380px and 1280px.
- 4 additional screenshots for the F15-05 similar-triangle preset and non-similar rectangle counterexample at each width.

## Review boundary
- This is a standalone demonstration of the visual engine, not an integrated NOVA Academy lesson. Owner must visually stress-test and approve before marking GOLD.
