from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib
ROOT=Path('/mnt/data/f13_04_premium');SHOTS=ROOT/'screenshots';SHOTS.mkdir(exist_ok=True)
S=Path('/mnt/data/F13-04-Plans-and-Elevations-PREMIUM-CORE.html').read_text()
BASE=Path('/mnt/data/F12-03-geoboard-builder(1).html').read_text()
RESULTS=[]
def check(name,v):
 ok=bool(v);RESULTS.append({'check':name,'passed':ok});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
original_core=BASE.split('<script>')[1].split('</script>')[0]
new_core=S.split('<script>')[1].split('</script>')[0]
check('Official inline NOVA core unchanged byte-for-byte',original_core==new_core)
check('Official stage + chalk font CSS retained',S.split('<style>',1)[1].startswith(BASE.split('<style>',1)[1].split('</style>',1)[0]))
with sync_playwright() as pw:
 b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server'])
 for width in (1280,380):
  pg=b.new_page(viewport={'width':width,'height':980},device_scale_factor=1)
  errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.set_content(S,wait_until='domcontentloaded',timeout=60000)
  pg.evaluate('NOVA.engines["F13-04"].timeline.pause()')
  prefix=f'{width}px'
  check(prefix+' official NOVA neon & chalk primitives',pg.evaluate('!!(NOVA.neonPath&&NOVA.chalkText&&NOVA.f12&&NOVA.scene.helperStrip)'))
  check(prefix+' official mascot embed',pg.evaluate('NOVA.helperImg("explain").src.startsWith("data:image/webp")'))
  check(prefix+' embedded chalk font',pg.evaluate('document.fonts.check("16px NOVA Chalk")'))
  check(prefix+' one in-stage mascot and bubble',pg.locator('.nova-stage .nv-dockfig').count()==1 and pg.locator('.nova-stage .nv-dockbub').count()==1)
  check(prefix+' stage visual background and SVG',pg.locator('.nova-stage .f13-pe-svg').count()==1 and pg.evaluate('getComputedStyle(document.querySelector(".nova-stage")).backgroundImage!=="none"'))
  check(prefix+' zero page horizontal overflow',pg.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
  check(prefix+' all 3 orthographic panels exist',pg.locator('.f13-pe-card').count()==3)
  for n in range(9):
   pg.evaluate('(i)=>NOVA.engines["F13-04"].timeline.go(i,"QA")',n)
   check(f'{prefix} Watch beat {n+1}',pg.locator('.f13-pe-svg').count()==1 and pg.locator('.nova-stage .nv-dockfig').count()==1 and pg.locator('.f13-pe-card').count()==3)
  pg.evaluate('NOVA.engines["F13-04"].timeline.go(6,"QA")')
  pg.locator('.nova-stage').screenshot(path=str(SHOTS/f'{width}-watch.png'),animations='disabled',timeout=60000)
  pg.get_by_role('tab',name='Guided').first.click()
  check(prefix+' guided text',pg.locator('.nova-fb.hint').count()>0 and pg.locator('.f13-pe-svg').count()==1)
  pg.get_by_role('tab',name='Explore').first.click()
  check(prefix+' explorer tool controls',pg.get_by_role('button',name='＋ Add unit cube').count()==1 and pg.get_by_role('button',name='− Remove top cube').count()==1)
  check(prefix+' 3 projections visible',pg.locator('.f13-pe-card').count()==3)
  ex='NOVA_F13_04_CONFIG._explore.state'
  expected={'single':(1,1,1),'row':(2,2,1),'platform':(4,4,1),'tower':(2,1,2),'corner':(4,3,2),'stairs':(6,3,3),'bridge':(6,4,2),'hidden':(6,4,2)}
  for preset,(total,area,tall) in expected.items():
   pg.locator('select[aria-label="Choose a 3D construction"]').select_option(preset)
   props=pg.evaluate('''() => {let g=NOVA_F13_04_CONFIG._explore.state.grid;return [g.flat().reduce((a,b)=>a+b,0),g.flat().filter(Boolean).length,Math.max(...g.flat())]}''')
   check(prefix+' preset '+preset+' correct cubes/top cells/height',props==[total,area,tall])
   check(prefix+' preset '+preset+' has neon cube faces',pg.locator('.f13-iso-face').count()>0)
   if width==1280 and preset in ['single','platform','tower','corner','stairs','hidden']:
    pg.locator('.nova-stage').screenshot(path=str(SHOTS/f'{width}-{preset}.png'),animations='disabled',timeout=60000)
  pg.locator('select[aria-label="Choose a 3D construction"]').select_option('single')
  # Convert SVG top plan cell centre to real screen point to verify pointer input.
  svg=pg.locator('.f13-pe-svg');svg.scroll_into_view_if_needed()
  def plan_cell(x,y):
   hit=pg.evaluate('NOVA_F13_04_CONFIG._explore.state._svg.f13ViewHit.top')
   bounds=svg.bounding_box()
   W=420 if width==380 else 780
   a=hit['x']+(x+.5)*hit['size'];cc=hit['y']+(y+.5)*hit['size']
   return (bounds['x']+a*bounds['width']/W,bounds['y']+cc*bounds['width']/W)
  px,py=plan_cell(1,1);pg.mouse.click(px,py)
  check(prefix+' real plan pointer places second cube',pg.evaluate('NOVA_F13_04_CONFIG._explore.state.grid[1][1]')==2) # preset single starts at level 1
  check(prefix+' live counter updates',pg.locator('.f12-strip .nv-ntile .mt').first.inner_text()=='2')
  pg.get_by_role('button',name='↶ Undo').click();check(prefix+' undo restores cube',pg.evaluate('NOVA_F13_04_CONFIG._explore.state.grid[1][1]')==1)
  pg.get_by_role('button',name='↷ Redo').click();check(prefix+' redo restores second stack cube',pg.evaluate('NOVA_F13_04_CONFIG._explore.state.grid[1][1]')==2)
  pg.get_by_role('button',name='− Remove top cube').click();svg.scroll_into_view_if_needed();px,py=plan_cell(1,1);pg.mouse.click(px,py)
  check(prefix+' remove top cube click',pg.evaluate('NOVA_F13_04_CONFIG._explore.state.grid[1][1]')==1)
  pg.get_by_role('button',name='＋ Add unit cube').click();pg.get_by_role('button',name='Clear',exact=True).click()
  # Test rapid move across all four neighbouring top plan cells on one held pointer.
  svg=pg.locator('.f13-pe-svg');svg.scroll_into_view_if_needed();a=plan_cell(0,2);z=plan_cell(3,2)
  pg.mouse.move(*a);pg.mouse.down()
  for t in range(18):pg.mouse.move(a[0]+(z[0]-a[0])*t/17,a[1]+(z[1]-a[1])*t/17)
  pg.mouse.up();pg.wait_for_timeout(100)
  check(prefix+' fast drag paints 3+ neighbouring plan cells',pg.evaluate('NOVA_F13_04_CONFIG._explore.state.grid.flat().filter(Boolean).length')>=3)
  check(prefix+' fast drag releases pointer capture',pg.evaluate('!NOVA_F13_04_CONFIG._explore.state.drag'))
  pg.get_by_role('button',name='Clear',exact=True).click()
  svg=pg.locator('.f13-pe-svg');svg.focus();pg.keyboard.press('Enter')
  check(prefix+' keyboard enter adds a cube',pg.evaluate('NOVA_F13_04_CONFIG._explore.state.grid[1][1]')==1)
  pg.keyboard.press('ArrowRight');pg.keyboard.press('Enter')
  check(prefix+' keyboard navigation moves to adjacent plan cell',pg.evaluate('NOVA_F13_04_CONFIG._explore.state.grid[2][1]')==1)
  pg.keyboard.press('Delete');check(prefix+' keyboard delete removes top cube',pg.evaluate('NOVA_F13_04_CONFIG._explore.state.grid[2][1]')==0)
  for name,key in [('Number each stack','showHeights'),('Show top plan','top'),('Show front','front'),('Show right side','side')]:
   inp=pg.locator('input[aria-label="'+name+'"]')
   if inp.is_checked():inp.uncheck()
   else:inp.check()
   state=pg.evaluate('(k)=>k==="showHeights"?NOVA_F13_04_CONFIG._explore.state.showHeights:NOVA_F13_04_CONFIG._explore.state.showViews[k]',key)
   check(prefix+' '+name+' interactive toggle',state==inp.is_checked())
  # Restore toggles for screenshot.
  for name in ['Show top plan','Show front','Show right side']:pg.locator('input[aria-label="'+name+'"]').check()
  pg.locator('select[aria-label="Choose a 3D construction"]').select_option('corner')
  pg.locator('.nova-stage').screenshot(path=str(SHOTS/f'{width}-explore.png'),animations='disabled',timeout=60000)
  pg.get_by_role('tab',name='Challenge').first.click()
  ch='NOVA_F13_04_CONFIG._challenge'
  check(prefix+' challenge begins at 0 cubes',pg.evaluate(ch+'.state.grid.flat().reduce((a,b)=>a+b,0)')==0)
  check(prefix+' challenge shows target projections',pg.evaluate(ch+'.state.view')=='target' and pg.locator('.f13-pe-card').count()==3)
  pg.get_by_role('button',name='Check all three views').click()
  check(prefix+' challenge missing top plan misconception',pg.locator('.nova-fb.bad').count()==1 and 'top plan' in pg.locator('.nova-fb.bad').inner_text())
  # Build first target by real plan clicks.
  sv=pg.locator('.f13-pe-svg');sv.scroll_into_view_if_needed();hit=pg.evaluate(ch+'.state._svg.f13ViewHit.top');bb=sv.bounding_box();W=420 if width==380 else 780
  def challcell(x,y):
   return (bb['x']+(hit['x']+(x+.5)*hit['size'])*bb['width']/W,bb['y']+(hit['y']+(y+.5)*hit['size'])*bb['width']/W)
  pg.mouse.click(*challcell(1,2));pg.mouse.click(*challcell(2,2))
  check(prefix+' challenge 1 built with two real taps',pg.evaluate(ch+'.check()'))
  pg.get_by_role('button',name='Check all three views').click()
  check(prefix+' challenge 1 correct',pg.locator('.nova-fb.ok').count()==1)
  pg.wait_for_timeout(1200);check(prefix+' challenge advances to task 2',pg.evaluate(ch+'.task()')==1)
  # Build tower via two clicks.
  sv.scroll_into_view_if_needed();bb=sv.bounding_box();hit=pg.evaluate(ch+'.state._svg.f13ViewHit.top');pg.mouse.click(*challcell(1,2));pg.mouse.click(*challcell(1,2))
  check(prefix+' tower reconstructed from top/front/side',pg.evaluate(ch+'.check()'))
  pg.get_by_role('button',name='Check all three views').click();pg.wait_for_timeout(1200)
  check(prefix+' challenge advances to final task',pg.evaluate(ch+'.task()')==2)
  # Alternative arrangement with same plan, front and side silhouettes must pass.
  pg.evaluate('''() => {let s=NOVA_F13_04_CONFIG._challenge.state;s.grid=[[0,0,0,0],[0,1,2,0],[0,2,1,0],[0,0,0,0]];s._svg.f13Draw()}''')
  check(prefix+' mathematically valid non-unique solution accepted',pg.evaluate(ch+'.check()'))
  pg.get_by_role('button',name='Check all three views').click()
  check(prefix+' final problem correct feedback',pg.locator('.nova-fb.ok').count()==1)
  pg.locator('.nova-stage').screenshot(path=str(SHOTS/f'{width}-challenge.png'),animations='disabled',timeout=60000)
  # Cancel during drag and switch modes.
  pg.get_by_role('tab',name='Explore').click();pg.get_by_role('tab',name='Watch').click();pg.evaluate('NOVA.engines["F13-04"].timeline.pause()')
  check(prefix+' mode switching retains single official mascot',pg.locator('.nova-stage .nv-dockfig').count()==1)
  check(prefix+' no uncaught JavaScript exceptions',not errors)
  check(prefix+' no final horizontal overflow',pg.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
  if errors:print('ERRORS',width,errors[:4],flush=True)
  pg.close()
 b.close()
passed=sum(r['passed'] for r in RESULTS)
(ROOT/'QA-RESULTS.json').write_text(json.dumps({'passed':passed,'total':len(RESULTS),'checks':RESULTS},indent=2))
print(f'FINAL {passed}/{len(RESULTS)}',flush=True)
