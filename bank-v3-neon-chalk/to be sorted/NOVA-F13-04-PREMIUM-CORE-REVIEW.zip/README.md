# NOVA F13-04 — Plans and Elevations · Premium Core Review

Open `F13-04-Plans-and-Elevations-PREMIUM-CORE.html` in a browser. Nothing else is needed at runtime; fonts, code, colours and official mascot artwork are embedded.

Modes: Watch (nine teaching steps), Guided (predict/reveal), Explore (build and compare orthographic views), Challenge (construct from three target views; three progressive tasks).

Use Explore controls or tap the TOP PLAN to add a cube, use Remove top cube to subtract, or drag across squares. On focused drawing use arrows to move the selection, Enter to add, Delete to remove.

Rebuild: `cd source` then `python build.py`. The approved F12-03 source shell, F13-04 engine source, and builder are included.

See `QA-REPORT.md` and `QA-RESULTS.json` for test evidence. This is a review build; do not overwrite approved sources until visually accepted. No GitHub update performed.
