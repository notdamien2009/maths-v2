from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1];ht=(R/'F16/F16-07-mean-explorer.html').read_text();evidence=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for w in [380,1280]:
  p=b.new_page(viewport={'width':w,'height':950},reduced_motion='reduce');errors=[];p.on('pageerror',lambda x:errors.append(str(x)));p.set_content(ht,wait_until='load');p.wait_for_timeout(100)
  for key in ['y7-fair-share','y8-grouped']:
   p.locator('.nova-tab[data-m="explore"]').click();p.locator('select[aria-label="Lesson"]').select_option(key);p.wait_for_timeout(100)
   for mode in ['watch','guided','explore','challenge']:
    p.locator(f'.nova-tab[data-m="{mode}"]').click();p.wait_for_timeout(100)
    if mode=='watch':p.evaluate('F16_07.timeline.pause();F16_07.timeline.go(7,"screenshot")');p.wait_for_timeout(70)
    name=f'F16-07-{w}-{key}-{mode}.png';p.screenshot(path=str(R/'shots'/name),full_page=True,animations='disabled')
    metric=p.evaluate('''()=>{let s=document.querySelector('.nova-stage'),v=s.querySelector('.f167-svg'),f=s.querySelector('.nv-dock');return {sceneHeight:v.getBoundingClientRect().height,stageHeight:s.getBoundingClientRect().height,helper:!!f,svgLabels:Array.from(v.querySelectorAll('text')).length,overflow:document.documentElement.scrollWidth-innerWidth,core:!!NOVA.ui.svgDrag}}''')
    evidence.append({'shot':name,**metric,'errors':errors[:]})
   if key=='y7-fair-share':
    p.locator('.nova-tab[data-m="watch"]').click()
    for i in (0,1,5,6):
     p.evaluate('i=>{F16_07.timeline.pause();F16_07.timeline.go(i,"screenshot")}',i);p.wait_for_timeout(80)
     name=f'F16-07-{w}-y7-watch-step{i}.png';p.screenshot(path=str(R/'shots'/name),full_page=True,animations='disabled');evidence.append({'shot':name,'watch_step':i,'errors':errors[:]})
   else:
    p.locator('.nova-tab[data-m="watch"]').click()
    for i in (0,1,2,5):
     p.evaluate('i=>{F16_07.timeline.pause();F16_07.timeline.go(i,"screenshot")}',i);p.wait_for_timeout(80)
     name=f'F16-07-{w}-y8-watch-step{i}.png';p.screenshot(path=str(R/'shots'/name),full_page=True,animations='disabled');evidence.append({'shot':name,'watch_step':i,'errors':errors[:]})
  p.close()
 b.close()
(R/'tests/VISUAL-RESULTS.json').write_text(json.dumps(evidence,indent=2))
print('captured',len(evidence),'with',sum(bool(e['errors']) for e in evidence),'console errors')
print('mobile ratios',[round(e['sceneHeight']/e['stageHeight'],3) for e in evidence if 'sceneHeight' in e and e['shot'].startswith('F16-07-380-')])
