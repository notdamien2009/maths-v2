"""F16-07 live Playwright maths, native mouse, keyboard and mode checks. Audit JSON records only actual assertions."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,math,sys
R=Path(__file__).resolve().parents[1];HTML=(R/'F16/F16-07-mean-explorer.html').read_text()
checks=[]
def check(name,ok,detail=''):
 checks.append({'test':name,'pass':bool(ok),'detail':str(detail)[:260]})
 print(('PASS' if ok else 'FAIL'),name,str(detail)[:140],flush=True)
def svgpt(p,x,y):return p.evaluate('''v=>{let e=document.querySelector('.f167-svg'),z=e.createSVGPoint();z.x=v[0];z.y=v[1];let pt=z.matrixTransform(e.getScreenCTM());return {x:pt.x,y:pt.y};}''',[x,y])
def native_drag(p,selector,x,y,steps=1):
 el=p.locator(selector).first;el.scroll_into_view_if_needed();p.wait_for_timeout(110);r=el.bounding_box();assert r;z=svgpt(p,x,y)
 p.mouse.move(r['x']+r['width']/2,r['y']+r['height']/2);p.mouse.down();p.mouse.move(z['x'],z['y'],steps=steps);p.mouse.up();p.wait_for_timeout(250)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
 for width in [380,1280]:
  p=browser.new_page(viewport={'width':width,'height':970},reduced_motion='reduce');errs=[];p.on('pageerror',lambda e:errs.append(str(e)))
  p.set_content(HTML,wait_until='load',timeout=90000);p.wait_for_timeout(120)
  a={'W':450,'xs':[68,146,224,302,380],'remove':(340,749)} if width==380 else {'W':770,'xs':[115,250,385,520,655],'remove':(625,742)}
  for mode in ['watch','guided','explore','challenge']:
   p.locator(f'.nova-tab[data-m="{mode}"]').click();p.wait_for_timeout(110)
   check(f'{width} {mode} SVG',p.locator('.nova-stage .f167-svg').count()==1)
   check(f'{width} {mode} single mascot dock',p.locator('.nova-stage .nv-dock').count()==1)
   check(f'{width} {mode} no overflow',p.evaluate('document.documentElement.scrollWidth<=innerWidth+2'))
  check(f'{width} original runtime',p.evaluate('typeof NOVA.ui.svgDrag==="function" && typeof NOVA.motion.arrive==="function" && typeof NOVA.neonBox==="function"'))
  p.locator('.nova-tab[data-m="watch"]').click();p.wait_for_timeout(80)
  for i in range(9):
   p.evaluate('i=>{F16_07.timeline.pause();F16_07.timeline.go(i,"qa")}',i);p.wait_for_timeout(65)
   check(f'{width} watch step {i} scene',p.locator('.f167-svg').count()==1)
  p.locator('.nova-tab[data-m="explore"]').click();p.wait_for_timeout(110)
  def e():return p.evaluate('NOVA_F16_07_CONFIG._explore.get()')
  check(f'{width} Y7 original towers',e()['heights']==[2,7,4,6,6])
  check(f'{width} Y7 exact mean',e()['mean']==5)
  p.evaluate('NOVA_F16_07_CONFIG._explore.move(1,0)');p.wait_for_timeout(120)
  check(f'{width} keyboard button transfer conserves sum',e()['heights']==[3,6,4,6,6] and e()['total']==25)
  p.get_by_role('button',name='Reset values').click();p.wait_for_timeout(70)
  # Fast actual pointer transfer, tall source stack to shorter Pupil 1.
  native_drag(p,'[data-transfer="1"]',a['xs'][0],360,1)
  check(f'{width} FAST native mouse: cube transferred',e()['heights']==[3,6,4,6,6],e()['heights'])
  check(f'{width} no detached pointer after transfer',p.evaluate('NOVA.ui._drag===null'))
  before=e()['heights'][:]
  native_drag(p,'[data-transfer="1"]',a['W']/2,93,8)
  check(f'{width} invalid drop restores cube',e()['heights']==before,e()['heights'])
  check(f'{width} no stranded drag after invalid',p.evaluate('NOVA.ui._drag===null'))
  # Regrab and cancel via Escape
  p.locator('[data-transfer="1"]').scroll_into_view_if_needed();bb=p.locator('[data-transfer="1"]').bounding_box();dst=svgpt(p,a['xs'][3],300)
  p.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);p.mouse.down();p.mouse.move(dst['x'],dst['y'],steps=4);p.keyboard.press('Escape');p.mouse.up();p.wait_for_timeout(150)
  check(f'{width} Escape cancel keeps heights',e()['heights']==before)
  check(f'{width} Escape ends drag',p.evaluate('NOVA.ui._drag===null'))
  p.locator('[data-transfer="1"]').focus();p.keyboard.press('ArrowLeft');p.wait_for_timeout(80)
  check(f'{width} keyboard moves cube',e()['heights']==[4,5,4,6,6])
  p.locator('select[aria-label="Lesson"]').select_option('y8-grouped');p.wait_for_timeout(130)
  check(f'{width} Y8 grouped exact frequency',e()['freq']==[2,5,4,1]);check(f'{width} Y8 grouped weighted mean',math.isclose(e()['mean'],220/12));
  groupTargets=p.locator('[data-bundle]');check(f'{width} Y8 grouped four drag handles',groupTargets.count()==4)
  # Source fourth frequency token -> third group at its badge's actual position
  p.locator('[data-bundle="3"]').scroll_into_view_if_needed();p.wait_for_timeout(80);r=p.locator('[data-bundle="2"]').bounding_box();z=svgpt(p,(a['xs'][0] if width==380 else 162),680) # overwritten from actual bbox center
  r3=p.locator('[data-bundle="2"]').bounding_box();r4=p.locator('[data-bundle="3"]').bounding_box();
  p.mouse.move(r4['x']+r4['width']/2,r4['y']+r4['height']/2);p.mouse.down();p.mouse.move(r3['x']+r3['width']/2,r3['y']+r3['height']/2,steps=1);p.mouse.up();p.wait_for_timeout(200)
  check(f'{width} grouped native mouse transfers one frequency',e()['freq']==[2,5,5,0],e()['freq'])
  check(f'{width} grouped total conserved',e()['total']==12)
  # Restore, then check weighted mean recalc with keyboard frequency transfer
  p.get_by_role('button',name='Reset values').click();p.wait_for_timeout(70)
  p.locator('[data-bundle="0"]').focus();p.keyboard.press('ArrowRight');p.wait_for_timeout(120)
  check(f'{width} Y8 keyboard frequency move',e()['freq']==[1,6,4,1])
  check(f'{width} Y8 estimate recomputed',math.isclose(e()['mean'],230/12),e()['mean'])
  p.get_by_role('button',name='Reset values').click();p.wait_for_timeout(80)
  native_drag(p,'[data-bundle="3"]',*a['remove'],steps=6)
  check(f'{width} red removal reduces grouped total',e()['total']==11)
  check(f'{width} no stray drag after remove',p.evaluate('NOVA.ui._drag===null'))
  # Y7 challenge solve tasks and test misconception feedback
  p.locator('select[aria-label="Lesson"]').select_option('y7-fair-share');p.locator('.nova-tab[data-m="challenge"]').click();p.wait_for_timeout(90)
  p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(90)
  check(f'{width} Y7 unbalanced rejected',p.locator('.nova-fb.bad').count()>0)
  p.evaluate('NOVA_F16_07_CONFIG._challenge.solve()');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(920)
  check(f'{width} Y7 task 2 mean prompt',p.locator('.pr-task').inner_text().startswith('The original scores'))
  p.locator('.pr-task + div input').fill('25');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(60)
  check(f'{width} Y7 sum-versus-mean rejected',p.locator('.nova-fb.bad').count()>0)
  p.locator('.pr-task + div input').fill('5');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(920)
  p.locator('.pr-task + div input').fill('6');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(90)
  check(f'{width} Y7 changed-mean accepted',p.locator('.nova-fb.ok').count()>0)
  # Y8 all three challenge tasks, including estimated numeric answer.
  p.locator('.nova-tab[data-m="explore"]').click();p.locator('select[aria-label="Lesson"]').select_option('y8-grouped');p.locator('.nova-tab[data-m="challenge"]').click();p.wait_for_timeout(110)
  check(f'{width} Y8 first challenge incorrect initially',p.evaluate('NOVA_F16_07_CONFIG._challengeState().values.freq')==[2,5,3,2])
  p.evaluate('NOVA_F16_07_CONFIG._challenge.solve()');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(920)
  check(f'{width} Y8 midpoint task loaded','midpoint' in p.locator('.pr-task').inner_text().lower())
  p.locator('.pr-task + div input').fill('30');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(70)
  check(f'{width} Y8 wrong class boundary rejected',p.locator('.nova-fb.bad').count()>0)
  p.locator('.pr-task + div input').fill('25');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(920)
  check(f'{width} Y8 estimated mean question loaded','estimate' in p.locator('.pr-task').inner_text().lower())
  p.locator('.pr-task + div input').fill('220');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(70)
  check(f'{width} Y8 weighted sum mistaken for mean rejected',p.locator('.nova-fb.bad').count()>0)
  p.locator('.pr-task + div input').fill('18.33');p.get_by_role('button',name='Check',exact=True).click();p.wait_for_timeout(100)
  check(f'{width} Y8 rounded estimated mean accepted',p.locator('.nova-fb.ok').count()>0)
  check(f'{width} no page errors',not errs,errs)
  p.close()
 browser.close()
result={'passed':sum(x['pass'] for x in checks),'total':len(checks),'failed':[x for x in checks if not x['pass']],'checks':checks}
(R/'tests/RESULTS.json').write_text(json.dumps(result,indent=2))
print('RESULT',result['passed'],'/',result['total'],'failed',result['failed'],flush=True)
sys.exit(1 if result['failed'] else 0)
