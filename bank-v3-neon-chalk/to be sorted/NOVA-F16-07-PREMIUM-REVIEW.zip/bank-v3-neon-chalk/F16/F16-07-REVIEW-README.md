# F16-07 — Mean Explorer / NOVA Maths V2

Premium review deliverable, not GOLD-approved. No GitHub changes.

## Open / review
Open `F16/F16-07-mean-explorer.html` in a browser. It is **standalone**: the established shared core, embedded NOVA Chalk fonts, original companion art and component logic are bundled in the page. Review the teaching story in Watch, the Guided stepper, the movable blocks and frequency tokens in Explore, and all three Challenge tasks in each preset.

## Two presets
- **Y7-069** Fair share: five stacks, 25 score-unit cubes, mean = 5. Transfer one top cube to a different stack by dragging, pressing Left/Right when focused or using the lower controls.
- **Y8-065** Grouped mean: classes 0–10, 10–20, 20–30, 30–40 (upper boundaries excluded); frequencies 2,5,4,1; each counted journey is represented by a tower using the **assumed** class midpoint, with 5 minutes per cube; total frequency = 12, weighted total = 220, estimated mean ≈ 18.33. Drag one `+1` frequency token to another class or to the red removal zone; use keyboard or lower controls as alternatives.

## Scoped ZIP layout
- `F16/F16-07-mean-explorer.html`: standalone deliverable
- `F16/F16-07-QA.md`: test evidence and open gates
- `src/F16-07.js`, `src/F16-07.css`: component-only source
- `build/F16-07.src.html`, `build/build-f16-07.py`: pinned local-only build
- `tests/`: live Playwright tests and output
- `shots/F16-07/`: screenshot evidence (380/1280)

## Rebuild
Place scoped files under `bank-v3-neon-chalk/` from your own repo checkout, which must already have `F2/F2-03-base-ten-blocks.html`. Run `python3 build/build-f16-07.py`. The builder extracts the exact approved shared runtime and **aborts if hashes differ**. It makes no commits/pushes and does not alter the original F0/F2 files.

To retest: run `python3 tests/stress_f1607.py` and `python3 tests/visual_f1607.py` with Playwright and local Chromium installed. The pictured results were generated in Chromium for this review build.
