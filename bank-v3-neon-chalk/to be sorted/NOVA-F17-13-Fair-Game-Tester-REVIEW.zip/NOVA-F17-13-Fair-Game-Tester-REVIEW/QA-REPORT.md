# NOVA F17-13 — Fair Game Tester — Review QA

**Status:** BUILT FOR REVIEW. NOT GOLD-approved. **Browser / physical device acceptance pending.**

## Source provenance and build fidelity
- Built from the F17-13 specification in `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, and the existing standalone F17-12 review shell. No GitHub writes.
- The embedded NOVA core script is **byte-for-byte identical** to F17-12 (`SHA-256 bc8b287a321aff1b3aeda8383879c68a6e7abf7542a6a9b72576a1c027bc4c6e`), retaining the original fonts, mascot, stage, visual helpers, four-mode mount and SVG drag system.
- `F17-13-Fair-Game-Tester-PREMIUM-REVIEW.html` is standalone, with inlined CSS, JS, core assets and fonts. No network fetches.
- **One lesson preset:** Y9-046 Experimental probability and relative frequency. Fair, house-advantaged and player-advantaged setups are configurations of the same engine, not duplicate engines.

## Evidence completed
- `tests/test_runtime.js` — **231/231 assertions passed** using a local headless JavaScript test harness with a mocked NOVA DOM layer. Includes: 6 WATCH render steps at 380/1280 dimensions, EXPLORE construction, draggable marker drop callbacks, all 4 Challenge questions with correct/incorrect answers, 0–6 winning faces × 5 prizes × 2 layouts, seeded random trial totals and exact accounting `gross wins − £1 × plays`.
- `tests/test_static.py` — **20/20 assertions passed**. Includes core hash match, fully embedded fonts and JS, established mascot dock, source code behind developer disclosure, retained NOVA drag kit and pointercancel hook, both responsive SVG layouts, print fallback and declared modes.
- Mathematical identity exhaustively checked for each prize: **expected net per trial = (winning faces / 6) × gross prize − £1**. Fair if and only if the expected net equals zero. Simulator's net is `winning plays × gross prize − all plays × £1`.
- Challenge reference results: `0`, `−0.5`, `+1`, and `3 winning faces` (with a £2 prize), each tested with correct and incorrect answers. Challenge 4 deliberately hides the target number of winning faces so it does not disclose the answer.

## Outstanding / unverified — do not treat as passing
- **Chromium browser could not be launched** in this environment, including for a blank page. No completed DOM/browser screenshot, responsive pixel-overlap audit or browser-console check is claimed for F17-13. The local harness tests the engine's logic and draw calls but is NOT actual browser rendering.
- Actual mouse/touch pointer movement, fast drags, drag cancellation and pixel-accurate snap zone recovery remain **unverified in a live browser**. The implementation uses the inherited `NOVA.ui.svgDrag` API and executable callback tests, which do not substitute for real pointer tests.
- Physical touchscreen, Firefox and Safari remain untested.
- **Screenshots omitted intentionally** rather than reusing earlier engines' screenshots or creating misleading mock screenshots. Owner should inspect at 380px and 1280px across WATCH / GUIDED / EXPLORE / CHALLENGE and stress-test the WIN marker before approval.

## Owner acceptance gate
Check: one helper inside the stage; six outcome faces with correct labels; every WIN marker can be dragged from the tray, re-grabbed and deleted; the green target/red removal feedback is correct; every trial resets on changes; all four Challenge answers/diagnostics; no viewport collisions; native mobile touch; Play/Pause/rewind/scrub; no blank stage; print fallback.

This is a **functional review build with unverified browser QA**, not a completed acceptance pass and not GOLD-approved.
