# NOVA F17-13 · Fair Game Tester

Open `F17-13-Fair-Game-Tester-PREMIUM-REVIEW.html` directly in a web browser. Everything required to use the interactive page is embedded; no external files or internet connection are needed.

Four modes: WATCH / GUIDED / EXPLORE / CHALLENGE. Y9-046 preset. In EXPLORE, assign WIN markers to numbered outcomes, choose a gross prize, observe expected net gains, run trials and compare observed results. Keyboard alternative: buttons for Faces 1–6.

**Review status only.** Automated mathematical / local DOM-contract checks passed, but screenshots and real-browser mouse/keyboard stress tests were not performed because the browser could not launch in this environment. See `QA-REPORT.md`. No GitHub files were modified.
