const fs=require('fs'),vm=require('vm'),src=fs.readFileSync(__dirname+'/engine.js','utf8');
let captured=null,passes=0,failed=[];
function ok(x,name){if(x){passes++;}else{failed.push(name);}}
function el(tag,a={},children=[]){let ob={tag,a,children:[],attributes:{},listeners:{},style:{},classList:{add(){},remove(){}},append(...x){this.children.push(...x);},replaceChildren(...x){this.children=x;},setAttribute(k,v){this.attributes[k]=v;},addEventListener(k,f){this.listeners[k]=f;},querySelector(){return null;},getAttribute(k){return this.attributes[k];},remove(){},focus(){}}; if(typeof children==='string')ob.children=[children];else if(Array.isArray(children))ob.children=children;return ob;}
let handlers=[],drops=[];
const NOVA={h:el,svg:{el,root:(w,h,alt)=>{const z=el('svg');z.W=w;z.H=h;z.alt=alt;return z;}},neonLine:()=>{},neonPath:()=>{},neonBox:()=>{},neonRing:()=>{},chalkText:()=>{},cap:()=>{},scene:{helperStrip:()=>{}},ui:{svgDrag:(svg,token,o)=>{drops.push(o);return token;},cancelDrag:()=>{}},motion:{flash:()=>{}},events:{emit:()=>{},history:()=>[],on:()=>()=>{}},bankMount:(o)=>{captured=o;},entryTask:()=>el('input'),challengeRun:(panel,api,tasks,show,cfg)=>{global.tasks=tasks;global.show=show;},reducedMotion:()=>true};
let document={getElementById:()=>null};let context={NOVA,window:{},innerWidth:1280,document,console,Set,Math,Number,Array};vm.createContext(context);
vm.runInContext(src,context,{timeout:2000});
ok(!!captured&&captured.id==='F17-13','registered');ok(captured?.def.steps.length===6,'six lessons');ok(Object.keys(context.window.NOVA_F17_13_CONFIG.presets).length===1,'one canonical preset');
for(const width of [380,1280]){
 context.innerWidth=width;
 for(let i=0;i<6;i++){try{captured.def.render(i,el('stage'));ok(true,`watch ${width} ${i}`);}catch(e){failed.push(`watch ${width} ${i} ${e}`);}}
 let panel=el('panel'),stage=el('stage'),api={onCleanup:()=>{}};
 try {captured.def.explore(panel,stage,api);ok(true,'explore '+width);}catch(e){failed.push(`explore ${width} ${e.stack}`);continue;}
 const x=context.window.NOVA_F17_13_CONFIG._explore;
 const cases=[[[0,2],3,0],[[0],3,-.5],[[0,2,4],4,1],[[0,1,2],2,0],[[0,1,2,3],2,1/3],[[],6,-1],[[0],12,1],[[0,1,2,3,4,5],2,1]];
 for(const [wins,pr,ev] of cases){try{x.set(wins,pr);const m=x.get();ok(Math.abs(m.expected-ev)<1e-8,`math ${width} ${wins} ${pr}`);ok(m.win.length===wins.length,`count ${width} ${wins}`);}catch(e){failed.push(`preset ${e.message}`);}}
 x.set([0,2],3);x.run(100);const res=x.get();ok(res.tries===100,'trials count');ok(res.success<=100&&res.success>=0,'wins bounded');ok(Number.isFinite(res.earned),'sum payout finite');x.reset();ok(x.get().tries===0,'reset');
 // callback contract: drag source marker onto a specific face, then regrab to another face.
 try{let d=drops.at(-1);ok(!!d&&!!d.onDrop,'source drag exists');const old=x.get().win.length;d.onDrop('face4');ok(x.get().win.includes(4),'real source onDrop changes model');let d2=drops.at(-2);ok(!!d2&&!!d2.onDrop,'placed drag exists');}catch(e){failed.push(`drag callbacks ${e.message}`);}
 try {captured.def.challenge(el('panel'),api,el('stage'));ok(true,'challenge '+width);const answers=[0,-.5,1,3];global.tasks.forEach((t,i)=>{const ch=t.check(answers[i]);ok(ch[0]===true,`correct ${width} ${i}`);ok(t.check(i===0?1:(answers[i]+1))[0]===false,`incorrect ${width} ${i}`);global.show(i);ok(true,'scene challenge '+width+' '+i);});}catch(e){failed.push(`challenge ${width} ${e.stack}`);}
}
// Exhaustively verify all 0..6 winning-face counts for five gross prizes; simulated bookkeeping is exact.
for(const width of [380,1280]){
 context.innerWidth=width;captured.def.explore(el('panel'),el('stage'),{onCleanup:()=>{}});
 const x=context.window.NOVA_F17_13_CONFIG._explore;
 for(const prize of [2,3,4,6,12]) for(let n=0;n<=6;n++){
  x.set([...Array(n).keys()],prize);const m=x.get();let theo=n/6*prize-1;
  ok(Math.abs(m.expected-theo)<1e-9,`exhaustive ${width} ${n} ${prize}`);
  ok(m.fair===(Math.abs(theo)<1e-9?'FAIR GAME':theo<0?'HOUSE ADVANTAGE':'PLAYER ADVANTAGE'),`classification ${width} ${n} ${prize}`);
 }
 x.set([0,1,2],2);x.run(500);const rr=x.get();ok(rr.earned===rr.success*2-rr.tries,`observed bookkeeping ${width}`);
}
console.log(JSON.stringify({passed:passes,failed,allPass:failed.length===0},null,2));process.exit(failed.length?1:0);
