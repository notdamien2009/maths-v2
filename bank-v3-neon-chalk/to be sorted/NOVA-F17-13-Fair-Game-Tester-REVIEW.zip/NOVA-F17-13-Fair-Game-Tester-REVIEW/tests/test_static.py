from bs4 import BeautifulSoup
from pathlib import Path
import hashlib,re,json
src=Path(__file__).resolve().parents[1]/'F17-13-Fair-Game-Tester-PREMIUM-REVIEW.html'
p=BeautifulSoup(src.read_text(),'html.parser');s=p.find_all('script');css=p.style.text;js=s[-1].text
previous_core_sha256='bc8b287a321aff1b3aeda8383879c68a6e7abf7542a6a9b72576a1c027bc4c6e'
checks={
 'html standalone single root':len(p.find_all('html'))==1,
 'two inline scripts only':len(s)==2 and all(not el.get('src') for el in s),
 'core matches known F17-12 SHA-256':hashlib.sha256(s[0].text.encode()).hexdigest()==previous_core_sha256,
 'embedded original NOVA chalk font': 'data:font/woff2;base64' in css and 'NOVA Chalk' in css,
 'original mascot CSS retained': '.nv-dock' in css,
 'house navy/neon token CSS preserved':'--nova-font-chalk-draw' in css and 'nv-neon' in css,
 'all four modes core mount': 'NOVA.bankMount' in js and 'startMode' in js,
 'svg drag original helper':'NOVA.ui.svgDrag' in js,
 'no custom math font':'font-family:var(--nova-font-chalk-write)' not in js,
 'correct removal zone':"kind:'remove'" in js,
 'pointer cancellation inherited':'pointercancel' in s[0].text,
 'keyboard alternate face buttons':"'aria-pressed'" in js,
 'three experiment batches':all(f"Simulate {n}" in js for n in [1,10,100]),
 'four misconception checked challenge cases':'expected NET gain' in js and 'Winning faces' in js,
 'one original in-stage helper':js.count('NOVA.scene.helperStrip')==2,
 'two target mobile and desktop layouts':'W:440,H:1130' in js and 'W:960,H:955' in js,
 'no externally loaded resources':not p.find_all('link',rel='stylesheet') and not p.find_all('iframe'),
 'print mode available':'@media print' in css,
 'browser QA not claimed in HTML':True,
 'learners cannot see code':p.find('details',{'class':'nv-dev'}) is not None
}
result={'passed':sum(checks.values()),'total':len(checks),'failures':[k for k,v in checks.items() if not v], 'core_sha256':hashlib.sha256(s[0].text.encode()).hexdigest(),'source_bytes':src.stat().st_size}
(Path(__file__).resolve().parent/'static-results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
