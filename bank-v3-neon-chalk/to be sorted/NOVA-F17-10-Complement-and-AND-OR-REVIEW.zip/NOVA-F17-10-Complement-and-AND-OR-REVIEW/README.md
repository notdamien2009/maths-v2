# NOVA Maths V2 · F17-10 Complement and AND/OR

Open `F17-10-Complement-and-AND-OR-PREMIUM-REVIEW.html` directly in your browser. No internet or external assets are required.

**Modes:** WATCH, GUIDED, EXPLORE, CHALLENGE. In Explore, select one of eight lesson presets and choose an event such as A AND B, A OR B, NOT A, NOT B or neither. Drag MARK tokens into the four labelled Venn regions, or use the accessible marker/region dropdowns and Place / move button. Try CHECK, Show correct regions or Clear. Fast pointer movement, re-grabbing, a REMOVE zone and Escape cancellation are supported.

**Presets:** Y7-073, Y7-077, Y8-068, Y8-070, Y8-071, Y8-072, Y9-044, Y9-045.

**Review evidence:** See `qa/QA-REPORT.md` and `qa/*.json`. There are 24 screenshots (four modes and all eight presets at 380px/1280px). All 234 recorded assertions passed. Physical touchscreen and non-Chromium browser testing remain outstanding.

**Status:** Review only, NOT GOLD-approved. No GitHub modifications.
