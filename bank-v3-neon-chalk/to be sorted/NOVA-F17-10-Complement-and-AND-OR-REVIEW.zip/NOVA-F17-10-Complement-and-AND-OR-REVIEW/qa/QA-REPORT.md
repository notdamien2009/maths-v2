# NOVA F17-10 — Component QA Report

**Engine:** Complement and AND/OR · FAMILY F17 · built 2026-10-13
**Status:** Built for owner review; NOT GOLD-approved.
**Source authority:** GitHub `notdamien2009/maths-v2`, `bank-v3-neon-chalk/00-master/NOVA-MASTER-FOR-OTHER-AI.md`, section `F17-10`; canonical core inherited from F17-08 standalone, consistent with previously reviewed F0/F2 visuals.

## Executed QA — 234 / 234 assertions passed

| File | Assertions passed | What was checked |
|---|---:|---|
| `qa/QA-BROWSER.json` | 32/32 | Modes, exact sampled probabilities, original docked mascot, actual fast mouse snap/re-grab/red removal, JS errors at 380px/1280px |
| `qa/QA-EXTRA.json` | 48/48 | Watch play controls, rewind/scrub, progression, four Challenges including incorrect-answer diagnostic text and correct marking, no exposed answer |
| `qa/QA-EDGE.json` | 16/16 | Escape recovery, direct pointercancel on the current draggable DOM element, invalid drop, accessible selection/return controls, no errors |
| `qa/QA-PRESETS.json` | 34/34 | All eight presets at both sizes, correct revealed model, exactly one original in-stage SVG helper |
| `qa/QA-MATH.json` | 104/104 | Every operator's boolean truth table against each of eight frequency models; complement identities, inclusion-exclusion, independent-event laws |

The automated checks were actually run using local Chromium via Playwright. Results are included in `qa/*.json`. Each JSON contains individual test names/status. Scripts are in `qa/tests/`. Use Python 3 + Playwright/Chromium to replay, from the extracted archive: `python qa/tests/f17_10_shortqa.py`. Tests do not modify GitHub.

## Visual evidence

`24` screenshots in `screenshots/`:
- Eight render captures: WATCH, GUIDED, EXPLORE and CHALLENGE at both 380px and 1280px.
- Sixteen preset captures: eight distinct datasets at both 380px and 1280px.

## Code evidence by source line

- `source/F17-10-engine-source.js`, lines 4–23: Eight presets; nine Boolean event operators; event meanings and exact region masks.
- Lines 25–34: Registered events, exact integer frequencies, rational reduction and independent-event calculation.
- Lines 36–93: Canonical NOVA neon shapes, stacked Chalk fraction display, one docked helper, labelled four-region SVG stage, SVG drag targets, red removal and keyboard equivalents.
- Lines 95–110: Six named Watch/Guided teaching steps with changing relevant mascot dialogue.
- Lines 111–128: Interactive Explore lesson/operator changes, mark/check/reset/reveal, independent-model explanation, keyboard placement.
- Lines 129–140: Four Challenge tasks, validation and misconception-specific feedback without revealing answers.
- Line 141 onwards: Shared NOVA `bankMount`, reusable config, linked components and spec card. Core remains inlined in the standalone HTML; repository sources are not modified.

## Acceptance gaps / limitations

- No **physical touchscreen hardware** verification was performed. Desktop Chromium pointer tests, pointer-cancellation tests and mobile-width browser simulation do not establish a successful physical touch test.
- Browser testing was on Chromium; Firefox and Safari testing were not performed.
- Animation controls were tested in reduced-motion mode; a full screen-recorded normal-motion animation review was not included in the stated pass count.
- Human owner visual/teaching acceptance is still required before GOLD status.

## Anti-drift checks

- Original NOVA core and mathematical chalk assets are inlined; original shared artwork is retained.
- Exactly one in-stage helper SVG is present across modes.
- Shared dark neon shell, mathematical colour semantics, gradients and interaction kit are retained.
- Traditional vertically stacked fractions with a horizontal bar are used in stage and readout.
- No GitHub actions used to commit, push or upload changes.
