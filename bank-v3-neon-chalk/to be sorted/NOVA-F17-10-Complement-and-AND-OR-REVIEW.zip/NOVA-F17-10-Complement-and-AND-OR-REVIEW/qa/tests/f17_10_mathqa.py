import asyncio,json,pathlib,math
from playwright.async_api import async_playwright
HTML=(pathlib.Path(__file__).resolve().parents[2]/'F17-10-Complement-and-AND-OR-PREMIUM-REVIEW.html').read_text();OUT=(pathlib.Path(__file__).resolve().parents[1])
checks=[]
def ck(t,v):
 checks.append({'name':t,'pass':bool(v)});
 if not v:print('FAIL',t)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=await b.new_page();await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',HTML)
  dat=await page.evaluate('()=>({presets:window.NOVA_F17_10_CONFIG.presets,ops:window.NOVA_F17_10_CONFIG.operators})');await b.close()
  funcs={
   'and':lambda a,b:a and b,'or':lambda a,b:a or b,'notA':lambda a,b:not a,'notB':lambda a,b:not b,
   'neither':lambda a,b:not a and not b,'a':lambda a,b:a,'b':lambda a,b:b,
   'xor':lambda a,b:a!=b,'notAorB':lambda a,b:not a or b
  }
  data={'a':(True,False),'both':(True,True),'b':(False,True),'none':(False,False)}
  for pid,pr in dat['presets'].items():
   counts=dict(zip(('a','both','b','none'),pr['counts']));tot=sum(counts.values());ck(pid+' valid counts',tot>0 and all(x>=0 for x in counts.values()))
   for op,d in dat['ops'].items():
    actual=set(d['mark']);expected={k for k,(a,b) in data.items() if funcs[op](a,b)}
    val=sum(counts[k] for k in actual)
    ck(pid+'/'+op+' boolean semantics',actual==expected and 0<=val<=tot)
   pA=(counts['a']+counts['both'])/tot;pB=(counts['b']+counts['both'])/tot;pBoth=counts['both']/tot;pOr=(counts['a']+counts['both']+counts['b'])/tot
   ck(pid+' complement identity',abs((counts['b']+counts['none'])/tot-(1-pA))<1e-12)
   ck(pid+' union identity',abs(pOr-(pA+pB-pBoth))<1e-12)
   ck(pid+' independence law',((abs(pBoth-pA*pB)<1e-12)==(pid in ('y8independent','y9independent'))))
  (OUT/'QA-MATH.json').write_text(json.dumps({'passed':sum(c['pass'] for c in checks),'total':len(checks),'checks':checks},indent=2));print('MATH',sum(c['pass'] for c in checks),'/',len(checks))
asyncio.run(main())
