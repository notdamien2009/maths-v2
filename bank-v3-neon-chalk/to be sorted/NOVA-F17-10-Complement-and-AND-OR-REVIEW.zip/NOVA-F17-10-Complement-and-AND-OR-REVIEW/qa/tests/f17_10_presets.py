import asyncio,pathlib,json
from playwright.async_api import async_playwright
HTML=(pathlib.Path(__file__).resolve().parents[2]/'F17-10-Complement-and-AND-OR-PREMIUM-REVIEW.html').read_text();O=(pathlib.Path(__file__).resolve().parents[1]);checks=[]
def ck(t,v):
 checks.append({'name':t,'pass':bool(v)});print(('PASS' if v else 'FAIL'),t,flush=True)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w in (380,1280):
   page=await b.new_page(viewport={'width':w,'height':1600},reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',HTML)
   await page.get_by_role('tab',name='Explore').click()
   for name in ['y7complement','y7table','y8frequency','y8sample','y8independent','y8venn','y9sets','y9independent']:
    data=await page.evaluate('id=>{let o=window.NOVA_F17_10_CONFIG._explore;o.setPreset(id);o.reveal();return o.get()}',name)
    ck(f'{w} preset {name} renders',data['correct'] and data['favourable']<=data['total'] and data['total']>0)
    ck(f'{w} preset {name} one mascot',await page.locator('.nv-dock svg.nv-dockfig').count()==1)
    await page.screenshot(path=str(O/f'F17-10-{w}-{name}.png'),full_page=True,animations='disabled')
   ck(f'{w} all preset transitions no errors',not errors)
   await page.close()
  await b.close()
 (O/'QA-PRESETS.json').write_text(json.dumps({'total':len(checks),'passed':sum(c['pass'] for c in checks),'checks':checks},indent=2));print('PRESETS',sum(c['pass'] for c in checks),'/',len(checks))
asyncio.run(main())
