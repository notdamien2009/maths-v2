import asyncio,pathlib,json
from playwright.async_api import async_playwright
HTML=(pathlib.Path(__file__).resolve().parents[2]/'F17-10-Complement-and-AND-OR-PREMIUM-REVIEW.html').read_text();O=(pathlib.Path(__file__).resolve().parents[1]);checks=[]
def ck(k,yes,detail=''):
 checks.append({'name':k,'pass':bool(yes),'detail':str(detail)[:200]});print(('PASS' if yes else 'FAIL'),k,flush=True)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for width in (380,1280):
   page=await b.new_page(viewport={'width':width,'height':1600},reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   await page.goto('about:blank');await page.evaluate('(h)=>{document.open();document.write(h);document.close()}',HTML)
   await page.get_by_role('tab',name='Watch').click();await page.wait_for_timeout(65)
   bars=await page.locator('button[aria-label]').evaluate_all('(x)=>x.map(e=>e.getAttribute("aria-label"))')
   ck(f'{width} Watch timeline',all(x in bars for x in ['Reset','Step back','Step forward']),bars)
   ck(f'{width} scrub control',await page.locator('input[type=range]').count()>0)
   if 'Pause' in bars:await page.get_by_role('button',name='Pause',exact=True).click()
   await page.get_by_role('button',name='Reset',exact=True).click()
   await page.get_by_role('button',name='Step forward',exact=True).click();await page.wait_for_timeout(60)
   ck(f'{width} step forward','STEP 2/6' in await page.locator('body').inner_text())
   await page.get_by_role('button',name='Step back',exact=True).click();await page.wait_for_timeout(55)
   ck(f'{width} step backwards','STEP 1/6' in await page.locator('body').inner_text())
   await page.get_by_role('tab',name='Challenge').click();await page.wait_for_timeout(80)
   for i,(ans,wrong,trap) in enumerate([('13/20','7/20','complement'),('1/6','9/12','overlap'),('3/4','18/20','twice'),('3/25','7/10','multiply')]):
    q=await page.locator('.pr-task').inner_text();ck(f'{width} question {i+1}',len(q)>30,q)
    ck(f'{width} answer hidden {i+1}','?' in await page.locator('.f1710-readouts').inner_text())
    inp=page.locator('input[type=text]');await inp.fill(wrong)
    await page.get_by_role('button',name='Check',exact=True).click();await page.wait_for_timeout(60)
    body=await page.locator('body').inner_text();ck(f'{width} diagnostic {i+1}',trap.lower() in body.lower(),body[-350:])
    await inp.fill(ans);await page.get_by_role('button',name='Check',exact=True).click();await page.wait_for_timeout(820 if i<3 else 100)
    body=await page.locator('body').inner_text();ck(f'{width} correct {i+1}','Correct' in body,body[-240:])
    if i<3:ck(f'{width} next question {i+1}',q!=await page.locator('.pr-task').inner_text())
   ck(f'{width} no script errors',not errors,errors)
   await page.close()
  await b.close()
 (O/'QA-EXTRA.json').write_text(json.dumps({'total':len(checks),'passed':sum(x['pass'] for x in checks),'checks':checks},indent=2))
 print('EXTRA',sum(x['pass'] for x in checks),'/',len(checks),flush=True)
asyncio.run(main())
