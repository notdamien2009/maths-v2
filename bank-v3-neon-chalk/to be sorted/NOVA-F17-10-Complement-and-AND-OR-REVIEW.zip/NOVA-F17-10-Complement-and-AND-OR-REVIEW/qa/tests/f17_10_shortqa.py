import asyncio,json,pathlib
from playwright.async_api import async_playwright
H=(pathlib.Path(__file__).resolve().parents[2]/'F17-10-Complement-and-AND-OR-PREMIUM-REVIEW.html').read_text();O=(pathlib.Path(__file__).resolve().parents[1]);O.mkdir(exist_ok=True)
checks=[]
def check(name,pass_,d=''):
 checks.append({'name':name,'pass':bool(pass_),'detail':str(d)[:300]});print(('PASS ' if pass_ else 'FAIL ')+name,flush=True)
async def clickmode(page,mode):
 b=page.get_by_role('tab',name=mode);b=b if await b.count() else page.get_by_role('button',name=mode,exact=True);await b.first.click(timeout=3000)
async def xy(page,x,y):return await page.evaluate('([x,y])=>{let s=document.querySelector("svg.f1710-plot"),p=s.createSVGPoint();p.x=x;p.y=y;let a=p.matrixTransform(s.getScreenCTM());return {x:a.x,y:a.y}}',[x,y])
async def drag(page,i,x,y):
 await page.locator('svg.f1710-plot').scroll_into_view_if_needed()
 el=page.locator(f'[data-event-chip="{i}"]');box=await el.bounding_box();print('bbox',box,flush=True);assert box
 dst=await xy(page,x,y)
 await page.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2);await page.mouse.down();await page.mouse.move(dst['x'],dst['y'],steps=1);await page.mouse.up();await page.wait_for_timeout(90)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for width in (380,1280):
   page=await b.new_page(viewport={'width':width,'height':1600},reduced_motion='reduce');errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
   await page.goto('about:blank');await page.evaluate('(h)=>{document.open();document.write(h);document.close()}',H);await page.wait_for_timeout(100)
   for mode in ('Watch','Guided','Explore','Challenge'):
    await clickmode(page,mode);check(f'{width} {mode} renders',await page.locator('svg.f1710-plot').count()==1)
    check(f'{width} {mode} one mascot',await page.locator('.nv-dock svg.nv-dockfig').count()==1)
    await page.screenshot(path=str(O/f'F17-10-{width}-{mode.lower()}.png'),full_page=True,animations='disabled')
   await clickmode(page,'Explore');api='window.NOVA_F17_10_CONFIG._explore'
   for preset,op,result in [('y7complement','notA',13),('y8sample','and',2),('y9sets','or',15),('y9independent','and',12)]:
    v=await page.evaluate(f'''([p,o])=>{{let x={api};x.setPreset(p);x.setOperator(o);x.reveal();return x.get();}}''',[preset,op]);check(f'{width} {preset} {op} reveal',v['correct'] and v['favourable']==result,v)
   print('Starting drag',width,flush=True)
   await page.evaluate(f'''()=>{{let x={api};x.setPreset('y8venn');x.setOperator('or');x.reset();}}''')
   x=58 if width==380 else 132;y=709 if width==380 else 720
   try:
    await drag(page,0,x,y);v=await page.evaluate(f'()=>{api}.get()');check(f'{width} actual drag',v['assignments'].get('0')=='a',v)
    await drag(page,0,162 if width==380 else 342,y);v=await page.evaluate(f'()=>{api}.get()');check(f'{width} regrab',v['assignments'].get('0')=='both',v)
    await drag(page,0,333 if width==380 else 750,940 if width==380 else 932);v=await page.evaluate(f'()=>{api}.get()');check(f'{width} red removal','0' not in v['assignments'],v)
   except Exception as e:check(f'{width} drag check exception',False,e)
   check(f'{width} no script errors',not errs,errs)
   await page.close()
  await b.close()
 (O/'QA-BROWSER.json').write_text(json.dumps({'checks':checks,'passed':sum(a['pass'] for a in checks),'total':len(checks)},indent=2));print('QA TOTAL',sum(a['pass'] for a in checks),len(checks),flush=True)
asyncio.run(main())
