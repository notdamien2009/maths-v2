import asyncio,pathlib,json
from playwright.async_api import async_playwright
H=(pathlib.Path(__file__).resolve().parents[2]/'F17-10-Complement-and-AND-OR-PREMIUM-REVIEW.html').read_text();O=(pathlib.Path(__file__).resolve().parents[1]);checks=[]
def ck(k,v,d=''):
 checks.append({'name':k,'pass':bool(v),'detail':str(d)[:250]});print(('PASS' if v else 'FAIL'),k,flush=True)
async def coords(page,x,y):return await page.evaluate('([x,y])=>{const s=document.querySelector("svg.f1710-plot"),p=s.createSVGPoint();p.x=x;p.y=y;{let q=p.matrixTransform(s.getScreenCTM());return {x:q.x,y:q.y}}}',[x,y])
async def drag(page,i,xy,cancel=None):
 await page.locator('svg.f1710-plot').scroll_into_view_if_needed()
 bb=await page.locator(f'[data-event-chip="{i}"]').bounding_box();pt=await coords(page,*xy)
 await page.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);await page.mouse.down();await page.mouse.move(pt['x'],pt['y'],steps=1)
 if cancel=='escape':await page.keyboard.press('Escape')
 if cancel=='pointercancel':await page.evaluate('()=>{let g=NOVA.ui._drag.el;g.dispatchEvent(new PointerEvent("pointercancel",{bubbles:true,pointerId:1,pointerType:"mouse"}))}')
 await page.mouse.up();await page.wait_for_timeout(85)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w in (380,1280):
   page=await b.new_page(viewport={'width':w,'height':1600},reduced_motion='reduce');errs=[];page.on('pageerror',lambda x:errs.append(str(x)))
   await page.goto('about:blank');await page.evaluate('(h)=>{document.open();document.write(h);document.close()}',H);await page.get_by_role('tab',name='Explore').click();await page.wait_for_timeout(75)
   await page.evaluate('()=>{let e=window.NOVA_F17_10_CONFIG._explore;e.setPreset("y8venn");e.setOperator("or");e.reset()}')
   sx=58 if w==380 else 132;sy=709 if w==380 else 720
   await drag(page,2,(sx,sy),'escape');v=await page.evaluate('()=>window.NOVA_F17_10_CONFIG._explore.get()');ck(f'{w} Escape drag restores',len(v['assignments'])==0,v)
   await drag(page,2,(sx,sy),'pointercancel');v=await page.evaluate('()=>window.NOVA_F17_10_CONFIG._explore.get()');ck(f'{w} pointer cancellation restores',len(v['assignments'])==0,v)
   await drag(page,0,(sx,sy));v=await page.evaluate('()=>window.NOVA_F17_10_CONFIG._explore.get()');ck(f'{w} place before invalid',v['assignments'].get('0')=='a',v)
   await drag(page,0,(sx,255));v=await page.evaluate('()=>window.NOVA_F17_10_CONFIG._explore.get()');ck(f'{w} invalid drop springs back',v['assignments'].get('0')=='a',v)
   # Keyboard alternative uses accessible select controls + place button.
   await page.locator('select[aria-label="Choose event marker"]').select_option('1')
   await page.locator('select[aria-label="Choose event region"]').select_option('both')
   await page.get_by_role('button',name='Place / move').click();v=await page.evaluate('()=>window.NOVA_F17_10_CONFIG._explore.get()');ck(f'{w} keyboard place',v['assignments'].get('1')=='both',v)
   await page.get_by_role('button',name='Return to tray').click();v=await page.evaluate('()=>window.NOVA_F17_10_CONFIG._explore.get()');ck(f'{w} keyboard return','1' not in v['assignments'],v)
   ck(f'{w} one original mascot',await page.locator('.nv-dock svg.nv-dockfig').count()==1)
   ck(f'{w} no JS errors',not errs,errs)
   await page.close()
  await b.close()
 (O/'QA-EDGE.json').write_text(json.dumps({'passed':sum(v['pass'] for v in checks),'total':len(checks),'checks':checks},indent=2))
 print('EDGE',sum(v['pass'] for v in checks),len(checks),flush=True)
asyncio.run(main())
