# NOVA Maths V2 — F14-13 Pattern Makers

**Status:** Premium REVIEW; not GOLD-approved. No GitHub modifications.

## Build

- Single self-contained HTML using the same embedded JavaScript core from the supplied F14-12/F0/F2 production bank. SHA256 of shared JS: `fbcb2028453cbdef88463266c004ef4d4041a2538a7e1716a7b47bebe240fabc`.
- NOVA premium frame, dark navy-purple background, neon-tube mathematics, Chalk labels and single mascot inside the bottom-right of stage.
- Watch, Guided, Explore, Challenge with shared NOVA controls, timeline and assessment interface.
- Six named presets: translation frieze; alternating vertical-line reflection; 60° six-fold rotation rosette; glide reflection (horizontal reflection plus translation); half-turn repetition; progressive enlargement.
- Reusable asymmetric arrow motif; mathematical placement/orientation calculated from repeat vectors, rotation matrices, reflection in vertical/horizontal lines, and scale factors.
- Explore: choose pattern, vary horizontal repeat step, show/hide guides, place/undo motif, keyboard Enter, drag next motif to exact snap target. Once placed, drag it to the REMOVE zone or use Delete. Escape cancels a drag.
- Challenge: six conceptual/interactive tasks. No game logic is embedded.

## Spec card

**Mathematical purpose:** Explore how a transformation applied repeatedly generates a geometric pattern, and explain the rule.

**Parameters:** Motif points, translation step, reflection axis, rotation angle, repeat count, preview/show guides, optional placement state.

**Animated learning:** (1) Study motif, (2) Choose transformation, (3) Move a copy, (4) Repeat, (5) Extend pattern, (6) Explain and generalise. Sir Bob prompts differ at each step.

**Common misconceptions:** Flipping rather than sliding, moving a reflected copy without reversing its orientation, using the wrong angle for a six-fold rosette, expecting a translation to resize, or positioning a next copy by eye instead of exact movement.

**GCSE extension:** Frieze/symmetry groups, combinations of transformations and invariant properties.

**Linked engines:** F0-02, F0-03, F0-04, F14-03, F14-05, F14-07, F14-08, F14-09.

## QA results

- Browser/maths regression: **104/104 passed** (380px and 1280px; all four modes; six presets; no JS exceptions; no horizontal overflow; single mascot dock; six challenge responses including interactive task).
- Real pointer stress: **10/10 passed** (380px and 1280px; physical mouse-to-target drag, snap, Escape cancellation, tray recovery).
- Removal regression: **2/2 passed** (real mouse drag of placed motif into red remove zone on 380px and 1280px). See final run of `_f14_13_remove.py`.
- Common premium core: exact equality checked against F14-12 JS core (without changing that shared source).
- Mathematics: 5 alternating reflection copies follow vertical mirror lines; glide pattern reflects across its horizontal guide at y=1.8 and translates by repeat step; each adjacent rosette copy rotates exactly 60° about O.
- Screenshots: **10** files, Watch / Guided / Explore / Challenge / placed at each viewport width; see `screenshots/`.
- **Review-only:** User visual and physical device approval remains required; this is not a GOLD certification.

## Files

`F14-13-pattern-makers-PREMIUM.html` — standalone complete engine; all assets embedded.

No source-bank files, GitHub commits, external fonts or external dependencies are included.
