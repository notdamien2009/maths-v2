# F11-07 — Regular Polygon Builder · Premium Review

**Review build, not owner GOLD-approved. GitHub untouched.**

## Output
- `F11/F11-07-regular-polygon-builder.html` is self-contained (embedded NOVA F0/F1 shared core, component styles, SVG and JavaScript). Open directly in a browser.
- `src/F11-07.js` and `.css` are the editable component-only sources.
- `build/F11-07.src.html` and `build/build-F11-07.py` rebuild the standalone HTML using the installed bank's shared `core/nova-core.js` and `.css`.

**Core preservation:** Neither shared core file is included in this ZIP; the components do not modify the core. The supplied HTML was built from the same local core snapshot used for F11-06 (JS SHA256 `98c73b52bd54d9f98c2fe4187c28d27ad9cfda6a51e6e258fc752e898d0029af`, CSS SHA256 `f4a6ad467f3f2efe4cbcc641efc70deceb8af2f3af422cee687e57f4673fde6b`). If your current checkout's core hashes differ, rebuild locally and re-run tests and visual checks before acceptance. This preserves the repository's canonical core rather than overwriting it.

## Teaching and maths
- 14 progressive Watch/Guided beats: circle, centre, equally spaced vertices, chords, central sectors, interior/exterior turns, generalisation.
- Exact regular polygons for 3–12 sides. All vertices lie on one circumcircle; side lengths are equal.
- Central and exterior angles: `360/n` degrees; interior angle: `180−360/n` degrees; interior sum: `(n−2)×180` degrees.
- Explore: side-count/preset controls, rotary vertex handle and radius grip with pointer capture and frame-synchronised updates, keyboard arrows, Escape rollback and reset.
- Challenge: 8 numerical questions PLUS selected/dragged mathematical reasons, with reason-specific feedback and no result card leak before checking.
- Presets: Y7-044, Y8-049, Y9-026, equilateral triangle, square, decagon.

## Visual consistency
- Reuses the established F11/F0 stage background, F0 Chalk typography, F9-sized in-container mascot dock and four-mode shell.
- Neon drawing is computed from mathematical vertices and drawn through NOVA core helpers; no external assets or libraries.
- Corrected a fast-drag fault during QA: the grip remains a stable node above the dynamic geometry layer so pointer capture is not interrupted by the redraw.

## Tests
- **166/166 passing**, with zero failures, at 380px and 1280px. Run `python tests/test_f117.py` after rebuilding. The suite tests 3–12-side construction, central/interior/exterior rules, all modes, answer secrecy, eight challenge solutions, live drag, Escape, keyboard and reason-card drop.
- Screenshots in `shots/F11-07/` show desktop/mobile modes and the interactive octagon.

## Review status
Premium Review candidate — user visual/physical-device stress test still required. Reason cards drag to the reason area, not directly onto individual SVG angle sectors; this remains a master-spec enhancement for a later targeted pass.
