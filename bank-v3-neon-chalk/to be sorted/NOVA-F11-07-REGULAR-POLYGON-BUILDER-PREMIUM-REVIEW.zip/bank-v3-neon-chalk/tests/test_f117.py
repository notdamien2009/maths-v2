#!/usr/bin/env python3
"""F11-07 automated QA: actual page, exact geometry, keyboard/pointer, four modes, challenge maths."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json,sys,math
root=Path(__file__).resolve().parents[1]
source=(root/'F11/F11-07-regular-polygon-builder.html').read_text()
source=source.replace("N.registry.add({id:ID,title:'Regular Polygon Builder'","window.__mathTest={vertices,calc};N.registry.add({id:ID,title:'Regular Polygon Builder'")
shots=root/'shots/F11-07';shots.mkdir(parents=True,exist_ok=True)
passlist=[];fails=[]
def check(name,cb):
 try: assert cb(),name;passlist.append(name)
 except Exception as e:fails.append(dict(check=name,error=str(e)[:350]))
def xy(page,x,y):return page.evaluate('''p=>{let svg=document.querySelector('[data-testid=f117-svg]'),pt=svg.createSVGPoint();pt.x=p[0];pt.y=p[1];let v=pt.matrixTransform(svg.getScreenCTM());return [v.x,v.y]}''',[x,y])
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in [380,1280]:
  page=b.new_page(viewport={'width':w,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(source,wait_until='load');page.wait_for_timeout(170)
  check(f'{w}: engine mounts',lambda:page.locator('#F11-07').count()==1)
  check(f'{w}: stage present',lambda:page.locator('[data-testid=f117-stage]').count()==1)
  check(f'{w}: all four modes',lambda:page.get_by_role('tab').count()==4)
  check(f'{w}: font embedded',lambda:page.evaluate('document.fonts.check("20px NOVA Chalk")'))
  check(f'{w}: mascot contained',lambda:page.evaluate('''()=>{let a=document.querySelector('#F11-07 .f117-theatre').getBoundingClientRect(),b=document.querySelector('#F11-07 .f117-theatre .nv-dockfig').getBoundingClientRect();return b.left>=a.left-2&&b.right<=a.right+2&&b.top>=a.top-2&&b.bottom<=a.bottom+2}'''))
  for n in range(3,13):
   vals=page.evaluate('''n=>{let p=__mathTest.vertices(n,188,-90),f=__mathTest.calc(n);return {centre:p.every(pt=>Math.abs(Math.hypot(pt[0]-366,pt[1]-257)-188)<1e-7),edges:p.map((pt,i)=>Math.hypot(pt[0]-p[(i+1)%n][0],pt[1]-p[(i+1)%n][1])),...f}}''',n)
   check(f'{w}: {n}-gon equally spaced on circle',lambda v=vals:v['centre'])
   check(f'{w}: {n}-gon equal sides',lambda v=vals:max(v['edges'])-min(v['edges'])<1e-6)
   check(f'{w}: {n}-gon 360 degree sector sum',lambda v=vals,n=n:abs(v['central']*n-360)<1e-7)
   check(f'{w}: {n}-gon exterior angle',lambda v=vals,n=n:abs(v['exterior']*n-360)<1e-7)
   check(f'{w}: {n}-gon interior angle sum',lambda v=vals,n=n:abs(v['interior']*n-v['total'])<1e-7)
  check(f'{w}: initial no runtime exceptions',lambda:errors==[])
  page.screenshot(path=str(shots/f'F11-07-{w}-explore.png'),full_page=True,animations='disabled')
  side=page.locator('[data-testid=f117-sides]');side.fill('8');page.wait_for_timeout(75)
  check(f'{w}: side control changes polygon',lambda:page.locator('.f117-card .f117-main').first.inner_text()=='8')
  check(f'{w}: selected central angle recalculated',lambda:page.locator('.f117-card .f117-main').nth(1).inner_text()=='45°')
  page.locator('[data-testid=f117-view]').select_option('interior');page.wait_for_timeout(65)
  check(f'{w}: selected interior angle recalculated',lambda:page.locator('.f117-card .f117-main').nth(2).inner_text()=='135°')
  # Rotate a vertex by direct fast pointer move, then escape rollback.
  hand=page.locator('[data-testid=f117-rotation-handle]');hand.scroll_into_view_if_needed();start=float(hand.get_attribute('aria-valuenow'));r=page.locator('[data-testid=f117-radius]').input_value();radius=float(r)
  hbox=hand.bounding_box();end=xy(page,*[366+radius*math.cos(math.radians(-50)),257+radius*math.sin(math.radians(-50))]);page.mouse.move(hbox['x']+hbox['width']/2,hbox['y']+hbox['height']/2);page.mouse.down();page.mouse.move(*end,steps=1);page.wait_for_timeout(100)
  check(f'{w}: fast vertex rotation live',lambda:float(hand.get_attribute('aria-valuenow'))>-70)
  page.keyboard.press('Escape');page.wait_for_timeout(90)
  check(f'{w}: rotation Escape rollback',lambda:abs(float(hand.get_attribute('aria-valuenow'))-start)<1e-7)
  page.mouse.up();hand.focus();page.keyboard.press('ArrowRight');page.wait_for_timeout(55)
  check(f'{w}: keyboard rotate',lambda:float(hand.get_attribute('aria-valuenow'))==start+5)
  # Resize radius by pointer, release and keyboard.
  rad=page.locator('[data-testid=f117-radius-handle]');rad.scroll_into_view_if_needed();b2=rad.bounding_box();old=float(rad.get_attribute('aria-valuenow'));dest=xy(page,366+old-22,257)
  page.mouse.move(b2['x']+b2['width']/2,b2['y']+b2['height']/2);page.mouse.down();page.mouse.move(*dest,steps=1);page.wait_for_timeout(70)
  check(f'{w}: live radius drag',lambda:float(rad.get_attribute('aria-valuenow'))<old-10)
  page.mouse.up();rad.focus();val=float(rad.get_attribute('aria-valuenow'));page.keyboard.press('ArrowRight');page.wait_for_timeout(50)
  check(f'{w}: radius keyboard',lambda:float(rad.get_attribute('aria-valuenow'))==val+5)
  check(f'{w}: no drag errors',lambda:errors==[])
  page.screenshot(path=str(shots/f'F11-07-{w}-octagon-explore.png'),full_page=True,animations='disabled')
  for mode in ['Watch','Guided','Challenge']:
   page.get_by_role('tab',name=mode,exact=True).click();page.wait_for_timeout(105)
   check(f'{w}: {mode} visible SVG',lambda:page.locator('[data-testid=f117-svg]').count()==1)
   check(f'{w}: {mode} runtime clean',lambda:errors==[])
   page.screenshot(path=str(shots/f'F11-07-{w}-{mode.lower()}.png'),full_page=True,animations='disabled')
   if mode=='Challenge':check(f'{w}: answer not leaked before check',lambda:page.locator('[data-testid=f117-aside] .f117-main').all_inner_texts()[1:]==['?','?','?'])
  # Drag an explanation card into the reason target.
  reason=page.locator('button[data-reason="centre"]');drop=page.locator('[data-testid=f117-reason-drop]');reason.scroll_into_view_if_needed();bb=reason.bounding_box();dd=drop.bounding_box();page.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);page.mouse.down();page.mouse.move(dd['x']+dd['width']/2,dd['y']+dd['height']/2,steps=4);page.mouse.up();page.wait_for_timeout(70)
  check(f'{w}: reason drag-and-drop',lambda:drop.get_attribute('data-set')=='true')
  check(f'{w}: reason drag no runtime error',lambda:errors==[])
  for i,(v,reason) in enumerate([(120,'centre'),(72,'centre'),(120,'straight'),(45,'turn'),(36,'centre'),(900,'triangles'),(140,'straight'),(30,'turn')],1):
   page.locator('[data-testid=f117-answer]').fill(str(v));page.locator(f'button[data-reason="{reason}"]').click();page.get_by_role('button',name='Check angle + reason').click();page.wait_for_timeout(65)
   if i<8:
    check(f'{w}: challenge {i} correct',lambda:page.get_by_role('button',name='Next challenge →').count()==1)
    page.get_by_role('button',name='Next challenge →').click();page.wait_for_timeout(50)
   else:check(f'{w}: final mastery',lambda:page.get_by_text('8 / 8 · REGULAR POLYGONS MASTERED').count()==1)
  check(f'{w}: final no exceptions',lambda:errors==[])
  page.close()
 b.close()
result={'checks':len(passlist)+len(fails),'passed':len(passlist),'failed':fails,'widths':[380,1280]}
(root/'tests/F11-07-QA.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2));sys.exit(1 if fails else 0)
