# NOVA Maths V2 · F13 Family Audit

**Review build only:** production/final GOLD status is not inferred from automated checks.

## Scope
Audited all 14 corrected premium-core HTML files currently in `/mnt/data`, F13-01 through F13-14, and their 14 individual original ZIP files. Excluded superseded standalone F13-01, F13-02 and F13-03 versions. No GitHub changes.

## Source integrity
- All 14 primary HTML files match the corresponding entry inside their original individual review ZIPs exactly.
- All 14 embed the same SHA-256 NOVA JavaScript core: `79abfd9ec5be96c973f28ec7e81e4724c960c9fb8b5fb14af65401eedea49513`.
- That core hash also matches the uploaded approved reference `F12-03-geoboard-builder(1).html`.
- The final ZIP includes the individual engines' editable files and QA evidence under `source/F13-xx`.

## Newly repeated browser smoke tests
- **364/364 checks passed** across **28 Chromium runs** (14 components × 2 viewport widths: 1280px and 380px).
- Checks: stage count, official cat asset presence, embedded core available, SVG rendering, mascot dock within the stage, no sideways page overflow, switching all four learning modes, and zero uncaught JS errors.
- Real component screenshots are included under `screenshots/`, selected from the original review ZIPs or captured from the original stage in Chromium (F13-11, 12 and 14 mobile).

## Discovered and corrected metadata
- **F13-06**: stale F13-05 HTML document title → corrected in combined bundle.
- **F13-07**: stale F13-05 HTML title and old prism subtitle → corrected in combined bundle.
- **F13-08**: stale F13-05 HTML title and old prism subtitle → corrected in combined bundle.
- All three changes are limited to `<title>` or the `data-sub` attribute on `#nova-header`. No shared styles, mascot art, NOVA runtime, engines or interactions were altered.
- Original files and Library entries remain unchanged; only bundle copies incorporate the metadata corrections.

## Limits of this family-level audit
Previous detailed maths, drag, timing, folding and challenge checks are documented in the respective individual source/QA reports. This family-level run **does not** independently repeat every one of those tests, does **not** prove pedagogy is perfect, and does **not** represent the user's final design or GOLD approval. Open each component, stress-test, and record any revisions before Git integration.

## Inventory
| ID | Component | Reported individual QA | This audit: 1280px / 380px |
|---|---|---|---|
| F13-01 | 3D Solid Viewer | 62/62 | 13/13 / 13/13 |
| F13-02 | Net Folder | 88/88 | 13/13 / 13/13 |
| F13-03 | Isometric Drawing Studio | 118/118 | 13/13 / 13/13 |
| F13-04 | Plans and Elevations | 126/126 | 13/13 / 13/13 |
| F13-05 | Cube-Stacking Volume | 135/135 | 13/13 / 13/13 |
| F13-06 | Prism Volume Slicer | 148/148 | 13/13 / 13/13 |
| F13-07 | Cuboid Volume and Surface Area | 239/239 | 13/13 / 13/13 |
| F13-08 | Cylinder Unroll | 248/248 | 13/13 / 13/13 |
| F13-09 | Pyramid and Cone Fill | 158/158 | 13/13 / 13/13 |
| F13-10 | Sphere Volume and Surface Area | 175/175 | 13/13 / 13/13 |
| F13-11 | Cross-Sections Explorer | 121/121 | 13/13 / 13/13 |
| F13-12 | Capacity and Volume Conversion | 114/114 | 13/13 / 13/13 |
| F13-13 | Surface-Area Unfolder | 644/644 | 13/13 / 13/13 |
| F13-14 | Solid Enlargement | 246/246 | 13/13 / 13/13 |

## Contents
`index.html` (family launcher); `components/` (14 standalone premium builds); `source/` (editable source/build scripts/individual QA); `screenshots/` (28 selected review-stage views plus contact sheet); `F13-FAMILY-MANIFEST.json` and `.csv`.
