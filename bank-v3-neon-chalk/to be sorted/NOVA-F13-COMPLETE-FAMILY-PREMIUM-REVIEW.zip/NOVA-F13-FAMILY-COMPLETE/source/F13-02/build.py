from pathlib import Path
p=Path('/mnt/data/F12-03-geoboard-builder(1).html')
s=p.read_text()
b=s.index('<script>\n/* ===== F12-03 CONFIG:')
e=s.index('</script>',b)
s=s[:b]+'<script>\n'+Path('/mnt/data/f13_02_premium/engine.js').read_text()+'\n'+s[e:]
s=s.replace('<title>NOVA F12-03 · Geoboard builder</title>','<title>NOVA F13-02 · Premium Net Folder</title>')
s=s.replace('data-run="F12 · 2D shapes, perimeter and area · F12-03" data-title="Geoboard builder" data-sub="Stretch a band round pegs to make shapes, then read their area, perimeter and name."', 'data-run="F13 · 3D shapes, volume and surface area · F13-02" data-title="Net folder" data-sub="Fold accurate flat nets into cubes, cuboids, prisms and pyramids with glowing hinged faces."')
css='''
/* F13-02 · additive component-specific rules; NOVA source frame is never replaced */
.f13-net-svg{width:100%!important;max-width:810px!important;height:auto!important;display:block;margin:4px auto 0!important;touch-action:none;cursor:grab;outline:none;user-select:none}
.f13-net-svg:focus-visible{outline:2px dashed var(--m-focus);outline-offset:-4px;border-radius:12px}
.f13-net-svg.f13-grabbing{cursor:grabbing}
.f13-net-geometry{pointer-events:none}
.f13-loose-face{pointer-events:all;cursor:grab;touch-action:none}
.f13-loose-face:focus-visible{filter:drop-shadow(0 0 5px #ffe07c)}
.f13-number-label{display:inline-flex;align-items:center;gap:8px;color:var(--v-ink);font:700 .85rem var(--nova-font-ui)}
.f13-number-label input{accent-color:var(--math-cyan)}
.f13-panel-row{margin-top:9px}
.f13-panel-row label{font:700 .94rem var(--nova-font-chalk-draw);color:var(--v-ink)}
.f13-panel-row select{margin-left:7px;max-width:260px}
.f13-fold-range{width:min(280px,36vw);accent-color:var(--math-cyan);margin:0 10px}
.f13-progress{font:700 1.2rem var(--nova-font-chalk-draw);min-width:53px;color:var(--math-cyan)}
.f13-teach-note{color:var(--v-ink);opacity:.88;font:700 .89rem/1.45 var(--nova-font-ui);margin:10px 0 4px}
.f13-choices{display:flex;gap:12px;flex-wrap:wrap;align-items:stretch;margin-top:9px}
.f13-choice{display:flex;flex-direction:column;align-items:center;gap:2px;min-width:140px;max-width:210px;border-radius:13px}
.f13-choice[aria-pressed=true]{outline:2px solid var(--math-green);box-shadow:0 0 18px #4fe2a155}
.f13-thumb-svg{width:92px;height:92px}
.nova-stage>.f13-net-svg{flex:0 0 auto}
@media(max-width:580px){.f13-net-svg{margin-top:7px!important}.f13-fold-range{width:min(55vw,250px)}.f13-teach-note{font-size:.82rem}.f12-strip{gap:5px;padding-left:4px;padding-right:4px}.f12-strip .nv-ntile{padding:3px 9px;font-size:1.05rem}}
'''
s=s.replace('</style>\n</head>',css+'</style>\n</head>',1)
out=Path('/mnt/data/F13-02-Net-Folder-PREMIUM-CORE.html');out.write_text(s)
print('built',out,out.stat().st_size,'unchanged F12 core before script',b)
