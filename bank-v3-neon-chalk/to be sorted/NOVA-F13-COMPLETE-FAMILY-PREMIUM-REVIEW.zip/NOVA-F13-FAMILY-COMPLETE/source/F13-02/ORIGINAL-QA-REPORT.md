# F13-02 — Premium Net Folder — QA and Visual Review

STATUS: Review build; user approval still required. Do not push to GitHub.

## Source / non-drift checks

- Used the user-uploaded `F12-03-geoboard-builder(1).html` as the exact NOVA core and frame source.
- The embedded production JavaScript core is **byte-for-byte identical** to the source, confirmed in the packaging assertion.
- Preserved the official NOVA mascot WebP pose packs, F0/F1 SVG primitives, design tokens, chalk fonts, premium stage background and mascot dock.
- Replaced the F12-03-specific engine with the F13-02 hinged geometry; only additive F13 CSS and page metadata were added.
- Compared the rendered frame against the approved F13-01 premium rebuild.

## Automated Chromium checks

- Main browser suite: **88/88** passing across 1280px and 380px.
- Additional controls/navigation suite: **14/14** passing across 1280px and 380px.
- Total **102/102**, zero failing assertions.
- No uncaught page JavaScript errors observed; no horizontal document overflow.

### Verified functionality

1. Eight Watch teaching steps, Guided prompts, Explore and Challenge.
2. Cube, cuboid (six faces each), triangular prism and square pyramid (five faces each).
3. True hinged-face nets, 0–100% fold slider, camera rotation and alternate cube net.
4. Twenty successive fast mouse moves with pointer capture; keyboard arrow rotation.
5. Detach cube end face, drag and snap to glowing green target; keyboard Enter snap, Escape fallback.
6. Three marked challenges: valid cube net, cuboid surface area 22 cm², triangular prism five faces.
7. Wrong-answer misconception feedback; one mascot inside stage at desktop and mobile sizes.
8. Folding animation cancels correctly when switching learning modes; working Show Face Numbers and Open Flat controls.

## Limitations

- Review build; independent visual/pedagogical approval is still needed.
- Tests were browser-based and do not cover every device or assistive technology.
- Nothing was pushed to GitHub; the rejected older standalone F13-02 is not included.
