# NOVA F13-03 — Premium Isometric Drawing Studio · Review QA

**Status:** Review build. **Automated browser checks: 118/118 passing.** No JavaScript page errors observed at either 1280px or 380px Chromium viewports.

## Canonical source integrity

- Canonical NOVA JavaScript core SHA-256 begins `79abfd9ec5be96c9` in the user's uploaded F12-03 and the accepted F13-02 premium-core build; **same SHA** in this F13-03 build.
- Canonical production CSS, fonts, page shell, mascot drawing implementation, stage/background and core interactions are inherited from F12-03. Only component-specific CSS is appended.
- Full official mascot image pose pack remains embedded, and one official NOVA mascot is in the original in-stage helper dock.
- Original stage background and frame remain unchanged, with no replacement stage or extra middle row.
- Source engine is F13-03-specific. GitHub has not been written to.

## Mathematical QA

- Exact isometric projection: x/y axes at ±30° and z vertical.
- Stacked cubes are located on a 4×4 footprint and each column has an integer height 0–4.
- Exterior top and side surfaces are generated from the current cube data; touching interior faces are suppressed.
- Seven checked presets: one cube, two adjacent cubes, 2×2 platform, 3-high tower, L shape (4 cubes), three-step stairs (6 cubes), hidden-cube model (6 cubes).
- Watch uses 9 teaching beats, with narration and prediction prompts; additional Guided, Explore and Challenge modes.
- Challenge marking verifies both column coordinates and stack heights. Identical total counts in wrong positions are rejected.

## Interaction QA

- Add, erase, inspect, live counters, pointer capture, rapid drag across multiple columns, undo/redo and clear.
- Keyboard cursor movement, Enter to add, Delete to remove. Board reset centres the keyboard cursor.
- Pencil-edge mode, dots visibility, three-axis visibility and height labels.
- No horizontal overflow at 1280px or 380px.
- Screenshot evidence included for both sizes and modes; 1280px screens for all seven presets.

## Known scope

- Intended for review and visual approval, not automatically GOLD approval.
- Isometric construction is represented by snap-to-grid cube outlines/solids. Full freehand line drawing and orthographic elevations are not part of F13-03; plans/elevations are assigned to F13-04.
