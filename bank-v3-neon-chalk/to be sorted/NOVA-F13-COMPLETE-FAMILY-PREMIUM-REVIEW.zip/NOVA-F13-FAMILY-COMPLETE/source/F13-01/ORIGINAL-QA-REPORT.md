# NOVA F13-01 — source-grounded rebuild QA

Status: review; not approved GOLD.

## Source integration verification

- Frame: directly inherited from user-provided `F12-03-geoboard-builder(1).html`.
- Original NOVA core JS preserved **byte-for-byte** (1,074,735 characters in the original extraction).
- All embedded official helper images, helper poses, NOVA Chalk WOFF2 fonts and background CSS retained.
- Existing F0 neon primitives, core timeline, state handling, events, challenge runner, helper dock and `NOVA.bankMount` retained.
- Additive F13-specific CSS only; engine behaviour supplied in standalone `source/F13-01-engine.js`.
- Official helper is inside `.nova-stage` and the shared `.nv-dock` container, not hand drawn.

## Browser verification

- **62/62 automated checks passed** via headless Chromium at widths 1280px and 380px.
- Seven lesson steps displayed; Watch, Guided, Explore and Challenge loaded.
- Seven solids rendered (cube, cuboid, triangular prism, square pyramid, cylinder, cone, sphere).
- Twenty consecutive pointer moves per viewport width, then pointer release; keyboard arrow rotation; no horizontal overflow.
- Edge-reveal toggle, face/edge/vertex modes, misconception feedback, all three challenge answers.
- No unhandled JavaScript exceptions observed in those tests.
- Screenshots included in `screenshots/` for human review.

## Maths conventions

Counts for cube (6,12,8), cuboid (6,12,8), triangular prism (5,9,6), square pyramid (5,8,5). For cylinder, cone and sphere, curved components are labelled **surfaces**: cylinder (3 surfaces,2 circular edges,0 vertices), cone (2 surfaces,1 circular edge,1 vertex), sphere (1 curved surface,0 edges,0 vertices).

## Pending user approval

Visual GOLD status cannot be determined by automated pass counts. Compare screen outputs against the user's approved F0, F1, F2 and attached F12 references. No GitHub changes made.
