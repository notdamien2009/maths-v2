# F13-13 Surface-Area Unfolder — QA Report

**Status:** Premium-core REVIEW build, not final GOLD approval. **GitHub:** unchanged.

## Production integrity

- Original, approved embedded NOVA core CSS: unchanged. SHA-256 `258729762fb387a1214b4ce6a5aab1fecde386711c2b7259446d1eff1c2ae97a`
- Original embedded NOVA JavaScript: unchanged. SHA-256 `79abfd9ec5be96c973f28ec7e81e4724c960c9fb8b5fb14af65401eedea49513`
- Official NOVA cat mascot, speech dock, background, Chalk fonts, F0/F1/F12 tools are inherited from the original embedded HTML.
- Only the F13-12 add-on CSS/engine were replaced by new F13-13 local code. The standalone HTML and supplied build script are self-contained.

## Browser QA

**644/644 passing assertions** in Chromium at 1280px and 380px, with no unhandled JavaScript errors.

Checks include all four modes and eight solids; the exact number of faces and surface-area calculations; summation of face areas; each rigid polygon preserving its area at fold increments 0%, 25%, 50%, 75%, 100%; each hinge remaining connected to both of its faces; complete nets; all-face tally and clearing; clickable face selection and deselection; hiding the total surface area until a correct Challenge answer; keyboard Home/End controls; 20 rapid mouse movements under pointer capture; four correctly marked mathematical challenges and rejection of a wrong answer; dock kept inside stage; no horizontal overflow.

All 12 Watch teaching steps were separately navigated with the real timeline controls, with no browser errors. Stage header correctly follows the solid selected. Manual rendered stage screenshots provided for all four solids at 0%, 50%, and 100% unfolded, in both viewport widths.

## Verified reference results

| Model | Surface area |
|---|---:|
| Cube, side 2 | 24 units² |
| Cube, side 3 | 54 units² |
| Cuboid 4 × 3 × 2 | 52 units² |
| Cuboid 5 × 2 × 1 | 34 units² |
| Equilateral triangular prism, side 4, length 6 | 72 + 8√3 ≈ 85.86 units² |
| Equilateral triangular prism, side 3, length 5 | 45 + (9√3)/2 ≈ 52.79 units² |
| Square pyramid, base side 4, slant height 3 | 40 units² |
| Square pyramid, base side 6, slant height 5 | 96 units² |

## Review notes

- Triangular prism examples use equilateral triangles, with exact triangular areas and two-decimal displayed totals; the perpendicular height, not sloping edge, is used for triangle area.
- Square pyramid examples use triangular-face **slant height** for surface area, not the pyramid's vertical height.
- Face selection is live in Explore; Watch and Guided are teaching stages. Challenge masks the whole-solid surface-area total until the answer is correctly marked, while showing individual face areas so pupils can reason through the sum.
- Visual approval by the project owner is still needed; QA is not a substitute for production GOLD approval.
