"""Reproduce F13-13 while preserving the approved F13-12 embedded NOVA CSS/JS core."""
from pathlib import Path
P=Path(__file__).resolve().parent
src=(P/'F13-12-PREMIUM-CORE-BASE.html').read_text()
css=(P/'f13_13_addon.css').read_text()
engine=(P/'f13_13_engine.js').read_text()
a=src.index('/* F13-12 additive styles');b=src.index('</style>',a)
src=src[:a]+css+'\n'+src[b:]
a=src.index('/* F13-12 CAPACITY AND VOLUME CONVERSION');b=src.rfind('</script>')
src=src[:a]+engine+'\n'+src[b:]
src=src.replace('NOVA F13-12 · Premium Capacity and Volume Conversion','NOVA F13-13 · Premium Surface-Area Unfolder')
src=src.replace('data-run="F13 · 3D shapes, volume and surface area · F13-12" data-title="Capacity and volume conversion" data-sub="See why a cubic centimetre holds one millilitre and how one litre fits into a ten-centimetre cube."','data-run="F13 · 3D shapes, volume and surface area · F13-13" data-title="Surface-area unfolder" data-sub="Open real connected surface nets, count the hidden faces, and add each area in square units."')
out=P.parent/'F13-13-Surface-Area-Unfolder-PREMIUM-CORE.html'
out.write_text(src)
print('Built',out,'(',out.stat().st_size,'bytes)')
