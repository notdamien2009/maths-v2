/* F13-13 SURFACE-AREA UNFOLDER — additive maths engine, official NOVA core unchanged. */
var NOVA_F13_13_CONFIG={startMode:'watch',presets:{cube2:'Cube · side 2',cube3:'Cube · side 3',cuboid:'Cuboid · 4 × 3 × 2',parcel:'Cuboid · 5 × 2 × 1',prism:'Equilateral triangular prism · side 4, length 6',prismSmall:'Equilateral prism · side 3, length 5',pyramid:'Square pyramid · base 4, slant height 3',pyramidLarge:'Square pyramid · base 6, slant height 5'}};
(function(){'use strict';
var EN='F13-13',CFG=NOVA_F13_13_CONFIG,h=NOVA.h,S=NOVA.svg,F=NOVA.f12,colors=['#43eafc','#ac9bff','#ffb578','#82f5bc','#ffdf85','#7eaaff'];
var DATA={
 cube2:{kind:'cube',dims:[2,2,2],name:'CUBE · 2 × 2 × 2'},cube3:{kind:'cube',dims:[3,3,3],name:'CUBE · 3 × 3 × 3'},
 cuboid:{kind:'cuboid',dims:[4,3,2],name:'CUBOID · 4 × 3 × 2'},parcel:{kind:'cuboid',dims:[5,2,1],name:'CUBOID · 5 × 2 × 1'},
 prism:{kind:'prism',dims:[4,6],name:'TRIANGULAR PRISM · SIDE 4 · LENGTH 6'},prismSmall:{kind:'prism',dims:[3,5],name:'TRIANGULAR PRISM · SIDE 3 · LENGTH 5'},
 pyramid:{kind:'pyramid',dims:[4,3],name:'SQUARE PYRAMID · BASE 4 · SLANT 3'},pyramidLarge:{kind:'pyramid',dims:[6,5],name:'SQUARE PYRAMID · BASE 6 · SLANT 5'}
};
function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
function num(x){return +(+x).toFixed(3);}
function fmt(x){return Math.abs(x-Math.round(x))<1e-7?String(Math.round(x)):String(Math.round(x*100)/100);}
function v(x,y,z){return [x,y,z||0];}
function add(a,b){return [a[0]+b[0],a[1]+b[1],a[2]+b[2]];}
function sub(a,b){return [a[0]-b[0],a[1]-b[1],a[2]-b[2]];}
function mul(a,t){return [a[0]*t,a[1]*t,a[2]*t];}
function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}
function dot(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
function avg(p){return mul(p.reduce(add,[0,0,0]),1/p.length);}
function rect(x,y,X,Y){return [[x,y],[X,y],[X,Y],[x,Y]];}
function face(id,title,poly,parent,a,b,degrees,role){return {id:id,title:title,poly:poly,parent:parent==null?-1:parent,a:a||null,b:b||null,degrees:degrees||90,role:role||'given'};}
function model(key){var d=DATA[key]||DATA.cuboid,a=d.dims,fs=[];
 if(d.kind==='cube'||d.kind==='cuboid'){
  var l=a[0],w=a[1],z=a[2],x=-l/2,X=l/2,y=-w/2,Y=w/2;
  fs=[face('base','BASE',rect(x,y,X,Y),-1,null,null,0,'given'),face('north','FRONT',rect(x,y-z,X,y),0,[x,y],[X,y],90,'op'),face('south','BACK',rect(x,Y,X,Y+z),0,[x,Y],[X,Y],90,'op'),face('west','LEFT',rect(x-z,y,x,Y),0,[x,y],[x,Y],90,'focus'),face('east','RIGHT',rect(X,y,X+z,Y),0,[X,y],[X,Y],90,'focus'),face('lid','TOP',rect(x,y-z-w,X,y-z),1,[x,y-z],[X,y-z],90,'given')];
 }else if(d.kind==='prism'){
  var s=a[0],L=a[1],x=-L/2,X=L/2,y=-s/2,Y=s/2,A=s*Math.sqrt(3)/2;
  fs=[face('rectA','SIDE A',rect(x,y,X,Y),-1,null,null,0,'op'),face('rectB','SIDE B',rect(x,y-s,X,y),0,[x,y],[X,y],120,'op'),face('rectC','SIDE C',rect(x,y-2*s,X,y-s),1,[x,y-s],[X,y-s],120,'op'),face('triL','END 1',[[x,y],[x,Y],[x-A,0]],0,[x,y],[x,Y],90,'focus'),face('triR','END 2',[[X,y],[X,Y],[X+A,0]],0,[X,y],[X,Y],90,'focus')];
 }else{
  var s=a[0],sl=a[1],half=s/2,ang=Math.acos(-half/sl)*180/Math.PI;
  fs=[face('base','SQUARE BASE',rect(-half,-half,half,half),-1,null,null,0,'given'),face('north','TRIANGLE 1',[[-half,-half],[half,-half],[0,-half-sl]],0,[-half,-half],[half,-half],ang,'focus'),face('south','TRIANGLE 2',[[-half,half],[half,half],[0,half+sl]],0,[-half,half],[half,half],ang,'focus'),face('west','TRIANGLE 3',[[-half,-half],[-half,half],[-half-sl,0]],0,[-half,-half],[-half,half],ang,'focus'),face('east','TRIANGLE 4',[[half,-half],[half,half],[half+sl,0]],0,[half,-half],[half,half],ang,'focus')];
 }
 fs.forEach(function(f,i){var z=f.poly,s=0;for(var j=0;j<z.length;j++){var q=z[j],t=z[(j+1)%z.length];s+=q[0]*t[1]-q[1]*t[0];}f.area=Math.abs(s)/2;f.i=i;});
 return fs;}
function area(key){return model(key).reduce(function(s,f){return s+f.area;},0);}
function groupName(key,id){var d=DATA[key]||DATA.cuboid;if(d.kind==='cube'||d.kind==='cuboid')return id==='base'||id==='lid'?'given':id==='north'||id==='south'?'op':'focus';return id==='base'?'given':d.kind==='prism'&&id.indexOf('rect')===0?'op':'focus';}
function areaSentence(key){var d=DATA[key]||DATA.cuboid,a=d.dims;
 if(d.kind==='cube')return '6 × ('+a[0]+' × '+a[0]+') = '+fmt(area(key))+' units²';
 if(d.kind==='cuboid')return '2 × ('+(a[0]*a[1])+' + '+(a[0]*a[2])+' + '+(a[1]*a[2])+') = '+fmt(area(key))+' units²';
 if(d.kind==='prism')return '3 × ('+a[0]+' × '+a[1]+') + 2 × (√3/4 × '+a[0]+'²) = '+fmt(area(key))+' units²';
 return a[0]+'² + 4 × (½ × '+a[0]+' × '+a[1]+') = '+fmt(area(key))+' units²';}
function state(key){return {preset:key||'cuboid',fold:0,selected:'',included:[],showAreas:true,yaw:-.64,pitch:.68,sv:null,refresh:null,raf:0,animation:0,finished:false};}
function spin(p,a,b,theta){var u=sub(b,a),len=Math.hypot(u[0],u[1],u[2])||1;u=mul(u,1/len);var q=sub(p,a),c=Math.cos(theta),s=Math.sin(theta);return add(a,add(add(mul(q,c),mul(cross(u,q),s)),mul(u,dot(u,q)*(1-c))));}
function folds(key,progress){var fs=model(key);
 function to3(p,i){if(i<0)return p;var f=fs[i];if(f.parent<0)return p;var pa=fs[f.parent],pc=avg(pa.poly.map(q=>v(q[0],q[1]))),fc=avg(f.poly.map(q=>v(q[0],q[1]))),dx=f.b[0]-f.a[0],dy=f.b[1]-f.a[1],side=Math.sign(dx*(fc[1]-pc[1])-dy*(fc[0]-pc[0]))||1;return to3(spin(p,v(f.a[0],f.a[1]),v(f.b[0],f.b[1]),side*f.degrees*Math.PI/180*progress),f.parent);}
 return fs.map(function(f,i){var pts=f.poly.map(q=>to3(v(q[0],q[1]),i));return {f:f,pts:pts,centre:avg(pts),hinge:f.parent<0?null:[to3(v(f.a[0],f.a[1]),f.parent),to3(v(f.b[0],f.b[1]),f.parent)]};});}
function camera(p,s){var t=Math.min(1,s.fold*2.3),ca=Math.cos(s.yaw),sa=Math.sin(s.yaw),co=Math.cos(s.pitch),si=Math.sin(s.pitch),u=p[0]*ca-p[1]*sa,q=p[0]*sa+p[1]*ca;return [p[0]*(1-t)+u*t,p[1]*(1-t)+(p[2]*co+q*si)*t,(p[2]*si-q*co)*t];}
function project(mesh,s,W){var cp=mesh.map(function(e){return {f:e.f,pts:e.pts.map(p=>camera(p,s)),centre:camera(e.centre,s),hinge:e.hinge?e.hinge.map(p=>camera(p,s)):null};});var all=cp.flatMap(e=>e.pts),xs=all.map(p=>p[0]),ys=all.map(p=>p[1]),minx=Math.min(...xs),maxx=Math.max(...xs),miny=Math.min(...ys),maxy=Math.max(...ys),ww=Math.max(.1,maxx-minx),hh=Math.max(.1,maxy-miny),mobile=W<500,sc=Math.min((mobile?359:620)/ww,(mobile?292:290)/hh,mobile?132:140),cx=(minx+maxx)/2,cy=(miny+maxy)/2,yMid=mobile?231:229;
 function pt(p){return [W/2+(p[0]-cx)*sc,yMid-(p[1]-cy)*sc,p[2]];}var glob=avg(cp.map(q=>q.centre));cp.forEach(e=>{e.screen=e.pts.map(pt);e.sc=pt(e.centre);e.sH=e.hinge?e.hinge.map(pt):null;var n=cross(sub(e.pts[1],e.pts[0]),sub(e.pts[2],e.pts[0])),out=dot(n,sub(e.centre,glob))>=0?1:-1;e.visible=n[2]*out>=-.005;});return {faces:cp,scale:sc};}
function E(p,t,a){return S.el(t,a||{},p);}
function P(points){return 'M'+points.map(q=>num(q[0])+','+num(q[1])).join(' L')+' Z';}
function T(p,x,y,txt,role,size){return NOVA.chalkText(p,x,y,String(txt),{role:role||'given',size:size||17,anchor:'middle'});}
function defs(sv){var d=sv.querySelector('defs')||E(sv,'defs');var roles=[['#c8ffff','#165580'],['#d4c7ff','#292365'],['#ffe5ba','#663727'],['#cafee1','#165557'],['#fff3c1','#644e28'],['#c1e5ff','#18366a']];roles.forEach(function(z,i){var g=E(d,'linearGradient',{id:'f13s-grad-'+i,x1:'10%',y1:'4%',x2:'90%',y2:'100%'});[[0,z[0],.86],[.16,colors[i],.57],[.7,z[1],.88],[1,'#07122a',.92]].forEach(q=>E(g,'stop',{offset:q[0],'stop-color':q[1],'stop-opacity':q[2]}));});var g=E(d,'radialGradient',{id:'f13s-aura'});E(g,'stop',{offset:'0%','stop-color':'#207dbb','stop-opacity':.34});E(g,'stop',{offset:'100%','stop-color':'#102e56','stop-opacity':0});}
function roundRect(g,x,y,w,hh,c){E(g,'rect',{x:x,y:y,width:w,height:hh,rx:12,fill:'#06172d',stroke:c,'stroke-width':1.2,opacity:.94});E(g,'path',{d:'M'+(x+12)+' '+(y+2)+'h'+(w-24),stroke:c,'stroke-width':2.2,opacity:.6});}
function illustration(root,s,W,H){root.replaceChildren();var mobile=W<500,mesh=folds(s.preset,s.fold),proj=project(mesh,s,W),faces=proj.faces,nearClosed=s.fold>.975;E(root,'ellipse',{cx:W/2,cy:228,rx:mobile?178:284,ry:157,fill:'url(#f13s-aura)'});
 var title=s.fold>.96?'FOLDED SOLID · COUNT THE OUTSIDE':s.fold<.04?'FLAT NET · EACH FACE HAS AN AREA':'UNFOLDING THE OUTSIDE FACES';T(root,W/2,54,title,'given',mobile?14:17);
 var grid=E(root,'g',{opacity:.3});for(var j=0;j<7;j++){var y=380+j*9;E(grid,'path',{d:'M'+(W*.10-j*4)+','+y+'Q'+W/2+','+(y+11)+' '+(W*.90+j*4)+','+y,stroke:'#1e95ba','stroke-width':j?1:2,fill:'none'});}var gr=E(root,'g',{'data-maths':'true-hinge-surface-net'});
 faces.sort((a,b)=>a.sc[2]-b.sc[2]);faces.forEach(function(o){if(nearClosed&&!o.visible)return;var f=o.f,i=f.i,chosen=s.selected===f.id,on=s.included.indexOf(f.id)>=0,colour=colors[i%colors.length],fade=s.selected&&s.selected!==f.id?.67:1;var fg=E(gr,'g',{'class':'f13sa-face','data-face':f.id,'data-area':String(num(f.area)),'data-role':groupName(s.preset,f.id),'tabindex':'0',role:'button','aria-label':f.title+' area '+fmt(f.area)+' square units. Click to '+(on?'remove':'add')+' its area.'});var outline=P(o.screen);
 E(fg,'path',{d:outline,fill:'url(#f13s-grad-'+(i%6)+')',stroke:colour,'stroke-width':on?3.4:2.4,'stroke-linejoin':'round',opacity:fade,filter:'url(#nv-neon-soft)'});E(fg,'path',{'class':'f13sa-face-rim',d:outline,fill:'transparent',stroke:on?'#faffce':colour,'stroke-width':on?2.4:1.4,opacity:on?.95:.85,'stroke-linejoin':'round'});
 if(s.fold<.38||s.fold>.92){var c=o.sc,shortTitle=DATA[s.preset].kind==='pyramid'?(f.id==='base'?'BASE':'TRI '+i):f.title,label=on?'✓ '+shortTitle:shortTitle;T(fg,c[0],c[1]-2,label,on?'result':'given',mobile?12:14);if(s.showAreas)T(fg,c[0],c[1]+18,fmt(f.area)+' u²','focus',mobile?13:16);}else if(s.fold<.68){var cc=o.sc;T(fg,cc[0],cc[1]+5,String(i+1),'given',18);}
 if(o.sH&&s.fold>.05&&s.fold<.93){var a=o.sH[0],b=o.sH[1];E(fg,'path',{d:'M'+num(a[0])+','+num(a[1])+'L'+num(b[0])+','+num(b[1]),stroke:'#ffe39e','stroke-width':3.4,'stroke-linecap':'round',opacity:.77});}
 });
 var fs=model(s.preset),total=area(s.preset),counted=s.included.reduce((a,id)=>a+(fs.find(f=>f.id===id)||{area:0}).area,0),left=mobile?12:34,yy=mobile?427:425,sep=mobile?8:13,w=(W-2*left-sep)/2;roundRect(root,left,yy,w,67,'#65e9fa');roundRect(root,left+w+sep,yy,w,67,'#ffce75');T(root,left+w/2,yy+20,'ALL OUTSIDE FACES','given',mobile?11:14);T(root,left+w/2,yy+49,s.maskAnswer?'? u²':fmt(total)+' u²','result',mobile?24:29);T(root,left+w+sep+w/2,yy+20,'FACES COUNTED','focus',mobile?11:14);T(root,left+w+sep+w/2,yy+49,fmt(counted)+' u²','result',mobile?24:29);
 T(root,W/2,513,s.fold>.94?'Each face stays joined at its hinge. Count it ONCE.':'Rotate, unfold, then tap faces to build the area total.','given',mobile?11:14);
 s._mesh=mesh;s._projected=proj;s._stats={shape:s.preset,total:total,subtotal:counted,faces:fs.map(q=>({id:q.id,area:q.area})),fold:s.fold,faceCount:fs.length};}
function makeStage(stage,s,message,pose,allow){if(stage._f13Cleanup)stage._f13Cleanup();stage.replaceChildren();var d=DATA[s.preset],mobile=window.innerWidth<=580,W=mobile?420:780,H=mobile?537:537;NOVA.cap(stage,'SURFACE AREA · '+d.kind.toUpperCase(),'SQUARE UNITS');var sv=S.root(W,H,'Interactive unfolding 3D solid and connected mathematical surface net. Coloured faces show exact area, and a live total tracks counted faces.');sv.classList.add('f13sa-svg');sv.setAttribute('role','group');sv.setAttribute('tabindex','0');sv.setAttribute('aria-label','Surface-area unfolder. Drag left or right to turn the folded solid. Use arrow keys to unfold. Click or focus a face and press Enter to add its area.');stage.appendChild(sv);defs(sv);var g=E(sv,'g',{'data-scene':'f13-13'}),raf=0,ac=new AbortController(),drag=null,wasDrag=false;
 function draw(){illustration(g,s,W,H);}
 function refresh(){if(raf)cancelAnimationFrame(raf);raf=requestAnimationFrame(function(){raf=0;draw();NOVA.events.emit('value',{engine:EN,control:'surface-area',value:s._stats});});}s.refresh=refresh;s.sv=sv;draw();
 F.strip(stage,[['FACES',model(s.preset).length,'given'],['NET',Math.round((1-s.fold)*100)+'%','op'],['AREA',s.maskAnswer?'?':fmt(area(s.preset)),'result']]);var dock=NOVA.scene.helperStrip(stage,pose||'explain',message||'Each coloured face is part of the outside surface. Count every face exactly once.');
 function syncStrip(){var name=stage.querySelector('.nv-cap > span:first-child');if(name)name.textContent='SURFACE AREA · '+DATA[s.preset].kind.toUpperCase();var tile=stage.querySelectorAll('.f12-strip .nv-ntile .mt');if(tile[0])tile[0].textContent=model(s.preset).length;if(tile[1])tile[1].textContent=Math.round((1-s.fold)*100)+'%';if(tile[2])tile[2].textContent=s.maskAnswer?'?':fmt(area(s.preset));}
 var baseDraw=draw;draw=function(){baseDraw();syncStrip();};
 function toggle(id){if(!allow||!id)return;var fs=model(s.preset);if(!fs.some(f=>f.id===id))return;s.selected=id;var i=s.included.indexOf(id);if(i>=0)s.included.splice(i,1);else s.included.push(id);refresh();NOVA.events.emit('step',{engine:EN,control:'face',face:id,area:(fs.find(q=>q.id===id)||{}).area,subtotal:s.included.reduce((a,k)=>a+(fs.find(q=>q.id===k)||{area:0}).area,0)});}
 sv.addEventListener('click',function(e){if(wasDrag){wasDrag=false;return;}var f=e.target.closest('[data-face]');if(f)toggle(f.getAttribute('data-face'));},{signal:ac.signal});
 sv.addEventListener('keydown',function(e){if(e.target.closest('[data-face]')&&(e.key==='Enter'||e.key===' ')){e.preventDefault();toggle(e.target.closest('[data-face]').getAttribute('data-face'));return;}if(e.key==='ArrowUp'||e.key==='ArrowDown'||e.key==='Home'||e.key==='End'){e.preventDefault();s.fold=e.key==='Home'?1:e.key==='End'?0:clamp(s.fold+(e.key==='ArrowDown'?.05:-.05),0,1);refresh();if(typeof s.onFold==='function')s.onFold(s.fold);}else if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();s.yaw=clamp(s.yaw+(e.key==='ArrowRight'?.08:-.08),-1.5,1.5);refresh();}},{signal:ac.signal});
 sv.addEventListener('pointerdown',function(e){if(e.pointerType==='mouse'&&e.button!==0)return;drag={id:e.pointerId,startX:e.clientX,yaw:s.yaw,startY:e.clientY,face:e.target.closest('[data-face]')?.getAttribute('data-face')||''};wasDrag=false;try{sv.setPointerCapture(e.pointerId);}catch(err){}sv.classList.add('is-dragging');},{signal:ac.signal});
 sv.addEventListener('pointermove',function(e){if(!drag||drag.id!==e.pointerId)return;var dx=e.clientX-drag.startX;if(Math.abs(dx)>5||Math.abs(e.clientY-drag.startY)>5)wasDrag=true;s.yaw=clamp(drag.yaw+dx/(sv.getBoundingClientRect().width||1)*1.4,-1.5,1.5);refresh();},{signal:ac.signal});
 function drop(e){if(!drag||e.pointerId!==drag.id)return;var faceTap=e.type==='pointerup'&&!wasDrag?drag.face:'';drag=null;sv.classList.remove('is-dragging');if(faceTap)toggle(faceTap);try{if(sv.hasPointerCapture(e.pointerId))sv.releasePointerCapture(e.pointerId);}catch(err){}}['pointerup','pointercancel','lostpointercapture'].forEach(name=>sv.addEventListener(name,drop,{signal:ac.signal}));window.addEventListener('blur',function(){drag=null;sv.classList.remove('is-dragging');},{signal:ac.signal});
 stage._f13Cleanup=function(){ac.abort();if(raf)cancelAnimationFrame(raf);if(s.animation)cancelAnimationFrame(s.animation);drag=null;sv.classList.remove('is-dragging');};return sv;}
function btn(text,fn,klass){return h('button',{class:'nova-btn'+(klass?' '+klass:''),text:text,onclick:fn});}
function row(p,items){p.appendChild(h('div',{class:'pr-row'},items));}
function slide(label,max,value,onInput){var r=h('input',{type:'range',min:'0',max:String(max),step:'1',value:String(value),'aria-label':label}),val=h('span',{class:'f13sa-reading',text:String(value)+'%'});r.oninput=function(){val.textContent=r.value+'%';onInput(+r.value/max);};return {node:h('label',{class:'f13sa-label'},[label+' ',r,val]),input:r,set:function(t){r.value=Math.round(t*max);val.textContent=r.value+'%';}};}
function stop(s){if(s.animation)cancelAnimationFrame(s.animation);s.animation=0;}
function animate(s,target){stop(s);var from=s.fold,start=performance.now(),dur=NOVA.reducedMotion()?1:1000,to=clamp(target,0,1);function tick(now){var t=clamp((now-start)/dur,0,1),v=t*t*(3-2*t);s.fold=from+(to-from)*v;s.refresh();if(typeof s.onFold==='function')s.onFold(s.fold);if(t<1)s.animation=requestAnimationFrame(tick);else {s.fold=to;s.animation=0;s.refresh();}}s.animation=requestAnimationFrame(tick);}
var STEPS=[
 {n:'Outside, not inside',key:'cuboid',fold:1,faces:[],pose:'explain',m:'Surface area is the amount of square units covering the OUTSIDE of a solid. There are six faces on a cuboid.',q:'Do we count the space inside? No: that is volume.'},
 {n:'Find the hidden faces',key:'cuboid',fold:1,faces:[],pose:'point-right',m:'Some faces are hidden from this angle, but still contribute to the total surface area.',q:'How many of the six rectangles must be counted?'},
 {n:'Open along the hinges',key:'cuboid',fold:.57,faces:[],pose:'explain',m:'Each face rotates around a shared edge. The sides never stretch, and the fold lines stay connected.',q:'Are the faces still the same sizes?'},
 {n:'Lay the net flat',key:'cuboid',fold:0,faces:[],pose:'point-right',m:'This flat net has all six faces. A net is the surface of the solid laid out without overlaps.',q:'Can you identify the top and bottom rectangles?'},
 {n:'Count the top and bottom',key:'cuboid',fold:0,faces:['base','lid'],pose:'think',m:'The base and top are each four by three, so each has area twelve square units. Their combined area is twenty-four.',q:'Why do we count both twelve-unit faces?'},
 {n:'Add the front and back',key:'cuboid',fold:0,faces:['base','lid','north','south'],pose:'point-right',m:'The front and back measure four by two, giving eight each. Our running subtotal is forty square units.',q:'How many square units did this pair add?'},
 {n:'Add both end faces',key:'cuboid',fold:0,faces:['base','lid','north','south','west','east'],pose:'celebrate',m:'Each end measures three by two, giving six each. Twelve more produces a total of fifty-two square units.',q:'Is fifty-two in square units or cubic units?'},
 {n:'A cube has equal squares',key:'cube3',fold:0,faces:['base','lid','north','south','west','east'],pose:'explain',m:'All six faces on a cube are equal squares. Three times three is nine, and six times nine is fifty-four.',q:'Why can we multiply one face area by six?'},
 {n:'A prism has two triangles',key:'prism',fold:0,faces:[],pose:'point-right',m:'This triangular prism has three rectangular side faces and two matching triangular end faces.',q:'Do we include the triangular ends?'},
 {n:'Area of triangular ends',key:'prism',fold:0,faces:['triL','triR'],pose:'think',m:'The two equilateral triangular ends must both be counted. Their area can use one half base times perpendicular height.',q:'Why does the sloping edge not give the triangle height?'},
 {n:'Pyramid faces',key:'pyramid',fold:0,faces:['base'],pose:'explain',m:'A square pyramid has one square base and four triangular faces. Its face height is the slant height.',q:'Why is the vertical height not the height of each sloping face?'},
 {n:'Add all four triangles',key:'pyramid',fold:0,faces:['base','north','south','west','east'],pose:'celebrate',m:'The base covers sixteen squares. Each triangle covers six. Four triangles add twenty-four, so total area is forty square units.',q:'Why is the answer forty square units?'}
];
var def={id:EN,title:'Surface-area unfolder',config:CFG,steps:STEPS.map(q=>({name:q.n,narration:q.m,prompt:q.q,dur:1950})),
 alt:'An interactive 3D net unfolds cube, cuboid, equilateral triangular prism, or square pyramid using mathematically hinged rigid faces. Tap faces to add their area to a running subtotal.',
 staticAlt:'Surface area is the sum of ALL exterior face areas, including hidden faces, in square units. A cuboid 4 by 3 by 2 has 52 square units; a cube side 3 has 54; a square pyramid base side 4 and slant height 3 has 40.',
 render:function(i,stage){var q=STEPS[i],s=state(q.key);s.fold=q.fold;s.included=q.faces.slice();makeStage(stage,s,q.m,q.pose,false);},
 exploreIntro:'Unfold a connected net, highlight each face and tap it to add or remove its area from the running total. Compare cuboids, cubes, prisms and pyramids.',
 explore:function(panel,stage,api){var s=state('cuboid'),sel=h('select',{class:'nova-input','aria-label':'Choose a solid for surface area'});Object.keys(CFG.presets).forEach(k=>sel.appendChild(h('option',{value:k,text:CFG.presets[k]})));sel.value='cuboid';var fd=slide('UNFOLD NET',100,0,function(t){stop(s);s.fold=1-t;s.refresh();}); // UI says % unfolded, fold internal 1=solid
 // The initial state is the fully folded SOLID. Slide reports unfolding progress.
 s.fold=1;function sync(){fd.set(1-s.fold);}s.onFold=sync;
 function preset(k){stop(s);s.preset=k;s.fold=1;s.selected='';s.included=[];sel.value=k;sync();s.refresh();if(formula)formula.textContent='FACE AREA TOTAL · '+areaSentence(k);}
 var formula=h('p',{class:'f13sa-instructions',text:'FACE AREA TOTAL · '+areaSentence('cuboid')});sel.onchange=function(){preset(sel.value);};row(panel,[h('label',{class:'f13sa-label'},['SOLID ',sel]),fd.node]);
 row(panel,[btn('Open the net',function(){animate(s,0);},'primary'),btn('Close the solid',function(){animate(s,1);},'ghost'),btn('Count all faces',function(){s.included=model(s.preset).map(f=>f.id);s.selected='';s.refresh();},'ghost'),btn('Clear tally',function(){s.included=[];s.selected='';s.refresh();},'ghost'),btn('Reset',function(){preset('cuboid');},'ghost')]);
 panel.appendChild(formula);panel.appendChild(h('p',{class:'f13sa-instructions',text:'When the net is flat, tap each coloured face to count its surface area. Drag across the drawing to rotate a folded solid, or use the keyboard: arrow left/right to turn, up/down to fold, Home for a solid, End for a flat net. The face sizes do not change as they open.'}));
 makeStage(stage,s,'All outside faces count, including the ones you could not see on the folded solid.','explain',true);if(api.onCleanup)api.onCleanup(function(){if(stage._f13Cleanup)stage._f13Cleanup();stop(s);});
 CFG._explore={state:s,preset:preset,unfold:function(t){stop(s);s.fold=1-clamp(t,0,1);sync();s.refresh();},include:function(id){if(s.included.indexOf(id)<0)s.included.push(id);s.selected=id;s.refresh();},clear:function(){s.included=[];s.refresh();},countAll:function(){s.included=model(s.preset).map(f=>f.id);s.refresh();},animate:function(t){animate(s,1-t);},read:function(){return s._stats;},geometry:function(){return folds(s.preset,s.fold);}};
 },
 challenge:function(panel,api,stage){var tasks=[
  {key:'cube3',q:'A cube has side length 3. What is its TOTAL surface area?',answer:54,unit:'units²',hint:'Six equal squares. Each has area 3 × 3.',mistake:'A cube has six outside squares. Multiply nine by six, not three.'},
  {key:'cuboid',q:'A cuboid is 4 × 3 × 2. Find the area of ALL SIX outside faces.',answer:52,unit:'units²',hint:'Count three opposite pairs: 12 + 12, 8 + 8, and 6 + 6.',mistake:'Remember the unseen back, bottom and second end: 2 × (12 + 8 + 6).'},
  {key:'pyramid',q:'A square pyramid has base side 4 and triangular-face slant height 3. Find its TOTAL surface area.',answer:40,unit:'units²',hint:'The base has area 16. Add four triangles, each ½ × 4 × 3.',mistake:'Use slant height 3 for triangular face area. Add the square base too.'},
  {key:'prism',q:'An equilateral triangular prism has triangular side 4 and length 6. Find its TOTAL surface area, to 2 decimal places.',answer:Math.round(area('prism')*100)/100,unit:'units²',hint:'Three rectangles: 3 × (4 × 6). Each equilateral triangle: √3/4 × 4². Count both triangles.',mistake:'Include the two end triangles as well as the three rectangles. A triangle height is perpendicular to its base.'}
 ];var idx=0,timer=0,currentState=null,question=h('p',{class:'pr-task'}),ans=h('input',{class:'nova-input',type:'number',step:'any','aria-label':'Surface area challenge answer',inputmode:'decimal'}),unit=h('span',{class:'unit'}),feedback=h('p',{class:'f13sa-feedback','aria-live':'polite'});
 function load(k){idx=k;ans.value='';feedback.textContent='';question.textContent=(k+1)+' / '+tasks.length+' · '+tasks[k].q;unit.textContent=tasks[k].unit;var s=state(tasks[k].key);s.fold=0;s.included=[];s.maskAnswer=true;currentState=s;makeStage(stage,s,'Surface area means ALL outside faces — include the hidden ones.','think',false);}
 function check(){var t=tasks[idx],valid=ans.value.trim()!==''&&Number.isFinite(+ans.value),val=+ans.value,ok=valid&&Math.abs(val-t.answer)<.005,msg=ok?'Correct — all outside faces have been counted.':valid?t.mistake:'Enter a numerical area before checking.';feedback.textContent=msg;if(ok&&currentState){currentState.maskAnswer=false;currentState.refresh();}api.check(ok,msg,{task:idx,expected:t.answer,value:valid?val:null});if(ok&&idx<tasks.length-1){if(timer)clearTimeout(timer);timer=setTimeout(function(){load(idx+1);},1050);}return ok;}
 panel.appendChild(question);row(panel,[h('label',{class:'f13sa-answer'},['SURFACE AREA ',ans,unit]),btn('Check',check,'primary'),btn('Hint',()=>api.hint(tasks[idx].hint),'ghost')]);panel.appendChild(feedback);
 if(api.onCleanup)api.onCleanup(function(){if(timer)clearTimeout(timer);if(stage._f13Cleanup)stage._f13Cleanup();});load(0);CFG._challenge={tasks:tasks,check:check,load:load,answer:ans,task:function(){return idx;}};
 }
};
NOVA.bankMount({id:EN,num:'F13·13',title:'Surface-area unfolder',def:def,linked:['F0-01','F0-02','F0-03','F0-04','F0-05','F12-03','F13-02','F13-07','F13-08'],spec:{
 purpose:'Unfold the outside of a 3D solid, identify every exact face area, and build a correct running surface-area total including hidden faces.',
 params:'Cube and cuboid dimensions, equilateral triangular prism with perpendicular triangle height, square pyramid with true triangular face slant height. Area in square units.',
 presets:Object.values(CFG.presets).join('; '),steps:STEPS.map(q=>q.n).join(' → '),
 interactions:'12 narration-led steps, eight example solids, actual rigid hinge rotation, select/tally each face, animated unfold/close, mouse/touch/keyboard rotation and four marked area challenges.',
 traps:'Never omit hidden outside faces; never use cubic units for surface area; do not confuse a pyramid face’s slant height with its vertical height; count both triangular prism ends.',
 gcse:'Apply surface area reasoning to prisms, pyramids, cubes and cuboids by finding and summing polygonal faces.'}});
var log=document.getElementById('log'),listener=x=>{log.textContent=new Date(x.time).toLocaleTimeString()+' '+x.type+' '+JSON.stringify(x.detail)+'\n'+log.textContent.slice(0,4000);};NOVA.events.history().forEach(listener);NOVA.events.on('*',listener);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
