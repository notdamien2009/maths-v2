# NOVA F13-14 — Solid Enlargement | QA Review

**Status:** Review build, pending user's visual acceptance; GitHub untouched.

**Test result:** 246/246 automated structural, maths and browser checks passed. Failed checks: 0.

## Structural integrity

- Canonical NOVA JS block byte-for-byte unchanged: True.
- Canonical CSS retained unchanged as a prefix: True.
- Canonical JS SHA-256: `79abfd9ec5be96c973f28ec7e81e4724c960c9fb8b5fb14af65401eedea49513`.
- The official embedded mascot packs, original chalk fonts, backgrounds, F12 number tiles and F0 drawing primitives remain embedded in the portable HTML.
- Only the F13-14 engine and its additive CSS were newly written.

## Teaching maths

- Length scale factor: **k**.
- Area scale factor: **k²**.
- Volume scale factor: **k³**.
- A 3 × 2 × 2 cuboid initially has surface area 32 units² and volume 12 units³.
- At k=2 the cuboid becomes 6 × 4 × 4, with area 128 units² and volume 96 units³.
- At k=3, area multiplier is 9 and volume multiplier is 27.
- At k=0.5, area multiplier is 0.25 and volume multiplier is 0.125.

## Tested behaviours

- Two browser widths (1280 and 380), all four modes, five presets, eight scale factors each.
- True relative size ratios in the projected 3D drawing for each case, not just arithmetic labels.
- Mouse slider, keyboard scale factor changes, Home/End controls, switching length/area/volume focus.
- Fast pointer dragging and official mascot contained in stage.
- Four marked challenges, incorrect-answer feedback, answer hidden until check.
- No browser JavaScript errors observed.

## Review points

The original becomes noticeably smaller at a high scale factor because the drawing uses an actual shared scale: this is intentional and mathematically accurate. This is not a final GOLD approval; visual and learner review remain with the user.

There are 22 captured PNG screenshots in the ZIP.
