from pathlib import Path
import re
ROOT=Path(__file__).parent
source=ROOT/'F13-13-base.html'
base=source.read_text(encoding='utf-8')
engine=(ROOT/'engine.js').read_text(encoding='utf-8')
extra_css=(ROOT/'style.css').read_text(encoding='utf-8')
base=base.replace('<title>NOVA F13-13 · Premium Surface-Area Unfolder</title>','<title>NOVA F13-14 · Premium Solid Enlargement</title>')
base=base.replace('data-run="F13 · 3D shapes, volume and surface area · F13-13"','data-run="F13 · 3D shapes, volume and surface area · F13-14"')
base=base.replace('data-title="Surface-area unfolder"','data-title="Solid enlargement"')
base=base.replace('data-sub="Open real connected surface nets, count the hidden faces, and add each area in square units."','data-sub="Compare true-scale 3D solids and discover why lengths, surfaces and volumes follow k, k² and k³."')
# Only strip and replace the additive script. The first script is the canonical NOVA runtime.
pattern=r'(<script>)(\s*/\* F13-13 SURFACE-AREA UNFOLDER[\s\S]*?)(</script>)'
base,n=re.subn(pattern,lambda m:m.group(1)+'\n'+engine+'\n'+m.group(3),base,count=1)
assert n==1,'cannot find additive F13-13 script'
base=base.replace('</style>','\n'+extra_css+'\n</style>',1)
output=ROOT/'F13-14-Solid-Enlargement-PREMIUM-CORE.html'
output.write_text(base,encoding='utf-8')
print(output,output.stat().st_size)
