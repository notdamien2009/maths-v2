/* F13-04 · PLANS + ELEVATIONS · genuine F0/F1/F12 runtime and official helper artwork retained. */
var NOVA_F13_04_CONFIG={startMode:'watch',preset:'corner',presets:{single:'One cube',row:'Two across',platform:'Four-cube platform',tower:'Two-high tower',corner:'Corner staircase',stairs:'Three-step wall',bridge:'Twin-height bridge',hidden:'Hidden support model'}};
(function(){'use strict';
var h=NOVA.h,S=NOVA.svg,F=NOVA.f12,C=NOVA_F13_04_CONFIG,EN='F13-04',N=4;
var PALETTE={cyan:'#2bdcf3',violet:'#a78aff',blue:'#51aaff',green:'#59eeb3',gold:'#ffce79'};
function blank(){return Array.from({length:N},function(){return Array(N).fill(0);});}
function put(g,places){places.forEach(function(t){g[t[0]][t[1]]=t[2]||1;});return g;}
function model(name){var g=blank();switch(name){
case 'single':return put(g,[[1,1,1]]);
case 'row':return put(g,[[1,2,1],[2,2,1]]);
case 'platform':return put(g,[[1,1,1],[2,1,1],[1,2,1],[2,2,1]]);
case 'tower':return put(g,[[1,2,2]]);
case 'corner':return put(g,[[1,1,2],[2,1,1],[1,2,1]]);
case 'stairs':return put(g,[[0,2,1],[1,2,2],[2,2,3]]);
case 'bridge':return put(g,[[1,1,2],[1,2,1],[2,1,1],[2,2,2]]);
case 'hidden':return put(g,[[1,1,2],[1,2,2],[2,1,1],[2,2,1]]);
default:return g;}}
function clone(g){return g.map(function(r){return r.slice();});}
function cubes(g){return g.reduce(function(s,row){return s+row.reduce(function(a,b){return a+b;},0);},0);}
function footprint(g){return g.reduce(function(s,row){return s+row.filter(function(v){return v>0;}).length;},0);}
function height(g){return Math.max(0,...g.map(function(row){return Math.max(...row);}));}
function plan(g){return Array.from({length:N},function(_,y){return Array.from({length:N},function(_,x){return g[x][y]>0?1:0;});});}
function front(g){return Array.from({length:N},function(_,x){return Math.max(...g[x]);});}
function side(g){return Array.from({length:N},function(_,i){return Math.max(...g.map(function(row){return row[N-1-i];}));});} // nearest/front end on LEFT
function sameVec(a,b){return a.length===b.length&&a.every(function(x,i){return Array.isArray(x)?sameVec(x,b[i]):x===b[i];});}
function matches(g,target){return sameVec(plan(g),plan(target))&&sameVec(front(g),front(target))&&sameVec(side(g),side(target));}
function inspect(g,target){return {top:sameVec(plan(g),plan(target)),front:sameVec(front(g),front(target)),side:sameVec(side(g),side(target))};}
function state(p){return {grid:model(p||'corner'),preset:p||'corner',focus:[1,1],tool:'add',showHeights:false,showEdges:true,view:'live',showViews:{top:true,front:true,side:true},selectedView:'all',challengeTarget:null,drag:null,undo:[],redo:[],paintOnChange:null};}
function projection(W,H,g){var mobile=W<520,u=mobile?(height(g)>3?42:49):56,OX=W/2,OY=mobile?(height(g)>3?258:239):270;return {W:W,H:H,u:u,point:function(x,y,z){return [OX+(x-y)*u*Math.sqrt(3)/2,OY+((x+y)-N)*u*.5-(z||0)*u];}};}
function path(p){return 'M'+p.map(function(a){return a[0].toFixed(2)+','+a[1].toFixed(2);}).join('L')+'Z';}
function ptIn(px,py,arr){var hit=false;for(var i=0,j=arr.length-1;i<arr.length;j=i++){var a=arr[i],b=arr[j];if((a[1]>py)!==(b[1]>py)&&px<(b[0]-a[0])*(py-a[1])/(b[1]-a[1])+a[0])hit=!hit;}return hit;}
function el(p,tag,attrs){return S.el(tag,attrs,p);}
function fmt(n){return Math.round(n*100)/100;}
function grad(sv){var d=sv.querySelector('defs')||el(sv,'defs',{});
 var specs=[['top','#bffcff','#3980af','#082849'],['right','#acb9ff','#6a68b6','#171c55'],['left','#aefff1','#267d85','#092c50']];
 specs.forEach(function(x){var gr=el(d,'linearGradient',{id:'iso-'+x[0],x1:'9%',y1:'3%',x2:'94%',y2:'94%'});el(gr,'stop',{offset:0,'stop-color':x[1],'stop-opacity':.85});el(gr,'stop',{offset:'.28','stop-color':x[2],'stop-opacity':.66});el(gr,'stop',{offset:1,'stop-color':x[3],'stop-opacity':.94});});
 var glow=el(d,'radialGradient',{id:'iso-halo'});el(glow,'stop',{offset:0,'stop-color':'#2bdcf3','stop-opacity':.24});el(glow,'stop',{offset:1,'stop-color':'#2bdcf3','stop-opacity':0});
}
function lines(sv,geom,pts,role,width){return NOVA.neonPath(geom,path(pts),{role:role||'op',width:width||2.2});}
function addBg(sv,pj,st){var W=pj.W,H=pj.H;
 el(sv,'ellipse',{cx:W/2,cy:H*.58,rx:W*.39,ry:H*.48,fill:'url(#iso-halo)',opacity:1});
 var backing=el(sv,'g',{class:'f13-iso-background',opacity:.6});
 for(var t=0;t<=N;t++){var aa=pj.point(t,0,0),bb=pj.point(t,N,0),cc=pj.point(0,t,0),dd=pj.point(N,t,0);
  el(backing,'path',{d:'M'+aa[0]+','+aa[1]+'L'+bb[0]+','+bb[1],stroke:'#2d728e','stroke-width':t===0||t===N?1.35:.8,fill:'none',opacity:t===0||t===N?.66:.37});
  el(backing,'path',{d:'M'+cc[0]+','+cc[1]+'L'+dd[0]+','+dd[1],stroke:'#2d728e','stroke-width':t===0||t===N?1.35:.8,fill:'none',opacity:t===0||t===N?.66:.37});}
 if(st.showDots){var dots=el(sv,'g',{class:'f13-iso-dots'});for(var x=0;x<=N;x++)for(var y=0;y<=N;y++){
 var a=pj.point(x,y,0);el(dots,'circle',{cx:a[0],cy:a[1],r:2.9,fill:'#9cfaff',opacity:.82,filter:'url(#nv-neon-soft)'});el(dots,'circle',{cx:a[0],cy:a[1],r:1.2,fill:'#e2feff'});}}
 if(st.showAxes){var x0=pj.point(0,0,0),xp=pj.point(1.05,0,0),yp=pj.point(0,1.05,0),zp=pj.point(0,0,1.05);
 [['x',xp,'given'],['y',yp,'focus'],['height',zp,'result']].forEach(function(a){NOVA.chalkText(sv,a[1][0]+(a[0]==='y'?-13:14),a[1][1]+(a[0]==='height'?0:10),a[0],{role:a[2],size:16});});
 NOVA.neonLine(sv,x0[0],x0[1],xp[0],xp[1],{role:'given',width:1.6});NOVA.neonLine(sv,x0[0],x0[1],yp[0],yp[1],{role:'focus',width:1.6});NOVA.neonLine(sv,x0[0],x0[1],zp[0],zp[1],{role:'result',width:1.6});}}
function topPts(pj,x,y,z){return [pj.point(x,y,z),pj.point(x+1,y,z),pj.point(x+1,y+1,z),pj.point(x,y+1,z)];}
function tintFace(parent,pts,role,visible,wire,focus,color){var g=el(parent,'g',{class:'f13-iso-face','data-iso-face':role});var colorFill='url(#iso-'+role+')';el(g,'path',{d:path(pts),fill:wire?'#102e4d38':colorFill,stroke:'none',opacity:wire?.37:1});
 var edge=focus?'focus':(role==='top'?'op':role==='right'?'support':'focus');lines(parent,g,pts,edge,focus?2.95:2.25);
 if(!wire&&role==='top'){el(g,'path',{d:'M'+pts[0][0]+','+pts[0][1]+'L'+pts[1][0]+','+pts[1][1]+'L'+pts[2][0]+','+pts[2][1],fill:'none',stroke:'#fff',opacity:.23,'stroke-width':1.05});}
 return g;}
function drawCubes(layer,pj,st){var cells=[];for(var x=0;x<N;x++)for(var y=0;y<N;y++)for(var z=0;z<st.grid[x][y];z++)cells.push([x,y,z]);
 cells.sort(function(a,b){return (a[0]+a[1]+a[2]*.7)-(b[0]+b[1]+b[2]*.7);});
 var cubeGrp=el(layer,'g',{class:'f13-iso-cubes','data-maths':'isometric-stack'}),vis={top:0,right:0,left:0};
 cells.forEach(function(c){var x=c[0],y=c[1],z=c[2],ce=el(cubeGrp,'g',{'data-cube':x+','+y+','+z,role:'img','aria-label':'Unit cube at column '+(x+1)+', row '+(y+1)+', level '+(z+1)}),focus=st.focus[0]===x&&st.focus[1]===y;
 // Only exterior faces are drawn; touching faces belong inside the solid.
 var top=z===st.grid[x][y]-1,
  xSide=x===N-1||st.grid[x+1][y]<=z,ySide=y===N-1||st.grid[x][y+1]<=z;
 var A=pj.point(x,y,z),B=pj.point(x+1,y,z),C=pj.point(x+1,y+1,z),D=pj.point(x,y+1,z),E=pj.point(x,y,z+1),F=pj.point(x+1,y,z+1),G=pj.point(x+1,y+1,z+1),H=pj.point(x,y+1,z+1);
 if(xSide){tintFace(ce,[B,C,G,F],'right',true,st.wire,focus);vis.right++;}
 if(ySide){tintFace(ce,[D,C,G,H],'left',true,st.wire,focus);vis.left++;}
 if(top){tintFace(ce,[E,F,G,H],'top',true,st.wire,focus);vis.top++;if(st.showNumbers){var mid=[(E[0]+F[0]+G[0]+H[0])/4,(E[1]+F[1]+G[1]+H[1])/4];NOVA.chalkText(ce,mid[0],mid[1]+5,String(z+1),{role:'given',size:16,anchor:'middle'});}}
 });return vis;}
function text(parent,x,y,s,role,size,anchor){var t=NOVA.chalkText(parent,x,y,String(s),{role:role||'given',size:size||18,anchor:anchor||'middle'});if(role==='op')t.style.fill='#b9a1ff';return t;}
function floor(root,pj){var mid=el(root,'g',{opacity:.64,'aria-hidden':'true'});
 for(var t=0;t<=N;t++){
 var a=pj.point(t,0,0),b=pj.point(t,N,0),c=pj.point(0,t,0),d=pj.point(N,t,0);
 el(mid,'path',{d:'M'+a[0]+','+a[1]+'L'+b[0]+','+b[1],stroke:'#2e7e98','stroke-width':1.2,'stroke-dasharray':'4 7',fill:'none',opacity:.5});
 el(mid,'path',{d:'M'+c[0]+','+c[1]+'L'+d[0]+','+d[1],stroke:'#2e7e98','stroke-width':1.2,'stroke-dasharray':'4 7',fill:'none',opacity:.5});}
 var dots=el(mid,'g',{});for(var x=0;x<=N;x++)for(var y=0;y<=N;y++){var p=pj.point(x,y,0);el(dots,'circle',{cx:p[0],cy:p[1],r:2,fill:'#9aefff',opacity:.55});}}
function scene(root,pj,st){var W=pj.W,glow=el(root,'g',{'aria-hidden':'true'});
 el(glow,'ellipse',{cx:W/2,cy:243,rx:W*.30,ry:195,fill:'url(#iso-halo)',opacity:.92});floor(root,pj);
 // Mathematical construction from the F13-03 approved 3D neon cube primitive.
 drawCubes(root,pj,st);
 var focus=st.focus,fp=topPts(pj,focus[0],focus[1],st.grid[focus[0]][focus[1]]);
 el(root,'path',{d:path(fp),fill:'#ffcf7516',stroke:'#ffce79','stroke-width':2.4,'stroke-dasharray':'7 6',filter:'url(#nv-neon-soft)','pointer-events':'none'});
 if(st.showHeights){for(var x=0;x<N;x++)for(var y=0;y<N;y++)if(st.grid[x][y]){var p=topPts(pj,x,y,st.grid[x][y]),c=[p.reduce(function(v,a){return v+a[0];},0)/4,p.reduce(function(v,a){return v+a[1];},0)/4];text(root,c[0],c[1]+5,st.grid[x][y],'given',17);}}
 text(root,W*.21,W<520?36:45,'SOLID','given',W<520?20:22);text(root,W*.79,W<520?36:45,cubes(st.grid)+' cubes','result',W<520?18:20);
 // 3D drag hit zones are constructed from the actual top faces.
 var hits=el(root,'g',{class:'f13-pe-hits'});for(var xx=0;xx<N;xx++)for(var yy=0;yy<N;yy++){var poly=topPts(pj,xx,yy,st.grid[xx][yy]);el(hits,'path',{d:path(poly),fill:'transparent',stroke:'transparent','pointer-events':'all','data-cubehit':xx+','+yy});}
}
function gridStyle(root,W,H,st){var mobile=W<520,x0=mobile?8:24,gap=mobile?8:14,
 cardW=(W-2*x0-2*gap)/3,cardY=mobile?355:417,cardH=mobile?172:181;
 var axis=mobile?18:26,gridS=Math.min((cardW-28)/4,(cardH-65)/4),cell=Math.floor(gridS*10)/10;
 return {cardX:function(i){return x0+i*(cardW+gap);},y:cardY,w:cardW,h:cardH,cell:cell,gridSize:cell*4};}
function card(root,x,y,w,h,role,active,label,caption){var color=role==='given'?'#5be4f9':role==='focus'?'#ffce79':'#a78aff',g=el(root,'g',{class:'f13-pe-card'});
 el(g,'rect',{x:x,y:y,width:w,height:h,rx:13,fill:'#07162a',opacity:.86,stroke:active?color:'#2d5677','stroke-width':active?1.9:1.1});
 el(g,'rect',{x:x+4,y:y+4,width:w-8,height:4,rx:2,fill:color,opacity:active?.7:.2});
 text(g,x+w/2,y+25,label,role,17);
 return g;}
function tile(g,x,y,w,h,fill,stroke,alpha){el(g,'rect',{x:x,y:y,width:w,height:h,rx:1.6,fill:fill||'#08152a',stroke:stroke||'#294768','stroke-width':.95,opacity:alpha||1});}
function views(root,W,H,st){var props=st.challengeTarget&&st.view==='target'?st.challengeTarget:st.grid,
 values={top:plan(props),front:front(props),side:side(props)},G=gridStyle(root,W,H,st),info={},labels=[['top','TOP PLAN','given'],['front','FRONT VIEW','focus'],['side','RIGHT SIDE','op']];
 labels.forEach(function(def,i){var view=def[0],x=G.cardX(i),y=G.y,c=card(root,x,y,G.w,G.h,def[2],st.selectedView===view,def[1]),k=G.cell,gx=x+(G.w-G.gridSize)/2,gy=y+43,
 visible=st.showViews[view],v=values[view];info[view]={x:gx,y:gy,size:k,kind:view,cardX:x,cardY:y,cardW:G.w};
 if(!visible){text(c,x+G.w/2,gy+G.gridSize*.52,'?','op',38);text(c,x+G.w/2,y+G.h-12,'PREDICT','given',14);return;}
 var occupied=[],used=0;
 for(var r=0;r<N;r++)for(var col=0;col<N;col++){
 var on=view==='top'?v[r][col]>0:view==='front'?(r>=N-v[col]):(r>=N-v[col]);
 var cX=gx+col*k,cY=gy+r*k;var bg='#081b33',lit=view==='top'?'#2bdcf3':view==='front'?'#ffce79':'#a78aff';
 if(on){used++;bg=view==='top'?'#164d63':view==='front'?'#5d412b':'#493d70';}
 tile(c,cX,cY,k-1.5,k-1.5,bg,on?lit:'#234a60',on?1:.64);
 if(on)el(c,'rect',{x:cX+2,y:cY+2,width:k-5,height:Math.max(2,k*.20),rx:1,fill:lit,opacity:.3});
 if(view==='top'&&on&&st.showHeights&&st.view!=='target')text(c,cX+k/2,cY+k*.69,st.grid[col][r],'given',Math.max(12,k*.65));
 }
 // Marker for a learner's highlighted edit cell; challenges retain the target outline but not solution stack heights.
 if(view==='top'&&st.view!=='target'){var xx=st.focus[0],yy=st.focus[1];el(c,'rect',{x:gx+xx*k+1,y:gy+yy*k+1,width:k-3,height:k-3,rx:1,fill:'none',stroke:'#ffd879','stroke-width':2.2,filter:'url(#nv-neon-soft)'});}
 
 var caption=view==='top'?'LOOK DOWN':view==='front'?'LOOK FROM FRONT':'LOOK FROM RIGHT';text(c,x+G.w/2,y+G.h-11,caption,def[2],W<520?11:13);
 if(view==='top'){var area=el(c,'rect',{x:gx,y:gy,width:G.gridSize,height:G.gridSize,fill:'transparent','pointer-events':'all','data-editplan':'1'});}
 });return info;}
function renderStage(stage,st,caption,pose,interactive){if(stage._f13Cleanup)stage._f13Cleanup();stage.replaceChildren();
 NOVA.cap(stage,'PLANS + ELEVATIONS · '+(C.presets[st.preset]||'YOUR CONSTRUCTION'),interactive?'edit from top plan':'view from three sides');
 var mobile=window.innerWidth<=580,W=mobile?420:780,H=mobile?545:615;
 var sv=S.root(W,H,'A three-dimensional model of unit cubes with a top plan, front elevation and right-side elevation.');sv.classList.add('f13-pe-svg');sv.setAttribute('role','group');sv.setAttribute('tabindex','0');sv.style.touchAction='none';stage.appendChild(sv);grad(sv);var fg=sv.querySelector('#iso-left');if(fg){['#ffe7ae','#e9994f','#53301e'].forEach(function(v,i){fg.querySelectorAll('stop')[i].setAttribute('stop-color',v);});}
 var root=el(sv,'g',{'data-plans-root':'true'}),pj=projection(W,H,st.grid),viewHit={},updated=false;
 function draw(){root.replaceChildren();pj=projection(W,H,st.grid);scene(root,pj,st);viewHit=views(root,W,H,st);
 var tiles=stage.querySelectorAll('.f12-strip .nv-ntile .mt');[cubes(st.grid),footprint(st.grid),height(st.grid)].forEach(function(v,i){if(tiles[i])tiles[i].textContent=String(v);});}
 draw();F.strip(stage,[['cubes',cubes(st.grid),'given'],['top cells',footprint(st.grid),'focus'],['max height',height(st.grid),'result']]);NOVA.scene.helperStrip(stage,pose||'explain',caption||'Look down for the plan. Look straight on for each elevation.');
 if(interactive){var ac=new AbortController(),pending=false;stage._f13Cleanup=function(){ac.abort();st.drag=null;};
  function schedule(){if(pending)return;pending=true;requestAnimationFrame(function(){pending=false;if(stage.contains(sv))draw();});}
  function coord(ev){var r=sv.getBoundingClientRect();return [(ev.clientX-r.left)*W/r.width,(ev.clientY-r.top)*H/r.height];}
  function fromPoint(p){var t=viewHit.top,k=t.size,px=p[0],py=p[1];if(px>=t.x&&px<t.x+4*k&&py>=t.y&&py<t.y+4*k)return [Math.floor((px-t.x)/k),Math.floor((py-t.y)/k)];
   var candidates=[];for(var x=0;x<N;x++)for(var y=0;y<N;y++){var poly=topPts(pj,x,y,st.grid[x][y]);if(ptIn(px,py,poly))candidates.push([x,y,st.grid[x][y]]);}candidates.sort(function(a,b){return (b[0]+b[1]+b[2]*.65)-(a[0]+a[1]+a[2]*.65);});return candidates[0]?[candidates[0][0],candidates[0][1]]:null;}
  function change(x,y,source){var old=st.grid[x][y],next=st.tool==='remove'?Math.max(0,old-1):Math.min(4,old+1);if(next===old)return;
   if(!st.drag||!st.drag.saved){st.undo.push(clone(st.grid));if(st.undo.length>50)st.undo.shift();st.redo=[];if(st.drag)st.drag.saved=true;}
   st.grid[x][y]=next;st.focus=[x,y];NOVA.events.emit('value',{engine:EN,control:'columnHeight',value:[x,y,next],source:source});if(st.paintOnChange)st.paintOnChange();schedule();}
  function apply(p,source){var a=fromPoint(p);if(!a||!st.drag)return;var key=a.join(',');if(st.drag.visited.has(key))return;st.drag.visited.add(key);change(a[0],a[1],source);}
  sv.addEventListener('pointerdown',function(e){if(e.pointerType==='mouse'&&e.button!==0)return;st.drag={id:e.pointerId,visited:new Set(),saved:false,last:coord(e)};try{sv.setPointerCapture(e.pointerId);}catch(x){}sv.classList.add('f13-pe-grabbing');apply(st.drag.last,'pointer');e.preventDefault();},{signal:ac.signal});
  sv.addEventListener('pointermove',function(e){if(!st.drag||st.drag.id!==e.pointerId)return;var p=coord(e),last=st.drag.last,dist=Math.hypot(p[0]-last[0],p[1]-last[1]),step=Math.max(6,(viewHit.top||{size:20}).size*.28),count=Math.min(90,Math.ceil(dist/step));
   for(var k=1;k<=count;k++)apply([last[0]+(p[0]-last[0])*k/count,last[1]+(p[1]-last[1])*k/count],'drag');st.drag.last=p;e.preventDefault();},{signal:ac.signal});
  function end(e){if(!st.drag||e.pointerId!==st.drag.id)return;st.drag=null;sv.classList.remove('f13-pe-grabbing');try{if(sv.hasPointerCapture(e.pointerId))sv.releasePointerCapture(e.pointerId);}catch(x){}schedule();}
  sv.addEventListener('pointerup',end,{signal:ac.signal});sv.addEventListener('pointercancel',end,{signal:ac.signal});sv.addEventListener('lostpointercapture',function(e){if(st.drag&&e.pointerId===st.drag.id){st.drag=null;sv.classList.remove('f13-pe-grabbing');}},{signal:ac.signal});
  sv.addEventListener('keydown',function(e){var q=st.focus.slice(),key=e.key;
   if(key==='ArrowLeft')q[0]=Math.max(0,q[0]-1);if(key==='ArrowRight')q[0]=Math.min(3,q[0]+1);if(key==='ArrowUp')q[1]=Math.max(0,q[1]-1);if(key==='ArrowDown')q[1]=Math.min(3,q[1]+1);
   if(key.startsWith('Arrow')){e.preventDefault();st.focus=q;schedule();return;}
   if(key==='Enter'||key===' '||key==='Backspace'||key==='Delete'){e.preventDefault();var old=st.tool;st.tool=key==='Backspace'||key==='Delete'?'remove':'add';st.drag=null;change(st.focus[0],st.focus[1],'keyboard');st.tool=old;}
   if(key==='Escape'){st.drag=null;sv.classList.remove('f13-pe-grabbing');}}, {signal:ac.signal});
  window.addEventListener('blur',function(){st.drag=null;sv.classList.remove('f13-pe-grabbing');},{signal:ac.signal});
 }
 sv.f13Draw=draw;sv.f13ViewHit=viewHit;st._svg=sv;return sv;}
var STEPS=[
 {name:'One object, three viewpoints',preset:'single',reveal:[],focus:[1,1],selectedView:'all',narration:'We are looking at a solid made from a cube. Plans and elevations are flat drawings of the very same object, seen from different directions.',prompt:'Why would a builder need more than one view?',pose:'explain'},
 {name:'Look straight down — the top plan',preset:'single',reveal:['top'],focus:[1,1],selectedView:'top',narration:'Look straight down on the cube. Its top plan is one square. A plan tells us where the solid covers the floor, but does not show its height.',prompt:'What shape do you see in the top plan?',pose:'point-right'},
 {name:'Face the solid — the front elevation',preset:'single',reveal:['top','front'],focus:[1,1],selectedView:'front',narration:'Look horizontally from the front. The front elevation shows width and height, not how far back the cube goes.',prompt:'Which dimension disappears from the front elevation?',pose:'think'},
 {name:'Turn right — the side elevation',preset:'single',reveal:['top','front','side'],focus:[1,1],selectedView:'side',narration:'Now look from the right-hand side. The right-side elevation shows depth and height. The front-to-back direction runs left to right in this view.',prompt:'Does the right-side view show width or depth?',pose:'point-right'},
 {name:'Four cubes — one large top plan',preset:'platform',reveal:['top','front','side'],focus:[2,2],selectedView:'top',narration:'A two by two platform uses four cubes. From above, we see four squares, but from the front we see only two. The same solid has different views.',prompt:'How many squares appear from above?',pose:'explain'},
 {name:'Height changes elevations',preset:'tower',reveal:['top','front','side'],focus:[1,2],selectedView:'front',narration:'This two-high stack still covers one square in its plan. Both elevations rise to two squares high. Taller solids do not necessarily have bigger plans.',prompt:'How has the top plan changed?',pose:'think'},
 {name:'A corner shape makes different outlines',preset:'corner',reveal:['top','front','side'],focus:[1,1],selectedView:'all',narration:'This corner has two cubes in one column, and one cube in each of two neighbouring columns. Read the plan first, then find the highest stack in every front and side line.',prompt:'Can the plan alone tell you which column is two high?',pose:'explain'},
 {name:'Each elevation shows the maximum height',preset:'stairs',reveal:['top','front','side'],focus:[2,2],selectedView:'front',narration:'The staircase rises from one to two to three cubes. In the front elevation those three heights show as three columns, while the side view overlaps them into a single three-high silhouette.',prompt:'Why does the side view show just one tall column?',pose:'point-right'},
 {name:'Hidden cubes need more thinking',preset:'hidden',reveal:['top','front','side'],focus:[1,1],selectedView:'all',narration:'Some cubes can hide behind others. You cannot always reconstruct every hidden cube from plans and elevations alone. Use all three views and make a model that fits each one.',prompt:'Could two different solids have the same three views?',pose:'think'}
];
function watchState(z){var st=state(z.preset);st.focus=z.focus.slice();st.showViews={top:z.reveal.includes('top'),front:z.reveal.includes('front'),side:z.reveal.includes('side')};st.selectedView=z.selectedView;return st;}
var def={id:EN,title:'Plans and elevations',config:C,steps:STEPS,
 alt:'Interactive three-dimensional neon-cube model and three matching orthographic projections: top plan, front elevation, right-side elevation.',
 staticAlt:'In a plan, view from above to see the footprint. From the front, the elevation shows maximum stack height in each width column. From the right, it shows maximum stack height in each depth column. Hidden cubes may not appear.',
 render:function(i,stage){var z=STEPS[i],st=watchState(z);renderStage(stage,st,z.name,z.pose,false);},
 exploreIntro:'Change one cube. Look at which views change and which stay the same.',
 explore:function(panel,stage,api){var st=state('corner');
  if(api.onCleanup)api.onCleanup(function(){if(stage._f13Cleanup)stage._f13Cleanup();});
  function paint(){renderStage(stage,st,'Edit the plan or the solid. Compare each viewpoint.','explain',true);}
  var selector=h('select',{class:'nova-input','aria-label':'Choose a 3D construction'});Object.keys(C.presets).forEach(function(k){selector.appendChild(h('option',{value:k,text:C.presets[k]}));});selector.value='corner';
  selector.onchange=function(){st.grid=model(selector.value);st.preset=selector.value;st.undo=[];st.redo=[];st.focus=[1,1];paint();NOVA.events.emit('value',{engine:EN,control:'preset',value:st.preset});};
  panel.appendChild(h('div',{class:'pr-row'},[h('label',{},['3D CONSTRUCTION ',selector])]));
  var buttons={},tools=h('div',{class:'pr-row','aria-label':'Builder tools'});
  [['add','＋ Add unit cube'],['remove','− Remove top cube']].forEach(function(v){var b=h('button',{class:'nova-btn'+(st.tool===v[0]?' primary':''),text:v[1],onclick:function(){st.tool=v[0];Object.keys(buttons).forEach(function(k){buttons[k].classList.toggle('primary',k===st.tool);});}});buttons[v[0]]=b;tools.appendChild(b);});panel.appendChild(tools);
  function undo(){if(!st.undo.length)return;st.redo.push(clone(st.grid));st.grid=st.undo.pop();paint();}
  function redo(){if(!st.redo.length)return;st.undo.push(clone(st.grid));st.grid=st.redo.pop();paint();}
  panel.appendChild(h('div',{class:'pr-row'},[
   h('button',{class:'nova-btn ghost',text:'↶ Undo',onclick:undo}),h('button',{class:'nova-btn ghost',text:'↷ Redo',onclick:redo}),
   h('button',{class:'nova-btn ghost',text:'Clear',onclick:function(){st.undo.push(clone(st.grid));st.grid=blank();st.redo=[];st.preset='own';st.focus=[1,1];paint();}}),
   h('button',{class:'nova-btn ghost',text:'Reset model',onclick:function(){st.grid=model(selector.value);st.undo=[];st.redo=[];paint();}})
  ]));
  var toggles=h('div',{class:'pr-row'});var vals=[['showHeights','Number each stack'],['top','Show top plan'],['front','Show front'],['side','Show right side']];
  vals.forEach(function(v){var checkbox=h('input',{type:'checkbox','aria-label':v[1]});checkbox.checked=v[0]==='showHeights'?st.showHeights:st.showViews[v[0]];checkbox.onchange=function(){if(v[0]==='showHeights')st.showHeights=checkbox.checked;else st.showViews[v[0]]=checkbox.checked;paint();};toggles.appendChild(h('label',{class:'f13-pe-tog'},[checkbox,' '+v[1]]));});panel.appendChild(toggles);
  panel.appendChild(h('p',{class:'f13-pe-help',text:'Draw directly on the TOP PLAN tiles or on a cube top. Each tap adds one cube to that column (maximum four). Drag across several tiles to build. Press arrow keys on the focused drawing to move the gold cursor, Enter to add and Delete to remove.'}));
  paint();C._explore={state:st,preset:function(k){selector.value=k;selector.onchange();},undo:undo,redo:redo,clear:function(){st.grid=blank();paint();},draw:paint};
 },
 challenge:function(panel,api,stage){
  var tasks=[
  {name:'Two adjacent unit cubes',target:put(blank(),[[1,2,1],[2,2,1]]),q:'Use the three TARGET VIEWS to construct a two-cube solid. Tap the top plan twice, once in each target square.',hint:'The top plan shows the two occupied positions. Both elevations are only one cube high.'},
  {name:'A tower in one square',target:put(blank(),[[1,2,2]]),q:'Use all three TARGET VIEWS to build a solid with a single occupied square but a height of two.',hint:'The top plan has one square. Tap the corresponding square twice to build a two-high column.'},
  {name:'Same views, different possible solids',target:put(blank(),[[1,1,2],[1,2,1],[2,1,1],[2,2,2]]),q:'Build any solid that matches these three target views. The hidden heights may have more than one correct arrangement.',hint:'The plan contains four cells. Each elevation has two adjacent columns rising to two cubes. Other occupied cells may be just one high.'}
  ];
  var selected=0,st=state('single'),qp=h('p',{class:'pr-task'}),progress=h('span',{class:'f13-pe-progress',text:''}),resultNote=h('p',{class:'f13-pe-help'});
  function load(k){selected=k;st.grid=blank();st.preset='own';st.focus=[1,1];st.undo=[];st.redo=[];st.tool='add';st.challengeTarget=tasks[k].target;st.view='target';st.showViews={top:true,front:true,side:true};st.selectedView='all';
    qp.textContent=(k+1)+' / '+tasks.length+' · '+tasks[k].q;resultNote.textContent='The three small drawings are TARGET views, not an automatic answer. Build a 3D model above them and check whether all three projections match.';
    st.paintOnChange=function(){progress.textContent=cubes(st.grid)+' cubes placed';};progress.textContent='0 cubes placed';renderStage(stage,st,'Copy all three projections, not just the top outline.','think',true);}
  panel.appendChild(qp);panel.appendChild(resultNote);
  panel.appendChild(h('div',{class:'pr-row'},[
   h('button',{class:'nova-btn primary',text:'Check all three views',onclick:function(){var target=tasks[selected].target,x=inspect(st.grid,target),ok=x.top&&x.front&&x.side;var feedback;
     if(ok)feedback='Correct! Your top plan, front elevation and right-side elevation ALL match the target. Different hidden cube arrangements may still be valid.';
     else if(!x.top)feedback='The top plan does not match. Check which floor squares are occupied before adding heights.';
     else if(!x.front)feedback='The plan fits, but the FRONT elevation does not. Check the tallest stack in each width column.';
     else feedback='Your top and front views match, but the RIGHT-SIDE elevation does not. Check maximum height along each front-to-back row.';
     api.check(ok,feedback,{task:selected,views:x,cubes:cubes(st.grid)});
     if(ok&&selected<tasks.length-1){var tm=setTimeout(function(){load(selected+1);},1100);if(api.onCleanup)api.onCleanup(function(){clearTimeout(tm);});}}}),
   h('button',{class:'nova-btn ghost',text:'Hint',onclick:function(){api.hint(tasks[selected].hint);}}),
   h('button',{class:'nova-btn ghost',text:'Clear model',onclick:function(){st.grid=blank();st.undo=[];st.redo=[];st.focus=[1,1];st.paintOnChange();renderStage(stage,st,'The target drawings stay. Start a fresh solid.','think',true);}}),progress
  ]));
  panel.appendChild(h('p',{class:'f13-pe-help',text:'Keyboard: focus the model, use arrows to move the gold cursor, Enter to add cubes, Delete to remove. The checker compares projections, not just total cube count.'}));
  load(0);C._challenge={state:st,task:function(){return selected;},load:load,targets:tasks,check:function(){return matches(st.grid,tasks[selected].target);},detail:function(){return inspect(st.grid,tasks[selected].target);}};
 }};
NOVA.bankMount({id:EN,num:'F13·04',title:'Plans and elevations',def:def,linked:['F0-01','F0-02','F0-03','F0-04','F0-05','F12-03','F13-01','F13-02','F13-03'],spec:{
 purpose:'Turn a physical unit-cube solid into accurate top plans and front/right-side orthographic elevations. Use three views to reconstruct a solid (Y8-059).',
 params:'4×4 ground footprint · column heights 0–4 · real 3D model · front/right-side projection masks · top occupancy · live editing and target-view challenge.',
 presets:'One cube, two across, four-cube platform, two-high tower, corner staircase, three-step wall, twin-height bridge, hidden support.',
 steps:STEPS.map(function(s){return s.name;}).join(' → '),
 interactions:'Nine narrated Watch/Guided beats; Explore add/remove, four visibility controls, live all-view updates, robust drag, keyboard, undo/redo; Challenge 3 projection reconstruction tasks.',
 traps:'A plan does not show height · elevations show maximum height from their line of sight · hidden cubes are not individually visible · multiple solids may share the same three projections.',
 gcse:'Orthographic construction, interpreting 3D plans and elevations, isometric sketches and 3D geometry.'}});
var log=document.getElementById('log'),addLog=function(e){log.textContent=new Date(e.time).toLocaleTimeString()+' '+e.type+' '+JSON.stringify(e.detail)+'\n'+log.textContent.slice(0,5000);};NOVA.events.history().forEach(addLog);NOVA.events.on('*',addLog);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
