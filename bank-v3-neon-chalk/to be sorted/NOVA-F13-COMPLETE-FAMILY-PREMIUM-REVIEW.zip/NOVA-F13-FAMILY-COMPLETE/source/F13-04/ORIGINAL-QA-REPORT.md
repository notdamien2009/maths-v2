# F13-04 — Plans and Elevations · Premium Core QA

**Status: REVIEW ONLY — pending human visual approval.**

## Ground truth
- The complete F12-03 approved NOVA CSS, JavaScript runtime, mascot pose assets, embedded NOVA Chalk font and helper dock are retained. The core JavaScript was byte-for-byte verified against the approved F12 upload.
- A new F13-04 engine script and additive styles implement the 3-D cube scene plus top plan, front elevation and right-side elevation. No edits made to F0/F1/F12 logic.

## Mathematical definitions
- Grid: 4 × 4 columns, each 0–4 cubes tall.
- Top plan: filled square wherever a column has height > 0; back at the top, front at the bottom.
- Front elevation: maximum column height over all depths for each x-position.
- Right-side elevation: maximum column height over all x-positions, with the front of the object to the left.
- A challenge solution is correct when all three projections match; exact internal heights need not match a single model.

## Browser stress tests
**126/126 checks passed.** Viewports: desktop 1280px and mobile 380px.

Checks include: core integrity, official mascot in stage, original background and fonts, no horizontal overflow, all 9 Watch steps and Guided mode, 8 drawing presets, pointer add/remove, live counters, undo/redo, high-speed drag across neighbouring cells, release cleanup, keyboard add/remove, toggles, incorrect-feedback, all three challenge tasks, and a mathematically valid alternative construction for the same orthographic projections. No uncaught JS exceptions observed.

## Review limitations
- Automated tests are not a substitute for your visual GOLD approval.
- The 3D model is an SVG projection with cube-face culling, rather than a hardware 3D mesh. The top/front/side views are calculated from true column heights.
- Save/push only after approval. GitHub remains untouched.

## Reproduction
From `source`, run `python build.py` to regenerate the standalone HTML. The approved F12-03 base is bundled in `source`. Reproducible SHA-256: `47face86c773e06b447965d3e5d2b95523c579914115b791a349c946ceef1577`.
