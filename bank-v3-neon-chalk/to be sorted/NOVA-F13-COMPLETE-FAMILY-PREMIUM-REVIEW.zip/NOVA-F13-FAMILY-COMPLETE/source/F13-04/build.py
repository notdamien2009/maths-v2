from pathlib import Path
base=(Path(__file__).resolve().parent/'approved-F12-03-base.html').read_text()
b=base.index('<script>\n/* ===== F12-03 CONFIG:')
e=base.index('</script>',b)
engine=(Path(__file__).resolve().parent/'F13-04.engine.js').read_text()
s=base[:b]+'<script>\n'+engine+'\n'+base[e:]
s=s.replace('<title>NOVA F12-03 · Geoboard builder</title>','<title>NOVA F13-04 · Premium Plans and Elevations</title>')
s=s.replace('data-run="F12 · 2D shapes, perimeter and area · F12-03" data-title="Geoboard builder" data-sub="Stretch a band round pegs to make shapes, then read their area, perimeter and name."', 'data-run="F13 · 3D shapes, volume and surface area · F13-04" data-title="Plans and elevations" data-sub="Turn one solid into its top, front and right-side drawings. Build the views and test what each view reveals."')
css='''
/* F13-04 additions. Everything above is the untouched NOVA F0/F1/F12 base. */
.f13-pe-svg{width:100%!important;max-width:840px!important;height:auto!important;display:block!important;margin:1px auto 0!important;touch-action:none;cursor:crosshair;user-select:none;outline:none}
.f13-pe-svg:focus-visible{outline:2px dashed var(--math-cyan);outline-offset:-3px;border-radius:10px}
.f13-pe-svg.f13-pe-grabbing{cursor:grabbing}
.f13-pe-face{pointer-events:none}
.f13-pe-help{font:700 .9rem/1.5 var(--nova-font-ui);color:var(--v-ink);margin:8px 0}
.f13-pe-tog{display:inline-flex;align-items:center;gap:6px;color:var(--v-ink);font:700 .84rem var(--nova-font-ui);white-space:nowrap}
.f13-pe-tog input{accent-color:var(--math-cyan)}
.f13-pe-progress{color:var(--math-cyan);font:700 1.1rem var(--nova-font-chalk-draw)}
.f13-pe-svg [data-editcell]{cursor:pointer}
.nova-stage>.f13-pe-svg{flex:0 0 auto}
@media(max-width:580px){.f13-pe-help{font-size:.83rem}.f12-strip{gap:5px;padding-left:4px;padding-right:4px}.f12-strip .nv-ntile{padding:3px 9px;font-size:1.05rem}}
'''
s=s.replace('</style>\n</head>',css+'</style>\n</head>',1)
out=Path(__file__).resolve().parent.parent/'F13-04-Plans-and-Elevations-PREMIUM-CORE.html';out.write_text(s)
print('created',out,'size',out.stat().st_size,'base',len(base),'engine',len(engine),'core shares',s[b-len(css)-200:b-len(css)]==base[b-200:b])
