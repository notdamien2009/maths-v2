from pathlib import Path
p=Path(__file__).resolve().parent
base=(p/'approved-F13-07-base.html').read_text('utf-8')
css=(p/'F13-08.component.css').read_text('utf-8')
js=(p/'F13-08.engine.js').read_text('utf-8')
css_start=base.index('/* F13-07 local additions only;')
css_end=base.index('</style>',css_start)
pre=base[:css_start]+css+base[css_end:]
engine_start=pre.index('/* F13-07 CUBOID VOLUME AND SURFACE AREA')
engine_tag=pre.rfind('<script>',0,engine_start)
result=pre[:engine_tag]+'<script>\n'+js+'\n</script>\n</body>\n</html>'
# Only change family-specific page headings. The original NOVA core CSS and JS remain unchanged.
head_end=result.index('</head>')
head=result[:head_end].replace('F13-07','F13-08').replace('Cuboid volume and surface area','Cylinder unroll')
result=head+result[head_end:]
start=result.index('</head>');end=result.rfind('<script>')
chunk=result[start:end].replace('F13-07','F13-08').replace('Cuboid volume and surface area','Cylinder unroll')
result=result[:start]+chunk+result[end:]
out=p.parent/'F13-08-Cylinder-Unroll-PREMIUM-CORE.html'
out.write_text(result,encoding='utf-8')
print(out,len(result))
