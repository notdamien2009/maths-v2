# NOVA F13-08 — Cylinder Unroll · Premium-Core QA Report

**Status:** Review build; visual approval outstanding.

**Browser test result:** 248/248 passed. Chromium, 1280px desktop and 380px mobile, real DOM rendering.

## Source integrity
- Original NOVA F0/F1/F12 runtime preserved identically within the embedded JS block. SHA-256: `79abfd9ec5be96c973f28ec7e81e4724c960c9fb8b5fb14af65401eedea49513`.
- Original core CSS preserved before the additive F13-08 component-only stylesheet.
- Embedded offline NOVA Chalk and official pose-based cat mascot are retained.
- Original background, frame, cap, badge strip and interior mascot dock are retained.
- F13-07 component code removed; F13-08 replaces its topic-specific engine only.
- Rebuilding `source/build.py` reproduces exactly the delivered HTML.

## Mathematical verification
- Curved material coordinate retains **exact circumference** `2πr` while the cut seam opens.
- At 100% opening the side surface is one flat rectangle with width `2πr` and height `h`; its ratio was checked against rendered polygon coordinates.
- Both circular end faces have radius `r` and are tangent to opposite rectangle edges in the open net.
- Exact curved area = `2πrh`, two circular ends = `2πr²`, total surface area = `2πrh+2πr²`.
- Five dimension presets tested; sample `r=2`, `h=3`: curved `12π`, ends `8π`, total `20π` square units.
- Intermediate states 15, 35, 55, 75, 90% checked for preserved material circumference and retained faces.

## Interaction verification
- All 12 Watch teaching steps and Guided mode.
- Explore: five presets, radius/height controls, unroll slider, end/side highlighting, visible guide toggle, full net and reclose actions.
- Fast drag across SVG; pointer capture released on pointer-up/cancel, lost capture and window blur.
- Keyboard arrows, Home and End.
- All three Challenge tasks; independent curved and total area, empty-answer handling, wrong-curved-area and missing-end-circle feedback.
- One official mascot and one speech bubble inside stage; zero observed JavaScript exceptions, no page-wide horizontal overflow at both widths.

## Manual visual review
- Initial closed cylinder enlarged to fill the mobile teaching area.
- Smoothed flat rectangle so it renders as one luminous surface, not repetitive facet bars.
- Halfway-open stage checked at 380px and desktop; neither cap clashes with heading or maths cards.
- **User approval required**; automated QA is not a substitute for subjective design review.

## Repository
No GitHub writes, commits or pushes were performed.
