/* F13-08 CYLINDER UNROLL — premium add-on to unchanged NOVA core. */
var NOVA_F13_08_CONFIG={startMode:'watch',preset:'classic',presets:{classic:'Standard · radius 2, height 3',slender:'Tall cylinder · radius 1, height 5',wide:'Wide cylinder · radius 3, height 2',balanced:'Equal measures · radius 2, height 2',column:'Column · radius 2, height 5'}};
(function(){'use strict';
var h=NOVA.h,S=NOVA.svg,F=NOVA.f12,CFG=NOVA_F13_08_CONFIG,EN='F13-08';
var C={cyan:'#43ebff',blue:'#619bff',purple:'#bca3ff',orange:'#ffba7d',gold:'#ffdf78',green:'#7af1bb',ink:'#07152f'};
var PRESETS={classic:[2,3],slender:[1,5],wide:[3,2],balanced:[2,2],column:[2,5]};
function state(p){var q=PRESETS[p]||PRESETS.classic;return {preset:p||'classic',r:q[0],ht:q[1],unroll:0,rotation:0,visible:'all',seams:true,stage:null,refresh:null,svg:null};}
function curved(st){return 2*st.r*st.ht;}
function ends(st){return 2*st.r*st.r;}
function total(st){return curved(st)+ends(st);}
function el(p,tag,props){return S.el(tag,props||{},p);}
function txt(p,x,y,t,role,size,anchor){return NOVA.chalkText(p,x,y,String(t),{role:role||'given',size:size||17,anchor:anchor||'middle'});}
function poly(points){return 'M'+points.map(function(p){return p[0].toFixed(3)+','+p[1].toFixed(3);}).join('L')+'Z';}
function dot(x){return Number(x).toFixed(3).replace(/\.000$/,'');}
function line(p,a,b,color,w,alpha,dash){var e=el(p,'path',{d:'M'+dot(a[0])+' '+dot(a[1])+'L'+dot(b[0])+' '+dot(b[1]),stroke:color,fill:'none','stroke-width':w||1.1,opacity:alpha===undefined?1:alpha,'stroke-linecap':'round'});if(dash)e.setAttribute('stroke-dasharray',dash);return e;}
function face(p,d,fill,stroke){return el(p,'path',{d:d,fill:fill,stroke:stroke||'none'});}
function addDefs(svg,W){var d=svg.querySelector('defs')||el(svg,'defs');
 [['shell','#a7f9ff','#1e8fbc','#12285a'],['cap','#e1faff','#83aff8','#24336b'],['capB','#fff4d5','#e39a7e','#44265c']].forEach(function(g){var a=el(d,'linearGradient',{id:'f13c-'+g[0],x1:'0',y1:'0',x2:String(W),y2:'310',gradientUnits:'userSpaceOnUse'});[[0,g[1],.84],[.45,g[2],.62],[1,g[3],.94]].forEach(function(z){el(a,'stop',{offset:String(z[0]*100)+'%','stop-color':z[1],'stop-opacity':z[2]});});});
 var a=el(d,'radialGradient',{id:'f13c-halo'});el(a,'stop',{offset:'0%','stop-color':'#3177f4','stop-opacity':.19});el(a,'stop',{offset:'100%','stop-color':'#10204b','stop-opacity':0});
 var f=el(d,'filter',{id:'f13c-soft',x:'-100%',y:'-100%',width:'300%',height:'300%'});el(f,'feGaussianBlur',{stdDeviation:4});
}
/* Flatten a developable cylindrical surface without changing material length.
  Its cut seam opens as the retained circular bend angle θ = 2π(1-t) tends to 0.
  Material coordinate u is always a fraction of EXACT circumference 2πr.
  Arc length Rθ = 2πr at EVERY t, including the flat limit. */
function mesh(st,W,mobile){var t=Math.max(0,Math.min(1,st.unroll/100)),r=st.r,ht=st.ht,circ=2*Math.PI*r,theta=2*Math.PI*(1-t);var n=80;
 function surface(u){var phi=theta*u;if(theta<.00001)return [circ*u,0];var R=circ/theta;return [R*Math.sin(phi),R*(1-Math.cos(phi))];}
 var xx=[];for(var i=0;i<=n;i++)xx.push(surface(i/n-.5)[0]);var span=Math.max.apply(null,xx)-Math.min.apply(null,xx);
 var availableW=W-(mobile?54:142),sc=Math.min(availableW/Math.max(span,2*r),(322-58*Math.sin(Math.PI*t))/(ht+r*(.8+3.2*t)),mobile?60:70);
 var netBase=69+(2*r+ht)*sc,closedBase=230+ht*sc/2,baseY=netBase*t+closedBase*(1-t)-25*Math.sin(Math.PI*t),cy=baseY,centerX=W/2;
 var yShift=t===0?0:0; // centre of the material strip is fixed in 3D scene coordinates.
 function project(u,z){var p=surface(u);return [centerX+p[0]*sc+(p[1]-r)*sc*.09,cy-(p[1]-r)*sc*.37-z*sc];}
 // The flat limit receives exactly horizontal top and bottom edges.
 function projectFlat(u,z){return [centerX+circ*u*sc,baseY-z*sc];}
 function P(u,z){var q=project(u,z),f=projectFlat(u,z);var k=Math.pow(t,2.1);return [q[0]*(1-k)+f[0]*k,q[1]*(1-k)+f[1]*k];}
 return {P:P,t:t,sc:sc,base:baseY,r:r,h:ht,circ:circ,W:W,mobile:mobile,surface:surface,theta:theta};
}
function drawSurface(g,st,m){var P=m.P,t=m.t,n=64,faces=[],vis=st.visible==='all'||st.visible==='curved';
 for(var i=0;i<n;i++){var u=i/n-.5,v=(i+1)/n-.5,mid=(u+v)/2,p0=P(u,0),p1=P(v,0),p2=P(v,st.ht),p3=P(u,st.ht);var depth=m.surface(mid)[1];faces.push({depth:depth,i:i,u:u,v:v,pts:[p0,p1,p2,p3]});}
 faces.sort(function(a,b){return b.depth-a.depth;});
 var sg=el(g,'g',{'data-maths':'true-cylinder-curved-surface',opacity:vis?1:.17});
 if(t>.985){el(sg,'path',{d:poly([P(-.5,0),P(.5,0),P(.5,st.ht),P(-.5,st.ht)]),fill:'url(#f13c-shell)',stroke:'none',opacity:.85});}
 else faces.forEach(function(f){var front=Math.cos(m.theta*((f.u+f.v)/2))>0,opacity=(front?.8:.34)+t*.09;
  el(sg,'path',{d:poly(f.pts),fill:front?'url(#f13c-shell)':'#183667',stroke:'none',opacity:opacity});
 });
 // Every line lies on the same developable material sheet, even mid-unroll.
 var seams=el(sg,'g',{'data-seams':'1'});
 if(st.seams){for(var j=1;j<8;j++){var u=j/8-.5;line(seams,P(u,0),P(u,st.ht),j===4?C.cyan:C.blue,j===4?1.7:1,Math.max(.32,t*.62));}
  for(var z=1;z<=3;z++){var zz=st.ht*z/4,pts=[];for(var a=0;a<=n;a++)pts.push(P(a/n-.5,zz));var e=el(seams,'path',{d:'M'+pts.map(function(p){return dot(p[0])+','+dot(p[1]);}).join('L'),stroke:C.blue,'stroke-width':.9,opacity:.29,fill:'none'});}
 }
 [0,st.ht].forEach(function(z){var pts=[];for(var j=0;j<=n;j++){var q=P(j/n-.5,z);pts.push(q);}var d='M'+pts.map(function(p){return dot(p[0])+','+dot(p[1]);}).join('L');if(z===0&&t<.12){var lineEl=el(sg,'path',{d:d,stroke:C.cyan,'stroke-width':1.5,opacity:.48,fill:'none','stroke-dasharray':'5 5'});}else NOVA.neonPath(sg,d,{role:'op',width:2.7});});
 if(t>.04){[-.5,.5].forEach(function(u){var a=P(u,0),b=P(u,st.ht);line(sg,a,b,C.orange,2.8,.98);NOVA.neonPath(sg,'M'+dot(a[0])+' '+dot(a[1])+'L'+dot(b[0])+' '+dot(b[1]),{role:'focus',width:2.4});});}
 // Nonnegotiable material-length property for programmatic QA.
 sg.setAttribute('data-development-length',String(2*Math.PI*st.r));sg.setAttribute('data-development-height',String(st.ht));sg.setAttribute('data-retained-angle',String(m.theta));
 return sg;
}
function drawCaps(g,st,m){var t=m.t,sc=m.sc,r=m.r,h=st.ht,circ=m.circ,W=m.W;
 // Fully flattened net circles are tangent to the top and bottom edges at x=-C/4,+C/4.
 // Closed caps sit at the cylinder's axis; the top is visible as an ellipse.
 var top0=[W/2,m.base-h*sc],bot0=[W/2,m.base];
 var top1=[W/2-circ*sc*.25,m.base-h*sc-r*sc],bot1=[W/2+circ*sc*.25,m.base+r*sc];
 var ease=t*t*(3-2*t);
 function mix(a,b){return a*(1-ease)+b*ease;}
 var ry=sc*r*(.37+.63*ease);var rx=sc*r;var all=el(g,'g',{'data-maths':'two-congruent-end-circles'}),vis=st.visible==='all'||st.visible==='ends';all.setAttribute('opacity',vis?'1':'.19');
 [ {id:'bottom',a:bot0,b:bot1,role:'focus',fill:'url(#f13c-capB)',name:'BOTTOM'}, {id:'top',a:top0,b:top1,role:'given',fill:'url(#f13c-cap)',name:'TOP'}].forEach(function(c){var x=mix(c.a[0],c.b[0]),y=mix(c.a[1],c.b[1]);var cap=el(all,'g',{'data-circle':c.id,'data-radius':String(r)});
  if(c.id==='bottom'&&t<.05){el(cap,'ellipse',{cx:x,cy:y,rx:rx,ry:ry,fill:c.fill,opacity:.19,stroke:C.orange,'stroke-width':1.5,'stroke-dasharray':'5 5'});return;}
  var halo=el(cap,'ellipse',{cx:x,cy:y,rx:rx+3,ry:ry+3,fill:'none',stroke:c.id==='top'?C.cyan:C.orange,'stroke-width':6,opacity:.12,filter:'url(#f13c-soft)'});
  el(cap,'ellipse',{cx:x,cy:y,rx:rx,ry:ry,fill:c.fill,stroke:c.id==='top'?C.cyan:C.orange,'stroke-width':2.4});
  if(t>.42){line(cap,[x,y],[x+rx*.88,y],C.gold,1.7,.95);el(cap,'circle',{cx:x,cy:y,r:3.1,fill:C.gold});txt(cap,x,y-9,'r = '+r,'given',m.mobile?13:15);}
  if(t>.82)txt(cap,x,y+ry*.48,c.name,'given',m.mobile?12.4:15);
 });
 // When the net is flat, top and bottom circles touch the rectangle at a single tangent point.
 if(t>.97){[[top1[0],m.base-h*sc],[bot1[0],m.base]].forEach(function(pt){el(all,'circle',{cx:pt[0],cy:pt[1],r:3.5,fill:C.gold,stroke:C.ink,'stroke-width':1.2});});}
 return all;
}
function metricCard(g,x,y,w,ht,color,title,mid,big,foot,mobile){el(g,'rect',{x:x,y:y,width:w,height:ht,rx:14,fill:'#06182c',stroke:color,'stroke-width':1.8});el(g,'path',{d:'M'+(x+14)+','+(y+4)+'H'+(x+w-14),stroke:color,'stroke-width':3,opacity:.65});txt(g,x+w/2,y+27,title,'given',mobile?16:19);txt(g,x+w/2,y+56,mid,'op',mobile?17:20);txt(g,x+w/2,y+88,big,'result',mobile?22:25);txt(g,x+w/2,y+ht-15,foot,'given',mobile?12.2:14.5);}
function scene(root,st,W,H){root.replaceChildren();var m=mesh(st,W,W<500),t=m.t,mob=m.mobile,sc=m.sc;
 el(root,'ellipse',{cx:W/2,cy:255,rx:mob?180:292,ry:175,fill:'url(#f13c-halo)',opacity:.9});
 txt(root,W/2,54,t>.98?'CYLINDER NET · 1 RECTANGLE + 2 CIRCLES':t<.02?'3D CYLINDER · 3 SURFACES':'CUT THE CURVED SURFACE · UNROLL','given',mob?15:18);
 var g=el(root,'g',{'data-maths':'cylinder-net','data-unroll':String(st.unroll)});
 if(t>.015){ // Ambient silhouette of cut seam and motion guide.
  var a=m.P(-.5,0),b=m.P(-.5,st.ht);line(g,a,b,C.orange,2.2,.8);
 }
 drawSurface(g,st,m);drawCaps(g,st,m);
 if(t<.1){txt(root,W/2,375,'top + curved side + bottom','given',mob?13.5:17);}
 else if(t>.82){var y=m.base-st.ht*sc;txt(root,W/2,y-8,'width = 2πr = '+(2*st.r)+'π','op',mob?14:17);txt(root,Math.min(W-24,W/2+m.circ*sc/2+8),y+st.ht*sc/2,'h = '+st.ht,'focus',mob?13:16,'end');}
 else {txt(root,W/2,404,'the curved surface keeps its exact length','given',mob?13:16);}
 var yC=mob?422:424,ww=mob?190:248,x1=mob?12:125,x2=mob?218:407;
 metricCard(root,x1,yC,ww,140,C.cyan,'CURVED AREA', (2*st.r)+'π × '+st.ht,curved(st)+'π units²','rectangle · 2πrh',mob);
 metricCard(root,x2,yC,ww,140,C.gold,'TOTAL AREA',curved(st)+'π + '+ends(st)+'π',total(st)+'π units²','side + two circles',mob);
}
function stageBuild(stage,st,message,pose){if(stage._f13Cleanup)stage._f13Cleanup();stage.replaceChildren();var mob=innerWidth<=580,W=mob?420:780,H=mob?590:590;
 NOVA.cap(stage,'CYLINDER UNROLL · r '+st.r+' · h '+st.ht,'3 SURFACES');
 var svg=S.root(W,H,'An exact developable cylindrical side surface opens smoothly into a rectangle of width two pi r and height h, with two congruent circular ends and live surface-area calculations.');svg.classList.add('f13c-svg');svg.setAttribute('tabindex','0');svg.setAttribute('role','group');svg.setAttribute('aria-label','Interactive cylinder. Drag horizontally to unroll or close. Use left or right arrow keys to adjust the unroll.');stage.appendChild(svg);addDefs(svg,W);
 var root=el(svg,'g',{'data-cylinder-root':'1'}),raf=0;
 function draw(){scene(root,st,W,H);var nt=stage.querySelectorAll('.f12-strip .nv-ntile .mt');[curved(st)+'π',ends(st)+'π',total(st)+'π'].forEach(function(n,i){if(nt[i])nt[i].textContent=n;});}
 function refresh(){if(raf)cancelAnimationFrame(raf);raf=requestAnimationFrame(function(){raf=0;draw();NOVA.events.emit('value',{engine:EN,control:'cylinder',value:{r:st.r,h:st.ht,unroll:st.unroll,curvedPi:curved(st),endsPi:ends(st),totalPi:total(st)}});});}
 st.refresh=refresh;st.stage=stage;st.svg=svg;draw();F.strip(stage,[['curved',curved(st)+'π','op'],['2 ends',ends(st)+'π','focus'],['total',total(st)+'π','result']]);
 NOVA.scene.helperStrip(stage,pose||'explain',message||'The curved side becomes a rectangle. The two circles make the cylinder’s ends.');
 var ctrl=new AbortController(),pointer=null,startX=0,startUnroll=0;
 stage._f13Cleanup=function(){ctrl.abort();if(raf)cancelAnimationFrame(raf);pointer=null;svg.classList.remove('f13c-grab');};
 svg.addEventListener('pointerdown',function(e){if(e.pointerType==='mouse'&&e.button!==0)return;pointer=e.pointerId;startX=e.clientX;startUnroll=st.unroll;try{svg.setPointerCapture(pointer);}catch(x){}svg.classList.add('f13c-grab');e.preventDefault();},{signal:ctrl.signal});
 svg.addEventListener('pointermove',function(e){if(pointer!==e.pointerId)return;var rect=svg.getBoundingClientRect();st.unroll=Math.max(0,Math.min(100,Math.round(startUnroll+(e.clientX-startX)/Math.max(1,rect.width)*150)));refresh();e.preventDefault();},{signal:ctrl.signal});
 function stop(e){if(e.pointerId!==pointer)return;pointer=null;svg.classList.remove('f13c-grab');try{if(svg.hasPointerCapture(e.pointerId))svg.releasePointerCapture(e.pointerId);}catch(x){} }
 ['pointerup','pointercancel'].forEach(function(k){svg.addEventListener(k,stop,{signal:ctrl.signal});});svg.addEventListener('lostpointercapture',function(e){if(e.pointerId===pointer){pointer=null;svg.classList.remove('f13c-grab');}},{signal:ctrl.signal});window.addEventListener('blur',function(){pointer=null;svg.classList.remove('f13c-grab');},{signal:ctrl.signal});
 svg.addEventListener('keydown',function(e){if(['ArrowRight','ArrowLeft','Home','End'].indexOf(e.key)<0)return;e.preventDefault();st.unroll=e.key==='Home'?0:e.key==='End'?100:Math.max(0,Math.min(100,st.unroll+(e.key==='ArrowRight'?5:-5)));refresh();},{signal:ctrl.signal});
 return svg;
}
function btn(label,fn,cls){return h('button',{class:'nova-btn'+(cls?' '+cls:''),text:label,onclick:fn});}
function row(panel,nodes){panel.appendChild(h('div',{class:'pr-row'},nodes));}
function slider(label,min,max,val,fn){var e=h('input',{type:'range',min:String(min),max:String(max),step:'1',value:String(val),'aria-label':label}),v=h('span',{class:'f13c-value',text:String(val)}),l=h('label',{class:'f13c-lab'},[label+' ',e,v]);e.oninput=function(){v.textContent=e.value;fn(+e.value);};return {node:l,inp:e,set:function(x){e.value=x;v.textContent=x;}};}
var STEPS=[
 {n:'Meet the curved cylinder',r:2,ht:3,u:0,pose:'explain',m:'This cylinder has one curved side and two congruent circular ends.',q:'How many surfaces does it have?'},
 {n:'Find the radius',r:2,ht:3,u:0,pose:'point-right',m:'Radius is the distance from the centre to the circular edge. Here it is two units.',q:'What is the diameter if radius is two?'},
 {n:'Find the circumference',r:2,ht:3,u:10,pose:'think',m:'The distance right around either circular end is two times pi times the radius. That is four pi units.',q:'What length does the cylinder’s curved material wrap around?'},
 {n:'Cut the vertical seam',r:2,ht:3,u:22,pose:'point-right',m:'Imagine making one careful straight cut down the curved side of the cylinder.',q:'Which measurement stays unchanged when we open it?'},
 {n:'Open the curved side',r:2,ht:3,u:48,pose:'explain',m:'As the side opens, its material keeps the same length. We are not stretching or shrinking it.',q:'Is this material length still four pi units?'},
 {n:'Flatten to a rectangle',r:2,ht:3,u:100,pose:'celebrate',m:'The curved surface unfolds to a rectangle. Its width is four pi and its height is three.',q:'What are the rectangle’s two dimensions?'},
 {n:'Calculate curved area',r:2,ht:3,u:100,pose:'point-right',m:'Multiply width by height: four pi times three gives twelve pi square units.',q:'Is curved area measured in square units or cubic units?'},
 {n:'Inspect both circular ends',r:2,ht:3,u:100,pose:'explain',m:'Each circular end has area pi times radius squared. Radius two gives four pi for one circle.',q:'Why do we need two circles?'},
 {n:'Calculate both end areas',r:2,ht:3,u:100,pose:'think',m:'Two congruent circles give eight pi square units altogether.',q:'How do the two ends contribute to surface area?'},
 {n:'Add all exterior surfaces',r:2,ht:3,u:100,pose:'celebrate',m:'Twelve pi for the curved side plus eight pi for the ends makes twenty pi square units.',q:'What is the total surface area?'},
 {n:'Change the radius',r:3,ht:2,u:100,pose:'think',m:'The width changes when radius changes: two times pi times three is six pi units.',q:'How does changing radius affect BOTH parts of the net?'},
 {n:'Transfer to a tall cylinder',r:1,ht:5,u:100,pose:'point-right',m:'For radius one and height five, curved area is ten pi and both ends total two pi.',q:'Find the new total surface area in terms of pi.'}
];
function stepState(p){var q=state('classic');q.r=p.r;q.ht=p.ht;q.unroll=p.u;return q;}
var def={id:EN,title:'Cylinder unroll',config:CFG,steps:STEPS.map(function(p){return {name:p.n,narration:p.m,prompt:p.q,dur:1800};}),
 alt:'Neon glass cylinder with a continuous exact-length mathematical unroll into one rectangular curved surface and two congruent circular end faces, with all areas expressed in multiples of pi.',
 staticAlt:'The curved surface of a cylinder opens to a rectangle of width 2πr and height h, area 2πrh. Two circular ends each have area πr², so total surface area is 2πrh + 2πr². Radius 2, height 3 gives 12π + 8π = 20π square units.',
 render:function(i,stage){var p=STEPS[i];stageBuild(stage,stepState(p),p.m,p.pose);},
 exploreIntro:'Drag the cylinder to open it, or use the precise unroll slider. Change radius and height to discover the rectangle’s width and the two matching circular ends.',
 explore:function(panel,stage,api){var st=state('classic');if(api.onCleanup)api.onCleanup(function(){if(stage._f13Cleanup)stage._f13Cleanup();});
 var sel=h('select',{class:'nova-input','aria-label':'Cylinder preset'});Object.keys(CFG.presets).forEach(function(k){sel.appendChild(h('option',{value:k,text:CFG.presets[k]}));});sel.value='classic';row(panel,[h('label',{class:'f13c-lab'},['PRESET ',sel])]);
 var radius=slider('RADIUS',1,4,st.r,function(n){st.r=n;st.preset='custom';st.refresh();}),height=slider('HEIGHT',1,6,st.ht,function(n){st.ht=n;st.preset='custom';st.refresh();}),unroll=slider('UNROLL (%)',0,100,0,function(n){st.unroll=n;st.refresh();});
 row(panel,[radius.node,height.node,unroll.node]);
 function apply(key){var p=PRESETS[key];st.preset=key;st.r=p[0];st.ht=p[1];radius.set(st.r);height.set(st.ht);st.refresh();}
 sel.onchange=function(){apply(sel.value);};
 var focus=h('select',{class:'nova-input','aria-label':'Highlight cylinder surfaces'});[['all','All three surfaces'],['curved','Curved side only'],['ends','Two circles only']].forEach(function(x){focus.appendChild(h('option',{value:x[0],text:x[1]}));});focus.onchange=function(){st.visible=focus.value;st.refresh();};row(panel,[h('label',{class:'f13c-lab'},['HIGHLIGHT ',focus])]);
 var cb=h('input',{type:'checkbox','aria-label':'Show curved material grid'});cb.checked=true;cb.onchange=function(){st.seams=cb.checked;st.refresh();};
 row(panel,[h('label',{class:'f13c-lab'},[cb,' Show curved material grid']),btn('3D Cylinder',function(){st.unroll=0;unroll.set(0);st.refresh();},'ghost'),btn('Unroll net',function(){st.unroll=100;unroll.set(100);st.refresh();},'ghost'),btn('Reset',function(){sel.value='classic';apply('classic');st.unroll=0;unroll.set(0);focus.value='all';st.visible='all';cb.checked=true;st.seams=true;st.refresh();},'ghost')]);
 panel.appendChild(h('p',{class:'f13c-hint',text:'The rectangle comes ONLY from the curved side. Its width is the circumference 2πr. Add the two circles to obtain the total external surface area.'}));
 stageBuild(stage,st,'Unroll the curved side and keep the two round ends. Every surface contributes to the total area.','explain');
 CFG._explore={state:st,preset:function(k){sel.value=k;sel.onchange();},unroll:function(n){unroll.inp.value=n;unroll.inp.oninput();},dimensions:function(r,z){radius.inp.value=r;radius.inp.oninput();height.inp.value=z;height.inp.oninput();},focus:function(k){focus.value=k;focus.onchange();}};
 },
 challenge:function(panel,api,stage){var tasks=[
 {r:2,ht:3,a:12,s:20,q:'A cylinder has radius 2 and height 3. Give the coefficient of π for its CURVED area and TOTAL surface area.',hint:'Curved = 2 × radius × height. Total = curved + 2 × radius².'},
 {r:3,ht:2,a:12,s:30,q:'A cylinder has radius 3 and height 2. Find the curved-area coefficient and the total-area coefficient of π.',hint:'Curved = 2 × 3 × 2. Each circle is 9π; count two circles.'},
 {r:1,ht:5,a:10,s:12,q:'A narrow cylinder has radius 1 and height 5. Find the two coefficients of π.',hint:'Its curved area is 2π × 5. Each circular end has area π.'}
 ];var st=state('classic'),k=0,timer=0,q=h('p',{class:'pr-task'}),a=h('input',{type:'number',step:'1',min:'0',class:'nova-input',placeholder:'e.g. 12 for 12π','aria-label':'Curved area coefficient of pi'}),b=h('input',{type:'number',step:'1',min:'0',class:'nova-input',placeholder:'e.g. 20 for 20π','aria-label':'Total surface area coefficient of pi'}),out=h('p',{class:'f13c-feedback','aria-live':'polite'});
 function load(i){k=i;var t=tasks[k];st.r=t.r;st.ht=t.ht;st.unroll=0;st.visible='all';a.value='';b.value='';q.textContent=(i+1)+' / '+tasks.length+' · '+t.q;out.textContent='';stageBuild(stage,st,'Find the curved rectangle area first. Then add BOTH circular ends.','think');}
 function check(){var t=tasks[k],av=Number(a.value),bv=Number(b.value),ok=a.value.trim()!==''&&b.value.trim()!==''&&av===t.a&&bv===t.s;
 var msg=ok?'Correct: curved '+t.a+'π square units and total '+t.s+'π square units.':a.value.trim()===''||b.value.trim()===''?'Enter BOTH coefficients of pi.':av!==t.a?'Curved area is the width of the rectangle, 2πr, multiplied by height.':'The curved area is right. Remember BOTH circle ends: add 2πr², not just one circle.';
 out.textContent=msg;api.check(ok,msg,{task:k,curvedPi:av,totalPi:bv,expectedCurved:t.a,expectedTotal:t.s});if(ok&&k<tasks.length-1){if(timer)clearTimeout(timer);timer=setTimeout(function(){load(k+1);},1200);}return ok;}
 if(api.onCleanup)api.onCleanup(function(){if(timer)clearTimeout(timer);if(stage._f13Cleanup)stage._f13Cleanup();});
 panel.appendChild(q);row(panel,[h('label',{class:'f13c-answer'},['CURVED AREA (×π units²) ',a]),h('label',{class:'f13c-answer'},['TOTAL AREA (×π units²) ',b])]);
 row(panel,[btn('Check answers',check,'primary'),btn('Hint',function(){api.hint(tasks[k].hint);},'ghost'),btn('See cylinder net',function(){st.unroll=st.unroll>=95?0:100;st.refresh();},'ghost')]);panel.appendChild(out);
 panel.appendChild(h('p',{class:'f13c-hint',text:'Write just the number multiplying π. For example, enter 12 for 12π. Total area includes BOTH circles.'}));
 load(0);CFG._challenge={state:st,tasks:tasks,load:load,check:check,task:function(){return k;},inputs:[a,b]};
 }
};
NOVA.bankMount({id:EN,num:'F13·08',title:'Cylinder unroll',def:def,linked:['F0-01','F0-02','F0-03','F0-04','F0-05','F12-03','F13-01','F13-02','F13-03','F13-04','F13-05','F13-06','F13-07'],spec:{
 purpose:'Demonstrate the complete net and total surface area of a closed cylinder (KS3 Year 8 / Year 9).',
 params:'Radius 1–4 units, height 1–6. Exact curved area 2πrh, two end circles 2πr², total surface area 2πrh+2πr².',
 presets:'Five real cylinder dimensions with precise integer multiples of π.',
 steps:STEPS.map(function(s){return s.n;}).join(' → '),
 interactions:'Twelve Watch/Guided teaching steps; smooth drag, keyboard and slider-driven developable unroll; five dimensions; highlight curved strip or two circle ends; three marked challenge tasks.',
 traps:'Curved area is not the whole surface: a closed cylinder also has TWO circular ends. Circumference is a length 2πr; curved area requires multiplication by height.',
 gcse:'Cylinder total surface area, exact answers involving π, surface nets and volume links.'}});
var log=document.getElementById('log'),ev=function(e){log.textContent=new Date(e.time).toLocaleTimeString()+' '+e.type+' '+JSON.stringify(e.detail)+'\n'+log.textContent.slice(0,5000);};NOVA.events.history().forEach(ev);NOVA.events.on('*',ev);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
