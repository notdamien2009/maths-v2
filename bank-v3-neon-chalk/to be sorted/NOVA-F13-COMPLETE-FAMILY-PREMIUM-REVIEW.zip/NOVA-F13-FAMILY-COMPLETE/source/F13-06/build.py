"""Rebuild F13-06 from approved NOVA F13-05 core and F13-06 additive engine.
Only the header details and component-local CSS/JS change. No network or Git required.
"""
from pathlib import Path
BASE_DIR=Path(__file__).resolve().parent
base=(BASE_DIR/'approved-F13-05-base.html').read_text(encoding='utf-8')
css=(BASE_DIR/'F13-06.component.css').read_text(encoding='utf-8')
engine=(BASE_DIR/'F13-06.engine.js').read_text(encoding='utf-8')
marker='/* F13-05 component-only presentation. Above CSS is the unmodified official NOVA production shell. */'
start=base.index(marker)
pre=base[:start]
aft=base[base.index('</style>',start):]
start_script=aft.index('<script>')
end_script=aft.index('</script>',start_script)+len('</script>')
head=aft[:start_script]
head=head.replace('F13-05','F13-06').replace('Cube-stacking volume','Prism volume slicer')
head=head.replace('Build 3D solids one unit cube at a time. Reveal horizontal layers and discover why length × width × height works.',
                  'Slide a cross-section through a 3D prism and discover why volume equals area × perpendicular length.')
core=aft[start_script:end_script]
result=pre+css+head+core+'\n<script>\n'+engine+'\n</script>\n</body>\n</html>'
output=BASE_DIR.parent/'F13-06-Prism-Volume-Slicer-PREMIUM-CORE.html'
output.write_text(result,encoding='utf-8')
print(f'Created {output} ({len(result):,} characters). NOVA core preserved.')
