# NOVA F13-06 — Prism Volume Slicer · Premium Core Review

**Status:** Functional and visual review build (not final GOLD sign-off).
**Browser QA:** **148/148 passed** in headless Chromium at **1280px** and **380px**.
**Repository:** No GitHub changes.

## Provenance and consistency

- Built as an *additive* F13 engine using the approved F13-05 production HTML as an exact source for the shared NOVA runtime and original stylesheet.
- Exact inline shared NOVA JavaScript core was checked against F13-05, **byte for byte**.
- Original F0/F1 neon/chalk primitives, embedded fonts, NOVA stage backdrop and official WebP pose-pack mascot are used, not substituted or redrawn.
- One stage, one mascot, one caption bubble; no inserted centre row or new shell.
- A reversible local component-specific stylesheet and source engine are supplied.

## Mathematical checks

| Prism cross-section | Exact area | Default perpendicular length | Default volume |
|---|---:|---:|---:|
| Rectangle 3 × 2 | 6 units² | 5 | 30 units³ |
| Right triangle base 4, height 3 | 6 units² | 4 | 24 units³ |
| Trapezium parallel sides 4 and 2, height 3 | 9 units² | 3 | 27 units³ |
| L section: 4 × 3 minus 2 × 2 | 8 units² | 4 | 32 units³ |
| House pentagon: 4 × 2 + ½ × 4 × 1 | 10 units² | 4 | 40 units³ |

All cross-sections are generated as polygon vertices and areas calculated by the shoelace formula. The moving gold plane is a translated copy of the constant cross-section; length is the extrusion distance perpendicular to that cross-section. No image swapping is used.

## Browser checks

- Watch: **11** lesson steps, each with a rendered 3D prism, cross-section card, volume card, official mascot and original stage styling at both sizes.
- Guided mode loads using the original NOVA engine.
- Explore: all five solids produce the correct area, length and volume. Changing the length from 4 to 7 for the triangle gives 6 × 7 = 42 units³ while area remains 6 units².
- Gold cutting plane: position slider, keyboard left/right/home/end and rapid pointer-captured dragging; changing the position never changes the prism volume.
- Toggles for repeated cross-sections and highlighted front face.
- Challenge: independently checks square-unit area and cubic-unit volume; rejects missing answers, wrong area and right-area/wrong-volume cases; accepts 30, 24 and 32 units³ in the three tests and advances correctly.
- 0 JavaScript page exceptions observed. 0 horizontal document overflow at 380px and 1280px. The official mascot remains inside the stage when modes change.

The full **148 individual checks** and their pass status are in `QA-RESULTS.json`. Re-run with `python recheck.py` on an environment with Python Playwright and Chromium installed (adjust Chromium executable path on Windows).

## Review gate

The automated tests demonstrate maths and interactions, not user approval of artistic quality. Review the rendered screenshots and open the HTML in a browser before approving the F13-06 visual as GOLD.
