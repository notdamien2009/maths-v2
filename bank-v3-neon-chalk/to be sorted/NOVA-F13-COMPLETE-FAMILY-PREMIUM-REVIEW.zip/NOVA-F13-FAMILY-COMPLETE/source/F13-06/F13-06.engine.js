/* F13-06 PRISM VOLUME SLICER — additive engine. F0/F1/F12 runtime and assets stay intact. */
var NOVA_F13_06_CONFIG={startMode:'watch',preset:'triangle',presets:{
 rectangle:'Rectangular prism · 3 × 2',triangle:'Right triangular prism · base 4, height 3',trapezium:'Trapezoidal prism · parallel sides 4 and 2',lshape:'L-section prism · 4 × 3 with notch',pentagon:'House-section prism · composite area'}};
(function(){'use strict';
var h=NOVA.h,S=NOVA.svg,F=NOVA.f12,EN='F13-06',CFG=NOVA_F13_06_CONFIG;
var PALS={cyan:'#40edff',orange:'#ffb26c',purple:'#bc9aff',mint:'#7af1bd',gold:'#ffdc7a',navy:'#07172d'};
var SHAPES={
 rectangle:{p:[[0,0],[3,0],[3,2],[0,2]],defaultLength:5,areaText:'3 × 2 = 6',explain:'A rectangle, 3 units wide and 2 units high.',formula:'3 × 2'},
 triangle:{p:[[0,0],[4,0],[0,3]],defaultLength:4,areaText:'½ × 4 × 3 = 6',explain:'A right triangle, base 4 units and height 3 units.',formula:'½ × 4 × 3'},
 trapezium:{p:[[0,0],[4,0],[3,3],[1,3]],defaultLength:3,areaText:'½ × (4 + 2) × 3 = 9',explain:'A trapezium with parallel sides 4 and 2, height 3.',formula:'½ × (4 + 2) × 3'},
 lshape:{p:[[0,0],[4,0],[4,1],[2,1],[2,3],[0,3]],defaultLength:4,areaText:'4 × 3 − 2 × 2 = 8',explain:'An L section: a 4 by 3 rectangle with a 2 by 2 square removed.',formula:'12 − 4'},
 pentagon:{p:[[0,0],[4,0],[4,2],[2,3],[0,2]],defaultLength:4,areaText:'4 × 2 + ½ × 4 × 1 = 10',explain:'A house-shaped cross-section: rectangle plus a triangle.',formula:'8 + 2'}
};
function area(poly){var v=0;for(var i=0;i<poly.length;i++){var b=poly[(i+1)%poly.length];v+=poly[i][0]*b[1]-poly[i][1]*b[0];}return Math.abs(v)/2;}
function unit(n){return Math.round(n*1000)/1000;}
function dims(shape){var p=SHAPES[shape].p;return [Math.max.apply(null,p.map(function(a){return a[0];})),Math.max.apply(null,p.map(function(a){return a[1];}))];}
function state(shape){shape=shape||'triangle';return {shape:shape,length:SHAPES[shape].defaultLength,cut:.44,showSlabs:true,showFace:true,showLabels:true,ghost:false,azimuth:0,activeDrag:null,stage:null,sv:null,refresh:null,step:0};}
function el(p,t,a){return S.el(t,a||{},p);}function pts(v){return 'M'+v.map(function(q){return q[0].toFixed(2)+','+q[1].toFixed(2);}).join('L')+'Z';}
function line(v){return 'M'+v.map(function(q){return q[0].toFixed(2)+','+q[1].toFixed(2);}).join('L');}
function text(p,x,y,value,role,size,anchor){return NOVA.chalkText(p,x,y,String(value),{role:role||'given',size:size||17,anchor:anchor||'middle'});}
function halo(p,v,role,w){return NOVA.neonPath(p,pts(v),{role:role||'op',width:w||2.2});}
function seg(p,v,role,w,dash){var o=el(p,'path',{d:line(v),stroke:role||PALS.cyan,'stroke-width':w||2.0,fill:'none','stroke-linecap':'round',opacity:1});if(dash)o.setAttribute('stroke-dasharray',dash);return o;}
function defs(sv){var d=sv.querySelector('defs')||el(sv,'defs',{});
 [['face','#98f8ff','#3283be','#0a2e51'],['top','#f0feff','#67bded','#12527e'],['orange','#ffe6ca','#c17b56','#5b3e5d'],['purple','#dfd6ff','#796ebd','#28266b']].forEach(function(a){var g=el(d,'linearGradient',{id:'f13s-'+a[0],x1:'5%',y1:'0%',x2:'95%',y2:'95%'});[[0,a[1],.80],[.42,a[2],.75],[1,a[3],.85]].forEach(function(z){el(g,'stop',{offset:z[0],'stop-color':z[1],'stop-opacity':z[2]});});});
 var g=el(d,'radialGradient',{id:'f13s-aura'});el(g,'stop',{offset:'0%','stop-color':'#1ac9e6','stop-opacity':.25});el(g,'stop',{offset:'100%','stop-color':'#1ac9e6','stop-opacity':0});
 var c=el(d,'linearGradient',{id:'f13s-slice',x1:'0%',y1:'0%',x2:'100%',y2:'100%'});el(c,'stop',{offset:'0%','stop-color':'#fff4b6','stop-opacity':.62});el(c,'stop',{offset:'100%','stop-color':'#ffc267','stop-opacity':.25});}
function proj(st,W,H){var xy=dims(st.shape),L=st.length,ang=Math.PI/4+st.azimuth;var cs=Math.cos(ang),sn=Math.sin(ang),yu=.52*sn,yd=.52*cs;
 // Visible prism bounds determine responsive scale; avoid clipping at long lengths.
 var q=[],p=SHAPES[st.shape].p;p.forEach(function(v){[0,L].forEach(function(d){q.push([(v[0]*cs-d*sn),(v[0]*yu+d*yd)-v[1]*1.09]);});});
 var x0=Math.min.apply(null,q.map(function(z){return z[0];})),x1=Math.max.apply(null,q.map(function(z){return z[0];})),y0=Math.min.apply(null,q.map(function(z){return z[1];})),y1=Math.max.apply(null,q.map(function(z){return z[1];}));
 var mobile=W<500, box={left:mobile?31:118,right:mobile?W-26:W-95,top:mobile?80:58,bottom:mobile?349:369};
 var scale=Math.min((box.right-box.left)/(x1-x0+1.1),(box.bottom-box.top)/(y1-y0+.95),mobile?75:79);
 var cx=(box.left+box.right)/2-(x0+x1)*scale/2,cy=(box.top+box.bottom)/2-(y0+y1)*scale/2;
 return {scale:scale,to:function(v,d){return [cx+(v[0]*cs-d*sn)*scale,cy+((v[0]*yu+d*yd)-v[1]*1.09)*scale];},box:box};}
function faceAt(st,P,d){return SHAPES[st.shape].p.map(function(q){return P.to(q,d);});}
function outerEdgeVisible(a,b,angle){var du=b[0]-a[0],dv=b[1]-a[1],x=dv,y=-du;return x*Math.cos(angle)+y*.78>0;}
function card(root,x,y,w,h,role,label){var gg=el(root,'g',{class:'f13s-card','data-card':label});el(gg,'rect',{x:x,y:y,width:w,height:h,rx:13,fill:'#06172c',stroke:role,'stroke-width':1.55,'stroke-opacity':.92});el(gg,'path',{d:'M'+(x+13)+','+(y+3)+'H'+(x+w-13),stroke:role,'stroke-width':2.5,opacity:.38});return gg;}
function grid(root,P,st,W){var c=el(root,'g',{opacity:.4,'aria-hidden':'true'}),origin=P.to([0,0],0),dim=dims(st.shape);
 for(var k=0;k<=Math.ceil(st.length);k++){var a=P.to([0,0],k),b=P.to([dim[0],0],k);seg(c,[a,b],'#35a6cd',k===0||k===st.length?1.2:.65,'4 9');}
 for(var j=0;j<=dim[0];j++){seg(c,[P.to([j,0],0),P.to([j,0],st.length)],'#35a6cd',.8,'4 9');}
 el(c,'ellipse',{cx:origin[0],cy:origin[1]+13,rx:W<500?110:155,ry:16,fill:'#133e6d',opacity:.2});}
function renderSolid(root,st,W,H){var P=proj(st,W,H),poly=SHAPES[st.shape].p,angle=Math.PI/4+st.azimuth,front=faceAt(st,P,0),back=faceAt(st,P,st.length),cut=Math.min(st.length,Math.max(0,st.cut*st.length)),plane=faceAt(st,P,cut);
 var aura=el(root,'g',{'aria-hidden':'true'});el(aura,'ellipse',{cx:W/2,cy:205,rx:W<500?175:260,ry:165,fill:'url(#f13s-aura)'});
 grid(root,P,st,W);
 var backG=el(root,'g',{'aria-hidden':'true',opacity:st.ghost?.45:.24});el(backG,'path',{d:pts(back),fill:'url(#f13s-face)',stroke:'#79d9f6','stroke-width':1.4,'stroke-dasharray':'5 8'});
 var sides=el(root,'g',{'data-maths':'real-prism-side-faces'});poly.forEach(function(a,i){var b=poly[(i+1)%poly.length],v=[P.to(a,0),P.to(b,0),P.to(b,st.length),P.to(a,st.length)],on=outerEdgeVisible(a,b,angle);
  if(!on)return;var role=i%2===0?'orange':'purple',pg=el(sides,'g',{'data-edge':i});el(pg,'path',{d:pts(v),fill:'url(#f13s-'+role+')',stroke:'none',opacity:.95});
  NOVA.neonPath(pg,pts(v),{role:role==='orange'?'support':'focus',width:1.9});});
 // The cross-section at d=0 is a translucent solid face; it remains visible while the plane moves.
 if(st.showFace){var fg=el(root,'g',{'data-maths':'cross-section-front'});el(fg,'path',{d:pts(front),fill:'url(#f13s-face)',stroke:'none',opacity:.89});NOVA.neonPath(fg,pts(front),{role:'op',width:3.1});}
 else {el(root,'path',{d:pts(front),fill:'none',stroke:'#46afca','stroke-width':1.5,'stroke-dasharray':'4 7',opacity:.6});}
 // True parallel sliced copies of the defining polygon (not arbitrary rectangles).
 if(st.showSlabs){var n=Math.floor(st.length),layers=el(root,'g',{'data-maths':'parallel-cross-section-layers',opacity:.54});for(var j=1;j<n;j++){var d=j,copy=faceAt(st,P,d);el(layers,'path',{d:pts(copy),fill:'none',stroke:'#2cbed6','stroke-width':1.25,'stroke-dasharray':'4 8'});}}
 // Moving slice plane perpendicular to the extrusion axis.
 var planeG=el(root,'g',{'data-maths':'cross-section-slice','data-cut':cut.toFixed(2)});
 el(planeG,'path',{d:pts(plane),fill:'url(#f13s-slice)',stroke:'#ffdf87','stroke-width':2.8,opacity:.91,'stroke-linejoin':'round'});
 halo(planeG,plane,'focus',2.7);
 plane.forEach(function(a){el(planeG,'circle',{cx:a[0],cy:a[1],r:2.5,fill:'#fff5bf',stroke:PALS.gold,'stroke-width':1.1});});
 var center=[plane.reduce(function(s,v){return s+v[0];},0)/plane.length,plane.reduce(function(s,v){return s+v[1];},0)/plane.length];
 if(st.showLabels){var pos=P.to([0,0],0),pos2=P.to([0,0],st.length),pc=P.to([0,0],cut);var pa=[pos[0]-20,pos[1]+18],pb=[pos2[0]-20,pos2[1]+18];
  seg(root,[pa,pb],'#a7f9ff',1.7,'5 6');text(root,(pa[0]+pb[0])/2,(pa[1]+pb[1])/2+26,'length '+st.length,'given',W<500?17:18);
  var labelY=Math.max(49,Math.min(365,center[1]-36));var labelX=Math.max(75,Math.min(W-65,center[0]+9));text(root,labelX,labelY,'SLICE','focus',W<500?17:19);}
 return {P:P,cut:cut,plane:plane};}
function crossDiagram(g,x,y,w,h,st,compact){var shape=SHAPES[st.shape],p=shape.p,dim=dims(st.shape),A=area(p);text(g,x+w/2,y+21,'CROSS-SECTION','op',compact?17:18);
 var mx=x+w/2,cy=y+78,scale=Math.min((w-38)/(dim[0]+.2),53/(dim[1]+.2));var v=p.map(function(q){return [mx+(q[0]-dim[0]/2)*scale,cy+(dim[1]/2-q[1])*scale];});
 el(g,'path',{d:pts(v),fill:'#125078','fill-opacity':.7,stroke:'#56e6ff','stroke-width':2.0,'stroke-linejoin':'round'});v.forEach(function(q){el(g,'circle',{cx:q[0],cy:q[1],r:2,fill:'#f0ffff'});});
 text(g,x+w/2,y+h-13,shape.areaText+' units²','result',compact?12.6:15.5);}
function infoCard(g,x,y,w,h,st,compact){var A=area(SHAPES[st.shape].p),V=A*st.length;text(g,x+w/2,y+22,'VOLUME','focus',compact?18:19);
 text(g,x+w/2,y+49,A+' × '+st.length+' = '+V,'given',compact?20:24);
 text(g,x+w/2,y+77,V+' units³','result',compact?22:23);
 text(g,x+w/2,y+h-15,'area × perpendicular length','given',compact?12.5:15);
 }
function renderStage(stage,st,message,pose){if(stage._f13Cleanup)stage._f13Cleanup();stage.replaceChildren();var M=window.innerWidth<=580,W=M?420:780,H=M?553:592;
 NOVA.cap(stage,'PRISM VOLUME SLICER · '+(CFG.presets[st.shape]||'PRISM'),'area × length');
 var sv=S.root(W,H,'Interactive 3D prism: true parallel cross-sectional polygons are highlighted by a movable slicing plane. 2D cross-section and exact volume appear underneath.');sv.classList.add('f13s-svg');sv.setAttribute('role','group');sv.setAttribute('tabindex','0');sv.setAttribute('aria-label','Prism volume slicer. Left and right arrows move the slicing plane.');stage.appendChild(sv);defs(sv);var root=el(sv,'g',{'data-prism-root':'1'});
 function draw(){root.replaceChildren();renderSolid(root,st,W,H);var mobile=W<500,x1=mobile?18:135,y=mobile?391:426,cw=mobile?187:242,ch=mobile?141:142,x2=mobile?215:403;
  var left=card(root,x1,y,cw,ch,PALS.cyan,'cross-section');crossDiagram(left,x1,y,cw,ch,st,mobile);
  var right=card(root,x2,y,cw,ch,PALS.gold,'volume');infoCard(right,x2,y,cw,ch,st,mobile);
  var tiles=stage.querySelectorAll('.f12-strip .nv-ntile .mt');[area(SHAPES[st.shape].p),st.length,area(SHAPES[st.shape].p)*st.length].forEach(function(v,i){if(tiles[i])tiles[i].textContent=String(v);});}
 draw();F.strip(stage,[['base area',area(SHAPES[st.shape].p),'given'],['length',st.length,'focus'],['volume',area(SHAPES[st.shape].p)*st.length,'result']]);NOVA.scene.helperStrip(stage,pose||'explain',message||'A prism has the same cross-section all along its length.');
 var ac=new AbortController(),drag=null,startX=0,startCut=0;stage._f13Cleanup=function(){ac.abort();drag=null;};
 function refresh(){draw();if(st.onChange)st.onChange();NOVA.events.emit('value',{engine:EN,control:'slicer',value:{shape:st.shape,length:st.length,cut:st.cut,area:area(SHAPES[st.shape].p),volume:area(SHAPES[st.shape].p)*st.length}});}
 st.refresh=refresh;st.sv=sv;
 sv.addEventListener('keydown',function(e){if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();st.cut=Math.min(1,Math.max(0,st.cut+(e.key==='ArrowRight'?.05:-.05)));refresh();}
  if(e.key==='Home'||e.key==='End'){e.preventDefault();st.cut=e.key==='Home'?0:1;refresh();}},{signal:ac.signal});
 // Pointer capture on the persistent SVG (never reconstructed). Active pointer affects the slice position only.
 sv.addEventListener('pointerdown',function(e){if(e.pointerType==='mouse'&&e.button!==0)return;drag=e.pointerId;startX=e.clientX;startCut=st.cut;try{sv.setPointerCapture(drag);}catch(x){}sv.classList.add('f13s-grabbing');e.preventDefault();},{signal:ac.signal});
 sv.addEventListener('pointermove',function(e){if(drag!==e.pointerId)return;var b=sv.getBoundingClientRect(),delta=(e.clientX-startX)/(b.width||1);st.cut=Math.max(0,Math.min(1,startCut+delta*1.75));refresh();e.preventDefault();},{signal:ac.signal});
 function end(e){if(drag!==e.pointerId)return;drag=null;sv.classList.remove('f13s-grabbing');try{if(sv.hasPointerCapture(e.pointerId))sv.releasePointerCapture(e.pointerId);}catch(x){}}
 ['pointerup','pointercancel'].forEach(function(q){sv.addEventListener(q,end,{signal:ac.signal});});sv.addEventListener('lostpointercapture',function(e){if(drag===e.pointerId){drag=null;sv.classList.remove('f13s-grabbing');}},{signal:ac.signal});window.addEventListener('blur',function(){drag=null;sv.classList.remove('f13s-grabbing');},{signal:ac.signal});
 st.stage=stage;return sv;}
var STEPS=[
 {name:'Meet a prism',shape:'rectangle',length:5,cut:.05,pose:'explain',msg:'This 3D solid is a prism: the same cross-section runs from one end to the other.',prompt:'Which face keeps the same shape along the entire prism?'},
 {name:'Spot the repeated cross-section',shape:'rectangle',length:5,cut:.3,pose:'point-right',msg:'Move the golden slicing plane. Every slice through the prism is the same rectangle.',prompt:'Does the shape or size of the cross-section change?'},
 {name:'Find the base area',shape:'rectangle',length:5,cut:.65,pose:'think',msg:'The rectangular cross-section measures three by two. Its area is six square units.',prompt:'Why are square units used for a cross-section?'},
 {name:'Stretch along the length',shape:'rectangle',length:3,cut:.46,pose:'point-right',msg:'The rectangular area stays six square units. Making the prism longer adds more identical layers.',prompt:'Which measurement changed: area or length?'},
 {name:'Multiply area by length',shape:'rectangle',length:5,cut:.8,pose:'celebrate',msg:'There are five unit lengths, each with an area of six. Six times five equals thirty cubic units.',prompt:'Explain why the final unit must be cubed.'},
 {name:'Meet a triangular prism',shape:'triangle',length:4,cut:.14,pose:'explain',msg:'This time the constant cross-section is a right triangle with base four and perpendicular height three.',prompt:'What is the area formula for a triangle?'},
 {name:'Calculate its triangular area',shape:'triangle',length:4,cut:.5,pose:'think',msg:'Half times four times three is six square units. That is the cross-sectional area.',prompt:'Why is there a one-half in the triangle area formula?'},
 {name:'Find triangular-prism volume',shape:'triangle',length:4,cut:.77,pose:'celebrate',msg:'Six square units repeated for four units of length gives twenty-four cubic units.',prompt:'What is six multiplied by four?'},
 {name:'A trapezium cross-section',shape:'trapezium',length:3,cut:.5,pose:'explain',msg:'The parallel sides are four and two. Half their sum, multiplied by the perpendicular height three, is nine square units.',prompt:'Which two sides of this trapezium are parallel?'},
 {name:'Composite L-shaped cross-section',shape:'lshape',length:4,cut:.4,pose:'point-right',msg:'A four by three rectangle has area twelve. Remove a two by two corner of area four: eight square units remain.',prompt:'How does removing a corner affect the total volume?'},
 {name:'The universal rule',shape:'pentagon',length:4,cut:.65,pose:'celebrate',msg:'Every prism follows the same rule: volume equals cross-sectional area multiplied by perpendicular length.',prompt:'Which measurement must you calculate first?'},
];
function stepState(i){var p=STEPS[i],st=state(p.shape);st.length=p.length;st.cut=p.cut;return st;}
function pRow(panel,nodes){panel.appendChild(h('div',{class:'pr-row'},nodes));}
function btn(t,fn,extra){return h('button',{class:'nova-btn'+(extra?' '+extra:''),text:t,onclick:fn});}
function setShape(st,k){st.shape=k;st.length=SHAPES[k].defaultLength;st.cut=.45;}
function slider(label,min,max,step,value,fn){var out=h('span',{class:'f13s-output',text:String(value)}),ip=h('input',{type:'range',min:String(min),max:String(max),step:String(step),value:String(value),'aria-label':label}),l=h('label',{class:'f13s-sliderlabel'},[label+' ',ip,out]);ip.oninput=function(){out.textContent=ip.value;fn(+ip.value);};return {node:l,slider:ip,out:out};}
var def={id:EN,title:'Prism volume slicer',config:CFG,steps:STEPS.map(function(t){return {name:t.name,narration:t.msg,prompt:t.prompt,dur:1800};}),
 alt:'Three-dimensional neon-glass prism with a gold movable cross-section perpendicular to its length, repeated parallel slices, precise 2D cross-section and volume calculation.',
 staticAlt:'Volume of any prism equals the area of its constant cross-section multiplied by its perpendicular length. Example: triangular area one half times four times three equals six square units; prism length four gives twenty-four cubic units.',
 render:function(i,stage){var st=stepState(i),t=STEPS[i];renderStage(stage,st,t.msg,t.pose);},
 exploreIntro:'Select a cross-section, drag the golden slice through the prism, and vary the perpendicular length. Watch the area stay fixed while the volume changes.',
 explore:function(panel,stage,api){var st=state('triangle');if(api.onCleanup)api.onCleanup(function(){if(stage._f13Cleanup)stage._f13Cleanup();});
  var select=h('select',{class:'nova-input','aria-label':'Choose prism cross-section'});Object.keys(CFG.presets).forEach(function(k){select.appendChild(h('option',{value:k,text:CFG.presets[k]}));});select.value=st.shape;
  select.onchange=function(){setShape(st,select.value);len.slider.value=st.length;len.out.textContent=st.length;cut.slider.value=Math.round(st.cut*100);cut.out.textContent=Math.round(st.cut*100)+'%';renderStage(stage,st,'The cross-section changes; area must be recalculated before finding the volume.','explain');};
  pRow(panel,[h('label',{},['CROSS-SECTION ',select])]);
  var len=slider('PERPENDICULAR LENGTH',1,8,1,st.length,function(v){st.length=v;if(st.refresh)st.refresh();}),cut=slider('SLICE POSITION',0,100,1,Math.round(st.cut*100),function(v){st.cut=v/100;if(st.refresh)st.refresh();});cut.out.textContent='44%';
  st.onChange=function(){cut.slider.value=Math.round(st.cut*100);cut.out.textContent=Math.round(st.cut*100)+'%';};
  panel.appendChild(h('div',{class:'pr-row'},[len.node]));panel.appendChild(h('div',{class:'pr-row'},[cut.node]));
  var toggles=h('div',{class:'pr-row'});[['showSlabs','Show repeated slices'],['showFace','Highlight front face'],['showLabels','Show length label']].forEach(function(a){var input=h('input',{type:'checkbox','aria-label':a[1]});input.checked=st[a[0]];input.onchange=function(){st[a[0]]=input.checked;if(st.refresh)st.refresh();};toggles.appendChild(h('label',{class:'f13s-check'},[input,' '+a[1]]));});panel.appendChild(toggles);
  pRow(panel,[btn('Reset prism',function(){setShape(st,select.value);len.slider.value=st.length;len.out.textContent=st.length;cut.slider.value=45;cut.out.textContent='45%';renderStage(stage,st,'Now move the cut and notice the cross-sectional area stays constant.','explain');},'ghost'),btn('Centre slice',function(){st.cut=.5;if(st.refresh)st.refresh();},'ghost')]);
  panel.appendChild(h('p',{class:'f13s-help',text:'Drag left or right on the 3D drawing to move the gold slice. You can also focus the drawing and press ← / →; Home and End move to the ends. The number of square units in the cross-section stays the same for a prism.'}));
  renderStage(stage,st,'A prism is made by extending one cross-section through a perpendicular length.','explain');CFG._explore={state:st,preset:function(k){select.value=k;select.onchange();},length:function(n){len.slider.value=n;len.slider.oninput();},slice:function(n){cut.slider.value=n;cut.slider.oninput();}};
 },
 challenge:function(panel,api,stage){var tasks=[
  {shape:'rectangle',length:5,A:6,V:30,q:'A rectangular prism has a cross-section 3 units by 2 units. Its perpendicular length is 5 units. Find its cross-sectional area and volume.',hint:'The area is 3 × 2. Multiply that area by the length 5.'},
  {shape:'triangle',length:4,A:6,V:24,q:'The triangular cross-section has base 4 units and perpendicular height 3 units. The prism is 4 units long. Find its area and volume.',hint:'Triangle area is ½ × base × perpendicular height. Then multiply the area by 4.'},
  {shape:'lshape',length:4,A:8,V:32,q:'A prism has an L-shaped cross-section: 4 × 3 rectangle minus a 2 × 2 square. The prism is 4 units long. Find the area and volume.',hint:'The cross-section area is 12 − 4. Multiply that by 4 to get cubic units.'}
 ];var k=0,st=state('rectangle'),q=h('p',{class:'pr-task'}),progress=h('span',{class:'f13s-progress'}),a=h('input',{type:'number',min:'0',step:'any',class:'nova-input',placeholder:'Area (units²)','aria-label':'Cross-sectional area in square units'}),v=h('input',{type:'number',min:'0',step:'any',class:'nova-input',placeholder:'Volume (units³)','aria-label':'Prism volume in cubic units'}),feedback=h('p',{class:'f13s-feedback','aria-live':'polite'}),timer=null;
  function load(n){k=n;var t=tasks[k];st.shape=t.shape;st.length=t.length;st.cut=.55;progress.textContent=(k+1)+' / '+tasks.length;q.textContent=progress.textContent+' · '+t.q;a.value='';v.value='';feedback.textContent='';renderStage(stage,st,'First find the cross-sectional area. Then multiply by the prism length.','think');}
  function check(){var t=tasks[k],AA=Number(a.value),VV=Number(v.value),ok=a.value.trim()!==''&&v.value.trim()!==''&&AA===t.A&&VV===t.V;var msg=ok?'Correct. Area '+t.A+' square units multiplied by length '+t.length+' gives '+t.V+' cubic units.':a.value.trim()===''||v.value.trim()===''?'Enter both an area and a volume.':AA!==t.A?'Check the AREA first: use the correct two-dimensional shape formula.':'Your area is correct. Multiply it by the perpendicular LENGTH; use cubic units for volume.';
   feedback.textContent=msg;api.check(ok,msg,{task:k,area:AA,volume:VV,expectedArea:t.A,expectedVolume:t.V});if(ok&&k<tasks.length-1){if(timer)clearTimeout(timer);timer=setTimeout(function(){load(k+1);},1300);}return ok;}
  if(api.onCleanup)api.onCleanup(function(){if(timer)clearTimeout(timer);if(stage._f13Cleanup)stage._f13Cleanup();});
  panel.appendChild(q);pRow(panel,[h('label',{class:'f13s-input-label'},['AREA (units²) ',a]),h('label',{class:'f13s-input-label'},['VOLUME (units³) ',v])]);
  pRow(panel,[btn('Check both answers',check,'primary'),btn('Hint',function(){api.hint(tasks[k].hint);},'ghost'),btn('Reset answers',function(){a.value='';v.value='';feedback.textContent='Try the question again.';},'ghost')]);panel.appendChild(feedback);
  panel.appendChild(h('p',{class:'f13s-help',text:'Remember: the cross-section is measured in square units, while the whole 3D prism is measured in cubic units. Do not use the sloping edge as the perpendicular length.'}));
  load(0);CFG._challenge={load:load,task:function(){return k;},inputs:[a,v],check:check,tasks:tasks,state:st};
 }
};
NOVA.bankMount({id:EN,num:'F13·06',title:'Prism volume slicer',def:def,linked:['F0-01','F0-02','F0-03','F0-04','F0-05','F12-03','F13-01','F13-02','F13-03','F13-04','F13-05'],spec:{
 purpose:'Connect constant cross-sectional area and perpendicular prism length to volume (KS3 Y8-060, Y8-062 and GCSE extension).',
 params:'True polygonal cross-sections (rectangle, right triangle, trapezium, L-shape, house shape) · plane position 0–100% · prism length 1–8 · exact area and volume.',
 presets:'Five mathematically validated cross-sections; each with a default length and exact area formula.',
 steps:STEPS.map(function(z){return z.name;}).join(' → '),
 interactions:'Eleven narrated Watch/Guided steps; Explore moving perpendicular slice with pointer capture and keyboard, length slider, cross-section selector; Challenge three area-and-volume calculations.',
 traps:'Cross-section AREA uses square units; prism VOLUME uses cubic units. Length must be perpendicular to the constant cross-section, not a slanted edge.',
 gcse:'Volume of prisms with triangular, trapezoidal and compound cross-sections.'}});
var log=document.getElementById('log'),logEvent=function(e){log.textContent=new Date(e.time).toLocaleTimeString()+' '+e.type+' '+JSON.stringify(e.detail)+'\n'+log.textContent.slice(0,5000);};NOVA.events.history().forEach(logEvent);NOVA.events.on('*',logEvent);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
