from pathlib import Path
p=Path(__file__).resolve().parent
base=(p/'approved-F13-06-base.html').read_text('utf-8')
css=(p/'F13-07.component.css').read_text('utf-8')
js=(p/'F13-07.engine.js').read_text('utf-8')
css_start=base.index('/* F13-06 component-only styles;')
css_end=base.index('</style>',css_start)
pre=base[:css_start]+css+base[css_end:]
engine_start=pre.index('/* F13-06 PRISM VOLUME SLICER')
engine_tag=pre.rfind('<script>',0,engine_start)
result=pre[:engine_tag]+'<script>\n'+js+'\n</script>\n</body>\n</html>'
# Only modify F13-specific visible headings, not frozen core content.
head_end=result.find('</head>'); head=result[:head_end].replace('F13-06','F13-07').replace('Prism volume slicer','Cuboid volume and surface area')
result=head+result[head_end:]
begin=result.find('</head>'); ending=result.rfind('<script>'); piece=result[begin:ending]
piece=piece.replace('F13-06','F13-07').replace('Prism volume slicer','Cuboid volume and surface area')
result=head+piece+result[ending:]
output=p.parent/'F13-07-Cuboid-Volume-and-Surface-Area-PREMIUM-CORE.html'
output.write_text(result,'utf-8')
print('Built',output,len(result),'bytes')
