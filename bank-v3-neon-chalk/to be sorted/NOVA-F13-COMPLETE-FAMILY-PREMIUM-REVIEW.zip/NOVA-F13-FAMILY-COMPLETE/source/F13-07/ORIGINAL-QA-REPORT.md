# F13-07 Browser + Geometry QA Report

- **239/239 checks passed**; 0 failures.
- Chromium, viewport widths 1280px and 380px.
- Original NOVA core JS preserved exactly; official core CSS preserved exactly.
- Embedded official WebP mascot pose artwork and NOVA Chalk fonts confirmed.
- Exactly one mascot dock inside the stage, no page-level horizontal overflow.
- Twelve steps in Watch and all other engine modes exercised on both widths.
- Five dimension presets, arithmetic cross-checks for each face pair, volume and total surface area.
- Six independently dimensioned faces verified when the net opens.
- **Physical hinge tests** at 25%, 55% and 75% (front/top, front/bottom, front/left, front/right, top/back); every shared endpoint coincides.
- Length, width and height control values update all calculations.
- Focus + arrow-key rotation, Home reset, 25-event fast pointer drag, capture cleanup, no stale mode shell.
- Challenge mode checked missing entry, incorrect volume, omitted opposite faces and all three correct answers.
- Source-to-standalone reproducibility SHA256 `45c3105e3bbd8fc11e6ea148ac47c8de77ebaa42622412ea311dad85b487a3f7`.
- Screenshots retained in review ZIP for desktop and 380px mobile visual comparison.
- GitHub not modified; this is a review build.

**Visual QA notes:** The revised visible faces avoid drawing the wrong hidden right face; the net is larger on mobile; numeric chips stay on one row; the official mascot remains docked within the approved NOVA stage.
