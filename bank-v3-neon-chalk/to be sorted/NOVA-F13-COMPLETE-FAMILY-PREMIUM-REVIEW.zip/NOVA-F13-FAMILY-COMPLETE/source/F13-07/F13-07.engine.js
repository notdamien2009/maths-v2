/* F13-07 CUBOID VOLUME AND SURFACE AREA — additive component on official NOVA F0/F1/F12 core. */
var NOVA_F13_07_CONFIG={startMode:'watch',preset:'classic',presets:{
 classic:'Classic cuboid · 4 × 3 × 2',cube:'Cube · 3 × 3 × 3',parcel:'Parcel · 5 × 3 × 2',tower:'Tall column · 2 × 2 × 5',shallow:'Shallow tray · 5 × 2 × 1'}};
(function(){'use strict';
var h=NOVA.h,S=NOVA.svg,F=NOVA.f12,CFG=NOVA_F13_07_CONFIG,EN='F13-07';
var PAL={cyan:'#43ebff',gold:'#ffdf78',orange:'#ffaf72',purple:'#b9a0ff',green:'#7af1bb',ink:'#091428'};
var PRESETS={classic:[4,3,2],cube:[3,3,3],parcel:[5,3,2],tower:[2,2,5],shallow:[5,2,1]};
var FACES=[
 {id:'back',name:'BACK',group:'front',dims:'l × h',color:PAL.cyan,role:'op',hidden:true},
 {id:'bottom',name:'BOTTOM',group:'top',dims:'l × w',color:PAL.purple,role:'given',hidden:true},
 {id:'right',name:'RIGHT',group:'side',dims:'w × h',color:PAL.orange,role:'focus',hidden:true},
 {id:'left',name:'LEFT',group:'side',dims:'w × h',color:PAL.orange,role:'focus',hidden:false},
 {id:'front',name:'FRONT',group:'front',dims:'l × h',color:PAL.cyan,role:'op',hidden:false},
 {id:'top',name:'TOP',group:'top',dims:'l × w',color:PAL.purple,role:'given',hidden:false}];
function stNew(which){var v=PRESETS[which]||PRESETS.classic;return {preset:which||'classic',l:v[0],w:v[1],ht:v[2],unfold:0,group:'all',grid:true,labels:true,angle:0,stage:null,sv:null,refresh:null};}
function V(st){return st.l*st.w*st.ht;}
function SA(st){return 2*(st.l*st.w+st.l*st.ht+st.w*st.ht);}
function A(st,g){return g==='top'?st.l*st.w:g==='front'?st.l*st.ht:st.w*st.ht;}
function el(p,t,a){return S.el(t,a||{},p);}
function path(p){return 'M'+p.map(function(q){return q[0].toFixed(2)+','+q[1].toFixed(2);}).join('L')+'Z';}
function seg(p,q,stroke,w,dash){var e=el(p,'path',{d:'M'+q.map(function(v){return v[0].toFixed(1)+','+v[1].toFixed(1);}).join('L'),fill:'none',stroke:stroke||PAL.cyan,'stroke-width':w||1.1,'stroke-linecap':'round',opacity:.9});if(dash)e.setAttribute('stroke-dasharray',dash);return e;}
function writing(p,x,y,t,role,size,anchor){return NOVA.chalkText(p,x,y,String(t),{role:role||'given',size:size||16,anchor:anchor||'middle'});}
function interpolation(a,b,t){return a.map(function(q,i){return [q[0]*(1-t)+b[i][0]*t,q[1]*(1-t)+b[i][1]*t];});}
function defs(sv){var d=sv.querySelector('defs')||el(sv,'defs',{});
 [['front','#d2fdff','#2793bc','#102d60'],['top','#e8e2ff','#786db7','#29235c'],['side','#ffe5c7','#b56869','#382043']].forEach(function(z){var gg=el(d,'linearGradient',{id:'f13v-'+z[0],x1:'0%',y1:'0%',x2:'100%',y2:'100%'});[[0,z[1],.83],[.5,z[2],.75],[1,z[3],.91]].forEach(function(s){el(gg,'stop',{offset:s[0],'stop-color':s[1],'stop-opacity':s[2]});});});
 var ar=el(d,'radialGradient',{id:'f13v-aura'});el(ar,'stop',{offset:'0%','stop-color':'#2dbffd','stop-opacity':.26});el(ar,'stop',{offset:'100%','stop-color':'#0d1745','stop-opacity':0});
 var glow=el(d,'filter',{id:'f13v-soft',x:'-100%',y:'-100%',width:'300%',height:'300%'});el(glow,'feGaussianBlur',{stdDeviation:4});}
function three(st,W,mobile){var ang=Math.PI/4+st.angle,cs=Math.cos(ang),sn=Math.sin(ang);var all=[];[0,st.l].forEach(function(x){[0,st.w].forEach(function(y){[0,st.ht].forEach(function(z){all.push([x*cs-y*sn,(x*sn+y*cs)*.48-z*1.12]);});});});
 var minx=Math.min.apply(null,all.map(function(p){return p[0];})),maxx=Math.max.apply(null,all.map(function(p){return p[0];})),miny=Math.min.apply(null,all.map(function(p){return p[1];})),maxy=Math.max.apply(null,all.map(function(p){return p[1];}));
 var sc=Math.min((W-(mobile?54:180))/(maxx-minx+.8),(mobile?288:294)/(maxy-miny+.8),mobile?66:72);
 var cx=W/2-(minx+maxx)*sc/2,cy=(mobile?226:227)-(miny+maxy)*sc/2;
 return function(x,y,z){return [cx+(x*cs-y*sn)*sc,cy+((x*sn+y*cs)*.48-z*1.12)*sc];};}
function faces3(st,P){var l=st.l,w=st.w,z=st.ht;return {
 back:[[0,w,z],[l,w,z],[l,w,0],[0,w,0]],
 bottom:[[0,0,0],[l,0,0],[l,w,0],[0,w,0]],
 left:[[0,w,z],[0,0,z],[0,0,0],[0,w,0]],
 right:[[l,0,z],[l,w,z],[l,w,0],[l,0,0]],
 front:[[0,0,z],[l,0,z],[l,0,0],[0,0,0]],
 top:[[0,w,z],[l,w,z],[l,0,z],[0,0,z]]};}
function net2(st,W,mobile){var l=st.l,w=st.w,z=st.ht,sc=Math.min((W-(mobile?54:170))/(l+2*w),(mobile?316:268)/(2*z+2*w),mobile?39:42),x0=W/2-l*sc/2,y0=(mobile?80:82)+(mobile?316:268)/2+(w+z)*sc-(2*w+2*z)*sc/2;
 function box(x,y,ww,hh){return [[x,y],[x+ww,y],[x+ww,y+hh],[x,y+hh]];}
 return {sc:sc,polys:{front:box(x0,y0,l*sc,z*sc),back:box(x0,y0-(w+z)*sc,l*sc,z*sc),top:box(x0,y0-w*sc,l*sc,w*sc),bottom:box(x0,y0+z*sc,l*sc,w*sc),right:box(x0+l*sc,y0,w*sc,z*sc),left:box(x0-w*sc,y0,w*sc,z*sc)}};}
function lineGrid(g,poly,u,v,nx,ny,color,a){var top=poly[0],tx=poly[1],bl=poly[3];for(var i=1;i<nx;i++){var t=i/nx;var p=[top[0]+(tx[0]-top[0])*t,top[1]+(tx[1]-top[1])*t],q=[bl[0]+(poly[2][0]-bl[0])*t,bl[1]+(poly[2][1]-bl[1])*t];var e=seg(g,[p,q],color,.7);e.setAttribute('opacity',a||.48);}for(var j=1;j<ny;j++){var z=j/ny,p2=[top[0]+(bl[0]-top[0])*z,top[1]+(bl[1]-top[1])*z],q2=[tx[0]+(poly[2][0]-tx[0])*z,tx[1]+(poly[2][1]-tx[1])*z];var e2=seg(g,[p2,q2],color,.7);e2.setAttribute('opacity',a||.48);}}
function faceNums(st,id){return id==='top'||id==='bottom'?[st.l,st.w]:id==='front'||id==='back'?[st.l,st.ht]:[st.w,st.ht];}
function card(g,x,y,w,h,color){el(g,'rect',{x:x,y:y,width:w,height:h,rx:13,fill:'#06172b',stroke:color,'stroke-width':1.7});el(g,'path',{d:'M'+(x+12)+' '+(y+3)+'H'+(x+w-12),stroke:color,'stroke-width':2.4,opacity:.55});}
/* True hinge motion: top/bottom rotate around the front's horizontal edges;
   left/right rotate around its vertical edges; back hinges onto the far edge of top.
   At 100% every face lies in exactly the same plane and forms an exact six-face net. */
function hinged(st,id,v,t){var x=v[0],y=v[1],z=v[2],h=st.ht,l=st.l,w=st.w,theta=Math.PI*t/2,c=Math.cos(theta),s=Math.sin(theta);
 if(id==='front')return [x,y,z];
 if(id==='top')return [x,y*c,h+y*s];
 if(id==='bottom')return [x,y*c,-y*s];
 if(id==='right')return [l+y*s,y*c,z];
 if(id==='left')return [-y*s,y*c,z];
 if(id==='back'){var d=h-z;return [x,w*c+d*Math.sin(theta*2),h+w*s-d*Math.cos(theta*2)];}
 return v;
}
function transitionProject(st,P,net,t,q){var pos=P.apply(null,q),flat=[net.polys.front[0][0]+q[0]*net.sc,net.polys.front[0][1]+(st.ht-q[2])*net.sc];return [pos[0]*(1-t)+flat[0]*t,pos[1]*(1-t)+flat[1]*t];}
function drawScene(root,st,W,H){root.replaceChildren();var mobile=W<500,t=Math.min(1,Math.max(0,st.unfold/100)),P=three(st,W,mobile),closed=faces3(st,P),open=net2(st,W,mobile);
 var aura=el(root,'g',{'aria-hidden':'true'});el(aura,'ellipse',{cx:W/2,cy:222,rx:mobile?175:270,ry:156,fill:'url(#f13v-aura)'});
 var name=st.unfold>=98?'UNFOLDED SURFACE NET':st.unfold<=2?'3D CUBOID · SIX FACES':'OPENING THE SIX FACES';writing(root,W/2,63,name,'given',mobile?15:17);
 var grp=el(root,'g',{'data-maths':'six-exact-cuboid-faces'});FACES.forEach(function(f){var q=closed[f.id].map(function(v){return transitionProject(st,P,open,t,hinged(st,f.id,v,t));}),active=st.group==='all'||st.group===f.group,alpha=(f.hidden?Math.min(1,t*1.7):1)*(active?1:.15),shade=el(grp,'g',{'data-face':f.id,'data-family':f.group,opacity:alpha.toFixed(3)});
  el(shade,'path',{d:path(q),fill:'url(#f13v-'+(f.group==='front'?'front':f.group==='top'?'top':'side')+')',stroke:'none'});
  if(st.grid){var nums=faceNums(st,f.id);lineGrid(shade,q,0,0,nums[0],nums[1],f.color,t>.92?.53:.3);}
  NOVA.neonPath(shade,path(q),{role:f.role,width:active?2.8:1.3});
  if(t>.83){var mid=[(q[0][0]+q[2][0])/2,(q[0][1]+q[2][1])/2];writing(shade,mid[0],mid[1]-3,f.name,f.role,mobile?16:15);writing(shade,mid[0],mid[1]+15,A(st,f.group)+' u²','result',mobile?14.5:14);}
 });
 if(t<.10&&st.labels){var f=closed,pf=function(a){return P.apply(null,a);};var l1=pf([0,0,0]),l2=pf([st.l,0,0]),d2=pf([0,st.w,0]),hi=pf([0,st.w,st.ht]);var dx=(l2[0]-l1[0]),dy=(l2[1]-l1[1]);writing(root,(l1[0]+l2[0])/2+13,(l1[1]+l2[1])/2+25,'length '+st.l,'given',mobile?15:18);
  writing(root,(l1[0]+d2[0])/2-17,(l1[1]+d2[1])/2+30,'width '+st.w,'focus',mobile?15:18);writing(root,d2[0]-27,(d2[1]+hi[1])/2,'height '+st.ht,'op',mobile?15:18);}
 if(t>.89&&!mobile){writing(root,W/2,395,'3 pairs · top/bottom · front/back · left/right','given',mobile?12:17);}
 var y=mobile?420:424,one=mobile?190:248,x1=mobile?12:125,x2=mobile?218:407,ch=mobile?139:140;
 card(root,x1,y,one,ch,PAL.cyan);card(root,x2,y,one,ch,PAL.gold);
 writing(root,x1+one/2,y+25,'VOLUME','op',mobile?17:20);
 writing(root,x1+one/2,y+54,st.l+' × '+st.w+' × '+st.ht,'given',mobile?21:24);
 writing(root,x1+one/2,y+83,V(st)+' units³','result',mobile?22:24);
 writing(root,x1+one/2,y+ch-15,'unit cubes inside','given',mobile?12.5:15);
 writing(root,x2+one/2,y+25,'SURFACE AREA','focus',mobile?17:19);
 writing(root,x2+one/2,y+53,'2('+st.l*st.w+' + '+st.l*st.ht+' + '+st.w*st.ht+')','given',mobile?19:22);
 writing(root,x2+one/2,y+82,SA(st)+' units²','result',mobile?22:24);
 writing(root,x2+one/2,y+ch-15,'all 6 outside faces','given',mobile?12.5:15);
 }
function renderStage(stage,st,message,pose){if(stage._f13Cleanup)stage._f13Cleanup();stage.replaceChildren();var mob=window.innerWidth<=580,W=mob?420:780,H=mob?579:590;
 NOVA.cap(stage,'CUBOID VOLUME + AREA · '+st.l+' × '+st.w+' × '+st.ht,'6 FACES');
 var sv=S.root(W,H,'Three-dimensional cuboid showing unit square grids on each face. Opens to a mathematically accurate flat six-face surface net. Two calculation cards show cubic volume and squared surface area.');sv.classList.add('f13v-svg');sv.setAttribute('tabindex','0');sv.setAttribute('role','group');sv.setAttribute('aria-label','Cuboid viewer. Drag horizontally or use left and right arrow keys to turn it. Open the surface net with the slider below.');stage.appendChild(sv);defs(sv);var root=el(sv,'g',{'data-cuboid-root':'1'});var raf=0;
 function draw(){drawScene(root,st,W,H);var cells=stage.querySelectorAll('.f12-strip .nv-ntile .mt');[st.l*st.w,st.l*st.ht,st.w*st.ht].forEach(function(n,i){if(cells[i])cells[i].textContent=n;});}
 function refresh(){if(raf)cancelAnimationFrame(raf);raf=requestAnimationFrame(function(){raf=0;draw();NOVA.events.emit('value',{engine:EN,control:'cuboid',value:{length:st.l,width:st.w,height:st.ht,volume:V(st),surfaceArea:SA(st),unfold:st.unfold,faceGroup:st.group}});});}
 st.refresh=refresh;st.sv=sv;draw();F.strip(stage,[['top',st.l*st.w,'given'],['front',st.l*st.ht,'op'],['side',st.w*st.ht,'focus']]);NOVA.scene.helperStrip(stage,pose||'explain',message||'The volume fills the inside; surface area covers the six outside faces.');
 var ac=new AbortController(),pid=null,px=0,pa=0;stage._f13Cleanup=function(){ac.abort();if(raf)cancelAnimationFrame(raf);pid=null;sv.classList.remove('f13v-grab');};
 sv.addEventListener('pointerdown',function(e){if(e.pointerType==='mouse'&&e.button!==0)return;pid=e.pointerId;px=e.clientX;pa=st.angle;try{sv.setPointerCapture(pid);}catch(x){}sv.classList.add('f13v-grab');e.preventDefault();},{signal:ac.signal});
 sv.addEventListener('pointermove',function(e){if(pid!==e.pointerId)return;var r=sv.getBoundingClientRect(),v=(e.clientX-px)/(r.width||1);st.angle=Math.min(.20,Math.max(-.20,pa+v*.55));refresh();e.preventDefault();},{signal:ac.signal});
 function stop(e){if(pid!==e.pointerId)return;pid=null;sv.classList.remove('f13v-grab');try{if(sv.hasPointerCapture(e.pointerId))sv.releasePointerCapture(e.pointerId);}catch(x){}}
 ['pointerup','pointercancel'].forEach(function(k){sv.addEventListener(k,stop,{signal:ac.signal});});sv.addEventListener('lostpointercapture',function(e){if(pid===e.pointerId){pid=null;sv.classList.remove('f13v-grab');}},{signal:ac.signal});window.addEventListener('blur',function(){pid=null;sv.classList.remove('f13v-grab');},{signal:ac.signal});
 sv.addEventListener('keydown',function(e){if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();st.angle=Math.min(.2,Math.max(-.2,st.angle+(e.key==='ArrowRight'?.06:-.06)));refresh();}if(e.key==='Home'){e.preventDefault();st.angle=0;refresh();}},{signal:ac.signal});return sv;
}
function pRow(panel,a){panel.appendChild(h('div',{class:'pr-row'},a));}
function btn(t,fn,klass){return h('button',{class:'nova-btn'+(klass?' '+klass:''),text:t,onclick:fn});}
function range(label,min,max,value,change){var p=h('input',{type:'range',min:String(min),max:String(max),step:'1',value:String(value),'aria-label':label}),o=h('span',{class:'f13v-value',text:String(value)}),w=h('label',{class:'f13v-lab'},[label+' ',p,o]);p.oninput=function(){o.textContent=p.value;change(+p.value);};return {node:w,inp:p,out:o,set:function(v){p.value=v;o.textContent=v;}};}
var STEPS=[
 {name:'Meet a cuboid',dims:[4,3,2],u:0,group:'all',pose:'explain',msg:'A cuboid has six rectangular faces. The coloured drawing shows three we can see.',prompt:'How many faces are hidden behind the solid?'},
 {name:'Count unit cubes',dims:[4,3,2],u:0,group:'all',pose:'point-right',msg:'Unit cube edges divide the visible faces into squares. Cubic units describe how much space the solid fills.',prompt:'Why are cubic units used for volume?'},
 {name:'Count one horizontal layer',dims:[4,3,1],u:0,group:'top',pose:'think',msg:'This layer has four rows along the length and three along the width. Four times three gives twelve cubes.',prompt:'How many cubes are in one layer?'},
 {name:'Stack the second layer',dims:[4,3,2],u:0,group:'top',pose:'explain',msg:'Two identical layers of twelve cubes give a volume of twenty-four cubic units.',prompt:'What is twelve multiplied by two?'},
 {name:'Calculate the volume',dims:[4,3,2],u:0,group:'all',pose:'celebrate',msg:'Multiply length by width by height. Four times three times two equals twenty-four cubic units.',prompt:'Why do we multiply three measurements?'},
 {name:'Discover surface area',dims:[4,3,2],u:0,group:'all',pose:'explain',msg:'Surface area counts the square units covering the outside of the solid, not its inside space.',prompt:'Are surface area units squared or cubed?'},
 {name:'Top and bottom pair',dims:[4,3,2],u:0,group:'top',pose:'point-right',msg:'The top face measures four by three, so its area is twelve. The bottom face is identical: two times twelve.',prompt:'What is the combined area of top and bottom?'},
 {name:'Front and back pair',dims:[4,3,2],u:0,group:'front',pose:'point-right',msg:'The front face measures four by two, so its area is eight. The hidden back has the same area.',prompt:'What is two times eight?'},
 {name:'Left and right pair',dims:[4,3,2],u:0,group:'side',pose:'point-right',msg:'Each end face measures three by two, giving six square units. Both ends together give twelve.',prompt:'What is the area of the pair?'},
 {name:'Unfold the six faces',dims:[4,3,2],u:100,group:'all',pose:'explain',msg:'Here is a net showing all six connected rectangles. Each has the correct dimensions; none may be omitted.',prompt:'Which rectangular faces appear twice?'},
 {name:'Find total surface area',dims:[4,3,2],u:100,group:'all',pose:'celebrate',msg:'Add all three pairs: twenty-four plus sixteen plus twelve gives fifty-two square units.',prompt:'Why is fifty-two in square units, not cubic units?'},
 {name:'Transfer to another cuboid',dims:[5,2,3],u:100,group:'all',pose:'think',msg:'The same formulas work when the dimensions change. Here the volume is thirty cubic units and the surface area is sixty-two square units.',prompt:'Which calculation gives the surface area of this new cuboid?'}];
function stepState(i){var p=STEPS[i],st=stNew('classic');st.l=p.dims[0];st.w=p.dims[1];st.ht=p.dims[2];st.unfold=p.u;st.group=p.group;return st;}
var def={id:EN,title:'Cuboid volume and surface area',config:CFG,steps:STEPS.map(function(p){return {name:p.name,narration:p.msg,prompt:p.prompt,dur:1800};}),
 alt:'Interactive neon-glass cuboid with fine unit-square face grids, live volume and surface area calculations and an unfolded, correctly dimensioned six-rectangle net.',
 staticAlt:'Cuboid volume is length × width × height in cubic units. Cuboid surface area is 2 × (length × width + length × height + width × height) in square units. A 4 by 3 by 2 cuboid has volume 24 cubic units and surface area 52 square units.',
 render:function(i,stage){var t=STEPS[i];renderStage(stage,stepState(i),t.msg,t.pose);},
 exploreIntro:'Change length, width and height; open the six-face net; highlight equal face pairs. Use drag or arrow keys to rotate the 3D model.',
 explore:function(panel,stage,api){var st=stNew('classic');if(api.onCleanup)api.onCleanup(function(){if(stage._f13Cleanup)stage._f13Cleanup();});
  var sel=h('select',{class:'nova-input','aria-label':'Cuboid preset'});Object.keys(CFG.presets).forEach(function(k){sel.appendChild(h('option',{value:k,text:CFG.presets[k]}));});sel.value='classic';
  pRow(panel,[h('label',{class:'f13v-lab'},['PRESET ',sel])]);
  var sliders={};[['l','LENGTH'],['w','WIDTH'],['ht','HEIGHT']].forEach(function(z){sliders[z[0]]=range(z[1],1,6,st[z[0]],function(n){st[z[0]]=n;st.preset='custom';if(st.refresh)st.refresh();});});
  function usePreset(key){var v=PRESETS[key];st.preset=key;st.l=v[0];st.w=v[1];st.ht=v[2];['l','w','ht'].forEach(function(k){sliders[k].set(st[k]);});st.angle=0;st.refresh();}
  sel.onchange=function(){usePreset(sel.value);};pRow(panel,[sliders.l.node,sliders.w.node,sliders.ht.node]);
  var fold=range('UNFOLD SIX FACES (%)',0,100,0,function(n){st.unfold=n;if(st.refresh)st.refresh();});pRow(panel,[fold.node]);
  var group=h('select',{class:'nova-input','aria-label':'Highlight face pair'});[['all','All six faces'],['top','Top and bottom'],['front','Front and back'],['side','Left and right']].forEach(function(z){group.appendChild(h('option',{value:z[0],text:z[1]}));});group.onchange=function(){st.group=group.value;st.refresh();};pRow(panel,[h('label',{class:'f13v-lab'},['FACE PAIR ',group])]);
  var ck=h('input',{type:'checkbox','aria-label':'Show unit-square grid'});ck.checked=true;ck.onchange=function(){st.grid=ck.checked;st.refresh();};pRow(panel,[h('label',{class:'f13v-lab'},[ck,' Show unit-square grid']),btn('3D Solid',function(){st.unfold=0;fold.set(0);st.refresh();},'ghost'),btn('Unfold net',function(){st.unfold=100;fold.set(100);st.refresh();},'ghost'),btn('Reset',function(){sel.value='classic';usePreset('classic');st.unfold=0;st.group='all';fold.set(0);group.value='all';st.grid=true;ck.checked=true;st.refresh();},'ghost')]);
  panel.appendChild(h('p',{class:'f13v-hint',text:'Look at the six rectangles in the net. Matching colours make three equal pairs: top/bottom, front/back and left/right. A volume measures cubic units; surface area measures square units.'}));
  renderStage(stage,st,'Inside space is volume; the six outside faces make surface area.','explain');CFG._explore={state:st,preset:function(k){sel.value=k;sel.onchange();},fold:function(n){fold.inp.value=n;fold.inp.oninput();},select:function(g){group.value=g;group.onchange();},set:function(l,w,z){sliders.l.inp.value=l;sliders.l.inp.oninput();sliders.w.inp.value=w;sliders.w.inp.oninput();sliders.ht.inp.value=z;sliders.ht.inp.oninput();}};
 },
 challenge:function(panel,api,stage){var tasks=[
  {d:[3,2,2],v:12,a:32,q:'A cuboid is 3 units long, 2 units wide and 2 units high. Find its volume and TOTAL surface area.',hint:'Volume: 3 × 2 × 2. Surface area: double (6 + 6 + 4).'},
  {d:[4,3,2],v:24,a:52,q:'A cuboid measures 4 by 3 by 2 units. Find its volume and the area of all SIX outside faces.',hint:'Three face areas are 12, 8 and 6. Each has an opposite twin.'},
  {d:[5,2,3],v:30,a:62,q:'A parcel is 5 units long, 2 wide and 3 high. Calculate its volume and its total surface area.',hint:'Volume = 5 × 2 × 3. Surface area = 2 × (10 + 15 + 6).'}
 ];var st=stNew('classic'),k=0,timer=null,q=h('p',{class:'pr-task'}),a=h('input',{type:'number',min:0,step:1,class:'nova-input',placeholder:'cubic units','aria-label':'Volume in cubic units'}),b=h('input',{type:'number',min:0,step:1,class:'nova-input',placeholder:'square units','aria-label':'Total surface area in square units'}),out=h('p',{class:'f13v-feedback','aria-live':'polite'});
  function load(i){k=i;var t=tasks[k];st.l=t.d[0];st.w=t.d[1];st.ht=t.d[2];st.unfold=0;st.group='all';a.value='';b.value='';q.textContent=(i+1)+' / '+tasks.length+' · '+t.q;out.textContent='';renderStage(stage,st,'Work out the number of unit cubes AND the area of all six faces.','think');}
  function check(){var t=tasks[k],av=Number(a.value),bv=Number(b.value),ok=a.value.trim()!==''&&b.value.trim()!==''&&av===t.v&&bv===t.a;
   var msg=ok?'Correct: '+t.v+' cubic units of volume, and '+t.a+' square units of total surface.':a.value.trim()===''||b.value.trim()===''?'Enter both measurements before checking.':av!==t.v?'The volume is the product length × width × height. Use cubic units.':bv===t.a/2?'Your surface area is HALF the correct value: remember the three OPPOSITE faces.':'Your volume is right. Surface area means ALL SIX faces; calculate each opposite pair in square units.';
   out.textContent=msg;api.check(ok,msg,{task:k,volume:av,surfaceArea:bv,expectedVolume:t.v,expectedSurfaceArea:t.a});if(ok&&k<tasks.length-1){if(timer)clearTimeout(timer);timer=setTimeout(function(){load(k+1);},1250);}return ok;}
  if(api.onCleanup)api.onCleanup(function(){if(timer)clearTimeout(timer);if(stage._f13Cleanup)stage._f13Cleanup();});
  panel.appendChild(q);pRow(panel,[h('label',{class:'f13v-answer'},['VOLUME (units³) ',a]),h('label',{class:'f13v-answer'},['SURFACE AREA (units²) ',b])]);
  pRow(panel,[btn('Check answers',check,'primary'),btn('Hint',function(){api.hint(tasks[k].hint);},'ghost'),btn('See unfolded net',function(){st.unfold=st.unfold>50?0:100;st.refresh();},'ghost')]);panel.appendChild(out);panel.appendChild(h('p',{class:'f13v-hint',text:'Two DIFFERENT quantities: volume measures inside space; surface area measures the entire outside. The opposite faces are the same size.'}));
  load(0);CFG._challenge={load:load,task:function(){return k;},inputs:[a,b],check:check,tasks:tasks,state:st};
 }
};
NOVA.bankMount({id:EN,num:'F13·07',title:'Cuboid volume and surface area',def:def,linked:['F0-01','F0-02','F0-03','F0-04','F0-05','F12-03','F13-01','F13-02','F13-03','F13-04','F13-05','F13-06'],spec:{
 purpose:'Teach cuboid volume and total external surface area using unit cubes, paired faces and an accurate surface net (Y7-049, Y8-042, Y8-060/061, Y9-036/037).',
 params:'Length, width, height 1–6 units; cubic volume V = l × w × h; surface area SA = 2(lw + lh + wh); six faces in three pairs.',
 presets:'Five dimensions including cube, shallow cuboid, rectangular parcel and tall column.',
 steps:STEPS.map(function(z){return z.name;}).join(' → '),
 interactions:'Twelve Watch/Guided teaching steps; Explore drag-to-rotate, dimensions and fold controls; selectable face pairs and visible square-unit grids; Challenge three volume-and-area assessments.',
 traps:'Volume uses cubic units; surface area uses square units. Surface area includes hidden opposite faces, not just the visible three.',
 gcse:'Cuboid surface-area nets, factor changes, compound surface area foundations.'}});
var log=document.getElementById('log'),ev=function(e){log.textContent=new Date(e.time).toLocaleTimeString()+' '+e.type+' '+JSON.stringify(e.detail)+'\n'+log.textContent.slice(0,5000);};NOVA.events.history().forEach(ev);NOVA.events.on('*',ev);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
