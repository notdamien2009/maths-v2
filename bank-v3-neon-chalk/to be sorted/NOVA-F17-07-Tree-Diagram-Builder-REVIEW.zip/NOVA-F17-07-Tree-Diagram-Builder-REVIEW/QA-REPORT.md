# F17-07 — QA evidence report

**Scope:** One F17-07 standalone premium review engine. Built on 13 October 2026 from the locked NOVA master, and actual embedded F0/F2 shared core inherited from the F17-06 canonical-style review build.

**Status:** REVIEW. Zero recorded failures in completed QA suites; physical touch and owner acceptance are outstanding. GitHub untouched.

## Evidence summary

- Core Chromium: **134 passed, 0 failed** — `tests/QA-RESULTS.json`, executable test `tests/stress_F17_07.py`.
- Normal motion + pointercancel: **12 passed, 0 failed** — `tests/QA-MOTION-CANCEL.json`, executable test `tests/motion_cancel_F17_07.py`.
- Screenshot inspection: **18** images in `screenshots/`, including 380px/1280px, all four modes, four presets and Watch step 5.

## Build guard and source evidence

1. Canonical core preserved and inlined in `F17-07-Tree-Diagram-Builder-PREMIUM-REVIEW.html`, lines 1–1795; no external source dependencies. Styling/embeds: original NOVA Chalk font, dark stage, helper dock and neon primitives. Local F17-07 CSS: lines 664–678.
2. Exact presets and their branch probabilities: line 1798 onward. Branch operations reduce rational fractions, multiply along paths and add separate favourable paths: lines 1805–1828. Full probability normalization and four presets validated in core QA.
3. Stage/tree layout using `NOVA.neonLine`, `NOVA.neonBox`, `NOVA.neonRing`, `NOVA.chalkText`, `NOVA.svg.root` and stacked chalk fractions: lines 1829–1893. Mobile endpoint probability cards were reworked specifically to avoid text clipping; see `F17-07-380-watch-step5.png`.
4. Original core SVG drag mechanism for pickup, snap targets, movement and red removal: lines 1865–1883. Tested **actual pointer motion**, including single-step fast movement and re-grabbing on both viewports. Invalid drops and Escape cancel were checked with no stranded markers.
5. Four modes, Watch animation and narration steps: lines 1894–1913. Scrub, rewind and normal-motion renders tested. Dedicated one-dock count and no-duplicate-mascot assertions in QA.
6. Explore lessons, exact probability editing, keyboard path roving, Enter and Delete: lines 1913–1932. No mutation of preset masters when sliders move.
7. Challenge four tasks: lines 1933–1943. Incorrect misconception-specific answers and correct responses were checked. The Y7 HH challenge diagram was aligned with its question, not the Explore lesson's 'exactly one head' event.
8. Developer event log remains collapsed in the pupil view; config declares value events with registered keys. All maths are in NOVA Chalk with proper stacked fractions.

## Acceptance limitations

- Browser automation does not replace physical touchscreen testing or an owner quality/stress review.
- Desktop Chromium and mobile 380px viewport emulation have been tested; no physical iPad/Android touch testing was performed.
- **Not GOLD-approved** until you review and explicitly approve.
