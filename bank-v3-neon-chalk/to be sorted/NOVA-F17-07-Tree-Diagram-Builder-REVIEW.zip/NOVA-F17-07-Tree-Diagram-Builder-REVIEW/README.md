# NOVA Maths V2 — F17-07 Tree Diagram Builder

**STATUS: BUILT FOR OWNER REVIEW; NOT GOLD-APPROVED.**

Open **F17-07-Tree-Diagram-Builder-PREMIUM-REVIEW.html** directly in Chrome or Edge. No server or internet connection is required; NOVA shared CSS/JS, chalk fonts and helper artwork are embedded in this single HTML file.

## Teaching and interaction

- **WATCH:** Six narrated/rewindable teaching steps; show sums of outgoing branches, multiply along paths, add across separate winning paths, validate complete model.
- **GUIDED:** Master NOVA four-mode guided teaching with worked branches and tutor prompts.
- **EXPLORE:** Choose one of four required lesson presets; drag an original NOVA marker into weighted tree endpoints; re-grab, move, remove, reset, or use arrow-key/Enter/Delete alternatives. Edit P(A), P(B) using sliders in Year 9 independent-events model.
- **CHALLENGE:** Four real probability tasks, correctly marked with context-specific feedback; answer is hidden until checked.

| Lesson preset | Event | Exact model probability |
|---|---|---|
| Y7-075 | Fair coins, exactly one head | 1/2 |
| Y8-071 | Two independent red spins, P(R)=2/5 | 4/25 |
| Y9-043 | Even on die, then Blue on fair 3-sector spinner | 1/6 |
| Y9-045 | Independent A then B, P(A)=7/10 and P(B)=2/5 | 7/25 |

**Challenge 1 is intentionally distinct from the Year 7 Explore event:** the question and its diagram both use H then H, probability 1/4.

## QA

- 134/134 Chromium core assertions passed at 380px and 1280px.
- 12/12 normal-motion and pointer-cancellation checks passed.
- 18 screenshots, including every mode and preset at both widths, plus a late teaching step.
- All mathematical endpoint probabilities sum to 1, also after permitted edits to the adjustable model.
- Tested real mouse movement, one-step fast re-grab, valid drop, invalid drop, red removal, Escape and pointercancel, keyboard navigation, wrong and correct challenges.

**Not yet tested:** physical touchscreen and owner visual acceptance. This is not GOLD-approved.

GitHub has not been modified.
