import asyncio,pathlib,json
from playwright.async_api import async_playwright
HTML=pathlib.Path('/mnt/data/F17-07-Tree-Diagram-Builder-PREMIUM-REVIEW.html').read_text()
record=[]
def check(name,cond,detail=None):
 record.append({'check':name,'passed':bool(cond),'detail':detail})
 if not cond: print('FAIL',name,detail,flush=True)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for width in (380,1280):
   page=await b.new_page(viewport={'width':width,'height':960},reduced_motion='no-preference');err=[];page.on('pageerror',lambda e:err.append(str(e)))
   await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',HTML)
   await page.wait_for_timeout(180)
   check(f'{width} normal-motion watch populated',await page.locator('.nova-stage svg.f177-plot').count()==1)
   btns=await page.locator('button[aria-label]').evaluate_all('(es)=>es.map(x=>x.getAttribute("aria-label"))')
   print(width,'buttons',btns[:30],flush=True)
   rng=page.locator('input[aria-label="Scrub through steps"]')
   await rng.fill('3');await page.wait_for_timeout(180)
   check(f'{width} normal-motion stage updates', 'STEP 4/6' in await page.locator('.nova-stage').inner_text())
   await page.locator('[role="tab"]',has_text='Explore').click()
   await page.evaluate('()=>{let s=document.querySelector("svg.f177-plot");scrollTo(0,s.getBoundingClientRect().top+scrollY-65)}');await page.wait_for_timeout(100)
   # Begin pointer capture then dispatch pointercancel; should return without altering the model.
   src=page.locator('[data-tree-token]');bb=await src.bounding_box()
   await page.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);await page.mouse.down();await page.mouse.move(bb['x']+bb['width']/2-55,bb['y']-45,steps=6)
   check(f'{width} active drag started before pointercancel',await page.evaluate('Boolean(NOVA.ui._drag)'))
   await page.evaluate('()=>{let d=NOVA.ui._drag;if(!d)return; let t=d.target||document.querySelector("[data-tree-token]");t.dispatchEvent(new PointerEvent("pointercancel",{bubbles:true,pointerId:d.pointerId||1}));}')
   await page.mouse.up();await page.wait_for_timeout(100)
   a=await page.evaluate('()=>NOVA_F17_07_CONFIG._explore.get()')
   check(f'{width} pointercancel does not create a ghost marker',a['marked']==[],a['marked'])
   # reset any drag state, then forced blur after pointer press should not select marker.
   await page.evaluate('()=>NOVA.ui.cancelDrag()')
   check(f'{width} drag clear leaves no live drag',not await page.evaluate('Boolean(NOVA.ui._drag)'))
   check(f'{width} no JS errors in normal motion or cancel',not err,err[:1])
   await page.close()
  await b.close()
 pathlib.Path('/mnt/data/f17_07_work/tests/QA-MOTION-CANCEL.json').write_text(json.dumps({'passed':sum(x['passed'] for x in record),'failed':sum(not x['passed'] for x in record),'checks':record},indent=2))
 print('TOTAL',sum(x['passed'] for x in record),'/',len(record))
asyncio.run(main())
