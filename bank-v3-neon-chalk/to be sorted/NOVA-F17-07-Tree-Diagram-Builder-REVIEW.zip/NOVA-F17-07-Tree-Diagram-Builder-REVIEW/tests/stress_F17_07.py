"""Browser QA for F17-07, uses actual Chromium pointer movement; no simulated keyboard-only drag pass."""
import asyncio, json, pathlib, traceback
from playwright.async_api import async_playwright
HTML=pathlib.Path('/mnt/data/F17-07-Tree-Diagram-Builder-PREMIUM-REVIEW.html').read_text()
WORK=pathlib.Path('/mnt/data/f17_07_work')
results=[]
def check(name, condition, detail=None):
    results.append({'check':name,'passed':bool(condition),'detail':detail})
    if not condition: print('FAIL',name,detail,flush=True)

async def bootstrap(browser,width,motion='reduce'):
    page=await browser.new_page(viewport={'width':width,'height':1050},reduced_motion=motion)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    await page.goto('about:blank');await page.evaluate('(s)=>{document.open();document.write(s);document.close()}',HTML)
    await page.wait_for_timeout(90)
    return page,errors

def pt(b):return (b['x']+b['width']/2,b['y']+b['height']/2)
async def drag(page,source,target,steps=12,post=90):
    a=await source.bounding_box();b=await target.bounding_box()
    if not a or not b:raise AssertionError('Missing drag source or target')
    await page.mouse.move(*pt(a));await page.mouse.down();await page.mouse.move(*pt(b),steps=steps);await page.mouse.up();await page.wait_for_timeout(post)
async def drag_xy(page,source,pos,steps=9):
    a=await source.bounding_box();await page.mouse.move(*pt(a));await page.mouse.down();await page.mouse.move(*pos,steps=steps);await page.mouse.up();await page.wait_for_timeout(90)
async def get(page):return await page.evaluate('()=>NOVA_F17_07_CONFIG._explore.get()')
async def scroll_stage(page):
    await page.evaluate('()=>{let e=document.querySelector("svg.f177-plot");scrollTo(0,e.getBoundingClientRect().top+scrollY-80)}');await page.wait_for_timeout(65)
async def point_in_svg(page,x,y):
    return await page.evaluate('([x,y])=>{let r=document.querySelector("svg.f177-plot").getBoundingClientRect(),v=document.querySelector("svg.f177-plot").viewBox.baseVal;return [r.x+r.width*x/v.width,r.y+r.height*y/v.height]}',[x,y])

async def mode_and_model(browser,width):
    page,errors=await bootstrap(browser,width)
    for mode in ('Watch','Guided','Explore','Challenge'):
        await page.locator('[role="tab"]',has_text=mode).click();await page.wait_for_timeout(60)
        check(f'{width} {mode} renders one SVG',await page.locator('svg.f177-plot').count()==1)
        check(f'{width} {mode} has one stage dock',await page.locator('.nova-stage .nv-dock').count()==1)
        check(f'{width} {mode} has no page error',not errors,errors[:2])
        await page.screenshot(path=str(WORK/'screenshots'/f'F17-07-{width}-{mode.lower()}.png'),full_page=True)
    await page.locator('[role="tab"]',has_text='Explore').click()
    wanted={'y7':(4,2,[1,2],['0-1','1-0']),'y8':(4,1,[4,25],['0-0']),'y9spaces':(6,1,[1,6],['0-1']),'y9ind':(4,1,[7,25],['0-0'])}
    for key,(total,favourable,fraction,winners) in wanted.items():
        await page.evaluate('(k)=>NOVA_F17_07_CONFIG._explore.setPreset(k)',key)
        a=await get(page)
        check(f'{width} {key} paths complete',a['total']==total and await page.locator('[data-path]').count()==total,{'actual':a['total'],'expected':total})
        check(f'{width} {key} favourable count',a['favourable']==favourable and a['winners']==winners,a['winners'])
        check(f'{width} {key} exact fraction',a['eventProbability']==fraction,a['eventProbability'])
        check(f'{width} {key} all endpoint probabilities sum to one',a['totalProbability']==[1,1],a['totalProbability'])
        await page.screenshot(path=str(WORK/'screenshots'/f'F17-07-{width}-{key}.png'),full_page=True)
    # Isolate the custom sliders from fixed lesson presets and verify dynamic fractions.
    sliders=page.locator('.f177-extra input[type="range"]')
    check(f'{width} independent editor has two real sliders',await sliders.count()==2)
    if await sliders.count()==2:
        await sliders.nth(0).fill('6');await sliders.nth(1).fill('3');a=await get(page)
        check(f'{width} changing P(A), P(B) recomputes path exactly',a['eventProbability']==[9,50],a)
        check(f'{width} adjustable tree stays normalized',a['totalProbability']==[1,1])
        await page.locator('[role="tab"]',has_text='Watch').click();await page.locator('[role="tab"]',has_text='Explore').click();await page.evaluate('()=>NOVA_F17_07_CONFIG._explore.setPreset("y9ind")');a=await get(page)
        check(f'{width} editable model does not mutate locked preset',a['eventProbability']==[7,25] and a['branchA']==[7,3] and a['branchB']==[2,3],a)
    # Stage must keep developer log collapsed and maintain one visible mascot.
    check(f'{width} developer log collapsed',await page.locator('details.nv-dev[open]').count()==0)
    check(f'{width} no second mascot outside stage',await page.locator('.nova-bob .face:visible,.nova-bob>img:visible').count()==0)
    await page.close()

async def interactions(browser,width):
    page,errors=await bootstrap(browser,width);await page.locator('[role="tab"]',has_text='Explore').click();await scroll_stage(page)
    a=await get(page);check(f'{width} starts with empty selection',a['marked']==[])
    # Genuine mouse movement onto SVG endpoints.
    await drag(page,page.locator('[data-tree-token]'),page.locator('[data-path="0-1"]'))
    a=await get(page);check(f'{width} genuine mouse snap',a['marked']==['0-1'] and a['markedProbability']==[1,4],a)
    await scroll_stage(page)
    await drag(page,page.locator('[data-placed="0-1"]'),page.locator('[data-path="1-0"]'),steps=1)
    a=await get(page);check(f'{width} fast re-grab & place',a['marked']==['1-0'],a)
    # Drop elsewhere on stage (no target); must spring back to prior safe state.
    await scroll_stage(page);xy=await point_in_svg(page,73,130)
    await drag_xy(page,page.locator('[data-placed="1-0"]'),xy)
    a=await get(page);check(f'{width} invalid drop retains safe selected path',a['marked']==['1-0'],a)
    # Escape should cancel an active pointer before release.
    await scroll_stage(page);bb=await page.locator('[data-placed="1-0"]').bounding_box()
    await page.mouse.move(*pt(bb));await page.mouse.down();await page.mouse.move(bb['x']-85,bb['y']-45,steps=5);await page.keyboard.press('Escape');await page.mouse.up();await page.wait_for_timeout(80)
    a=await get(page);check(f'{width} Escape cancellation retains model',a['marked']==['1-0'],a)
    # Red removal area has precise position in SVG viewBox, no fake keyboard-only removal.
    await scroll_stage(page);mobile=(width<=500);remove=await point_in_svg(page,237+135/2 if mobile else 555+175/2,794)
    await drag_xy(page,page.locator('[data-placed="1-0"]'),remove)
    a=await get(page);check(f'{width} mouse drop to red remove zone',a['marked']==[],a)
    # Keyboard equivalent and roving one-tab-stop grid navigation.
    await page.locator('[data-path="0-0"]').focus();before=await page.locator('[data-path][tabindex="0"]').count()
    await page.keyboard.press('ArrowRight');focus=await page.evaluate('document.activeElement?.getAttribute("data-path")')
    check(f'{width} keyboard arrow navigates branches',focus=='0-1',focus)
    await page.keyboard.press('Enter');a=await get(page)
    check(f'{width} keyboard Enter marks path',a['marked']==['0-1'] and before==1,a)
    await page.locator('[data-placed="0-1"]').focus();await page.keyboard.press('Delete');a=await get(page)
    check(f'{width} keyboard Delete removes path',a['marked']==[],a)
    # Rapid cancel by mode change leaves no floating selected marker.
    await scroll_stage(page);bb=await page.locator('[data-tree-token]').bounding_box()
    await page.mouse.move(*pt(bb));await page.mouse.down();await page.mouse.move(bb['x']-85,bb['y']-60,steps=3)
    await page.locator('[role="tab"]',has_text='Guided').click(force=True);await page.mouse.up();await page.locator('[role="tab"]',has_text='Explore').click();a=await get(page)
    check(f'{width} mode switch cancels active drag',a['marked']==[],a)
    check(f'{width} no JS errors in pointer stress',not errors,errors[:2]);await page.close()

async def challenge(browser,width):
    page,errors=await bootstrap(browser,width);await page.locator('[role="tab"]',has_text='Challenge').click()
    labels=['Probability of HH','Red then red','Even and blue','A and B'];answers=['0.25','0.16','1/6','0.28']
    for i,(label,value) in enumerate(zip(labels,answers)):
        check(f'{width} task {i+1} label present',await page.locator('input[aria-label="'+label+'"]').count()==1)
        text=await page.locator('svg.f177-plot').inner_text() if False else await page.locator('.nova-stage').inner_text()
        phrase=['Head, then head','Red, then red','Even, then Blue','A, then B'][i]
        check(f'{width} challenge {i+1} correct matching diagram',phrase in text,text[:110])
        check(f'{width} challenge {i+1} hides answer', 'EVENT CHANCE\n?' in text and ' = ?' in text)
        if i==0:
            await page.locator('input[aria-label="'+label+'"]').fill('0.5');await page.get_by_role('button',name='Check').click()
            panel=(await page.locator('.nova-panel').all_inner_texts())[-1]
            check(f'{width} wrong answer misconception-specific', 'multiply both branches' in panel,panel[-180:])
        await page.locator('input[aria-label="'+label+'"]').fill(value);await page.get_by_role('button',name='Check').click();await page.wait_for_timeout(95)
        panel=(await page.locator('.nova-panel').all_inner_texts())[-1]
        check(f'{width} challenge {i+1} correct accepted', 'Correct.' in panel,panel[-170:])
        if i<3:await page.wait_for_timeout(855)
    check(f'{width} no JS errors in Challenge',not errors,errors[:2])
    await page.close()

async def timeline(browser,width):
    page,errors=await bootstrap(browser,width)
    # Timeline progress, scrub, pause and step controls should operate with no exceptions.
    rng=page.locator('input[aria-label="Scrub through steps"]')
    check(f'{width} timeline scrub available',await rng.count()==1)
    if await rng.count():
        await rng.fill('5');await page.wait_for_timeout(80)
        check(f'{width} scrub to last teaching step', 'STEP 6/6' in await page.locator('.nova-stage').inner_text())
        await rng.fill('0');await page.wait_for_timeout(70)
        check(f'{width} scrub rewind to first', 'STEP 1/6' in await page.locator('.nova-stage').inner_text())
    check(f'{width} timeline no JS errors',not errors,errors[:2]);await page.close()

async def main():
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    for width in (380,1280):
      for fn in [mode_and_model,interactions,challenge,timeline]:
       try:await fn(browser,width)
       except Exception as e:check(f'{width} {fn.__name__} completed without exception',False,repr(e));print(traceback.format_exc()[-1200:],flush=True)
      print('FINISHED',width,'checks',len(results),flush=True)
    await browser.close()
  path=WORK/'tests'/'QA-RESULTS.json';path.write_text(json.dumps({'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results),'checks':results},indent=2))
  print('FINAL',sum(r['passed'] for r in results),'/',len(results),'failed',sum(not r['passed'] for r in results),flush=True)
if __name__=='__main__':asyncio.run(main())
