import asyncio,pathlib
from playwright.async_api import async_playwright
S=pathlib.Path('/mnt/data/F17-07-Tree-Diagram-Builder-PREMIUM-REVIEW.html').read_text()
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for w in (380,1280):
   q=await b.new_page(viewport={'width':w,'height':990},reduced_motion='reduce');await q.goto('about:blank');await q.evaluate('(s)=>{document.open();document.write(s);document.close()}',S);await q.locator('input[aria-label="Scrub through steps"]').fill('4');await q.wait_for_timeout(80);await q.screenshot(path=f'/mnt/data/f17_07_work/screenshots/F17-07-{w}-watch-step5.png',full_page=True);await q.close()
  await b.close()
asyncio.run(main())
