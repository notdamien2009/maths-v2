# NOVA F5-12 — Premium Review QA

Status: Review candidate, not owner-approved GOLD.

## Source / architecture
- Uses F0/F1 neon and NOVA Chalk on the v3.6.2 shared bank.
- The original bank and previous F5-11 core were not edited; shared JavaScript and CSS hashes match.
- Source lives in `build/F5-12.src.html` with `@@CSS@@` and `@@JS@@` substitution.
- The full bank `build.py` passes with its existing filter/primitive checks.
- Built F5-12 HTML is byte-for-byte reproducible from the included source and core.

## QA evidence
- 116/116 main browser checks passed at 380px and 1280px, plus 320px/768px in normal and reduced motion.
- 28/28 additional pointer cancellation, Escape, preset, navigation and stranded-object stress checks passed.
- Challenge correct/wrong answers, question progression and hidden answer state passed.
- All 100 cells exist and selected count exactly equals painted count.
- 100 individually focusable tab stops were replaced by one roving tabindex and arrow-key cell navigation.
- On-screen click/drag paint, erase and core svgDrag percentage handle tested.
- Percentage, decimal and stacked fraction readouts checked for 0, 1, 13, 25, 50, 62, 75, 100.
- No uncaught page JavaScript errors or horizontal page overflow in completed tests.

## Owner review gates
- Final NOVA Gold visual approval is outstanding.
- App lesson-shell integration and persistence are not claimed.
