# NOVA F5-13 Premium candidate — QA record

Built: October 10, 2026

## Status
- Integrated v3.6.2 bank build: PASS
- Standalone rebuild byte-for-byte: PASS
- Functional checks at 380 and 1280 px (both with reduced motion): **42/42 PASS**
- Stress checks at 320 and 768 px (normal and reduced motion): **48/48 PASS**
- Total: **90/90 PASS**
- No JavaScript page errors reported by the completed checks
- No horizontal page overflow at tested widths
- 4 modes tested; 3 Challenge questions submitted correctly
- Input drag-to-hopper, keyboard feed, invalid drop and Escape cancellation tested
- Fraction, decimal and percentage inputs; terminating and recurring decimal cases tested

## Mathematical examples
- 1/3 = 0.(3) = 33.(3)%
- 1/6 = 0.1(6) = 16.(6)%
- 2/5 = 0.4 = 40%
- 7/8 = 0.875 = 87.5%
- 12.5% = 1/8 = 0.125
- -3/8 = -0.375 = -37.5%

## Files and compatibility
- Canonical bank source: `bank-v3-neon-chalk/build/F5-13.src.html`
- Bank registry: `bank-v3-neon-chalk/build/build.py` now registers F5-13; this complete script requires the parent bank's other F0/F5 sources to run
- Independent standalone compiler: `build_f513.py` works on just this pack
- `bank-v3-neon-chalk/core/nova-core.js` and `.css` are unaltered copies of current source
- `tests/` includes functional and stress test files; they require the original full working `/mnt/data` layout if run unmodified. Repoint the test path for another environment
- Owner GOLD approval and live NOVA lesson-shell integration are outstanding

## Review notes
- Recurring decimal notation uses parentheses, e.g. `0.(3)` to mark the repeat period.
- Diagram notation uses NOVA Chalk traditional stacked fractions.
- Decimal long division uses exact integer remainders; no floating-point decimal approximation is used for the visible conversion.
- For especially long repeat cycles, visible text is shortened; the engine still retains exact rational state.
