# NOVA F5-13 — FDP Conversion Machine (Premium Review Candidate)

Open `bank-v3-neon-chalk/F5/F5-13-fdp-conversion-machine.html` in your browser, or use the standalone HTML linked separately.

This pack is an INCREMENTAL bank-v3 production component, not a replacement for the whole bank. Place its F5-13 source in your current bank-v3 `build/` folder and append the F5-13 registry entry from `build/build.py` when integrating. Keep the current shared core intact; do not overwrite it unnecessarily.

Alternatively run `python build_f513.py` at the package root to rebuild the F5-13 output from its template and the bundled exact shared-core snapshot.

Modes: Watch / Guided / Explore / Challenge. Explore supports input formats such as `1/3`, `0.(3)`, `12.5%`, `-3/8`. Drag or keyboard-feed the input card into the conversion hopper. The remainder track illustrates the exact repeating/terminating decimal behaviour.

Status: automated review checks passed; awaiting user visual GOLD approval and lesson shell integration.
