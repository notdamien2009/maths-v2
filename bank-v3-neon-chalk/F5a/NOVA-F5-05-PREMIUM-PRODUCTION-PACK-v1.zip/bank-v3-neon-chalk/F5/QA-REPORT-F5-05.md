# NOVA F5-05 · Premium Edition Rebuild — QA Report

**Status: technical review candidate — not owner-approved GOLD.**

## Source and architecture
- Built with original NOVA F0/F1 Neon Tube + Chalk design assets and the unchanged current v3.6.2 shared core.
- F5-05 uses its own source `build/F5-05.src.html`, with the core embedded only in generated HTML via the shared bank `build/build.py` placeholders.
- Core JS and CSS exactly match the source files supplied in the prior F5-04 Premium bank (SHA-256 for JS: 940ccb34d0bb19b2564cb0e6ed32b17f353cf725b0876c7cabcbd173a6223418).
- Traditional stacked NOVA Chalk fractions; no `fraction design TBD` placeholder.
- The original F5-01 to F5-04 and F0/F1 source are not modified. `build.py` adds one new F5 registration.

## Mathematical accuracy
- Exact whole length across both bars, shared x-origin/width, fixed shaded endpoint x = x0 + width × numerator/denominator.
- Denominator grows from d to d×k; numerator grows from n to n×k. Factor k=2,3,4. Fraction values verified including 0/d and d/d.
- Animation reveals each large original piece splitting into k smaller pieces in sequence without resizing the whole.
- The denominator is *number of equal pieces in the same whole*, not an arbitrary count.
- Challenge hides the resulting displayed numeric fraction; pupils must select the factor and enter the shaded-part count.

## Test outcomes
- Functional and mathematical tests: **64/64 PASS** at 380px and 1280px, covering Watch, Guided, Explore, Challenge, six teaching states, a real SVG grip drag, keyboard arrows/Home/End/focus, invalid drop, Escape, edge fractions, and three Challenge problems.
- Additional normal and reduced motion stress tests: **52/52 PASS** at 320/380/768/1280, covering actual animated split, reduction to final state, rapid redraw, no ghost tiles, no stranded drag element, overflow and page errors.
- Eight additional *real pointer* snapping actions at 320/768 under normal motion: **8/8 PASS**.
- Integrated `python build/build.py`: **PASS**, including shared glow-filter and unapproved-primitive checks.
- 380 and 1280 screenshots: **all four modes**. Additional Explore screenshots at 320 and 768.
- Browser console/page errors in completed checks: **0**.

## Notes and outstanding gates
- Integrated lesson-shell runtime, narration/audio playback on the live site, and full screen-reader user testing remain untested.
- Draggable factor is constrained to snap zones and supports keyboard equivalents. The visual subdivision is pedagogical, not physical cut-out drag pieces.
- Owner must review and approve visuals and motion before this is called GOLD or becomes the canonical bank build.
- The audit had requested a Node-based JS stress harness. The supplied verified browser stress suite is Python Playwright; no Node Playwright dependency is assumed.
