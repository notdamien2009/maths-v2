# F5-01 Premium Edition candidate — QA report

**State:** Functional + visual candidate for owner review. **NOT owner-approved GOLD yet.**

## Mathematical evidence
- Every row uses one whole of identical length; `1/d` means exactly one of `d` equal subdivisions.
- Selecting part `n` shades a contiguous `n/d` of the whole. Denominators 1–12 are supported.
- The compare rails share a starting position and identical unit scale. The green connector joins endpoints only when `a.n*b.d == b.n*a.d`.
- In Challenge, the equality proof is hidden until assessment. Answers are not shown on the stage.
- Default examples: `1/2 = 2/4`, `1/3 = 2/6`, `1/4 = 2/8`, non-match `1/2 != 2/5`.

## Visual and teaching
- Upgraded glass fraction strips and coloured selected parts follow current NOVA F0/F1/F2 Neon Tube + Chalk tokens.
- User-locked traditional stacked NOVA Chalk fractions (SVG and existing HTML maths renderer).
- Mobile (380): rows 1,2,3,4,6,8 with optional Show all; desktop 1280: all 12.
- Watch and Guided: six named mathematical teaching states with Sir Bob narration.
- Explore: partition selection, numeric controls, four mathematical presets, two live comparison rails.
- Challenge: 3 interactive equivalence tasks, 3/3 acceptance verified; Izaac visual reactions are wired for open, hint, wrong, and success.
- The two rail endpoints physically align on the page for equivalent fractions, so the match is geometric evidence rather than just a written answer.

## Browser / interaction / regression checks
- **42 / 42 passed** across 380 and 1280 browser checks (see `tests/f501-qa-results.json`).
- Covers Watch, Guided, Explore, Challenge captures; no horizontal overflow; math model; 12/6 rows; accepted SVG drag; rejected SVG drop springs back; active pieces re-grabbable; red removal tray; keyboard Delete; Escape cancel; keyboard row selection; challenge wrong/correct marking; 0 JavaScript exceptions.
- All four modes photographed at **both** 380 and 1280 under `shots/F5/`.
- Extra normal-motion page checks: 320 and 768 loaded all six Guided states and Explore with **no JS errors/overflow**.
- Reconstructed F2-03 with patched core: loads at 380 and 1280 with 13 draggable elements and 0 JS errors; original F2 files are not modified.
- `build/build.py` regenerates the self-contained HTML from placeholders and validates the bank SVG filter lock.

## Necessary core fix discovered by stress testing
The supplied bank's `NOVA.ui.svgDrag` may lose SVG pointer capture after reparenting a dragged `<g>` to the front of the SVG. Desktop valid-drop test initially failed while leaving `NOVA.ui._drag` active. The working-copy shared handler is patched to **listen to window pointermove/pointerup/pointercancel during an active drag** and unregister on finish. This is a two-hunk change to the supplied v3.6.2 JS; the original uploaded bank is unmodified. The corrected version passes 42/42 checks. Audit before merging the patch into any approved upstream core.

## Outstanding before GOLD
- Owner visual review/sign-off.
- Live lesson-shell integration and the complete bank build and drag-suite regression after merging.
- Follow-up technical review of the shared core pointer-capture fix before applying it globally.
- Continue F5-02/F5-03 migration only after F5-01 approved.
