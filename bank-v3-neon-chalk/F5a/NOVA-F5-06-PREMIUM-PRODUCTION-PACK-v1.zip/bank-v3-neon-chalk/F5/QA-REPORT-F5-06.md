# NOVA F5-06 · Premium Review QA

Status: **Review candidate, not owner-approved GOLD**.

## Foundation
- Built using the v3.6.2 shared NOVA CSS/JS from the preceding F5-05 premium run.
- Source `build/F5-06.src.html` uses `@@CSS@@` / `@@JS@@` and registers through `build/build.py`.
- `core/nova-core.js` and `core/nova-core.css` are unchanged from F5-05.
- Two traditional stacked NOVA Chalk fractions; not raw slash notation in the teaching scene.
- All SVG drawing uses NOVA shared primitives. Motion uses `NOVA.motion` and drag uses `NOVA.ui.svgDrag`.

## Mathematical correctness
- Shaded length remains n/d both before and after grouping: (n/g)/(d/g).
- Only g that divides both n and d is accepted; invalid group sizes preserve current state and explain why.
- Intermediate form 12/18 ÷2 = 6/9 correctly says more simplification is possible; 12/18 ÷6 = 2/3 identifies simplest form.
- Already simplest 5/7, zero (0/10) and a whole (8/8) tested.
- Three Challenge prompts require the HCF and both simplified counts; answers remain hidden.

## Automated browser checks
- `tests/qa_f506.py` at 380px and 1280px with reduced motion: **76/76 passed**, including real pointer drags, keyboard movements, invalid factor, Escape cancellation, 6 beats, 3 Challenge questions, zero and whole, and no page errors/overflow.
- `tests/stress_f506.py` at 320px and 768px under reduced and normal motion: **32/32 passed**, including changing factors and 3 maths cases per run; no page errors/overflow.
- Total automated checks: **108/108 passed**. These are scripted functional checks, not exhaustive formal verification.
- Eight snapshots: Watch/Guided/Explore/Challenge at 380 and 1280; additional Explore snapshots at 320 and 768 under reduced and normal motion.

## Limits
- Final live lesson-shell integration is untested.
- No owner GOLD approval.
- Follow-up accessibility screen-reader review advisable. Core mascot and interaction framework is unchanged.
