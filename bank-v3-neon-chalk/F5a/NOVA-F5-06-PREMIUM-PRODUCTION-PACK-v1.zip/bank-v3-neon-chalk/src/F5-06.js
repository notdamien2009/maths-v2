var NOVA_F5_06_CONFIG={startMode:'guided',preset:'sixEighths',events:['preset','numerator','denominator','factor','factorDrag','groupDrag','groupKeyboard','reset'],presets:{
 sixEighths:{label:'Six eighths',n:6,d:8,g:2},sixTwelfths:{label:'Six twelfths',n:6,d:12,g:6},twelveEighteenths:{label:'Twelve eighteenths',n:12,d:18,g:6},eighteenTwentyfourths:{label:'Eighteen twenty-fourths',n:18,d:24,g:6},nineTwelfths:{label:'Nine twelfths',n:9,d:12,g:3},alreadySimple:{label:'Five sevenths · simplest',n:5,d:7,g:1},zero:{label:'Zero tenths',n:0,d:10,g:10},whole:{label:'Eight eighths',n:8,d:8,g:8}}};
(function(){'use strict';
var N=NOVA,S=N.svg,E=S.el,M=N.motion,H=N.h,C=NOVA_F5_06_CONFIG,ID='F5-06',live=null;
function emit(key,val){if(C.events.indexOf(key)<0)throw Error('F5-06 undeclared value key '+key);N.events.emit('value',{engine:ID,key:key,value:val});}
function lab(p,x,y,v,role,size,anchor){return N.chalkText(p,x,y,String(v),{role:role||'support',size:size||20,anchor:anchor||'middle'});}
function rect(p,x,y,w,h,fill,attrs){return E('rect',Object.assign({x:x,y:y,width:w,height:h,fill:fill},attrs||{}),p);}
function fraction(p,x,y,n,d,role,z){z=z||27;var a=E('g',{'aria-label':n+' over '+d},p);lab(a,x,y-z*.35,n,role,z);N.neonLine(a,x-z*.65,y+1,x+z*.65,y+1,{role:role,width:2.5});lab(a,x,y+z*.9,d,role,z);return a;}
function gcd(a,b){a=Math.abs(a);b=Math.abs(b);while(b){var t=b;b=a%b;a=t;}return a||1;}
function divisorList(d){var a=[];for(var i=1;i<=d;i++)if(d%i===0)a.push(i);return a;}
function valid(n,d,g){return g>=1&&d%g===0&&n%g===0;}
function model(n,d,g){d=Math.max(2,Math.min(24,Math.round(d)));n=Math.max(0,Math.min(d,Math.round(n)));var candidates=divisorList(d);g=candidates.indexOf(g)>=0&&n%g===0?g:1;return {n:n,d:d,g:g,position:0};}
function starting(k){var t=C.presets[k]||C.presets.sixEighths;return model(t.n,t.d,t.g);}
function defs(s){var d=E('defs',{},s);function grad(id,stops){var g=E('linearGradient',{id:id,x1:'0%',y1:'0%',x2:'20%',y2:'100%'},d);stops.forEach(function(a){E('stop',{offset:a[0],'stop-color':a[1], 'stop-opacity':a[2]===undefined?1:a[2]},g);});}
 grad('sf-edge',[['0%','#d0eaf8'],['12%','#5b8eac'],['29%','#102740'],['84%','#37647f'],['100%','#d1eaf5']]);
 grad('sf-face',[['0%','#214963'],['42%','#102841'],['100%','#07172c']]);
 grad('sf-amber',[['0%','#ffedbd'],['30%',S.c('focus')],['100%','#a95e20']]);
 grad('sf-green',[['0%','#d7ffea'],['32%',S.c('result')],['100%','#0c5d50']]);
 grad('sf-blue',[['0%','#b5f4ff'],['40%',S.c('op')],['100%','#11527a']]);
}
function frame(s,x,y,w,h){rect(s,x-18,y-16,w+36,h+32,'url(#sf-edge)',{rx:18,stroke:'#b2ddf1','stroke-width':1.4});rect(s,x-11,y-9,w+22,h+18,'#061329',{rx:12,stroke:'#3e718f','stroke-width':2});rect(s,x-5,y-4,w+10,h+8,'url(#sf-face)',{rx:9,stroke:'#6395ae','stroke-width':1.3});}
function strip(s,x,y,w,h,count,shade,role,o){o=o||{};frame(s,x,y,w,h);var cellW=w/count,cells=[];for(var i=0;i<count;i++){
 var xp=x+i*cellW,on=i<shade,fill=on?(role==='result'?'url(#sf-green)':'url(#sf-amber)'):'#10283f';
 var cell=rect(s,xp+1.2,y+2,Math.max(.4,cellW-2.4),h-4,fill,{rx:Math.min(3,cellW*.12),stroke:on?S.c(role):'#4b6c85','stroke-width':1.0, 'data-part':i});cells.push(cell);
 if(on&&cellW>13)rect(s,xp+2.8,y+3,Math.max(.4,cellW-5.6),Math.min(7,h*.14),'#f4fffd',{rx:1,opacity:.19,'pointer-events':'none'});
 }
 return cells;
}
function groupBracket(s,a,b,y,role){var gap=b-a;if(gap<7)return;N.neonLine(s,a+2,y,b-2,y,{role:role,width:1.7});N.neonLine(s,a+2,y-7,a+2,y+4,{role:role,width:1.6});N.neonLine(s,b-2,y-7,b-2,y+4,{role:role,width:1.6});}
function rail(s,x,y,w,divs,g,interact,setFactor,dead){N.neonBox(s,x-16,y-39,w+32,112,{role:'op',r:15});lab(s,x+w/2,y-14,'Choose a group size','support',20);
 var stations=[],span=divs.length<=1?0:(w-42)/(divs.length-1);for(var i=0;i<divs.length;i++){
  var xx=x+21+i*span,z=divs[i];N.neonRing(s,xx,y+28,{role:z===g?'op':'support',r:z===g?13:8,pulse:false});lab(s,xx,y+62,'÷'+z,'op',20);stations.push(xx);
 }
 if(!interact)return;
 var idx=divs.indexOf(g),cx=stations[Math.max(0,idx)],drag=E('g',{'class':'sf-handle','data-factor-handle':'yes',tabindex:0,role:'slider','aria-label':'Common grouping factor','aria-valuemin':1,'aria-valuemax':divs[divs.length-1], 'aria-valuenow':g},s);
 N.neonBox(drag,cx-17,y+11,34,34,{role:'op',r:9});N.neonRing(drag,cx,y+28,{role:'focus',r:9,pulse:false});
 drag.addEventListener('keydown',function(e){var p=divs.indexOf(g),delta=e.key==='ArrowRight'||e.key==='ArrowUp'?1:e.key==='ArrowLeft'||e.key==='ArrowDown'?-1:0,idx2=delta?Math.max(0,Math.min(divs.length-1,p+delta)):e.key==='Home'?0:e.key==='End'?divs.length-1:null;
  if(idx2!==null){e.preventDefault();setFactor(divs[idx2],'keyboard');}});
 N.ui.svgDrag(s,drag,{box:{x:cx-17,y:y+11,w:34,h:34},canStart:function(){return !dead();},zones:function(){return stations.map(function(a,i){return {id:'factor:'+divs[i],kind:'drop',x:a-23,y:y,w:46,h:61};});},onDrop:function(id){setFactor(+id.split(':')[1],'drag');return true;}});
}
function render(stage,o,opt){opt=opt||{};if(live)live.dead=true;var sc={dead:false};live=sc;var mobile=window.innerWidth<=670,W=mobile?420:1100,V=mobile?1120:680;
 stage.innerHTML='';N.cap(stage,'F5-06 · '+(opt.name||'Simplify without changing the whole'),'PREMIUM');
 var svg=S.root(W,V,'Fraction simplification. One fixed whole has '+o.d+' equal parts, of which '+o.n+' are shaded. Grouping every '+o.g+' pieces shows an equivalent fraction while preserving the endpoint.');svg.classList.add('sf-svg');defs(svg);
 var x=mobile?46:128,w=mobile?328:585,y1=mobile?234:187,y2=mobile?508:383,h=mobile?65:70,remain=o.n/o.d,edge=x+w*remain,showLower=opt.phase!=='original',hidden=!!opt.hide;
 lab(svg,mobile?210:412,mobile?42:46,'Group equal parts · same whole','support',mobile?23:29);
 lab(svg,mobile?210:412,mobile?82:84,'Combine smaller units into larger units','given',mobile?18:21);
 lab(svg,x,y1-39,o.d+' equal original parts','focus',mobile?20:21,'start');
 strip(svg,x,y1,w,h,o.d,o.n,'focus');
 // Genuine equal-part lasso: one selected group is defined by g adjacent original parts.
 var g=o.g,groups=o.d/g,selected=Math.max(0,Math.min(groups-1,o.position||0)),unit=w/o.d,
 probeX=x+selected*g*unit,probeWidth=g*unit;
 if(showLower){
  var gy=y1+h+31;
  for(var i=0;i<groups;i++)groupBracket(svg,x+i*g*unit,x+(i+1)*g*unit,gy,i<o.n/g?'focus':'support');
  lab(svg,x,y2-40,groups+' larger equal parts','result',mobile?20:21,'start');
  var refined=strip(svg,x,y2,w,h,groups,o.n/g,'result');
  // Cover strips initially represent a group of small parts, then gather into one larger tile.
  if(opt.animate&&!N.reducedMotion())for(var k=0;k<groups;k++)(function(index){var c=rect(svg,x+index*g*unit+1,y2+2,g*unit-2,h-4,index<o.n/g?'url(#sf-amber)':'#142c47',{rx:3,stroke:'#8bb9d5','stroke-width':1.2,opacity:.95});
   M.delay(130+index*145,function(){if(sc.dead||!c.isConnected)return;M.tween(350,function(t){if(c.isConnected)c.style.opacity=String(1-t);},M.ease.inOut,function(){if(c.isConnected)c.remove();});M.flash(svg,x+(index+.5)*g*unit,y2+h/2,'result',Math.min(28,g*unit*.31));});})(k);
  N.neonLine(svg,edge,y1+h+15,edge,y2-16,{role:'op',width:2.9});N.neonRing(svg,edge,y1+h+15,{role:'focus',r:8,pulse:false});N.neonRing(svg,edge,y2-16,{role:'result',r:8,pulse:false});
 }
 if(opt.interactive&&!hidden){
  var group=E('g',{'data-group-probe':'yes',class:'sf-probe',tabindex:0,role:'slider','aria-label':'Move the grouping lasso across the original fraction strip','aria-valuemin':0,'aria-valuemax':Math.max(0,groups-1),'aria-valuenow':selected},svg);
  rect(group,probeX+2,y1-5,probeWidth-4,h+10,'#6ee7e5',{rx:6,'fill-opacity':.07,stroke:S.c('op'),'stroke-width':3,'stroke-dasharray':'7 5'});
  N.neonRing(group,probeX+probeWidth/2,y1-6,{role:'op',r:6,pulse:false});
  group.addEventListener('keydown',function(e){var next=e.key==='ArrowRight'||e.key==='ArrowDown'?selected+1:e.key==='ArrowLeft'||e.key==='ArrowUp'?selected-1:e.key==='Home'?0:e.key==='End'?groups-1:null;
   if(next!==null){e.preventDefault();opt.onGroup(Math.max(0,Math.min(groups-1,next)),'keyboard');}});
  N.ui.svgDrag(svg,group,{box:{x:probeX+2,y:y1-5,w:Math.max(12,probeWidth-4),h:h+10},canStart:function(){return !sc.dead;},zones:function(){var a=[];for(var j=0;j<groups;j++)a.push({id:'group:'+j,kind:'drop',x:x+j*g*unit,y:y1-28,w:g*unit,h:h+56});return a;},onDrop:function(id){opt.onGroup(+id.split(':')[1],'drag');return true;}});
 }
 var ruler=mobile?634:518;N.neonLine(svg,x,ruler,x+w,ruler,{role:'support',width:1.9});N.neonLine(svg,edge,ruler-10,edge,ruler+11,{role:'focus',width:2.6});lab(svg,x,ruler+25,'0','support',19);lab(svg,x+w,ruler+25,'1 whole','support',19);
 var resultY=mobile?704:203,resultX=mobile?43:767,resultW=mobile?334:294,resultH=mobile?166:216;
 N.neonBox(svg,resultX,resultY,resultW,resultH,{role:'result',r:16});
 lab(svg,resultX+resultW/2,resultY+31,hidden?'Work out the simplest form':'Same shaded length','result',mobile?22:21);
 var lineY=resultY+(mobile?93:104),lx=resultX+(mobile?94:79),rx=resultX+(mobile?242:224);
 fraction(svg,lx,lineY,o.n,o.d,'focus',mobile?25:27);lab(svg,resultX+resultW/2,lineY+4,'=','support',29);
 if(hidden){lab(svg,rx,lineY+6,'?','unknown',31);}else{fraction(svg,rx,lineY,o.n/o.g,o.d/o.g,'result',mobile?25:27);}
 var rest=gcd(o.n/o.g,o.d/o.g),bottomText=hidden?'Count groups of equal parts':rest===1?'Simplest form reached':'More grouping is possible';
 lab(svg,resultX+resultW/2,resultY+resultH-16,bottomText,rest===1?'result':'support',mobile?17:19);
 if(mobile){
  rail(svg,65,934,290,divisorList(o.d),o.g,!!opt.interactive,opt.onFactor||function(){},function(){return sc.dead;});
  lab(svg,210,1094,'The whole and shaded endpoint remain fixed','support',18);
 }else{
  rail(svg,776,483,277,divisorList(o.d),o.g,!!opt.interactive,opt.onFactor||function(){},function(){return sc.dead;});
  lab(svg,916,646,'Group every '+g+' tiny pieces together','support',18);
 }
 stage.appendChild(svg);N.scene.helperStrip(stage,opt.pose||'ruler',opt.caption||'Grouping does not change the shaded amount.');return sc;
}
var steps=[
 {name:'Observe six eighths',n:6,d:8,g:1,phase:'original',pose:'explain',caption:'The whole is divided into eight equal pieces',narration:'Six eighths means six of eight equally sized parts are shaded. The fixed glass whole is our unit. We will keep that whole and the shaded endpoint unchanged.',prompt:'How many eighths are shaded?'},
 {name:'Gather equal pairs',n:6,d:8,g:2,phase:'result',animate:true,pose:'count',caption:'Pairs combine into larger equal parts',narration:'Group each pair of eighths into one larger part. Six shaded eighths become three shaded pairs, and eight eighths become four total pairs.',prompt:'How many shaded groups of two can you find?'},
 {name:'Prove the equal length',n:6,d:8,g:2,phase:'result',pose:'ruler',caption:'Three quarters reaches the same endpoint',narration:'Six divided by two is three. Eight divided by two is four. The shaded length did not change. Six eighths is the same size as three quarters.',prompt:'Why does three quarters have the same value as six eighths?'},
 {name:'Simplify in stages',n:12,d:18,g:2,phase:'result',animate:true,pose:'compare',caption:'Six ninths can simplify again',narration:'Twelve eighteenths grouped into pairs becomes six ninths. This is equivalent, but six and nine share a factor of three, so it is not simplest yet.',prompt:'What other factor do six and nine share?'},
 {name:'Use the highest common factor',n:12,d:18,g:6,phase:'result',animate:true,pose:'show-three',caption:'Groups of six give two thirds',narration:'Six is the highest common factor of twelve and eighteen. Grouping six small parts at a time gives two shaded groups out of three equal groups. Two thirds is the simplest form.',prompt:'Why does dividing both by the highest common factor finish the simplification?'},
 {name:'Recognise simplest form',n:5,d:7,g:1,phase:'result',pose:'idea',caption:'No shared factor above one',narration:'Five sevenths is already in simplest form. The highest common factor of five and seven is one. There is no larger equal group to form.',prompt:'How can you tell whether a fraction can simplify?'}
];
function guided(i,stage){var a=steps[i],o=model(a.n,a.d,a.g);render(stage,o,{name:a.name,phase:a.phase,animate:!!a.animate,pose:a.pose,caption:a.caption});}
function explore(panel,stage){var o=starting(C.preset),preset=H('select',{class:'nova-input','aria-label':'Fraction to simplify'}),status=H('p',{class:'sf-msg',role:'status','aria-live':'polite'}),den=H('select',{class:'nova-input','aria-label':'Original denominator'});
 Object.keys(C.presets).forEach(function(k){preset.appendChild(H('option',{value:k,text:C.presets[k].label}));});[4,5,6,7,8,9,10,12,18,24].forEach(function(d){den.appendChild(H('option',{value:d,text:d+' parts'}));});preset.value=C.preset;den.value=o.d;
 function paint(anim,focus){render(stage,o,{name:'Explore · group equal parts',phase:'result',animate:!!anim,pose:gcd(o.n/o.g,o.d/o.g)===1?'celebrate':'ruler',caption:'Both the numerator and denominator must divide exactly',interactive:true,onFactor:choose,onGroup:move});if(focus){var k=stage.querySelector(focus);if(k)k.focus();}}
 function choose(g,via){if(!valid(o.n,o.d,g)){status.textContent='Not a common factor: '+g+' cannot divide both counts exactly. Try another group size.';emit(via==='drag'?'factorDrag':'factor',g);return;}o.g=g;o.position=0;emit(via==='drag'?'factorDrag':'factor',g);status.textContent='Group every '+g+' original pieces: '+(o.n/g)+' shaded groups out of '+(o.d/g)+'. '+(gcd(o.n/g,o.d/g)===1?'This is simplest form.':'More simplifying is possible.');paint(true,via==='keyboard'?'[data-factor-handle]':null);}
 function move(pos,via){o.position=pos;emit(via==='drag'?'groupDrag':'groupKeyboard',pos);status.textContent='Grouping probe moved to group '+(pos+1)+' of '+(o.d/o.g)+'. Each group contains '+o.g+' equal original parts.';paint(false,via==='keyboard'?'[data-group-probe]':null);}
 function setNum(n){o=model(n,o.d,o.g);emit('numerator',o.n);status.textContent='Shaded '+o.n+' of '+o.d+' original equal parts.';paint(false);}
 preset.onchange=function(){C.preset=preset.value;o=starting(C.preset);den.value=o.d;emit('preset',C.preset);status.textContent='Choose a common factor, then count the larger equal parts.';paint(false);};
 den.onchange=function(){o=model(Math.min(o.n,+den.value),+den.value,1);emit('denominator',o.d);paint(false);};
 var minus=H('button',{class:'nova-btn',text:'−', 'aria-label':'Shade one fewer original part',onclick:function(){setNum(Math.max(0,o.n-1));}}),plus=H('button',{class:'nova-btn',text:'+', 'aria-label':'Shade one more original part',onclick:function(){setNum(Math.min(o.d,o.n+1));}}),auto=H('button',{class:'nova-btn',text:'Use HCF',onclick:function(){choose(gcd(o.n,o.d),'button');}}),reset=H('button',{class:'nova-btn ghost',text:'Reset',onclick:function(){o=starting(C.preset);den.value=o.d;emit('reset',true);paint(false);}});
 panel.appendChild(H('div',{class:'sf-controls'},[H('label',{text:'Preset'}),preset,H('label',{text:'Total pieces'}),den]));
 panel.appendChild(H('div',{class:'sf-controls'},[H('label',{text:'Shade'}),minus,plus,auto,reset]));panel.appendChild(status);
 panel.appendChild(H('p',{class:'sf-msg',text:'Drag the factor selector to divide both counts. Move the dotted grouping lasso along the original strip, or use its arrow keys.'}));
 C._explore={get:function(){return {...o};},set:function(n,d,g){o=model(n,d,g);den.value=o.d;paint(false);},factor:choose,move:move};status.textContent='The shaded endpoint must remain in the same place.';paint(false);
}
function challenge(panel,api,stage){var tasks=[
 {n:6,d:8,g:2,a:3,b:4,q:'Simplify six eighths fully. Select the common factor, then enter the new numerator and denominator.',hint:'Six and eight have highest common factor two.'},
 {n:12,d:18,g:6,a:2,b:3,q:'Simplify twelve eighteenths in one step. Choose its highest common factor.',hint:'The highest number dividing both twelve and eighteen is six.'},
 {n:9,d:12,g:3,a:3,b:4,q:'Simplify nine twelfths fully. Show the resulting shaded groups.',hint:'Nine and twelve share a greatest common factor of three.'}
 ],ix=0,wrong=0,o=model(6,8,1),question=H('p',{class:'sf-msg'}),status=H('p',{class:'sf-msg',role:'status','aria-live':'polite'}),ansN=H('input',{class:'nova-input sf-input',type:'number',min:0,step:1,'aria-label':'Simplified numerator'}),ansD=H('input',{class:'nova-input sf-input',type:'number',min:1,step:1,'aria-label':'Simplified denominator'}),check=H('button',{class:'nova-btn primary',text:'Check answer'}),hint=H('button',{class:'nova-btn ghost',text:'Hint'}),img=N.helperImg('read-tablet','teen'),peer=H('img',{src:img.src,alt:img.alt}),peerText=H('span',{text:'Izaac is following your reasoning.'});
 function pose(k,text){var a=N.helperImg(k,'teen');peer.src=a.src;peer.alt=a.alt;peerText.textContent=text;}
 function repaint(){render(stage,o,{name:'Challenge · find the simplest form',phase:'result',hide:true,interactive:true,pose:'think',caption:'Prove the answer using equal groups',onFactor:function(g,via){if(!valid(o.n,o.d,g)){status.textContent='That factor cannot divide both counts.';return;}o.g=g;emit(via==='drag'?'factorDrag':'factor',g);repaint();}});}
 function load(){var t=tasks[ix];o=model(t.n,t.d,1);wrong=0;question.textContent='Challenge '+(ix+1)+' of 3 · '+t.q;status.textContent='Choose a grouping factor, then enter two numbers.';ansN.value='';ansD.value='';api.fb.textContent='';pose('read-tablet','Izaac is checking the grouping.');repaint();}
 check.onclick=function(){var t=tasks[ix],ok=o.g===t.g&&ansN.value.trim()!==''&&ansD.value.trim()!==''&&Number(ansN.value)===t.a&&Number(ansD.value)===t.b;api.check(ok,ok?'Correct. Both counts were divided by the highest common factor.':'Not yet. Divide BOTH original counts by the same highest common factor.',{task:ix});if(ok){pose(ix===2?'victory':'proud','The fraction is in simplest form.');status.textContent=ix===2?'All three challenges complete.':'Correct! Next challenge…';if(ix<2)M.delay(650,function(){ix++;load();});else check.disabled=true;}else{wrong++;pose(wrong>=2?'worried':'read-tablet','Check what divides both numbers exactly.');status.textContent='Your selected factor and both simplified numbers must agree.';}};
 hint.onclick=function(){var t=tasks[ix];api.hint(t.hint);pose('idea','Izaac has a clue.');status.textContent=t.hint;};
 panel.appendChild(question);panel.appendChild(H('div',{class:'sf-controls'},[H('label',{text:'Numerator'}),ansN,H('label',{text:'Denominator'}),ansD,check,hint]));panel.appendChild(status);panel.appendChild(H('div',{class:'sf-peer'},[peer,peerText]));
 C._challenge={task:function(){return ix;},set:function(g,n,d){o.g=g;ansN.value=n;ansD.value=d;repaint();},get:function(){return {...o,a:ansN.value,b:ansD.value};}};load();
}
var DEF={id:ID,title:'Fraction Simplifier · Magnetic Group Forge',config:C,steps:steps,render:guided,explore:explore,challenge:challenge,
 alt:'Two equal-length glass fraction strips, small original pieces in amber and larger regrouped pieces in green. A common-factor magnetic selector and movable group lasso prove exact regrouping without changing the shaded endpoint.',
 staticAlt:'Six eighths is three quarters by grouping in pairs. Twelve eighteenths simplifies to two thirds by grouping six original pieces together. Five sevenths cannot simplify because five and seven have greatest common factor one.',
 exploreIntro:'Pick any fraction, choose a number that divides both counts exactly, and move the group lasso to inspect the equally sized groups. The shaded amount never changes.'};
N.registry.add({id:ID,title:DEF.title,family:'F5',topics:['simplifying fractions','common factors','HCF'],deps:['F0-02','F0-03','F0-04','F0-05','F5-05']});
N.bankMount({id:ID,num:'F5·06',title:DEF.title,def:DEF,years:'KS3 Years 7–9',linked:['F5-01','F5-05','F5-07'],spec:{purpose:'Simplify by regathering the equal partition units, dividing numerator and denominator by one shared common factor, with unchanged physical shaded length.',params:'Whole has 2–24 original equal parts and 0–d shaded parts; factor must divide both counts exactly; group positions snap and can be changed by keyboard.',presets:'Six eighths, six twelfths, twelve eighteenths, eighteen twenty-fourths, nine twelfths, already-simplest five sevenths, zero, one whole.',steps:'Fix whole → form equal pairs → prove matching endpoint → unfinished intermediate form → HCF grouping → already simplest.',interactions:'Native svgDrag factor selector plus draggable group probe with Arrow/Home/End equivalents, presets, numerator stepper, HCF helper and 3 Challenge questions.',traps:'Dividing only numerator, using a non-common factor, confusing fewer pieces with less value, treating an intermediate equivalent fraction as simplest.',gcse:'HCF and lowest terms precede operations with fractions and rational algebra; use core v3.6.2 motion, SVG, helper art and stacked NOVA Chalk fractions.'}});
var log=document.getElementById('log');function logIt(e){log.textContent=new Date(e.time).toLocaleTimeString()+' '+e.type+' '+JSON.stringify(e.detail)+'\n'+log.textContent.slice(0,4000);}N.events.history().forEach(logIt);N.events.on('*',logIt);document.getElementById('clearlog').onclick=function(){log.textContent='';};
})();
