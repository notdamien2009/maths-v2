# NOVA F5-02 · Premium sector circle · QA report

Build: 10 October 2026 · user review candidate, NOT owner-signed GOLD.

## Baseline and architecture

- Built with F5-01-approved working core based on bank-v3 v3.6.2 (including the inherited SVG pointer-capture fix). The uploaded master bank has not been overwritten.
- Component source: `build/F5-02.src.html`, `@@CSS@@` and `@@JS@@` resolved by the shared `build/build.py`.
- F0 neon drawing and NOVA Chalk fraction notation (numerator above a horizontal fraction bar above denominator), as locked by owner.
- F5-01 and F5-02 build reproducibly from shared source. No `reference/` directory and no bespoke fonts shipped.
- No extra private NOVA core namespace: engine config `NOVA_F5_02_CONFIG` only. Uses shared `NOVA.ui.svgDrag`, `NOVA.motion`, `NOVA.scene.helperStrip`, `NOVA.bankMount` and existing neon SVG primitives.

## Automated checks

- 33/33 pass in the 1280px suite and 33/33 pass in the 380px suite (66/66 total; six normal-motion 320/768 smoke cases are repeated within the two runs).
- Additional latest-patch smoke: two tests at 380px/1280px verify immediate explanation of incompatible sector drags, no errors, and no page overflow.
- All four mode screenshots captured at 380px and 1280px, eight images in `shots/F5/`.
- Real pointer drags into the dial succeed; incompatible cuts spring back; full circles reject extra wedges. No dangling `.nv-drag-lift` elements or shared active drag state.
- Dragging a fitted sector back to tray removes it. Enter adds, Delete removes, Escape cancels.
- Each preset preserves exact rational equivalence under factor 3; factor 2 also supported.
- Three Challenge checks passed at both target widths; incorrect submissions were rejected and Izaac updated.
- Normal-motion smoke at 320px and 768px produced zero page errors or horizontal overflow.

## Teaching and visual notes

- Both discs represent the SAME whole. The right subdivides each equal sector, so its shaded part occupies exactly the same angle/area as the left.
- Cannot add a piece of a different denominator until the current circle is empty; this prevents false equal-part interpretations.
- Distinct chip/fraction labels remain ≥14 CSS pixels on 380px mobile where labels appear in the mathematical drawing.
- Wedges physically separate and rejoin with `NOVA.motion`; reduced-motion mode resolves to the complete end state.

## Remaining approval gates

- Human visual acceptance of premium styling and UX.
- Integration into the live NOVA lesson v21 shell and lesson-specific event mappings.
- Bank core patch needs review before merging into the canonical user repository. No source upstream was changed.

## Test evidence

- `tests/run_f502_qa.py`
- `tests/f502-qa-results-380.json`, `tests/f502-qa-results-1280.json`
- `tests/qa-380.log`, `tests/qa-1280.log`
