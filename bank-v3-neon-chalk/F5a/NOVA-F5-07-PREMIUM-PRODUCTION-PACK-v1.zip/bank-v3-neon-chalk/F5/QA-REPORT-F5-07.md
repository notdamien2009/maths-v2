# NOVA F5-07 · Premium Review QA

Status: **Interactive review candidate, not owner-approved GOLD.**

## Core and drawing
- Uses the latest shared v3.6.2 NOVA core inherited unchanged from the F5-06 premium bank. Sources live at `build/F5-07.src.html` and are compiled by the existing registered `build/build.py`.
- Uses native `NOVA.neonBox`, `NOVA.neonLine`, `NOVA.neonRing`, `NOVA.chalkText`, `NOVA.ui.svgDrag`, `NOVA.motion.tween`, and helper art. Proper stacked NOVA Chalk fractions are used in all teaching diagrams.
- Source units and result whole are aligned to the same width; common denominator is the LCM. A second result whole is drawn if the sum exceeds one.

## Mathematical teaching checks
- Addition 1/2 + 1/3 = 3/6 + 2/6 = 5/6.
- Addition 3/4 + 2/3 = 9/12 + 8/12 = 17/12 = 1 and 5/12 (second result whole).
- Subtraction 3/4 − 1/2 = 3/4 − 2/4 = 1/4 and 5/6 − 1/3 = 1/2.
- Additional cases: 1/4 + 2/4, 2/5 + 1/10, 0/3 + 2/3, 1/2 + 1/2.
- No silently changed operands: unsupported LCM >24 or subtraction below zero is rejected, preserving prior valid inputs.
- Challenge hides the numerical answer but retains the physical pieces a pupil must manipulate.

## Interaction and automated testing
- `tests/qa_f507.py` **82/82 passed** at 380 and 1280 with reduced motion after the final changes. Coverage: 4 modes per width; 6 teaching steps; real drag of first/second operand pieces to result; real removal to tray; keyboard pickup; subtraction; improper sum; eight arithmetic examples; three Challenge questions; blank-answer rejection; no page errors or horizontal overflow.
- `tests/stress_f507.py` **80/80 passed before the final presentation refinements** at 320, 380, 768 and 1280, in normal and reduced motion. Coverage: invalid drop rebound; Escape; no stranded objects after completed transitions; keyboard moves and focus retention; unsupported LCM input rejection; no console errors or overflow. A subsequent full rerun did not finish (browser runner timeout) and is not counted as a post-change pass.
- Targeted post-change Challenge subtraction retest passed at 380 and 1280: initial result strip contains three movable quarter-pieces, the numeric answer remains hidden, and no browser errors occurred.
- Supplied screenshots: Watch, Guided, Explore, Challenge at 380 and 1280, plus improper result screenshots and responsive stress previews.

## Known limitations / approvals
- No owner GOLD approval yet; live NOVA lesson-shell embedding untested.
- Current Explore models avoid negative subtraction and denominators requiring >24 cells. An unsupported input produces an explanation; it is never silently changed.
- Full post-change normal-motion stress rerun was interrupted by runner timeout; earlier completed stress run passed. Re-run it before strict release sign-off if the owner requires a final identical-version full stress report.
