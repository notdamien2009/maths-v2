# F5-04 Premium Rebuild — QA Report

**Status:** Review candidate; not owner-approved GOLD.
**Date:** 2026-10-10
**Core:** supplied NOVA v3.6.2 with previously carried-forward drag pointer-capture fix; no new styling system.
**Source:** `build/F5-04.src.html` with shared core placeholders, built by `build/build_f504.py`.
**Original F1-01 unchanged:** True; sha256 `13aaf069881e63f93a7b39eec9c6411575aa296f1a5985d03d3e6344327f0818`.

## Test results
- Final functional browser suite: **48 / 48 PASS**, widths 380 and 1280, reduced-motion. Tested all four modes, six Guided steps, 3/4=6/8 example, keyboard + Home, real pointer drag snap, Escape, three Challenge questions, wrong submission, no overflow, no uncaught JS errors.
- Full normal-motion stress suite: **56 / 56 PASS**, widths 320, 380, 768, 1280, BEFORE final text-label spacing-only adjustment. Six signed/proper/improper examples per width, six consecutive drag placements per width, no stranded objects.
- Following spacing-only change: **14 / 14 PASS** in separate final 1280px normal-motion stress, plus **48 / 48 PASS** final 380/1280 functional suite.
- Combined long full stress rerun timed out during its final 1280px section. Do not count that incomplete run as a pass. The shorter final desktop run verified the remaining desktop cases.
- Integrated `build.py` with F0 and F5-01 through F5-04: PASS, including glow-filter locks and SVG primitive validation.
- Isolated `build_f504.py`: PASS.
- Owner fraction notation: stacked Chalk numerator/bar/denominator in stage.

## Engineering specifics
- Both scales call `NOVA.numberLine`, with `major:1`, `minor:1/d` and `minor:1/(d*factor)` respectively. No component tick drawing loops.
- All point positions use the exact rational coordinate `n/d` and identical line bounds on both tracks.
- The draggable ring uses `NOVA.ui.svgDrag` and defined snap zones; no unsanctioned drag implementation.
- Intentional fraction hop arcs use core `NOVA.svg.hop`, and refinement uses `NOVA.motion.tween`.
- F5-04 is an F1-01 **preset adapter mapped by manifest**, not an in-place modification to F1-01. The original F1-01 HTML has an obsolete TBD preset and would need a separate owner-authorised integration patch to expose the new experience *inside* that existing page. The new F5-04 standalone engine works now.
- No lesson-shell integration or owner GOLD visual sign-off has been performed.

## Caveats
- Shared v3.6.2 core in the pack includes an earlier narrow drag pointer-capture fix carried over from F5-01; merge it deliberately against the live bank rather than blindly overwriting a newer core.
- Mobile screenshot checks cover 320, 380, 768; full challenge paths are covered at 380 and 1280.
