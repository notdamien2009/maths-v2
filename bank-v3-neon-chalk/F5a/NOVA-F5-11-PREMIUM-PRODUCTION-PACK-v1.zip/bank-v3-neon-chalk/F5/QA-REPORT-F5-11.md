# NOVA F5-11 — Premium Rebuild QA

Status: Premium review candidate; not owner-approved GOLD.

## Functionality
- Exact equal-sharing counter model. `a` counters are distributed across `d` equal groups.
- Each group shows `floor(a/d)` whole counters plus `a % d / d` of a counter where needed.
- Selected result is `selected_groups × a / d`, exact rational arithmetic.
- Watch, Guided, Explore, Challenge implemented; six named teaching steps.
- F0 Neon Tube + NOVA Chalk stacked fractions retained; same core as F5-10.
- Native `NOVA.ui.svgDrag` valid group selection and remove zones, keyboard equivalents, Escape and invalid-drop return.
- `NOVA.motion.tween` animates actual counters from source coordinates into the equal-group trays in Guided step 3 (not just opacity).
- Extra tall mobile scene adjusts existing userSpaceOnUse glow filter height on the local SVG so the answer/return/proof section is not clipped. No shared-core files changed.

## Automated checks — FINAL source
- `tests/qa_f511.py`: 74/74 passed at 380 px and 1280 px with reduced-motion testing, 4 modes, 6 guided stages, exact counter distribution including 48 units, 3 Challenge questions, keyboard+real SVG drag and return, invalid drop, no JS errors/overflow.
- `tests/stress_f511.py`: 44/44 passed at 320 px and 768 px under normal and reduced motion, including zero stranded drag objects, Escape cancellation, 8 group view and exact fractional remainders.
- Targeted normal-motion Guided distribution replay at 380 px: 0 JavaScript page errors, 24 distributed group counter elements.
- Integrated build script generates F0 and F5 source including F5-11 with filter and registered toolkit checks.
- Core nova-core.js and nova-core.css match F5-10 reference byte-for-byte.

## Important scope
- Owner visual approval is still required.
- No live NOVA lesson-shell integration has been attempted.
- Tests demonstrate use of the existing shared drag API, not upstream modification of the original bank.
- Fraction notation follows the owner-locked stacked NOVA Chalk design, superseding the older placeholder requirement.
