# NOVA F5-14 — Percentage of an Amount — Premium Edition review candidate

- Run: single component F5-14. This is not yet owner-approved GOLD.
- Source: `bank-v3-neon-chalk/build/F5-14.src.html` with `@@CSS@@/@@JS@@` placeholders.
- Built page: `bank-v3-neon-chalk/F5/F5-14-percentage-of-an-amount.html`.
- Rebuild: `python bank-v3-neon-chalk/build/build.py` (from any working directory).
- Current core: `bank-v3-neon-chalk/core/nova-core.js` and `.css` (unmodified from F5-13).
- Tests: `bank-v3-neon-chalk/tests/qa_f514.py` and `guided_f514.py`; requires Playwright and Chromium.
- Screenshots: `bank-v3-neon-chalk/shots/F5` across desktop, mobile and all four modes.

## Features
Fixed 100% reference tape; moving green selection; 0–200% with second matching whole for above 100; draggable and keyboard-operable percentage slider; animated fill; amount-pill tracking and exact arithmetic to 0.005 unit; presets; six guided stages; Bob narration; Izaac Challenge peer; three questions; no answer reveal in Challenge.

## Constraints
Integer whole amount 0–1000, percentage 0–200 in 0.5% steps. The visual continuously preserves the original 100% scale. This is a review build, not lesson-shell integration.
