# F5-14 QA report

**Automated functional / stress / mathematical / responsive checks:** 248/248 passed.

**Guided step and browser-error checks:** 14/14 passed.

**Combined:** 262/262 passed.

Widths: 320, 380, 768, 1280 CSS px. Motion: reduce at desktop/mobile and both modes at 320,768. All four modes rendered at 380 and 1280; separate snapshots captured for Watch, Guided, Explore and Challenge. Real pointer drag tested at 380 and 1280. Key steps, Home/End and all three Challenge tasks verified; Challenge answer remained hidden. Math cases include 0%, 0.5%, 12.5%, 25%, 35%, 37.5%, 150% and 200%, including 0 amount.

Original core hashes copied from F5-13 (not edited):
- CSS SHA-256: `eaf043ca9db09bee17c0aa04a1ba3e17ecbde330a3c55acc1b914b48b01c4cc4`
- JS SHA-256: `940ccb34d0bb19b2564cb0e6ed32b17f353cf725b0876c7cabcbd173a6223418`

Limitations: Visual GOLD approval by owner and live NOVA lesson shell integration remain outstanding. Stress coverage tests one end-to-end pointer drop at each primary width, not an exhaustive device-matrix or physical touch-device certification.
